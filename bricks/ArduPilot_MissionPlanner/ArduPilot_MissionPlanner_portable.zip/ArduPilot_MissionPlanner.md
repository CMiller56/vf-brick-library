---
kb_id: ardupilot-mission-planner-gcs
title: ArduPilot Mission Planner — GCS
author: ArduPilot Dev Team
created_date: 2026-07-18
classification: Internal
confidence_level: High
domain_tags: ["ardupilot", "mission-planner", "gcs", "calibration", "logs"]
entity_mentions: ["System Assembly", "System Overview"]
document_type: Technical Reference
primary_subject: Mission Planner ground station: install, connect, calibrate, flight data, planning, logs
intended_audience: Plane operators, maintainers, field teams
sources: [{"filename": "common-accelerometer-calibration.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-accelerometer-calibration.md", "page_count": 1}, {"filename": "common-apm-navigation-extended-kalman-filter-overview.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-apm-navigation-extended-kalman-filter-overview.md", "page_count": 1}, {"filename": "common-canbus-setup-advanced.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-canbus-setup-advanced.md", "page_count": 1}, {"filename": "common-compass-calibration-in-mission-planner.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-compass-calibration-in-mission-planner.md", "page_count": 1}, {"filename": "common-connect-mission-planner-autopilot.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-connect-mission-planner-autopilot.md", "page_count": 1}, {"filename": "common-diagnosing-problems-using-logs.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-diagnosing-problems-using-logs.md", "page_count": 1}, {"filename": "common-downloading-and-analyzing-data-logs-in-mission-planner.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-downloading-and-analyzing-data-logs-in-mission-planner.md", "page_count": 1}, {"filename": "common-loading-firmware-onto-pixhawk.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-loading-firmware-onto-pixhawk.md", "page_count": 1}, {"filename": "common-logs.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-logs.md", "page_count": 1}, {"filename": "common-mavlink-mission-command-messages-mav_cmd.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-mavlink-mission-command-messages-mav_cmd.md", "page_count": 1}, {"filename": "common-measuring-vibration.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-measuring-vibration.md", "page_count": 1}, {"filename": "common-power-module-configuration-in-mission-planner.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-power-module-configuration-in-mission-planner.md", "page_count": 1}, {"filename": "common-prearm-safety-checks.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-prearm-safety-checks.md", "page_count": 1}, {"filename": "common-radio-control-calibration.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-radio-control-calibration.md", "page_count": 1}, {"filename": "common-telemetry-landingpage.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-telemetry-landingpage.md", "page_count": 1}, {"filename": "common-uavcan-setup-advanced.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-uavcan-setup-advanced.md", "page_count": 1}, {"filename": "common-vibration-damping.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/common-vibration-damping.md", "page_count": 1}, {"filename": "mission-planner-flight-data.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/mission-planner-flight-data.md", "page_count": 1}, {"filename": "mission-planner-flight-plan.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/mission-planner-flight-plan.md", "page_count": 1}, {"filename": "mission-planner-initial-setup.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/mission-planner-initial-setup.md", "page_count": 1}, {"filename": "mission-planner-installation.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/mission-planner-installation.md", "page_count": 1}, {"filename": "mission-planner-overview.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/mission-planner-overview.md", "page_count": 1}, {"filename": "mission-planner-simulation.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/mission-planner-simulation.md", "page_count": 1}, {"filename": "mission-planner-telemetry-logs.md", "path": "docs/corpus/ardupilot_gcs_mission_planner/structured_md/mission-planner-telemetry-logs.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-07-18T17:22:27.608481", "page_count": 24, "extraction_methods": {"txt": 24}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "confidence_level", "created_date", "entity_mentions", "ingest_provenance", "kb_id", "sources"]
brick_role: gcs_mission_planner
out_of_scope: ["flight mode and failsafe doctrine (ArduPilot_Plane)", "full parameter dictionary (ArduPilot_Plane_Params)", "MAVLink field definitions (ArduPilot_MAVLink)", "live vehicle control / onboard code", "sample .bin/.tlog flight analysis (needs FC logs \u2014 separate log brick)"]
usage_notes: GCS / Mission Planner operator workflows. Docs-only. Sample DataFlash/tlog files not included until FC card read is available.
routing_policy: For how the vehicle behaves in a mode → ArduPilot_Plane. For param numbers → ArduPilot_Plane_Params. For MAVLink message fields → ArduPilot_MAVLink. For this brick: install, connect, calibrate UI, flight plan UI, download logs.
adjacent_bricks: [{"brick_id": "ArduPilot_Plane", "role": "ops_doctrine", "when_to_use": ["modes", "failsafes", "TECS doctrine"], "status": "built"}, {"brick_id": "ArduPilot_Plane_Params", "role": "params_reference", "when_to_use": ["parameter definitions"], "status": "built"}, {"brick_id": "ArduPilot_MAVLink", "role": "mavlink_protocol", "when_to_use": ["message and MAV_CMD definitions"], "status": "built"}]
kb_name: ArduPilot_MissionPlanner
created: 2026-07-18T17:22:27.609856
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 191
template: technical_reference
domain: general
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-18T17:22:36.210677
  chunk_count: 191
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: common-accelerometer-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 340
content_hash: d4b3fd99a2b305b1
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: Common Accelerometer Calibration
document_type: technical_reference

# Common Accelerometer Calibration

Accelerometer Calibration &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 
Install Ground Station Software 

Autopilot System Assembly 

Loading Firmware to boards with existing ArduPilot firmware 

Loading Firmware to boards without existing ArduPilot firmware 

Connect Mission Planner to AutoPilot 

Configuration 
Basic System Overview 

Choosing Servo Output Functions 

RC Input Throw and Trim 

Radio Control Calibration 

Accelerometer Calibration 
Calibration steps 

Simple Calibration 

Video demonstration (Copter) 

Compass Calibration 

Flight Modes 

RC Transmitter Mode Setup 

ESC Calibration 

Automatic Trim 

Failsafe Function 

Airspeed Parameters Setup 

Basic FPV Plane 

Airframe Specific Setup Guides 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Setup for Plane 

Plane Configuration 

Accelerometer Calibration

Edit on GitHub 

# Accelerometer Calibration 

This article shows how to perform basic accelerometer calibration (using
Mission Planner ). The accelerometers in the autopilot must be calibrated to correct for their bias offsets in all three axes, as well as any off-axis variations. Attention

Accelerometer calibration is mandatory in ArduPilot. Important

Accelerometer calibration cannot be performed while the vehicle is armed.

--- chunk_id: chunk-0001
source_document: common-accelerometer-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: 07f99df14c838f75
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Calibration steps
document_type: technical_reference

## Calibration steps 

Warning

If the board is mounted in a non-standard orientation (i.e. arrow is not pointing forward) then please ensure the AHRS_ORIENTATION is properly set before doing the accelerometer calibration. Tip

For very large vehicles, this may be done on the bench, after the orientation is set for how it will be mounted in the vehicle and the calibration orientations are done as fit in the vehicle. Then be sure to use the Calibrate Level step in the following instructions once mounted. Under Setup | Mandatory Hardware , select Accel Calibration from the left-side menu. Mission Planner: Calibrate Acceleration 

Click Calibrate Accel to start the full 3-axis calibration. Mission Planner will prompt you to place the vehicle on each axis during the calibration. Press any key to indicate that the autopilot is in position and then proceed to the next orientation. The calibration positions are: level, right side, left side, nose down, nose up, and on its back. Accelerometer Calibration Positions (Copter) 

The vehicle must be kept still immediately after pressing the key for each step. This is more important than getting the angle exactly right, ie. left being 90deg to horizontal, etc. Except for the first “LEVEL”, the positions can be within 20 degrees of being exact. Being still in each position as you press the key is much more important. . Do not hold the vehicle when doing this step, find some way to pose the vehicle (e.g. lie on the ground or put it in a jig). You should calibrate the board mounted in the vehicle if possible. However, you may need to calibrate the board before it is mounted if the size/shape of the vehicle makes this difficult. The level position is the most important to get right as this will be the attitude that your controller considers level while flying. You can recalibrate this Level position using Mission Planner after you have installed the autopilot and are ready to fly. Place the vehicle in its level flying attitude and use the Calibrate Level button. Note

this Calibrate Level operation can only correct up to a 10 degree difference between the initial calibration and the final position in the vehicle, and only corrects pitch and roll differences, not yaw. Tip

For planes, the “level” angle for pitch is important for steady altitude flight.

--- chunk_id: chunk-0002
source_document: common-accelerometer-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 317
content_hash: 247c768b1e3a22d9
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: Calibration steps
document_type: technical_reference

Note

this Calibrate Level operation can only correct up to a 10 degree difference between the initial calibration and the final position in the vehicle, and only corrects pitch and roll differences, not yaw. Tip

For planes, the “level” angle for pitch is important for steady altitude flight. See Tuning Cruise Configuration for more details. The STAB_PITCH_DOWN parameter will add “nose-down” trim when the throttle stick is lowered in pilot throttle controlled and stabilized modes, such as FBWA, to prevent the autopilot from holding the nose up as the plane slows down and potentially causing a stall. This can be tested, at altitude, in FBWA mode by moving the throttle to idle and checking that there is sufficient airspeed in a turn to avoid stalling. Be prepared to recover from a stall! Increase the value of STAB_PITCH_DOWN , if necessary. Tip

For small planes or gliders, STAB_PITCH_DOWN often needs to be set more than the default value of 2 degrees. Proceed through the required positions, using the Click when Done button once each position is reached and held still. When you have completed the calibration process, Mission Planner will display “Calibration Successful!” as shown below. Mission Planner: Calibration Successful 

Note

If your autopilot has a built-in IMU heater, then it is recommended that the IMU Temperature Calibration also be done. Some autopilots have this calibration done at the factory in which case, this calibration need not be done.

--- chunk_id: chunk-0003
source_document: common-accelerometer-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 213
content_hash: 0c60f870524290a1
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: Simple Calibration
document_type: technical_reference

## Simple Calibration 

Sometimes, for very large vehicles, it’s not easy to do the full 3-axis calibration. In this case, the Simple Accel Cal can be done with the vehicle held still and in a level attitude. This only calibrates the main offsets of the accelerometers, not the minor off-axis variations, so it’s not ideal in terms of optimal performance, but is sometimes an acceptable compromise. Note

This is NOT the same as the Calibrate Level function. To use that function, either a full 3-axis or simple calibration must be done first! ### Video demonstration (Copter) 
Video demonstration of accelerometer calibration. This is for an older
version of Copter/Mission Planner, but is useful as an example of how
you might hold a Copter. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0004
source_document: common-apm-navigation-extended-kalman-filter-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: a0bb0c9170364771
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: Common Apm Navigation Extended Kalman Filter Overview
document_type: technical_reference

# Common Apm Navigation Extended Kalman Filter Overview

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 
Analog Pins 

Advanced Failsafe 

Autopilot Output Mapping 

Auxiliary Functions 

Battery Voltage Compensation 

Bootloader Update 

BLHeli ESCs 

CAN Bus Setup 

Compass Setup (Advanced) 

Compass-less Operation 

Crash Detection 

Damaged Motor/Prop RPM Checks 

DisplayPort 

DroneCAN Setup 

EKF (Extended Kalman Filter) 
Should the EKF2 or EKF3 be used? Choosing the EKF and number of cores 

Affinity and Lane Switching 

GPS / Non-GPS Transitions 

Commonly modified parameters 

EKF3 Fallback to DCM 

EKF Affinity &amp; Lane Switching 

EKF Sources and Selection 

Ethernet/Network Setup 

Network Capture 

Flight Time Recorder 

Flight Options 

Fly-By-Wire Low Altitude Limit 

FPort Setup 

GeoFencing Failsafe 

GPIOs 

GPS for Yaw (aka Moving Baseline) 

GPS for Altitude 

GPS/Non-GPS Transitions 

Ground Control Station Only Operation 

IMU Temperature Calibration 

Independent Watchdog 

In-Flight FTT and filter control 

Limiting Maximum Power Draw 

Limit Cycle Prevention 

LUA Scripting 

Magnetic Interference 

Magnetometer GeoPhys Array 

MAVLink 

MAVLink2 Packet Signing (Security) 

Moving Vehicle Initialization 

Multiple Radio Control Receivers 

Non-GPS Navigation 

Notification Devices (LEDs,Buzzer,etc.) 

Notch Filter Configuration 

Object Avoidance 

Optical Flow Sensor 

On Screen Displays (OSD) 

OSD Parameter Editor 

Parameter List (Full) 

Parameter Lockdown 

Parameter Reset 

RC Input Channel Mapping (RCMAP) 

RC Options 

Received Signal Strength Indication (RSSI) 

Redundant Telemetry 

Reverse Thrust Setup 

RunCam Camera Configuration and Control 

Safety Switch 

Sensor Position Offset Compensation 

Sensor Testing 

Serial Forwarding to DroneCAN 

Serial Port to Port Passthrough 

Serial Port Configuration 

Ship(Moving Vehicle) Takeoff/Landing 

Telemetry Port Setup 

Terrain Following 

Transmitter Based Tuning 

Video Stabilization (Gyroflow) 

Video Transmitter Control 

UBlox GPS Configuration 

Vibration Damping 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Advanced Configuration 

Extended Kalman Filter (EKF)

Edit on GitHub 

# Extended Kalman Filter (EKF) 

An Extended Kalman Filter (EKF) algorithm is used to
estimate vehicle position, velocity and angular orientation based on
rate gyroscopes, accelerometer, compass, GPS, airspeed and barometric
pressure measurements.

--- chunk_id: chunk-0005
source_document: common-apm-navigation-extended-kalman-filter-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 522
content_hash: b790ec6dddcb5eae
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: Common Apm Navigation Extended Kalman Filter Overview
document_type: technical_reference

# Common Apm Navigation Extended Kalman Filter Overview

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 
Analog Pins 

Advanced Failsafe 

Autopilot Output Mapping 

Auxiliary Functions 

Battery Voltage Compensation 

Bootloader Update 

BLHeli ESCs 

CAN Bus Setup 

Compass Setup (Advanced) 

Compass-less Operation 

Crash Detection 

Damaged Motor/Prop RPM Checks 

DisplayPort 

DroneCAN Setup 

EKF (Extended Kalman Filter) 
Should the EKF2 or EKF3 be used? Choosing the EKF and number of cores 

Affinity and Lane Switching 

GPS / Non-GPS Transitions 

Commonly modified parameters 

EKF3 Fallback to DCM 

EKF Affinity &amp; Lane Switching 

EKF Sources and Selection 

Ethernet/Network Setup 

Network Capture 

Flight Time Recorder 

Flight Options 

Fly-By-Wire Low Altitude Limit 

FPort Setup 

GeoFencing Failsafe 

GPIOs 

GPS for Yaw (aka Moving Baseline) 

GPS for Altitude 

GPS/Non-GPS Transitions 

Ground Control Station Only Operation 

IMU Temperature Calibration 

Independent Watchdog 

In-Flight FTT and filter control 

Limiting Maximum Power Draw 

Limit Cycle Prevention 

LUA Scripting 

Magnetic Interference 

Magnetometer GeoPhys Array 

MAVLink 

MAVLink2 Packet Signing (Security) 

Moving Vehicle Initialization 

Multiple Radio Control Receivers 

Non-GPS Navigation 

Notification Devices (LEDs,Buzzer,etc.) 

Notch Filter Configuration 

Object Avoidance 

Optical Flow Sensor 

On Screen Displays (OSD) 

OSD Parameter Editor 

Parameter List (Full) 

Parameter Lockdown 

Parameter Reset 

RC Input Channel Mapping (RCMAP) 

RC Options 

Received Signal Strength Indication (RSSI) 

Redundant Telemetry 

Reverse Thrust Setup 

RunCam Camera Configuration and Control 

Safety Switch 

Sensor Position Offset Compensation 

Sensor Testing 

Serial Forwarding to DroneCAN 

Serial Port to Port Passthrough 

Serial Port Configuration 

Ship(Moving Vehicle) Takeoff/Landing 

Telemetry Port Setup 

Terrain Following 

Transmitter Based Tuning 

Video Stabilization (Gyroflow) 

Video Transmitter Control 

UBlox GPS Configuration 

Vibration Damping 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Advanced Configuration 

Extended Kalman Filter (EKF)

Edit on GitHub 

# Extended Kalman Filter (EKF) 

An Extended Kalman Filter (EKF) algorithm is used to
estimate vehicle position, velocity and angular orientation based on
rate gyroscopes, accelerometer, compass, GPS, airspeed and barometric
pressure measurements. The advantage of the EKF over the simpler complementary filter
algorithms (i.e.

--- chunk_id: chunk-0006
source_document: common-apm-navigation-extended-kalman-filter-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 482
content_hash: fb5cc883253c2fff
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: Common Apm Navigation Extended Kalman Filter Overview
document_type: technical_reference

Choosing the EKF and number of cores 

Affinity and Lane Switching 

GPS / Non-GPS Transitions 

Commonly modified parameters 

EKF3 Fallback to DCM 

EKF Affinity &amp; Lane Switching 

EKF Sources and Selection 

Ethernet/Network Setup 

Network Capture 

Flight Time Recorder 

Flight Options 

Fly-By-Wire Low Altitude Limit 

FPort Setup 

GeoFencing Failsafe 

GPIOs 

GPS for Yaw (aka Moving Baseline) 

GPS for Altitude 

GPS/Non-GPS Transitions 

Ground Control Station Only Operation 

IMU Temperature Calibration 

Independent Watchdog 

In-Flight FTT and filter control 

Limiting Maximum Power Draw 

Limit Cycle Prevention 

LUA Scripting 

Magnetic Interference 

Magnetometer GeoPhys Array 

MAVLink 

MAVLink2 Packet Signing (Security) 

Moving Vehicle Initialization 

Multiple Radio Control Receivers 

Non-GPS Navigation 

Notification Devices (LEDs,Buzzer,etc.) 

Notch Filter Configuration 

Object Avoidance 

Optical Flow Sensor 

On Screen Displays (OSD) 

OSD Parameter Editor 

Parameter List (Full) 

Parameter Lockdown 

Parameter Reset 

RC Input Channel Mapping (RCMAP) 

RC Options 

Received Signal Strength Indication (RSSI) 

Redundant Telemetry 

Reverse Thrust Setup 

RunCam Camera Configuration and Control 

Safety Switch 

Sensor Position Offset Compensation 

Sensor Testing 

Serial Forwarding to DroneCAN 

Serial Port to Port Passthrough 

Serial Port Configuration 

Ship(Moving Vehicle) Takeoff/Landing 

Telemetry Port Setup 

Terrain Following 

Transmitter Based Tuning 

Video Stabilization (Gyroflow) 

Video Transmitter Control 

UBlox GPS Configuration 

Vibration Damping 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Advanced Configuration 

Extended Kalman Filter (EKF)

Edit on GitHub 

# Extended Kalman Filter (EKF) 

An Extended Kalman Filter (EKF) algorithm is used to
estimate vehicle position, velocity and angular orientation based on
rate gyroscopes, accelerometer, compass, GPS, airspeed and barometric
pressure measurements. The advantage of the EKF over the simpler complementary filter
algorithms (i.e. “Inertial Nav” or DCM), is that by fusing all available measurements it is better
able to reject measurements with significant errors. This makes the
vehicle less susceptible to faults that affect a single sensor. An EKF also
enables measurements from optional sensors such as optical flow and
laser range finders to be used to assist navigation. Current stable versions of ArduPilot use EKF3 as their primary attitude and position estimation source with DCM running quietly in the background. If the autopilot has two (or more) IMUs available, two EKF “cores” (i.e. two instances of the EKF) will run in parallel, each using a different IMU.

--- chunk_id: chunk-0007
source_document: common-apm-navigation-extended-kalman-filter-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 133
content_hash: 4c9068de23452ae2
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Common Apm Navigation Extended Kalman Filter Overview
document_type: technical_reference

If the autopilot has two (or more) IMUs available, two EKF “cores” (i.e. two instances of the EKF) will run in parallel, each using a different IMU. At any one time, only the output from a single EKF core is ever used, that core being the one that reports the best health which is determined by the consistency of its sensor data. Most users should not need to modify any EKF parameters, but the information below provides some information on those parameters that are most commonly changed. More detailed information can be found on the developer EKF wiki page .

--- chunk_id: chunk-0008
source_document: common-apm-navigation-extended-kalman-filter-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: 4f117a477092465e
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: Should the EKF2 or EKF3 be used?
document_type: technical_reference

## Should the EKF2 or EKF3 be used? In general, we recommend users stick with the EKF3, which is now the default. In addition, 1MB autopilots only have this option due to space limitations. EKF2 can still be used but does not have many of the enhancements of EKF3 such as newer sensor sources including Beacons, Wheel Encoders and Visual Odometry. ### Choosing the EKF and number of cores 
AHRS_EKF_USE : set to “1” to use the EKF, “0” to use DCM for attitude control and ahrs dead reckoning (Plane) for position control. In Copter this parameter is forced to “1” and cannot be changed. AHRS_EKF_TYPE : set to “2” to use EKF2 for attitude and position estimation, “3” for EKF3. EK2_ENABLE , EK3_ENABLE : set to “1” to enable the EKF2 and/or EKF3 respectively. EK2_IMU_MASK , EK3_IMU_MASK : a bitmask specifying which IMUs (i.e. accelerometer/gyro) to use. An EKF “core” (i.e. a single EKF instance) will be started for each IMU specified. 1: starts a single EKF core using the first IMU

2: starts a single EKF core using only the second IMU

3: starts two separate EKF cores using the first and second IMUs respectively

EK3_PRIMARY : selects which “core” or “lane” is used as the primary. A value of 0 selects the first IMU lane in the EK3_IMU_MASK , 1 the second, etc. Be sure that the selected primary lane exists. See Affinity and Lane Switching below. Note

Plane and Rover will fall back from EKF2 or EKF3 to DCM if the EKF becomes unhealthy or the EKF is not fusing GPS data despite the GPS having 3D Lock. There is no fallback from EKF3 to EKF2 (or EKF2 to EKF1)

Warning

Using the parameters above it is possible to run up to 5 AHRSs in parallel at the same time (DCMx1, EKF2x2, EKF3x2) but this can result in performance problems so if running EKF2 and EKF3 in parallel, set the IMU_MASK to reduce the total number of cores.

--- chunk_id: chunk-0009
source_document: common-apm-navigation-extended-kalman-filter-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 312
content_hash: 31fb838502777eaf
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Affinity and Lane Switching
document_type: technical_reference

## Affinity and Lane Switching 

EKF3 provides the feature of sensor affinity which allows the EKF cores to also use non-primary instances of sensors, specifically, Airspeed, Barometer, Compass (Magnetometer) and GPS. This allows the vehicle to better manage good quality sensors and be able to switch lanes accordingly to use the best-performing one for state estimation. For more details and configuration, refer EKF3 Affinity and Lane Switching . ### GPS / Non-GPS Transitions 
EKF3 supports in-flight switching of sensors which can be useful for transitioning between GPS and Non-GPS environments. See GPS / Non-GPS Transitions for more details. ### Commonly modified parameters 
EKF sensor sources, see EKF Source Selection and Switching . EK3_ALT_M_NSE : Default is “1.0”. Lower number reduces reliance on accelerometers, increases reliance on barometer. EK3_GPS_TYPE :
Controls how GPS is used. 0 : use 3D velocity &amp; 2D position from GPS

1 : use 2D velocity &amp; 2D position (GPS velocity does not contribute
to altitude estimate)

2: use 2D position

3 : no GPS (will use optical flow only if available)

EK3_YAW_M_NSE : Controls the weighting between GPS and Compass when calculating the heading. Default is “0.5”, lower values will cause the compass to be trusted more (i.e. higher weighting to the compass)

As mentioned above, a more detailed overview of EKF theory and tuning parameters is available on the developer wiki’s Extended Kalman Filter Navigation Overview and Tuning .

--- chunk_id: chunk-0010
source_document: common-apm-navigation-extended-kalman-filter-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 368
content_hash: 4e0ac5b61e3cd50d
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: EKF3 Fallback to DCM
document_type: technical_reference

## EKF3 Fallback to DCM 

In ArduPlane, the older filter (DCM) is used as a fallback if the EKF3 stops using GPS (ie does not think that the GPS is providing accurate position and velocity) but the GPS is still reporting a 3D lock. In this case, ArduPlane switches to the DCM filter as its position, velocity, and attitude estimator. This is indicated by a GCS message that DCM has now become active. The reasons why EKF3 may start rejecting GPS are varied (but still have GPS 3D lock), but include GPS jamming, high vibrations making the EKF3 think it has moved to a different position inertially than GPS reports, etc. Using DCM (if GPS is indeed still accurate) as a fallback filter is not a real issue for fixed wing flight. It was the original ArduPlane inertial navigation algorithm. For VTOL QuadPlane hovering modes, it is more problematic, since DCM does not consider velocities in its estimator, so hovering is less accurate. If DCM fallback is observed, it would be worthwhile to determine the root cause and address it, since this is not a desired operating mode. However, in some situations where GPS lock is valid, but the GPS may give incorrect data leading to DCM being worse than just using EKF3 without GPS (for example, GPS jamming environments), you may wish to prevent fallback to DCM. This can be accomplished using the bits in the AHRS_OPTIONS parameter. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0011
source_document: common-canbus-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: cb1a5de96c51de75
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Common Canbus Setup Advanced
document_type: technical_reference

# Common Canbus Setup Advanced

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 
Analog Pins 

Advanced Failsafe 

Autopilot Output Mapping 

Auxiliary Functions 

Battery Voltage Compensation 

Bootloader Update 

BLHeli ESCs 

CAN Bus Setup 
Overview 

Configuration settings 
Enabling CAN interfaces 

Configuration of CAN interfaces 

Configuration of CAN driver 

CAN Logging 

CAN ESCs 

Compass Setup (Advanced) 

Compass-less Operation 

Crash Detection 

Damaged Motor/Prop RPM Checks 

DisplayPort 

DroneCAN Setup 

EKF (Extended Kalman Filter) 

EKF Affinity &amp; Lane Switching 

EKF Sources and Selection 

Ethernet/Network Setup 

Network Capture 

Flight Time Recorder 

Flight Options 

Fly-By-Wire Low Altitude Limit 

FPort Setup 

GeoFencing Failsafe 

GPIOs 

GPS for Yaw (aka Moving Baseline) 

GPS for Altitude 

GPS/Non-GPS Transitions 

Ground Control Station Only Operation 

IMU Temperature Calibration 

Independent Watchdog 

In-Flight FTT and filter control 

Limiting Maximum Power Draw 

Limit Cycle Prevention 

LUA Scripting 

Magnetic Interference 

Magnetometer GeoPhys Array 

MAVLink 

MAVLink2 Packet Signing (Security) 

Moving Vehicle Initialization 

Multiple Radio Control Receivers 

Non-GPS Navigation 

Notification Devices (LEDs,Buzzer,etc.) 

Notch Filter Configuration 

Object Avoidance 

Optical Flow Sensor 

On Screen Displays (OSD) 

OSD Parameter Editor 

Parameter List (Full) 

Parameter Lockdown 

Parameter Reset 

RC Input Channel Mapping (RCMAP) 

RC Options 

Received Signal Strength Indication (RSSI) 

Redundant Telemetry 

Reverse Thrust Setup 

RunCam Camera Configuration and Control 

Safety Switch 

Sensor Position Offset Compensation 

Sensor Testing 

Serial Forwarding to DroneCAN 

Serial Port to Port Passthrough 

Serial Port Configuration 

Ship(Moving Vehicle) Takeoff/Landing 

Telemetry Port Setup 

Terrain Following 

Transmitter Based Tuning 

Video Stabilization (Gyroflow) 

Video Transmitter Control 

UBlox GPS Configuration 

Vibration Damping 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Advanced Configuration 

CAN Bus Setup

Edit on GitHub 

# CAN Bus Setup 

This article shows how to setup CAN bus and what options users have
to accomplish the setup suitable for their specific needs. Tip

The DroneCAN setup page is here . But the parameters below must be configured correctly in order to use the DroneCAN driver.

--- chunk_id: chunk-0012
source_document: common-canbus-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 40
content_hash: 9fd7dc6e5fa59a3f
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: Common Canbus Setup Advanced
document_type: technical_reference

Tip

The DroneCAN setup page is here . But the parameters below must be configured correctly in order to use the DroneCAN driver. Note

DroneCAN was formerly known as UAVCAN.

--- chunk_id: chunk-0013
source_document: common-canbus-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 293
content_hash: 653dddf23d6e5fdb
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: Overview
document_type: technical_reference

## Overview 

A Controller Area Network (CAN bus) is a robust vehicle bus standard designed
to allow microcontrollers and devices to communicate with each other in
applications without a host computer. It is a message-based protocol, designed
originally for multiplex electrical wiring within automobiles to save on copper,
but is also used in many other contexts. All nodes are connected to each other through a two wire bus. The wires are
120 Ω nominal twisted pair. Most autopilots that run ArduPilot have either one or two CAN interfaces
for connection of different devices. ArduPilot can support up to 3 CAN interfaces. The setup of the interfaces can be made in a way that will provide redundancy or
maximum throughput or a mix of both. This is accomplished with a three layer approach, where apart from the physical
interface there exists a driver layer that represents a specific protocol and a
software layer (ArduPilot) that communicates on CAN bus through these drivers. Each physical interface can be virtually connected to one of up to three drivers that
represent the protocols to be used. For example, the most common scenario will be with all
interfaces connected to a DroneCAN driver. Such setup will provide redundancy for devices with
up to three CAN interfaces and full functionality for devices with one CAN interface.

--- chunk_id: chunk-0014
source_document: common-canbus-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 472
content_hash: 92e8b7dc9ab42970
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: Configuration settings
document_type: technical_reference

## Configuration settings 
### Enabling CAN interfaces 

Each physical port can be turned off or connected to corresponding driver with
parameter CAN_Px_DRIVER , where x is the number of the CAN port. The value of this parameter is the id of driver that will be associated with this
port (interface). Each enabled bus/driver will use a block of RAM memory (not Flash) depending on the type of driver and if CANFD is enabled. For example, DroneCAN will allocate 12KB for its driver (24K if CANFD) by default, but can vary from board to board depending on its defaults, if set by its hardware definition file. The CAN_Dx_UC_POOL parameter can be used to change the pool size. Required pool size depends on bus traffic required by the attached DroneCAN peripheral and can sometimes be reduced for peripherals such as GPS or Compass, whereas peripherals such as ESCs require more bus traffic and therefore a larger pool size. For example, the most common setup will have one driver and all interfaces will be connected
to it. The CAN_P1_DRIVER and CAN_P2_DRIVER parameters in this configuration should be set to 1 (first
driver). And that driver ( CAN_D1_PROTOCOL ) be set to 1 (DroneCAN). After change of any CAN_Px_DRIVER or CAN_Dx_PROTOCOL the autopilot has to be rebooted for the changes to take place. ### Configuration of CAN interfaces 

After enabling the interface and reboot two more parameters can be set for each
of the enabled interfaces. These are:

CAN_Px_BITRATE - sets the desired rate of transfer on this interface

CAN_Px_DEBUG - allows output of debug messages

Usually the bitrate used by default is 1 Mbit. Debug level can also be set on user’s preference and needs. When any of the interfaces are associated with any driver, that driver will be
loaded with specified protocol. ### Configuration of CAN driver 

The driver should be set to use some protocol. Currently there is support for DroneCAN devices,
which is numbered 1, and numerous CAN ESCs and other devices. The parameter CAN_Dx_PROTOCOL , where x is the number of driver, should be filled
with the number of protocol for this driver.

--- chunk_id: chunk-0015
source_document: common-canbus-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: 83b2d1fe4da290c5
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: Configuration settings
document_type: technical_reference

Currently there is support for DroneCAN devices,
which is numbered 1, and numerous CAN ESCs and other devices. The parameter CAN_Dx_PROTOCOL , where x is the number of driver, should be filled
with the number of protocol for this driver. CAN_Dx_PROTOCOL

Protocol Type

0

Disabled

1

DroneCAN

4

PiccoloCAN

6

EFI_NWPMU

7

USD1 (RangeFinder)

8

KDECAN

10

Scripting based CAN driver

11

Benewake (RangeFinder)

12

Scripting2 (allows two drivers)

13

NoopLoop TOFSenseP (RangeFinder)

14

RadarCAN (NanoRadar/Hexsoon RangeFinders)

After the change to protocol the autopilot has to be rebooted for the changes to take place. Note

only devices matching the selected protocol can be connected to a given CAN bus. Mixing of different protocol devices on a single CAN bus is not allowed. However, if the Protocol is set to DroneCAN, certain devices with different protocols can be attached. See Mixed Protocols on a DroneCAN CAN bus . ### CAN Logging 

Logging of all CAN frames can be enabled using the CAN_P1_OPTIONS and/or CAN_P2_OPTIONS parameters.

--- chunk_id: chunk-0016
source_document: common-canbus-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 96
content_hash: 2a520788b15ab769
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: CAN ESCs
document_type: technical_reference

## CAN ESCs 

Several types of CAN based ESCs are supported: DroneCAN, KDECAN, ToshibaCAN, UAVCAN, and PiccoloCAN. For these ESCs, each type use several parameters for configuration. See the ESC’s individual description page here . Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0017
source_document: common-compass-calibration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 488
content_hash: b077f8a91d820302
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: Common Compass Calibration In Mission Planner
document_type: technical_reference

# Common Compass Calibration In Mission Planner

Compass Calibration &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 
Install Ground Station Software 

Autopilot System Assembly 

Loading Firmware to boards with existing ArduPilot firmware 

Loading Firmware to boards without existing ArduPilot firmware 

Connect Mission Planner to AutoPilot 

Configuration 
Basic System Overview 

Choosing Servo Output Functions 

RC Input Throw and Trim 

Radio Control Calibration 

Accelerometer Calibration 

Compass Calibration 
Calibration first steps 

Onboard Calibration 

Onboard Calibration using RC Switch 

Large Vehicle MagCal 

Compass Ordering 

Additional information 

Video demonstration 

Flight Modes 

RC Transmitter Mode Setup 

ESC Calibration 

Automatic Trim 

Failsafe Function 

Airspeed Parameters Setup 

Basic FPV Plane 

Airframe Specific Setup Guides 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Setup for Plane 

Plane Configuration 

Compass Calibration

Edit on GitHub 

# Compass Calibration 

Note

Operation of fixed wing Planes and some Rovers is possible without the use of a compass (See Compass-less Operation ), but utilizing a compass is recommended for all other vehicles unless yaw is provided by some other means ( GPS for Yaw (aka Moving Baseline) or Non-GPS Navigation or External AHRS Systems )

This article explains how to perform basic compass calibration. It assumes that you have at least one compass, either internally or externally in the system, and it has been enabled. See Advanced Compass Setup for more information and to setup other compass related features. Warning

It is important that when compass calibration is done, the vehicle have a good 3D gps lock, in order to assure the best setup. If necessary, move outdoors in order to get a good 3D gps lock before doing the compass calibration. Note

Compass calibration cannot be performed while vehicle is armed.

--- chunk_id: chunk-0018
source_document: common-compass-calibration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 108
content_hash: 9f39985edb486575
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: Common Compass Calibration In Mission Planner
document_type: technical_reference

If necessary, move outdoors in order to get a good 3D gps lock before doing the compass calibration. Note

Compass calibration cannot be performed while vehicle is armed. Tip

It is not necessary to recalibrate the compass when the vehicle is flown at a new location because ArduPilot includes a “world magnetic model” which allows converting the location’s magnetic North to true North without recalibrating . In addition the location’s “inclination” is calibrated at startup and then again soon after takeoff.

--- chunk_id: chunk-0019
source_document: common-compass-calibration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 490
content_hash: b2b60ecea19ff6bc
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: Calibration first steps
document_type: technical_reference

## Calibration first steps 

Warning

Do not calibrate the compasses near any metallic or magnetic field producing object (computers, cell phones, metal desks, power supplies, etc.) or incorrect calibration will occur. Under SETUP| Mandatory Hardware select Compass . Mission Planner: Compass Calibration 

You may wish to disable any internal compasses if you are consistently seeing the “inconsistent compasses” pre-arm message often and you are sure that the external compass is calibrated. ### Onboard Calibration 
“Onboard Calibration” is a calibration routine that runs on the autopilot. This method is more accurate than the older “Offboard Calibration” (aka “Live Calibration”) which runs on the ground station because in addition to offsets, scaling and orientation are also automatically determined. Note

Calibration could fail for the compasses integrated into the autopilot, if any, if the autopilot board orientation parameter is not correct. To perform the onboard calibration of all compasses:

click the “Onboard Mag Calibration” section’s “Start” button

if your autopilot has a buzzer attached you should hear a single tone followed by short beep once per second

hold the vehicle in the air and rotate it so that each side (front, back, left, right, top and bottom) points down towards the earth for a few seconds in turn. Consider a full 360-degree turn with each turn pointing a different direction of the vehicle to the ground. It will result in 6 full turns plus possibly some additional time and turns to confirm the calibration or retry if it initially does not pass. as the vehicle is rotated the green bars should extend further and further to the right until the calibration completes

upon successful completion three rising tones will be emitted and a “Please reboot the autopilot” window will appear and you will need to reboot the autopilot before it is possible to arm the vehicle. If calibration fails:

you will hear an “unhappy” failure tone, the green bars may reset to the left, and the calibration routine may restart (depending upon the ground station). Mission Planner will automatically retry, so continue to rotate the vehicle as instructed above. if a compass is not calibrating, consider moving to a different area away from magnetic disturbances, and remove electronics from your pockets.

--- chunk_id: chunk-0020
source_document: common-compass-calibration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 129
content_hash: 35d07ba10973cd5a
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
section_heading: Calibration first steps
document_type: technical_reference

Mission Planner will automatically retry, so continue to rotate the vehicle as instructed above. if a compass is not calibrating, consider moving to a different area away from magnetic disturbances, and remove electronics from your pockets. if, after multiple attempts, the compass has not passed the calibration, Press the “Cancel” button and change the “Fitness” drop-down to a more relaxed setting and try again. if compass calibration still fails it may help to raise COMPASS_OFFS_MAX from 850 to 2000 or even 3000

finally, if a single compass is not calibrating and you trust the others, disable it.

--- chunk_id: chunk-0021
source_document: common-compass-calibration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 293
content_hash: 1cd006d64e8de348
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: Onboard Calibration using RC Switch
document_type: technical_reference

## Onboard Calibration using RC Switch 

Onboard Calibration can be started using an RC switch instead using the Mission Planner technique above. This allows calibrating without the tangle of the USB cable. Setup an RC channel to start the calibration by setting its RCx_OPTION to be “171”. A high value on the channel will start calibrating all compasses and you would move the vehicle as above. A low value will cancel the calibration. The tones for success or failure above will be emitted. ### Large Vehicle MagCal 
Large or heavy vehicles are impractical to rotate on all axis. This feature allows a fairly accurate calibration if GPS lock is active on the autopilot and the vehicles actual heading is known, either using a landmark reference on the Mission Planner map, or using another compass (eg cell phone) and entering the vehicles heading. Warning

The proper orientation of the compass must also be set in order for this method to give a good result. If orientation is incorrect this procedure will appear to succeed while leaving the compass calibration in a very bad state. Note

the heading entered should be TRUE, not MAGNETIC. Using a phone’s compass app will usually required adding the local declination value to the reading in order to obtain the TRUE geographic heading which should be entered.

--- chunk_id: chunk-0022
source_document: common-compass-calibration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 158
content_hash: f6f8b446065931b0
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
section_heading: Compass Ordering
document_type: technical_reference

## Compass Ordering 

At the top of the page, you can change the priority of the attached compasses, if desired. ### Additional information 
More information about compass configuration can be found in Advanced Compass Setup . This includes instructions for how to set up additional compasses, automatic setting of offsets , non-standard compass alignments, compassmot , etc. General discussion on magnetic interference and ways to reduce it can be
found in Magnetic Interference . ### Video demonstration 
Video demonstrations of compass calibration. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0023
source_document: common-connect-mission-planner-autopilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 298
content_hash: 307ce833baffe11b
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: Common Connect Mission Planner Autopilot
document_type: technical_reference

# Common Connect Mission Planner Autopilot

Connect Mission Planner to AutoPilot &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 
Install Ground Station Software 

Autopilot System Assembly 

Loading Firmware to boards with existing ArduPilot firmware 

Loading Firmware to boards without existing ArduPilot firmware 

Connect Mission Planner to AutoPilot 
Setting up the connection 
Connecting to multiple vehicles 

Troubleshooting 

Troubleshooting Composite Connections 

Related topics 

Configuration 

Airframe Specific Setup Guides 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Setup for Plane 

Connect Mission Planner to AutoPilot

Edit on GitHub 

# Connect Mission Planner to AutoPilot 

This article explains how to connect Mission Planner to an autopilot
in order to receive telemetry and control the vehicle. Note

There are separate instructions for connecting in order to Load Firmware for existing ArduPilot firmware installations, or for boards without existing ArduPilot firmware .

--- chunk_id: chunk-0024
source_document: common-connect-mission-planner-autopilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 460
content_hash: 6a7e6e5dbf1d1a9a
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: Setting up the connection
document_type: technical_reference

## Setting up the connection 

To establish a connection you must first choose the communication
method/channel you want to use, and then set up the physical hardware
and Windows device drivers. You can connect the PC and autopilot using
USB cables, Telemetry Radios ,
Bluetooth ,
IP connections etc. Note

The driver for your connection hardware must be present on Windows
as this makes your connection’s COM port and default data rate available
to Mission Planner . Pixhawk USB Connection 

Connection using SiK Radio 

On Mission Planner , the connection and data rate are set up using the
drop down boxes in the upper right portion of the screen. Once you’ve attached the USB or Telemetry Radio, Windows will
automatically assign your autopilot a COM port number, and that will
show in the drop-down menu (the actual number does not matter). The
appropriate data rate for the connection is also set (typically the USB
connection data rate is 115200 and the radio connection rate is 57600). Select the desired port and data rate and then press the CONNECT 
button to connect to the autopilot. After connecting Mission Planner 
will download parameters from the autopilot and the button will change
to DISCONNECT as shown:

Tip

The “select port” dropdown also contains TCP or UDP port options
that can be used to connect to an autopilot over a network. The “Stats…” hotlink beneath the port selection box, if clicked, will give information about the connection, such as if Signing security is active, link stats, etc. Sometimes this window pops up beneath the current screen and will have to be brought to the front to be seen. ### Connecting to multiple vehicles 

Additional connections can be made by right-clicking the CONNECT button and selecting Connection Options from the drop-down list. A file with a pre-written list of connections can be loaded with the Connection List drop-down option. This is an example format of the file:

tcp : // 127.0.0.1 : 5670 
udp : // 127.0.0.1 : 14550 
udpcl : // 192.168.1.255 : 14550 
serial : com4 : 115200

--- chunk_id: chunk-0025
source_document: common-connect-mission-planner-autopilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 338
content_hash: 8333f944c8010faf
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: Troubleshooting
document_type: technical_reference

## Troubleshooting 

If Mission Planner is unable to connect:

Check that the correct baud rate is used for the selected method
(115200 on USB or 57600 on Radio/Telemetry)

If attaching via USB, be sure that a few seconds after power up have passed before attempting to connect. If you attempted to connect during the bootloader initialization time, Windows may get the wrong USB information. Connection attempts after this may require that the USB connection be unplugged and re-plugged,then wait for bootloader to enter the main code ( few seconds), then attempt the connection. Occasionally, MP must be restarted if an attempt to connect is made while in the bootloader initialization period. If using a COM port on Windows, check that the connection’s COM port
exists in the Windows Device Manager’s list of serial ports. If your autopilot has an F7 or H7 processor and has CAN ports, then see the section below, Troubleshooting Composite Connections 

If using a USB port, try a different physical USB port

If using a UDP or TCP connection, check that your firewall is not blocking IP traffic

You should also ensure that the autopilot controller board has
appropriate ArduPilot firmware installed and has booted correctly (on
Pixhawk there are useful LEDs and
Sounds which can tell you the state of the autopilot). If using a remote link (not USB) and Mission Planner connects, but does not download parameters or you cannot get commands, like mode changes acted upon,then the autopilot probably has Signing turned on. See MAVLink2 Signing .

--- chunk_id: chunk-0026
source_document: common-connect-mission-planner-autopilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: bac729facace0bb6
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: Troubleshooting Composite Connections
document_type: technical_reference

## Troubleshooting Composite Connections 

Autopilots with F7 or H7 processors and having CAN interfaces use firmware that presents two USB interfaces: One for the normal MAVLink connection, and one for SLCAN serial connections to the CAN interface for configuration and firmware updates.This is called a composite USB device. By default, the MAVLink USB interface is SERIAL0 and the SLCAN USB interface is the highest SERIALx port the board presents. The Windows driver currently installed with Mission Planner may select to use either one, and since both are set by default in ArduPilot firmware for MAVLINK protocol, it will work fine, whichever one it chooses as the COM port. However, there is a situation where the user will find that it will not connect to the obvious COM port in the Mission Planner dropdown box.This occurs when the user accidentally changes the protocol of whichever SERIALx port the Windows driver is using as the MAVLink COM port to something other than MAVLink. This can easily happen if the user takes an existing parameter file from a vehicle configuration used with a different autopilot that has the protocol changed. For example, the user has a plane with non F7/H7 CAN capable autopilot and upgrades it to one that is, then loads his existing parameter file while setting up the plane with the new autopilot. As soon as the parameter file is loaded and the autopilot is rebooted, communication is lost and cannot be re-established. What has occurred, is that the protocol for the SERIALx port that Windows was using has been changed. Almost always, this is the highest numbered SERIALx port since that is commonly set to -1 on non-CAN capable autopilots, and the Windows COM port driver has selected this interface as the COM port instead of SERIAL0. The procedure to recover is as follows:

Go to Windows Device Manager and find the COM port being used by the autopilot in the Ports listings. It will have the COM Port # you used to connect initially to Mission Planner. Right click and it will present “Update driver software” as one of the options. Click it. Click the “Browse my computer……” option and then click the “Choose from a list…” option and you will see this screen:

Scroll down the top list until “Composite USB” option appears and click it.

--- chunk_id: chunk-0027
source_document: common-connect-mission-planner-autopilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 257
content_hash: 17b7a98d86541811
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
section_heading: Troubleshooting Composite Connections
document_type: technical_reference

Click it. Click the “Browse my computer……” option and then click the “Choose from a list…” option and you will see this screen:

Scroll down the top list until “Composite USB” option appears and click it. Now reconnect your autopilot to the PC and two COM ports will be presented. One will connect (the remaining one with MAVLink Protocol) and the other will not. If you do not connect to one, try the other. But DO NOT disconnect the autopilot from the PC or the composite driver will unload and you will have to start over. Now that you are connected to Mission Planner, change back the protocol of the Serialx port protocol to 2 (MAVLink2). You can now disconnect and reconnect the autopilot and it will present only one COM port and you should be able to connect from now on. Do not change this protocol from now on unless trying to utilize the SLCAN interface. It may be a bit unfamiliar since the Mission Planner SERIALx port being used is no longer the normal SERIAL0 but rather,the highest port, but this does not affect anything in the autopilot’s configuration and operation.

--- chunk_id: chunk-0028
source_document: common-connect-mission-planner-autopilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 58
content_hash: b46908698f646ba4
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
section_heading: Related topics
document_type: technical_reference

## Related topics 

Mission Planner Bluetooth Connectivity 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0029
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 268
content_hash: ba730bf067b71316
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: Common Diagnosing Problems Using Logs
document_type: technical_reference

# Common Diagnosing Problems Using Logs

Diagnosing some common problems using Logs &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 
Logs 
Log Types (Dataflash vs Tlogs) 
Topics related to logging and analysis 

Tools for Log Analysis 

What to do if you have an issue 

Vehicle Will Not Arm 

Interference issues on Electric Vehicles 

Free RAM issues 

H7 AutoPilot Will Not Initialize 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

When Problems Arise 

Logs 

Diagnosing some common problems using Logs

Edit on GitHub 

# Diagnosing some common problems using Logs 

This page show how to diagnose the six most common problems affecting Copter in particular but to some extent Plane and Rover as well.

--- chunk_id: chunk-0030
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: d75b551cc0c1db1d
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
section_heading: Mechanical Failures
document_type: technical_reference

## Mechanical Failures 

Common mechanical failures include a motor or ESC failure ( including ESC sync failures ), the propeller breaking or coming off, etc. These appear in the log as a sudden divergence in the desired roll and pitch vs the vehicle’s actual roll and pitch. This divergence is visible by graphing the ATT message’s DesRoll vs Roll, DesPitch vs Pitch and to a lesser extent DesYaw vs Yaw. In the example above the vehicle’s actual roll (“Roll”) closely follows the desired roll (“DesRoll”) for the first part of the log but then suddenly diverges. The autopilot wanted the roll to remain level (“Roll” = 0) but it was unable to likely meaning there was a mechanical failure. This is very different from a software failure in which the autopilot freaked out and for some strange reason suddenly wanted the copter up-side-down because in such cases the DesRoll would be also be crazy and actual Roll would follow. Tlogs contain the same data. Compare NAV_CONTROLLER_OUTPUT’s nav_roll (desired roll) and nav_pitch (desired pitch) to ATTITUDE.roll (actual roll) and pitch (actual pitch).

--- chunk_id: chunk-0031
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 192
content_hash: 8bc46daf4b5eb957
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
section_heading: Vibrations
document_type: technical_reference

## Vibrations 

High vibrations can cause the Copter’s accelerometer based altitude and horizontal position estimates to drift far off from reality which leads to problems with altitude hold (the vehicle may rocket into the sky) or position control in modes like Loiter, PosHold, Auto, etc. As covered on the Measuring Vibration page, vibrations are best viewed by graphing the VIBE message’s VibeX , VibeY and VibeZ values. Vibration levels below 30m/s/s are normally acceptable. Levels above 30m/s/s may have problems and levels above 60m/s/s nearly always have problems with position or altitude hold. The below graph shows acceptable vibration levels which are consistently below 30m/s/s

The graph below is from a vehicle that had position estimation problems due to high vibrations

Tlog’s VIBRATION vibration_x , vibration_y and vibration_z can also be used and show the same information as is stored to the dataflash log

--- chunk_id: chunk-0032
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: 9820d5ebb498a7ae
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
section_heading: Compass interference
document_type: technical_reference

## Compass interference 

Interference from the power distribution board, motors, battery, ESCs and other electrical devices near the autopilot can throw off the compass heading which can lead to circling (aka “toilet bowling”) or even the copter flying off in completely the wrong direction. Graphing the tlog’s mag_field (found under “CUSTOM”) and throttle (found under VFR_HUD) is the easiest way to quickly see the amount of interference. The graph below shows an acceptable amount of magnetic interference with mag_field fluctuations of only 10% to 20% when the throttle is raised. Below 30% interference is acceptable. Between 30% ~ 60% is in the grey zone where it might be OK (some users are OK, some are not) and really bad magnetic interference will show up as jumps of over 60% when the throttle is raised. Extra Notes:

The length of the mag_field can be anywhere from 120 ~ 550 depending upon where in the world the vehicle is but it is normally around 330

The magnetic interference as a percentage of the total mag field is also displayed at the end of the compassmot set-up procedure. Search for “CompassMot” on the Advanced Compass Setup page page to learn more about compassmot

Dataflash log’s COMPASS message hold the compass’s raw x, y and z axis values (called MagX, MagY, MagZ) which are equivalent to the tlog’s RAW_IMU xmag, ymag and zmag fields. It is possible to calculate the mag-field length by first loading the dataflash log file into excel, filtering by the COMPASS message and then calculating the mag-field using the formula mag_field = sqrt(MagX^2, MagY^2, MagZ^2). Note that the COMPASS message is not enabled by default in the dataflash logs because it runs at 50hz and does affect CPU performance a bit. The image above it shows a short spike at the beginning of the graph but this can be ignored because it is before the throttle is raised so it is probably just as the user plugged in some other electrical device

--- chunk_id: chunk-0033
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: 42b6703069471e7e
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
section_heading: GPS glitches
document_type: technical_reference

## GPS glitches 

When in autonomous modes (Loiter, RTL, Auto, etc) position errors from the GPS can cause the vehicle to think that it is suddenly in the wrong place and lead to aggressive flying to correct the perceived error. These “glitches” show up in both the tlogs and dataflash logs as a decrease in the number of satellites visible and an increase in the hdop . Graph the Dataflash log’s GPS message’s “HDop” and “NSats” values. Hdop values below 1.5 are very good, values over 2.0 could indicate the GPS positions are not good. The number of satellites falling below 12 is also bad. A significant change in these two values often accompanies a GPS position change. If using tlogs graph the GPS_RAW_IT group’s “eph” and “satellites_visible” values. Hdop values below 150 are good, values over 200 could indicate a bad position. See the EKF failsafe wiki page for more details on how the vehicle may switch to non-autonomous modes in the case of very bad GPS glitches

--- chunk_id: chunk-0034
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 281
content_hash: 7e2bc319f97a582b
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: Power Problems (BrownOuts, etc)
document_type: technical_reference

## Power Problems (BrownOuts, etc) 

Power Modules provide a reliable power supply to the autopilot but brown-outs do still occasionally occur. They can normally be recognised by the logs suddenly ending while the vehicle is still in the air (i.e. barometer or EKF altitude is still reporting the vehicle’s altitude is well above zero). Try graphing the:

Dataflash log’s CTUN Alt (altitude above home) or BAlt (Barometer altitude)

Dataflash log’s GPS Alt (altitude above sea level)

Tlog’s VFR_HUD alt (the combined accelerometer + barometer altitude estimate)

Tlog’s GLOBAL_POSITION relative_alt (altitude above home)

Changes in the board voltage can also be a sign of a power problem. Variations of 0.10 to 0.15 volts are normal. Beyond that could be a sign that other devices sharing the power source with the autopilot are causing ripples in the power supply that could lead to a brown-out. The board voltage can be graphed using:

Dataflash POWR message’s VCC

Tlog HWSTATUS’s Vcc

In the image directly below shows the board voltage sinking by 0.15V when the throttle is raised. This is generally not a good thing but because it’s only 0.15V it’s probably OK. The 2nd graph below (a dataflash graph from a different user’s log) shows a very stable voltage with ripples less than 0.1V.

--- chunk_id: chunk-0035
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: de3b6eba71311680
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: Unexpected ERRORS including Failsafes
document_type: technical_reference

## Unexpected ERRORS including Failsafes 

When unexpected behaviour from the autopilot occurs (especially when the user complains that the copter no longer responded to their input) it is often caused by one of the failsafes being triggered. The easiest way to find these is to look in the dataflash logs and filter the first column by “ERR”. If using the Mission Planner, the errors will also appear in red markers at the top of the graphing area. The Subsys (aka Sub-system) gives the area that generated the error and the ECode (aka Error Code) tells you what the error was specifically. The list of subsystems and error codes can be found in the AP_Logger library AP_Logger.h file . Subsys 
ECode and Description 

2 = Radio 

0 = Errors Resolved

2 = Late Frame : no updates received from receiver for two seconds

3 = Compass 

0 = Errors Resolved

1 = Failed to initialise (probably a hardware issue)

4 = Unhealthy : failed to read from the sensor

5 = Radio Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

6 = Battery Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

8 = GCS Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

9 = Fence Failsafe 

0 = Failsafe Resolved

1 = Altitude fence breach, Failsafe Triggered

2 = Circular fence breach, Failsafe Triggered

3 = Both Alt and Circular fence breached, Failsafe Triggered

4 = Polygon fence breached, Failsafe Triggered

10 = Flight mode Change failure 
Vehicle was unable to enter the desired flight mode normally because of a bad position estimate

See flight mode numbers here for Copter, Plane modes here , and Rover modes here 

11 = GPS 

0 = Glitch cleared

2 = GPS Glitch occurred

12 = Crash Check 

1 = Crash into ground detected. Normally vehicle is disarmed soon after

2 = Loss of control detected.

--- chunk_id: chunk-0036
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 680
content_hash: 3fa4dc1a7cacc313
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
section_heading: Unexpected ERRORS including Failsafes
document_type: technical_reference

Subsys 
ECode and Description 

2 = Radio 

0 = Errors Resolved

2 = Late Frame : no updates received from receiver for two seconds

3 = Compass 

0 = Errors Resolved

1 = Failed to initialise (probably a hardware issue)

4 = Unhealthy : failed to read from the sensor

5 = Radio Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

6 = Battery Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

8 = GCS Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

9 = Fence Failsafe 

0 = Failsafe Resolved

1 = Altitude fence breach, Failsafe Triggered

2 = Circular fence breach, Failsafe Triggered

3 = Both Alt and Circular fence breached, Failsafe Triggered

4 = Polygon fence breached, Failsafe Triggered

10 = Flight mode Change failure 
Vehicle was unable to enter the desired flight mode normally because of a bad position estimate

See flight mode numbers here for Copter, Plane modes here , and Rover modes here 

11 = GPS 

0 = Glitch cleared

2 = GPS Glitch occurred

12 = Crash Check 

1 = Crash into ground detected. Normally vehicle is disarmed soon after

2 = Loss of control detected. Normally parachute is released soon after

13 = Flip mode 
2 = Flip abandoned (not armed, pilot input or timeout) 

15 = Parachute 

2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check 

0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer 

0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe 

0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data 
2 = missing terrain data 

22 = Navigation 

2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed 

0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check 

0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub) 

0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub) 

0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only) 

0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe 

0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums .

--- chunk_id: chunk-0037
source_document: common-diagnosing-problems-using-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 462
content_hash: e813f09eace698de
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
section_heading: Unexpected ERRORS including Failsafes
document_type: technical_reference

Normally vehicle is disarmed soon after

2 = Loss of control detected. Normally parachute is released soon after

13 = Flip mode 
2 = Flip abandoned (not armed, pilot input or timeout) 

15 = Parachute 

2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check 

0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer 

0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe 

0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data 
2 = missing terrain data 

22 = Navigation 

2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed 

0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check 

0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub) 

0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub) 

0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only) 

0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe 

0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0038
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 474
content_hash: b129c5fbaa0643d8
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: Common Downloading And Analyzing Data Logs In Mission Planner
document_type: technical_reference

# Common Downloading And Analyzing Data Logs In Mission Planner

Downloading and Analyzing Data Logs in Mission Planner &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 
Logs 
Log Types (Dataflash vs Tlogs) 
Topics related to logging and analysis 

Tools for Log Analysis 

What to do if you have an issue 

Vehicle Will Not Arm 

Interference issues on Electric Vehicles 

Free RAM issues 

H7 AutoPilot Will Not Initialize 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

When Problems Arise 

Logs 

Downloading and Analyzing Data Logs in Mission Planner

Edit on GitHub 

# Downloading and Analyzing Data Logs in Mission Planner 

Dataflash logs are stored on the autopilot
and can be downloaded after a flight. By default, they are created after you first
arm the vehicle. This topic explains how to configure and access
Dataflash logs. Depending on the autopilot type and configuration, the dataflash logs may be saved on a SD card, dataflash chip or streamed over MAVLink telemetry ports. The MAVLink option does require a high-speed telemetry port, typically 921600 baud. Note

In addition to using Mission Planner, many other tools are available to users for log analysis: MAVExplorer(part of MAVProxy installation) and Web-based tools . Note

Telemetry logs (also known as “tlogs”) collect similar information to dataflash logs (see Diagnosing problems using Logs for more information). Note

If your vehicle is having trouble producing dataflash logs - including the infamous “No IO heartbeat” diagnostic message - try a different SD card. You may also choose to test the card using a dedicated tool, such as H2testw . Low board voltages are also known to cause logging issues.

--- chunk_id: chunk-0039
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 520
content_hash: 1668ae5200bbc398
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: Logging Parameters
document_type: technical_reference

## Logging Parameters 

Some commonly used parameters are:

LOG_BACKEND_TYPE : Bitmask for where to save logs to. Common values are “0” to disable logging, “1” (bit 0 set) to log to SD card file, “2”(bit 1 set) to stream over MAVLink and “4”(bit 2 set) to log to board dataflash memory, if equipped. LOG_BITMASK : Bitmask for what items are logged. Normally, use default value, or “0” to disable logging. LOG_DISARMED : Setting to 1 will start logging when power is applied, rather than at the first arming of the vehicle. Useful when debugging pre-arm failures. Setting to 2 will only log on power application other than USB power to prevent logging while setting up on the bench. Setting to 3 will also erase any log in which the vehicle does not proceed to the armed stated. This prevents accumulating numerous logs while configuring on the bench or at the field. See LOG_DARM_RATEMAX also for managing log file sizes while logging disarmed. LOG_FILE_DSRMROT : Setting this bit will force the creation of a new log file after disarming, waiting 15 seconds, and then re-arming. Normally, a log will be one file for every power cycle of the autopilot, beginning upon first arm. LOG_FILE_MB_FREE : This parameter sets the minimum free space on the logging media before logging begins. If this is not available, then older logs will be deleted to provide it during initialization. Default is 500MB. LOG_FILE_RATEMAX : This sets the maximum rate that streaming log messages will be logged to the file backend to limit file sizes. A value of zero(default) means no limit is applied to normal logging, which depends on the SCHED_LOOP_RATE value ( 50Hz: Plane, 300Hz: QuadPlane/Rover, 400Hz: Copter, normally). Note that similarly, LOG_BLK_RATEMAX and LOG_MAV_RATEMAX perform the same optional limiting for the BLOCK logging and MAVLink logging streams, respectively. LOG_MAX_FILES : The maximum number of log file that will be written on dataflash or SD card before starting to rotate log number. Limit is a maximum of 500 logs. Note

If you suspect that you are missing logging entries due to excessive logging speed, you can check the DSF.Dp log message for the amount of missed entries. Note

Logging of the continuously streaming log messages, such as attitude, sensors, etc. can be paused by using the RCx_OPTION auxiliary function “164” on a transmitter channel.

--- chunk_id: chunk-0040
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 121
content_hash: 504a2d51944f72c4
prev_chunk_id: chunk-0039
next_chunk_id: chunk-0041
section_heading: Logging Parameters
document_type: technical_reference

Note

Logging of the continuously streaming log messages, such as attitude, sensors, etc. can be paused by using the RCx_OPTION auxiliary function “164” on a transmitter channel. Switching this channel high will pause these messages, but not events, mode changes, warnings, etc. This allows autopilots with limited logging capabilities (ie using Block logging to chip memory and no SD card) to log only when desired during the flight, as during tuning phases or determination of TECs parameters, etc. You can also eliminate unneeded log messages using LOG_BITMASK to reduce log size

--- chunk_id: chunk-0041
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 268
content_hash: 636c70fe6a06fd9e
prev_chunk_id: chunk-0040
next_chunk_id: chunk-0042
section_heading: Replay Logging
document_type: technical_reference

## Replay Logging 

ArduPilot has the ability to log in a fashion that solutions to EKF/AHRS issues can be more easily verified by actually re-playing a log against code changes to see if the solution results in the desired, corrected behavior. This requires that the logs showing the issue to be worked on be made with logging active during disarmed periods (with LOG_DISARMED set to a non-zero value, preferably 3) and LOG_REPLAY =1 , thereby logging more sensor data than normal. ### SD Card Logging Issues 
If you are running into problems with bad logging errors on SD cards, here are some things you can try. Format the card to FAT32 or vFAT (newer formats can work with new versions of Ardupilot and better hardware). Perform a full format to check for bad sectors. Check that the card is not write protected. Check card contacts. Some cards are problematic, try using a different one. Ensure that the card is fast enough to keep up with logging demands (Class 10 works for many, but lower speeds can work too). Reduce the amount of data included with the logs in LOG_BITMASK. Incrementally increase BRD_SD_SLOWDOWN up to a maximum of 32 (default is 0).

--- chunk_id: chunk-0042
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 340
content_hash: 0d577e4468a65d2a
prev_chunk_id: chunk-0041
next_chunk_id: chunk-0043
section_heading: On-Board DataFlash Logging
document_type: technical_reference

## On-Board DataFlash Logging 

Some boards do not have SD card interfaces for logging, but rather a limited amount of dataflash, typically 16MB. This saves log files in a manner like a circular buffer. Once the flash is filled, the oldest log file is overwritten with the current logging data. If there is only one file on the flash when space runs out, logging is stopped instead. A new log file will be started after boot, upon arming, or, immediately if LOG_DISARMED is 1. If LOG_FILE_DSRMROT is enabled, any disarm will stop logging and a new file started upon the next arm or immediately if LOG_DISARMED is 1. Otherwise, logging to the current file will resume on a re-arm. Any reboot stops logging to the current file. In order to maximize the utility of the limited flash space several things can be done:

Reduce the things logged using LOG_BITMASK . Eliminate logging the EKF3 messages which are voluminous and usually needed only for problem diagnosis using the EK3_LOG_LEVEL parameter. Only log when needed during the flight, ie tuning, gathering data for TECS tuning, etc. using an RC Aux switch set to “164” to start and stop log writes. Reduce the logging rate to a slower rate (below 10Hz) by setting LOG_BLK_RATEMAX which is by default unrestricted. Download and erase the logs each flight and only log one file for a flight

Note

some dataflash chips are particularly slow, leading to gaps in the logs. Setting LOG_BLK_RATEMAX to a lower value can help eliminate these gaps.

--- chunk_id: chunk-0043
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 2f2134164c0fc196
prev_chunk_id: chunk-0042
next_chunk_id: chunk-0044
section_heading: Downloading logs via MAVLink
document_type: technical_reference

## Downloading logs via MAVLink 

Connect your vehicle to the ground station using the micro USB cable

Open the Mission Planner’s Flight Data screen

On the bottom left, select the “DataFlash Logs” tab and push the
“Download DataFlash Log Via Mavlink” button

Then, select the log you want to download. This will save that log to
your MissionPlanner/logs directory, in a folder named after the vehicle
type, such as QUADCOPTER. ### Review a log 
For more detailed analysis, click on “Review a Log” and select a log
that you’ve already saved to the MissionPlanner/logs directory. Once
again, they will be in folders named after the vehicle type, such as
QUADCOPTER or ROVER. ### Steps to review a log downloaded from the internet, or your vehicle 

For DataFlash logs, with a .bin or .log extension:

Download the log file. Note the place on your computer to which it is downloaded. (For example, it might be C:\Downloads)

Open Mission Planner

Navigate to the “Flight Data” page (top left)

Select the “Dataflash Logs” tab (mid-screen, left side)

Select the “Review a Log” button. A standard Windows “select a file” box will let you go find the .bin file that you downloaded, at the place that you downloaded it. (Per the example above, it is in C:\Downloads) Choose that file. After reading the log, a Manual Log Review window will be open, which allows you to plot data from the log for inspection. (see below)

### Reviewing the log data 

Once you pick the log you want, you will get charts
such as the below. The basic format of the dataflash is:

Line numbers appear on the very left side of the viewer

Software version and board type appear at the top

FMT messages are next which tell the mission planner the column
headers for each message type

PARM rows which show each parameter (in the order in which they
appear in the eeprom) along with their value at the beginning of the
flight

Flight data messages including GPS, IMU, etc. Graph any flight data by first clicking on the appropriate row, you
should see the column headers update appropriately. Next find the column
you wish to graph, click on it and then push the “Graph this data”
button. In the example above the ATT’s Roll-In and Roll data have been
graphed.

--- chunk_id: chunk-0044
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 180
content_hash: 63707c2b33248621
prev_chunk_id: chunk-0043
next_chunk_id: chunk-0045
section_heading: Downloading logs via MAVLink
document_type: technical_reference

Next find the column
you wish to graph, click on it and then push the “Graph this data”
button. In the example above the ATT’s Roll-In and Roll data have been
graphed. The mouse’s scroll wheel can be used to zoom in or out. You may
also select an area of the graph to zoom in on it. Zoom out by
right-mouse-button clicking and selecting “Set Scale to Default”. Here’s 
a mini tutorial on using this feature. You may also filter on just the
first column (the flight data message type) by clicking on the first
column and selecting the message type from the drop-down. This is very
useful especially for viewing the different flight modes (called “MODE”
messages) used during the mission. Click the first column again but
press “Cancel” to clear the filter.

--- chunk_id: chunk-0045
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 216
content_hash: e74bf4bdbcf5731e
prev_chunk_id: chunk-0044
next_chunk_id: chunk-0046
section_heading: Setting what data you want recorded
document_type: technical_reference

## Setting what data you want recorded 

The LOG_BITMASK parameter controls what messages are recorded in the logs. The bits differ between vehicles. The image above is for Copter. ### Bitmask Table (Plane) 

Bit

BitMask Name

What is logged if bit is set

0

Fast Attitude

Attitude &#64; 25Hz

1

Medium Attitude

Attitude &#64; 10Hz

2

GPS

GPS

3

System Performance

CPU,etc. Performance monitoring

4

Control Tuning

Control Data

5

Navigation Tuning

Navigation Data

7

IMU

IMU (ACC/Gyro) Data

8

Mission Commands

Mission/GCS Commands

9

Battery Monitor

Battery Monitors data

10

Compass

Compasses Data

11

TECS

Speed/Height Controller Data

12

Camera

Camera Data (if present)

13

RC Input &amp; Output

RC input/Servo output data

14

Rangefinder

Rangefinder Data (if present)

19

Raw IMU

Raw IMU data, unprocessed

20

Full Rate Attitude

Attitude at SCHED_LOOP_RATE 

21

Video Stabilization

GyroFlow Data logs

ATTITUDE logging will occur at highest rate of the selections. Note

the logging of EKF3 data is controlled by the EK3_LOG_LEVEL parameter.

--- chunk_id: chunk-0046
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 216
content_hash: 52998db0ee89d05e
prev_chunk_id: chunk-0045
next_chunk_id: chunk-0047
section_heading: Message Details (Copter specific)
document_type: technical_reference

## Message Details (Copter specific) 

Note

Many messages are detailed in the Onboard Message Log Messages page in each vehicle’s wiki section. ATT (attitude information): 

DesRoll

The pilot’s desired roll angle in degrees (roll left is negative, right is positive)

Roll

The vehicle’s actual roll in degrees (roll left is negative, right is positive)

DesPitch

The pilot’s desired pitch angle in degrees (pitch forward is negative, pitch back is positive)

Pitch

The vehicle’s actual pitch angle in degrees (pitch forward is negative, pitch back is positive)

DesYaw

The pilot’s desired heading in degrees with 0 = north

Yaw

The vehicle’s actual heading in degrees with 0 = north

ErrRP

The average size of the roll/pitch error estimate (values between 0 and 1)

ErrYaw

The average size of the yaw error estimate (values between 0 and 1)

ATUN (auto tune overview): 

Axis: 0 = Roll, 1 = Pitch

TuneStep

0 = Returning towards Level (before
or after a test), 1 = Testing (i.e.

--- chunk_id: chunk-0047
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 540
content_hash: 59ac9f07002b2cef
prev_chunk_id: chunk-0046
next_chunk_id: chunk-0048
section_heading: Message Details (Copter specific)
document_type: technical_reference

## Message Details (Copter specific) 

Note

Many messages are detailed in the Onboard Message Log Messages page in each vehicle’s wiki section. ATT (attitude information): 

DesRoll

The pilot’s desired roll angle in degrees (roll left is negative, right is positive)

Roll

The vehicle’s actual roll in degrees (roll left is negative, right is positive)

DesPitch

The pilot’s desired pitch angle in degrees (pitch forward is negative, pitch back is positive)

Pitch

The vehicle’s actual pitch angle in degrees (pitch forward is negative, pitch back is positive)

DesYaw

The pilot’s desired heading in degrees with 0 = north

Yaw

The vehicle’s actual heading in degrees with 0 = north

ErrRP

The average size of the roll/pitch error estimate (values between 0 and 1)

ErrYaw

The average size of the yaw error estimate (values between 0 and 1)

ATUN (auto tune overview): 

Axis: 0 = Roll, 1 = Pitch

TuneStep

0 = Returning towards Level (before
or after a test), 1 = Testing (i.e. performing a twitch to test
response), 2 = Updating gains
(twitch completed and gains
adjusted)

RateMin

Minimum recorded rate during this
test

RateMax

Maximum recorded rate during this
test

RPGain

Rate P gain value being tested

RDGain

Rate D gain value being tested

SPGain

Stabilize P gain being tested

ATDE (auto tune step details): 

Angle

Angle of the copter in centi-degrees for the axis being testedx

Rate

Rate of rotation of the copter for the axis being tested

CAM (time and position when camera shutter was activated): 

GPSTime

The GPS reported time since epoch in milliseconds

Lat

The accelerometer + GPS latitude estimate

Lng

The accelerometer + GPS longitude estimate

Alt

The accelerometer + barometer estimated altitude in cm above ground

Roll

The vehicle roll angle in centi-degrees

Pitch

The vehicle pitch angle in centi-degrees

Yaw

The vehicle’s heading in centi-degrees

CMD (commands received from the ground station or executed as part of
a mission): 

CTot

The total number of commands in the mission

CNum

This command’s number in the mission (0 is always home, 1 is the first command, etc)

CId

The MAVLink message id 

Copt

The option parameter (used for many different purposes)

Prm1

The command’s parameter (used for many different purposes)

Alt

The command’s altitude in meters

Lat

The command’s latitude position

Lng

The command’s longitude position

COMPASS (raw compass, offset and compassmot compensation values): 

Field

Description

MagX, MagY, MagZ

Raw magnetic field values for x, y, and z axis.

--- chunk_id: chunk-0048
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 525
content_hash: 3d1005bf52c3bf8f
prev_chunk_id: chunk-0047
next_chunk_id: chunk-0049
section_heading: Message Details (Copter specific)
document_type: technical_reference

ATT (attitude information): 

DesRoll

The pilot’s desired roll angle in degrees (roll left is negative, right is positive)

Roll

The vehicle’s actual roll in degrees (roll left is negative, right is positive)

DesPitch

The pilot’s desired pitch angle in degrees (pitch forward is negative, pitch back is positive)

Pitch

The vehicle’s actual pitch angle in degrees (pitch forward is negative, pitch back is positive)

DesYaw

The pilot’s desired heading in degrees with 0 = north

Yaw

The vehicle’s actual heading in degrees with 0 = north

ErrRP

The average size of the roll/pitch error estimate (values between 0 and 1)

ErrYaw

The average size of the yaw error estimate (values between 0 and 1)

ATUN (auto tune overview): 

Axis: 0 = Roll, 1 = Pitch

TuneStep

0 = Returning towards Level (before
or after a test), 1 = Testing (i.e. performing a twitch to test
response), 2 = Updating gains
(twitch completed and gains
adjusted)

RateMin

Minimum recorded rate during this
test

RateMax

Maximum recorded rate during this
test

RPGain

Rate P gain value being tested

RDGain

Rate D gain value being tested

SPGain

Stabilize P gain being tested

ATDE (auto tune step details): 

Angle

Angle of the copter in centi-degrees for the axis being testedx

Rate

Rate of rotation of the copter for the axis being tested

CAM (time and position when camera shutter was activated): 

GPSTime

The GPS reported time since epoch in milliseconds

Lat

The accelerometer + GPS latitude estimate

Lng

The accelerometer + GPS longitude estimate

Alt

The accelerometer + barometer estimated altitude in cm above ground

Roll

The vehicle roll angle in centi-degrees

Pitch

The vehicle pitch angle in centi-degrees

Yaw

The vehicle’s heading in centi-degrees

CMD (commands received from the ground station or executed as part of
a mission): 

CTot

The total number of commands in the mission

CNum

This command’s number in the mission (0 is always home, 1 is the first command, etc)

CId

The MAVLink message id 

Copt

The option parameter (used for many different purposes)

Prm1

The command’s parameter (used for many different purposes)

Alt

The command’s altitude in meters

Lat

The command’s latitude position

Lng

The command’s longitude position

COMPASS (raw compass, offset and compassmot compensation values): 

Field

Description

MagX, MagY, MagZ

Raw magnetic field values for x, y, and z axis. These are magnetometer readings with
calibration applied, not raw magnetometer readings.

--- chunk_id: chunk-0049
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 398
content_hash: 9e7d4c37cee4674c
prev_chunk_id: chunk-0048
next_chunk_id: chunk-0050
section_heading: Message Details (Copter specific)
document_type: technical_reference

performing a twitch to test
response), 2 = Updating gains
(twitch completed and gains
adjusted)

RateMin

Minimum recorded rate during this
test

RateMax

Maximum recorded rate during this
test

RPGain

Rate P gain value being tested

RDGain

Rate D gain value being tested

SPGain

Stabilize P gain being tested

ATDE (auto tune step details): 

Angle

Angle of the copter in centi-degrees for the axis being testedx

Rate

Rate of rotation of the copter for the axis being tested

CAM (time and position when camera shutter was activated): 

GPSTime

The GPS reported time since epoch in milliseconds

Lat

The accelerometer + GPS latitude estimate

Lng

The accelerometer + GPS longitude estimate

Alt

The accelerometer + barometer estimated altitude in cm above ground

Roll

The vehicle roll angle in centi-degrees

Pitch

The vehicle pitch angle in centi-degrees

Yaw

The vehicle’s heading in centi-degrees

CMD (commands received from the ground station or executed as part of
a mission): 

CTot

The total number of commands in the mission

CNum

This command’s number in the mission (0 is always home, 1 is the first command, etc)

CId

The MAVLink message id 

Copt

The option parameter (used for many different purposes)

Prm1

The command’s parameter (used for many different purposes)

Alt

The command’s altitude in meters

Lat

The command’s latitude position

Lng

The command’s longitude position

COMPASS (raw compass, offset and compassmot compensation values): 

Field

Description

MagX, MagY, MagZ

Raw magnetic field values for x, y, and z axis. These are magnetometer readings with
calibration applied, not raw magnetometer readings. OfsX, OfsY, OfsZ

Raw magnetic offsets (will only change if COMPASS_LEARN parameter is 1)

MOfsX, MOfsY, MOfsZ

Compassmot compensation for throttle or current

CURRENT (battery voltage, current and board voltage information): 

FIELD

DESCRIPTION

Thr

Pilot input throttle from 0 ~ 1000

ThrInt

Integrated throttle (i.e.

--- chunk_id: chunk-0050
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: d89083c19724b4b4
prev_chunk_id: chunk-0049
next_chunk_id: chunk-0051
section_heading: Message Details (Copter specific)
document_type: technical_reference

These are magnetometer readings with
calibration applied, not raw magnetometer readings. OfsX, OfsY, OfsZ

Raw magnetic offsets (will only change if COMPASS_LEARN parameter is 1)

MOfsX, MOfsY, MOfsZ

Compassmot compensation for throttle or current

CURRENT (battery voltage, current and board voltage information): 

FIELD

DESCRIPTION

Thr

Pilot input throttle from 0 ~ 1000

ThrInt

Integrated throttle (i.e. sum of total throttle output for this flight)

Volt

Battery voltage in volts * 100

Curr

Current drawn from the battery in amps * 100

Vcc

Board voltage

CurrTot

Total current drawn from battery

CTUN (Control, Throttle and altitude information): 

FIELD

DESCRIPTION

TimeUS

Time stamp for messages in microseconds (can be ignored)

ThI

The pilot’s throttle in as a number from 0 to 1000

ABst

Angle Boost: throttle increase (from 0 ~ 1000) as a result of the copter leaning over
(automatically added to all pilot and autopilot throttle to reduce altitude loss while leaning)

ThO

Final throttle output sent to the motors (from 0 ~ 1000). Normally equal to ThrI+ABst while
in stabilize mode. ThH

Estimated throttle required to hover throttle in the range 0 ~ 1

DAlt

The Desired Altitude while in AltHold, Loiter, RTL or Auto flight modes. It is influenced by EKF origin, which in 3.5.X is corrected by GPS altitude. This behaviour is
turned off in 3.6.X and can be turned on with EKF_OGN_HGT_MASK. Alt

The current EKF Altitude

BAlt

Barometer Altitude: The altitude above ground according to the barometer

DSAlt

Desired distance in cm from ground or ceiling (only visible if Sonar is available)

SAlt

Sonar Altitude: the altitude above ground according to the sonar
(Only visible of Sonar is available)

TAlt

Terrain altitude (not used by default)

DCRt

Desired Climb Rate in cm/s

CRt

Climb Rate in cm/s

N

Harmonic notch current center frequency for gyro in Hz

D32, DU32 (single data values which are either signed 32bit integers
or unsigned 32bit integers): 

FIELD

DESCRIPTION

id

Identification number for the variable. There are only two possible values:

7 = bit mask of internal state (The meaning of individual bits can be found in the def’n of the
ap structure 

9 = simple mode’s initial heading in centi-degrees

EKF (Extended Kalman Filter ):

Log information here 
(Dev Wiki). Overview here .

--- chunk_id: chunk-0051
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 326
content_hash: 63766849b3c5679b
prev_chunk_id: chunk-0050
next_chunk_id: chunk-0052
section_heading: Message Details (Copter specific)
document_type: technical_reference

There are only two possible values:

7 = bit mask of internal state (The meaning of individual bits can be found in the def’n of the
ap structure 

9 = simple mode’s initial heading in centi-degrees

EKF (Extended Kalman Filter ):

Log information here 
(Dev Wiki). Overview here . ERR (an error message): 

SubSystem and Error codes listed below

Subsys 
ECode and Description 

2 = Radio 

0 = Errors Resolved

2 = Late Frame : no updates received from receiver for two seconds

3 = Compass 

0 = Errors Resolved

1 = Failed to initialise (probably a hardware issue)

4 = Unhealthy : failed to read from the sensor

5 = Radio Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

6 = Battery Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

8 = GCS Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

9 = Fence Failsafe 

0 = Failsafe Resolved

1 = Altitude fence breach, Failsafe Triggered

2 = Circular fence breach, Failsafe Triggered

3 = Both Alt and Circular fence breached, Failsafe Triggered

4 = Polygon fence breached, Failsafe Triggered

10 = Flight mode Change failure 
Vehicle was unable to enter the desired flight mode normally because of a bad position estimate

See flight mode numbers here 

11 = GPS 

0 = Glitch cleared

2 = GPS Glitch occurred

12 = Crash Check 

1 = Crash into ground detected. Normally vehicle is disarmed soon after

2 = Loss of control detected.

--- chunk_id: chunk-0052
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 665
content_hash: c200e8c53e7e5edb
prev_chunk_id: chunk-0051
next_chunk_id: chunk-0053
section_heading: Message Details (Copter specific)
document_type: technical_reference

ERR (an error message): 

SubSystem and Error codes listed below

Subsys 
ECode and Description 

2 = Radio 

0 = Errors Resolved

2 = Late Frame : no updates received from receiver for two seconds

3 = Compass 

0 = Errors Resolved

1 = Failed to initialise (probably a hardware issue)

4 = Unhealthy : failed to read from the sensor

5 = Radio Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

6 = Battery Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

8 = GCS Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

9 = Fence Failsafe 

0 = Failsafe Resolved

1 = Altitude fence breach, Failsafe Triggered

2 = Circular fence breach, Failsafe Triggered

3 = Both Alt and Circular fence breached, Failsafe Triggered

4 = Polygon fence breached, Failsafe Triggered

10 = Flight mode Change failure 
Vehicle was unable to enter the desired flight mode normally because of a bad position estimate

See flight mode numbers here 

11 = GPS 

0 = Glitch cleared

2 = GPS Glitch occurred

12 = Crash Check 

1 = Crash into ground detected. Normally vehicle is disarmed soon after

2 = Loss of control detected. Normally parachute is released soon after

13 = Flip mode 
2 = Flip abandoned (not armed, pilot input or timeout) 

15 = Parachute 

2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check 

0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer 

0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe 

0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data 
2 = missing terrain data 

22 = Navigation 

2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed 

0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check 

0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub) 

0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub) 

0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only) 

0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe 

0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated

EV: (an event number) .

--- chunk_id: chunk-0053
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 612
content_hash: 4a5becef01a4213e
prev_chunk_id: chunk-0052
next_chunk_id: chunk-0054
section_heading: Message Details (Copter specific)
document_type: technical_reference

Normally vehicle is disarmed soon after

2 = Loss of control detected. Normally parachute is released soon after

13 = Flip mode 
2 = Flip abandoned (not armed, pilot input or timeout) 

15 = Parachute 

2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check 

0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer 

0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe 

0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data 
2 = missing terrain data 

22 = Navigation 

2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed 

0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check 

0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub) 

0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub) 

0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only) 

0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe 

0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated

EV: (an event number) . The full list of possible events can be found
in AP_Logger.h 
but the most common are:

Event No

DESCRIPTION

10

Armed

11

Disarmed

15

Auto Armed (pilot has raised throttle above zero and autopilot is free to take control of throttle)

18

Land Complete

25

Set Home (home location coordinates have been capture)

28

Not Landed (aka Takeoff complete)

GPA: (Global Position Accuracy) 

FIELD

DESCRIPTION

VDop

Vertical dilution of precision, a unitless measure of precision
https://en.wikipedia.org/wiki/Dilution_of_precision 

HAcc

Horizontal Accuracy as reported by the GPS module, in meters

VAcc

Vertical Accuracy as reported by the GPS module, in meters

SAcc

Speed accuracy as reported by the GPS, in m/s/s

VV

Flag to indicate if the GPS is reporting vertical velocity 0 No vertical velocity data
1 GPS has vertical velocity data

SMS

The autopilot time in milliseconds that the accuracy/GPS position data is associated with.

--- chunk_id: chunk-0054
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 810
content_hash: 4a6fa28c4fe6e982
prev_chunk_id: chunk-0053
next_chunk_id: chunk-0055
section_heading: Message Details (Copter specific)
document_type: technical_reference

Normally parachute is released soon after

13 = Flip mode 
2 = Flip abandoned (not armed, pilot input or timeout) 

15 = Parachute 

2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check 

0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer 

0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe 

0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data 
2 = missing terrain data 

22 = Navigation 

2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe 

0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed 

0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check 

0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub) 

0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub) 

0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only) 

0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe 

0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated

EV: (an event number) . The full list of possible events can be found
in AP_Logger.h 
but the most common are:

Event No

DESCRIPTION

10

Armed

11

Disarmed

15

Auto Armed (pilot has raised throttle above zero and autopilot is free to take control of throttle)

18

Land Complete

25

Set Home (home location coordinates have been capture)

28

Not Landed (aka Takeoff complete)

GPA: (Global Position Accuracy) 

FIELD

DESCRIPTION

VDop

Vertical dilution of precision, a unitless measure of precision
https://en.wikipedia.org/wiki/Dilution_of_precision 

HAcc

Horizontal Accuracy as reported by the GPS module, in meters

VAcc

Vertical Accuracy as reported by the GPS module, in meters

SAcc

Speed accuracy as reported by the GPS, in m/s/s

VV

Flag to indicate if the GPS is reporting vertical velocity 0 No vertical velocity data
1 GPS has vertical velocity data

SMS

The autopilot time in milliseconds that the accuracy/GPS position data is associated with. Delta

The time between when the previous GPS message and the current GPS message was parsed by the
autopilot, in milliseconds

GPS: 

FIELD

DESCRIPTION

Status

0 = no GPS, 1 = GPS but no fix, 2 = GPS with 2D fix, 3 = GPS with 3D fix

Time

The GPS reported time since epoch in milliseconds

NSats

The number of satellites current being used

HDop

A measure of gps precision (1.5 is good, &gt;2.0 is not so good)
https://en.wikipedia.org/wiki/Dilution_of_precision 

Lat

Latitude according to the GPS

Lng

Longitude according to the GPS

RelAlt

Accelerometer + Baro altitude in meters

Alt

GPS reported altitude (not used by the autopilot)

SPD

Horizontal ground speed in m/s

GCrs

Ground course in degrees (0 = north)

IMU (accelerometer and gyro information): 

FIELD

DESCRIPTION

GyrX, GyrY, GyrZ

The raw gyro rotation rates in radians/second

AccX, AccY, AccZ

The raw accelerometer values in m/s/s

Mode (flight mode): 

FIELD

DESCRIPTION

Mode

The flight mode displayed as a string (i.e.

--- chunk_id: chunk-0055
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 403169a8e43f733f
prev_chunk_id: chunk-0054
next_chunk_id: chunk-0056
section_heading: Message Details (Copter specific)
document_type: technical_reference

The full list of possible events can be found
in AP_Logger.h 
but the most common are:

Event No

DESCRIPTION

10

Armed

11

Disarmed

15

Auto Armed (pilot has raised throttle above zero and autopilot is free to take control of throttle)

18

Land Complete

25

Set Home (home location coordinates have been capture)

28

Not Landed (aka Takeoff complete)

GPA: (Global Position Accuracy) 

FIELD

DESCRIPTION

VDop

Vertical dilution of precision, a unitless measure of precision
https://en.wikipedia.org/wiki/Dilution_of_precision 

HAcc

Horizontal Accuracy as reported by the GPS module, in meters

VAcc

Vertical Accuracy as reported by the GPS module, in meters

SAcc

Speed accuracy as reported by the GPS, in m/s/s

VV

Flag to indicate if the GPS is reporting vertical velocity 0 No vertical velocity data
1 GPS has vertical velocity data

SMS

The autopilot time in milliseconds that the accuracy/GPS position data is associated with. Delta

The time between when the previous GPS message and the current GPS message was parsed by the
autopilot, in milliseconds

GPS: 

FIELD

DESCRIPTION

Status

0 = no GPS, 1 = GPS but no fix, 2 = GPS with 2D fix, 3 = GPS with 3D fix

Time

The GPS reported time since epoch in milliseconds

NSats

The number of satellites current being used

HDop

A measure of gps precision (1.5 is good, &gt;2.0 is not so good)
https://en.wikipedia.org/wiki/Dilution_of_precision 

Lat

Latitude according to the GPS

Lng

Longitude according to the GPS

RelAlt

Accelerometer + Baro altitude in meters

Alt

GPS reported altitude (not used by the autopilot)

SPD

Horizontal ground speed in m/s

GCrs

Ground course in degrees (0 = north)

IMU (accelerometer and gyro information): 

FIELD

DESCRIPTION

GyrX, GyrY, GyrZ

The raw gyro rotation rates in radians/second

AccX, AccY, AccZ

The raw accelerometer values in m/s/s

Mode (flight mode): 

FIELD

DESCRIPTION

Mode

The flight mode displayed as a string (i.e. STABILIZE, LOITER, etc)

ThrCrs

Throttle cruise (from 0 ~ 1000) which is the autopilot’s best guess as to what throttle
is required to maintain a stable hover

Rsn

Reason for mode change (TX command, failsafe, etc) . The meaning of code values can be found in
ModeReason 

NTUN (navigation information): 

FIELD

DESCRIPTION

WPDst

Distance to the next waypoint (or loiter target) in cm. Only updated while in Loiter, RTL, Auto.

--- chunk_id: chunk-0056
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: 98b5cef64b949baa
prev_chunk_id: chunk-0055
next_chunk_id: chunk-0057
section_heading: Message Details (Copter specific)
document_type: technical_reference

The meaning of code values can be found in
ModeReason 

NTUN (navigation information): 

FIELD

DESCRIPTION

WPDst

Distance to the next waypoint (or loiter target) in cm. Only updated while in Loiter, RTL, Auto. WPBrg

Bearing to the next waypoint in degrees

PErX

Distance to intermediate target between copter and the next waypoint in the latitude direction

PErY

Distance to intermediate target between copter and the next waypoint in the longitude direction

DVelX

Desired velocity in cm/s in the latitude direction

DVelY

Desired velocity in cm/s in the longitude direction

VelX

Actual accelerometer + gps velocity estimate in the latitude direction

VelY

Actual accelerometer + gps velocity estimate in the longitude direction

DAcX

Desired acceleration in cm/s/s in the latitude direction

DAcY

Desired acceleration in cm/s/s in the longitude direction

DRol

Desired roll angle in centi-degrees

DPit

Desired pitch angle in centi-degrees

PM (performance monitoring): 

FIELD

DESCRIPTION

NLon

Number of long running main loops (i.e. loops that take more than 20% longer
than they should according to SCHED_LOOP_RATE - ex. 3ms for 400Hz rate)

NLoop

The total number of loops since the last PM message was displayed. This allows you to calculate
the percentage of slow running loops (which should never be higher than 15%). Note that the
value will depend on the autopilot clock speed

MaxT

The maximum time that any loop took since the last PM message. This shouldn’t exceed 120% of
scheduler loop period, but will be much higher during the interval where the motors are armed

Mem

Available memory, in bytes

Load

Percentage (times 10) of the scheduler loop period when CPU is used

RCOUT (pwm output to individual RC outputs): 

RC1, RC2, etc : pwm command sent from autopilot to the
esc/motor/RC output

--- chunk_id: chunk-0057
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 129
content_hash: eb2a16d85194959e
prev_chunk_id: chunk-0056
next_chunk_id: chunk-0058
section_heading: Viewing KMZ FILES
document_type: technical_reference

## Viewing KMZ FILES 

When you download the dataflash log files from the autopilot it will
automatically create a KMZ file (file with extension .kmz). This file
can be opened with Google Earth (just double click the file) to view
your flight in Google Earth. Please see the instructions on the
Telemetry Logs Page 
for additional details. ### Video tutorials 
Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0058
source_document: common-loading-firmware-onto-pixhawk.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 342
content_hash: 49d0d4c9a43bf254
prev_chunk_id: chunk-0057
next_chunk_id: chunk-0059
section_heading: Common Loading Firmware Onto Pixhawk
document_type: technical_reference

# Common Loading Firmware Onto Pixhawk

Loading Firmware &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 
Install Ground Station Software 

Autopilot System Assembly 

Loading Firmware to boards with existing ArduPilot firmware 
Installation Steps 
Connect autopilot to computer 

Select the COM port 

Install firmware 

Using Beta, Developer, and Customized Versions 
Beta 

Latest Developer Version 

Custom Firmware Build Server 

Firmware Limitations 

Loading Firmware via SD Card 

Testing 
Loading Firmware via SD Card 

ArduPilot Custom Firmware Builder 

Loading Firmware to boards without existing ArduPilot firmware 

Connect Mission Planner to AutoPilot 

Configuration 

Airframe Specific Setup Guides 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Setup for Plane 

Loading Firmware

Edit on GitHub 

# Loading Firmware 

These instructions will show you how to download the latest firmware onto the autopilot hardware that already has ArduPilot firmware installed. This process will use the Mission Planner ground control station. See Loading Firmware onto boards without existing ArduPilot firmware . Note

for some autopilots, it may be possible to update the firmware by flashing from SD card

--- chunk_id: chunk-0059
source_document: common-loading-firmware-onto-pixhawk.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: 8f47836a3a606132
prev_chunk_id: chunk-0058
next_chunk_id: chunk-0060
section_heading: Installation Steps
document_type: technical_reference

## Installation Steps 
### Connect autopilot to computer 

Once you have installed a ground station on your computer, connect
the autopilot using a USB cable as shown
below. Use a direct USB port on your computer (not a USB hub). Pixhawk USB Connection 

Windows should automatically detect and install the correct driver
software. ### Select the COM port 

If using Mission Planner as the GCS, select the COM port drop-down in the upper-right corner of the window near the Connect button. Select AUTO or the specific port for your board. Set the Baud rate to 115200 as shown. Do not hit Connect just yet. ### Install firmware 

In Mission Planner’s SETUP | Install Firmware screen
select the appropriate icon that matches your vehicle or frame type(i.e. Quad, Hexa). Answer Yes when it asks you “Are you sure?”. Mission Planner: Install FirmwareScreen 

Note

some boards are specifically targeted to a particular vehicle type and firmware is not automatically built for other vehicles. However, ArduPilot could still be built for those other vehicles using the Custom Firmware Server . Mission Planner will try to detect which board you are using. It may ask you to unplug the board, press OK, and plug it back in to detect the board type. Mission Planner: Install Firmware Prompt 

Often you will be presented with a dropdown box of firmware variants for the board, which you can select from (such as bi-directional DShot variants, if available). For boards which share the Pixhawk board id, the list will be extensive, as shown below:

Select the appropriate firmware for your board. For boards marked “Pixhawk”, Pixhawk1 firmware is usually the best choice. Warning

some boards labeled as Pixhawk 2.4.x may have sensor substitutions which may lead to pre-arm checks or no secondary IMU. Please see the BARO_OPTIONS parameter for a workaround for a known sensor substitution on some boards of a MS5607 barometer where a MS5611 should be used. IMUs may also be substituted. Where possible, please source autopilots from ArduPilot partners. If all goes well, you will see a status appear on the bottom right including the words: “erase…”, “program…”, “verify..”, and “Upload Done”. The firmware has been successfully uploaded to the board. It usually takes a few seconds for the bootloader to exit and enter the main code after programming or a power-up.

--- chunk_id: chunk-0060
source_document: common-loading-firmware-onto-pixhawk.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: cfc06ef80fcc8c6d
prev_chunk_id: chunk-0059
next_chunk_id: chunk-0061
section_heading: Installation Steps
document_type: technical_reference

The firmware has been successfully uploaded to the board. It usually takes a few seconds for the bootloader to exit and enter the main code after programming or a power-up. Wait to press CONNECT until this occurs. Note

Updating the firmware to a newer version does not alter existing parameters unless the firmware is for a different vehicle, in which case parameters are reset to their default values for that vehicle. However, it is always a good idea to save your parameters to a file using the “Save to File” button on the Mission Planner’s CONFIG/Full Parameter Tree tab before any firmware updates, just in case of any issues while updating. Do not apply all parameters after upgrading to a new version as some parameters might have a different meaning.

--- chunk_id: chunk-0061
source_document: common-loading-firmware-onto-pixhawk.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: 47f1b95a85e3b0d7
prev_chunk_id: chunk-0060
next_chunk_id: chunk-0062
section_heading: Using Beta, Developer, and Customized Versions
document_type: technical_reference

## Using Beta, Developer, and Customized Versions 
### Beta 

Prior to Stable releases, Beta versions are released. These may be used if you wish to try newer features or help the developers flight test new code. Since these are “beta” versions, there may still be bugs. This is possible even in Stable release firmware. However, a Beta release has been tested by the development team, and already flight tested. This release allows a wider user base to final test the firmware before releasing as Stable . Experienced ArduPilot users are encouraged to test fly this firmware and provide feedback. Mission Planner has an option on the Install Firmware page to upload this release, but later Stable releases may already be available. Be sure to check the normal vehicle upload option first. ### Latest Developer Version 

This reflects the current state of the development branch of the ArduPilot code. It has been reviewed by the development team, passed all automated test suites, and in most cases test flown. This code gets built daily and is available for testing by experienced users. This corresponds to an “alpha” release, and may have bugs, although very rarely “crash inducing”. Very shortly after an addition that changes or introduces a feature is added, the Upcoming Features section of the Wiki is updated with information about the addition or change. This code must be manually downloaded from the Firmware Downloads page as latest for your particular board, and then uploaded using Mission Planner’s “Load Custom Firmware” option on its Install Firmware Page 

### Custom Firmware Build Server 

ArduPilot is currently experimentally testing a custom firmware build server that will allow users to generate firmware builds for their autopilots with selectable features. Since all 1MB flash sized boards now have feature restrictions to allow the code to fit, this will give a path to enable a user to select which features will or will not be included, giving some flexibility to users of 1MB autopilots. The server is located HERE and instructions for its use are on this page HERE . It allows creating a custom build, which can be downloaded, and flashed to the autopilot using Mission Planner’s “Load Custom Firmware” option on its Install Firmware Page .

--- chunk_id: chunk-0062
source_document: common-loading-firmware-onto-pixhawk.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 273
content_hash: 3df95ed2542bf2e7
prev_chunk_id: chunk-0061
next_chunk_id: chunk-0063
section_heading: Using Beta, Developer, and Customized Versions
document_type: technical_reference

The server is located HERE and instructions for its use are on this page HERE . It allows creating a custom build, which can be downloaded, and flashed to the autopilot using Mission Planner’s “Load Custom Firmware” option on its Install Firmware Page . connect the ground station PC to the autopilot using a USB cable

select the COM port and baud rate (normally 115200, but you can choose higher if your hardware allows) for the board. These are selected on the top right of the screen. Do not press the Connect button

go to MP firmware install screen (select “Setup &gt;&gt; Install Firmware”)

click the “Load custom firmware” link and select the .apj file you downloaded (do not select the .hex files, which are only meant to be used with DFU/JTAG/SWD methods). If the “Load custom firmware” link is not visible select “Config &gt;&gt; Planner” and set the “Layout” drop-down to “Advanced”. you may need to click on “Force bootloader” before the step above (assuming the board has been previously flashed with Ardupilot’s bootloader)

follow any instructions displayed regarding plugging/unplugging the board

if all goes well some status should be displayed at the bottom of the screen. i.e. “erase…”, “program…”, “verify..” and “Upload Done”.

--- chunk_id: chunk-0063
source_document: common-loading-firmware-onto-pixhawk.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 228
content_hash: 9a99fde963dc8d08
prev_chunk_id: chunk-0062
next_chunk_id: chunk-0064
section_heading: Firmware Limitations
document_type: technical_reference

## Firmware Limitations 

For a list of what features are not included in the current “latest” firmware for any given autopilot, see this page . All the feature options currently not included in the 1MB autopilots, by default, are on the list of options on the Custom Firmware Build Server. There are also many features still included in the 1MB autopilots that may not be required for your application. So it is possible to create a build that includes some of the currently excluded features while removing some of the unneeded features. The list of feature options will be continuously expanded, allowing other large features to be dropped and more restricted features added to the custom build. For example, not including QuadPlane features will save space for Planes not requiring it. Drivers and peripheral support may be individually selected, allowing only those used to be in the code thus allowing other features to be included in the custom firmware. Current build is from the daily master branch, Stable and Beta branches.

--- chunk_id: chunk-0064
source_document: common-loading-firmware-onto-pixhawk.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 174
content_hash: 0c6e8f31e1c3a611
prev_chunk_id: chunk-0063
next_chunk_id: chunk-0065
section_heading: Loading Firmware via SD Card
document_type: technical_reference

## Loading Firmware via SD Card 

The firmware on some autopilots may be uploaded by copying an ‘ardupilot.abin’ firmware file to the SD card and then power cycling the board. Details on how to update the firmware via SD Card can be found here . ### Testing 
You can test the firmware is working on a basic level by switching to the Mission Planner Flight Data screen and pressing the Connect button. The HUD should update as you tilt the board. Connect Mission Planner to AutoPilot has more
information on connecting to Mission Planner. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0065
source_document: common-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 210
content_hash: 60fe497c71853203
prev_chunk_id: chunk-0064
next_chunk_id: chunk-0066
section_heading: Common Logs
document_type: technical_reference

# Common Logs

Logs &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 
Logs 
Log Types (Dataflash vs Tlogs) 
Topics related to logging and analysis 

Tools for Log Analysis 

What to do if you have an issue 

Vehicle Will Not Arm 

Interference issues on Electric Vehicles 

Free RAM issues 

H7 AutoPilot Will Not Initialize 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

When Problems Arise 

Logs

Edit on GitHub 

# Logs

--- chunk_id: chunk-0066
source_document: common-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 281
content_hash: dc36eb785f481a3e
prev_chunk_id: chunk-0065
next_chunk_id: chunk-0067
section_heading: Log Types (Dataflash vs Tlogs)
document_type: technical_reference

## Log Types (Dataflash vs Tlogs) 

There are two ways to record your flight data. With some exceptions, the
two methods record very similar data but in different ways:

Dataflash logs are recorded on the autopilot (often to the SD card) so they must be downloaded from the autopilot after a flight

Telemetry logs (also known as “Tlogs”) are recorded by the ground station (i.e. Mission Planner) on the local PC when the autopilot is connected via a telemetry link 

If you are not yet familiar with the basics of these log files, first review the introductory pages to understand where these logs are stored and how you can download and view the information held within them. ### Topics related to logging and analysis 

Dataflash Logs 

Telemetry Logs 

Diagnosing problems using Logs 

Plane Log Messages 

Log Analysis Case Study: Fly-by-Wire 

Log Analysis Case Study: Turn Rate Adjustment 

Measuring Vibration 

Measuring Vibration with &quot;Batch Sampling&quot; 

Measuring Vibration with &quot;Raw IMU Logging&quot; (Preferred) 

### Tools for Log Analysis 

MAVExplorer 

ArduPilot WebTools 

MissionPLanner 

QGroundControl 

Dronee Plotter 

PlotJuggler 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0067
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 264
content_hash: 55d1ef1371cb0b4c
prev_chunk_id: chunk-0066
next_chunk_id: chunk-0068
section_heading: Common Mavlink Mission Command Messages Mav Cmd
document_type: technical_reference

# Common Mavlink Mission Command Messages Mav Cmd

Mission Commands &mdash; Mission Planner documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Mission Planner

Mission Planner Overview 

Installing Mission Planner 

Loading Firmware onto boards with existing ArduPilot firmware 

Loading Firmware onto boards without existing ArduPilot firmware (first time only) 

Connect Mission Planner to AutoPilot 

Mission Planning 
Planning a Mission with Waypoints and Events 

Mission Command List 
Overview 
Types of commands 

Frames of reference 

How accurate is the information? How to interpret the command parameters 

Using this information with a GCS 

Navigation commands 
MAV_CMD_NAV_WAYPOINT 

MAV_CMD_NAV_LOITER_UNLIM 

MAV_CMD_NAV_LOITER_TIME 

MAV_CMD_NAV_RETURN_TO_LAUNCH 

MAV_CMD_NAV_DELAY 

MAV_CMD_NAV_PAYLOAD_PLACE 

MAV_CMD_DO_JUMP 

MAV_CMD_JUMP_TAG 

MAV_CMD_DO_JUMP_TAG 

Conditional commands 
MAV_CMD_CONDITION_DELAY 

MAV_CMD_CONDITION_DISTANCE 

DO commands 
MAV_CMD_DO_CHANGE_SPEED 

MAV_CMD_DO_SET_HOME 

MAV_CMD_DO_SET_RELAY 

MAV_CMD_DO_REPEAT_RELAY 

MAV_CMD_DO_SET_SERVO 

MAV_CMD_DO_REPEAT_SERVO 

MAV_CMD_DO_SET_ROI, MAV_CMD_DOE_SET_ROI_LOOCATION, MAV_CMD_DO_SET_ROI_NONE 

MAV_CMD_DO_DIGICAM_CONFIGURE 

MAV_CMD_DO_DIGICAM_CONTROL 

MAV_CMD_DO_MOUNT_CONTROL 

MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW 

MAV_CMD_DO_SET_CAM_TRIGG_DIST 

MAV_CMD_DO_FENCE_ENABLE 

MAV_CMD_DO_AUX_FUNCTION 

MAV_CMD_DO_SET_RESUME_REPEAT_DIST 

MAV_CMD_STORAGE_FORMAT 

Camera Control in Auto Missions 

Rally Points 

DO_LAND_START 

DO_RETURN_PATH_START 

Geotagging Images with Mission Planner 

Rewind-on-resume 

Continue Mission After Landing 

Mission Planner Features/Screens 

OpenDroneID Panel 

Mission Planner Building

--- chunk_id: chunk-0068
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 86
content_hash: a5c0038b3c9f08e9
prev_chunk_id: chunk-0067
next_chunk_id: chunk-0069
document_type: technical_reference

Appendix 

Individual 
Partners 
SWAG Shop 

Mission Planner 

Mission Planning 

Mission Commands

Edit on GitHub 

# Mission Commands 

This article describes the mission commands that are supported by Copter, Plane, Sub and Rover when switched into Auto mode. Note

there are many other MAVLink commands that a GCS or other device can send to the autopilot. See the ArduPilot/navlink repository, or the documentation for your GCS.

--- chunk_id: chunk-0069
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 488
content_hash: 4933adec4b9f7bf2
prev_chunk_id: chunk-0068
next_chunk_id: chunk-0070
section_heading: Overview
document_type: technical_reference

## Overview 

The MAVLink protocol defines a large number of
MAV_CMD 
waypoint command types (sent in a MAVLink_mission_item_message ). ArduPilot implements handling for the subset of these commands and
command parameters that are most relevant and meaningful for each of
the vehicles. Unsupported commands that are sent to a particular
autopilot will simply be dropped. This article lists and describes the commands and command-parameters
that are supported on each of the vehicle types. Any parameter that is
“grey” is not supported by the autopilot and will be ignored. They are
still documented to make it clear which properties are supported by
the MAV_CMD protocol 
are not implemented by the vehicle. Some commands and command parameters are not implemented because they
are not relevant for particular vehicle types (for example
“MAV_CMD_NAV_TAKEOFF” command makes sense for Plane and Copter but
not Rover and the pitch parameter only makes sense for Plane). There
are also some potentially useful command parameters that are not handled
because there is a limit to the message size, and a decision has been
made to prioritize some parameters over others. Note

There is additional information about the supported commands on
Copter (from a Mission Planner perspective) in the Copter Mission Command List . ### Types of commands 

There are several different types of commands that can be used within
missions:

Navigation commands are used to control the movement of the vehicle,
including takeoff, moving to and around waypoints, changing altitude,
and landing. DO commands are for auxiliary functions and do not affect the
vehicle’s position (for example, setting the camera trigger distance,
or setting a servo value). Condition commands are used to delay DO commands until some condition
is met, for example, the UAV reaches a certain altitude or distance
from the waypoint. During a mission at most one “Navigation” command and one “Do” or
“Condition” command can be running at one time. A typical mission might
set a waypoint (NAV command), add a CONDITION command that doesn’t
complete until a certain distance from the destination
( MAV_CMD_CONDITION_DISTANCE ), and
then add a number of DO commands that are executed sequentially (for
example
MAV_CMD_DO_SET_CAM_TRIGG_DIST 
to take pictures at regular intervals) when the condition completes.

--- chunk_id: chunk-0070
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 9a2c1b46a8a366d5
prev_chunk_id: chunk-0069
next_chunk_id: chunk-0071
section_heading: Overview
document_type: technical_reference

During a mission at most one “Navigation” command and one “Do” or
“Condition” command can be running at one time. A typical mission might
set a waypoint (NAV command), add a CONDITION command that doesn’t
complete until a certain distance from the destination
( MAV_CMD_CONDITION_DISTANCE ), and
then add a number of DO commands that are executed sequentially (for
example
MAV_CMD_DO_SET_CAM_TRIGG_DIST 
to take pictures at regular intervals) when the condition completes. Note

CONDITION and DO commands are associated with the preceding NAV
command: if the UAV reaches the next waypoint before these commands are
executed, the next NAV command is loaded and they will be
skipped. ### Frames of reference 

Many of the commands (in particular the NAV_ commands ) include position/location
information. The information is provided relative to a particular “frame
of reference”, which is specified in the message’s Frames of reference field. Copter and Rover Mission use MAV_CMD_DO_SET_HOME command to set the
“home position” in the global coordinate frame (MAV_FRAME_GLOBAL),
WGS84 coordinate system , where
the altitude is relative to mean sea level. All other commands use the
MAV_FRAME_GLOBAL_RELATIVE_ALT frame, which uses the same latitude
and longitude, but sets altitude as relative to the home position 
(home altitude = 0). Plane commands can additionally use MAV_FRAME_GLOBAL_TERRAIN_ALT
frame of reference. This again has the same WGS84 frame of reference for
latitude/longitude, but specifies altitude relative to ground height (as
defined in a terrain database). Note

The other frame types are defined in the MAVLink protocol (see
MAV_FRAME )
are not supported for mission commands. ### How accurate is the information? If a command or parameter is marked as supported then it is likely (but
not guaranteed) that it will behave as indicated. If a command or
parameter is not listed (or marked as not supported) then it is
extremely likely that it is not supported on ArduPilot. The reason for this is that the information was predominantly inferred
by inspecting the command handlers for messages:

The switch statement in AP_Mission::mavlink_to_mission_cmd 
was inspected to determine which commands are handled by all 
vehicle platforms, and which parameters from the message are stored. The command handler switch for each vehicle type
( Plane ,
Copter ,
Rover )
tells us which commands are likely to be supported in each vehicle
and which parameters are passed to the handler.

--- chunk_id: chunk-0071
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 449
content_hash: 387db8b212b27918
prev_chunk_id: chunk-0070
next_chunk_id: chunk-0072
section_heading: Overview
document_type: technical_reference

The reason for this is that the information was predominantly inferred
by inspecting the command handlers for messages:

The switch statement in AP_Mission::mavlink_to_mission_cmd 
was inspected to determine which commands are handled by all 
vehicle platforms, and which parameters from the message are stored. The command handler switch for each vehicle type
( Plane ,
Copter ,
Rover )
tells us which commands are likely to be supported in each vehicle
and which parameters are passed to the handler. The above checks give a very accurate picture of what commands and
parameters are not supported. They give a fairly accurate picture of
what commands/parameters are likely to be supported . However, this
indication is not guaranteed to be accurate because a command handler
could just throw away all the information (and we have not fully checked
all of these). In addition to the above checks, we have also merged information from
the Copter Mission Command List . ### How to interpret the command parameters 

The parameters for each command are listed in a table. The parameters
that are “greyed out” are not supported. The command field column (param
name) uses “bold” text to indicate those parameters that are defined in
the protocol (normal text is used for “empty” parameters). This allows users/developers to see both what is supported, and what
protocol fields are not supported in ArduPilot. ### Using this information with a GCS 

Mission Planner (MP) exposes the full subset of commands and
parameters supported by ArduPilot, filtered to display just those
relevant to the currently connected vehicle. Mapping the MP commands to
this documentation is easy, because it simply names commands using a
cut-down version of the full command name (e.g. DO_SET_SERVO rather
than the full command name: MAV_CMD_DO_SET_SERVO ). In addition, this
document conveniently lists the column label used by Mission Planner
alongside each of the parameters. Other GCSs (APM Planner 2, Tower etc.) may support some other subset of
commands/parameters and use alternative names/labels for them. In most
cases, the mapping should be obvious.

--- chunk_id: chunk-0072
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 498
content_hash: 81e970c2da0b79b5
prev_chunk_id: chunk-0071
next_chunk_id: chunk-0073
section_heading: Navigation commands
document_type: technical_reference

## Navigation commands 

Navigation commands are used to control the movement of the vehicle,
including takeoff, moving to and around waypoints, and landing. NAV commands have the highest priority. Any DO_ and CONDITION_
commands that have not executed when a NAV command is loaded are skipped
(for example, if a waypoint completes and the NAV command for another
waypoint is loaded, and unexecuted DO/CONDITION commands associated with
the first waypoint are dropped. ### MAV_CMD_NAV_WAYPOINT 

Supported by: All vehicles. Navigate to the specified position. ### MAV_CMD_NAV_LOITER_UNLIM 

Supported by: All vehicles. Loiter at the specified location for an unlimited amount of time. ### MAV_CMD_NAV_LOITER_TIME 

Supported by: Copter, Plane, Rover. ### MAV_CMD_NAV_RETURN_TO_LAUNCH 

Supported by: All vehicles. Return to the home location or the nearest Rally
Point , if closer. The home location is where
the vehicle was last armed (or when it first gets GPS lock after arming
if the vehicle configuration allows this). ### MAV_CMD_NAV_DELAY 

Supported by: Copter, Rover, Plane. ### MAV_CMD_NAV_PAYLOAD_PLACE 

Supported by: Copter and Plane. [wiki site=”copter,plane”]
Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Maximum Descent 
meters 

param2 

Empty 

param3 

Empty 

param4 

Empty 

param5 
Lat 
Latitude. param6 
Long 
Longitude 

param7 
Alt 
Altitude 

[/site]

### MAV_CMD_DO_JUMP 

Supported by: All vehicles. Jump to the specified command in the mission list. The jump command can
be repeated either a specified number of times before continuing the
mission, or it can be repeated indefinitely. Tip

Despite the name, this command is really a “NAV_” command rather
than a “DO_” command. Conditional commands like CONDITION_DELAY don’t
affect DO_JUMP (it will always perform the jump as soon as it reaches
the command). Note

There can be a maximum of 15 jump commands in a mission after which new DO_JUMP commands are ignored. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
WP# 
The command index/sequence number of the command to jump to. param2 
Repeat# 
Number of times that the DO_JUMP command will execute before moving to
the next sequential command. However, if MIS_OPTIONS bit 2 is not set, then the repeat count will be used again if the command is encountered again after the last repeat. If the value is zero the next command will
execute immediately. A value of -1 will cause the command to repeat
indefinitely.

--- chunk_id: chunk-0073
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 468
content_hash: 09e17b75d8c74025
prev_chunk_id: chunk-0072
next_chunk_id: chunk-0074
section_heading: Navigation commands
document_type: technical_reference

If the value is zero the next command will
execute immediately. A value of -1 will cause the command to repeat
indefinitely. param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission Planner Settings for DO_JUMP command 

In the example above the vehicle would fly back-and-forth between
waypoints #1 and #2 a total of 3 times before flying on to waypoint #4. ### MAV_CMD_JUMP_TAG 

Supported by: Copter, Plane, Rover. This is a location marker in the mission command sequence that can be used as a “jump to” location for the MAV_CMD_DO_JUMP_TAG command. The tag id in its parameter field can be any arbitrary number between 1 and 65535. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Tag# 
The tag number for the DO_JUMP_TAG command. param2 

Empty 

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

### MAV_CMD_DO_JUMP_TAG 

Supported by: Copter, Plane, Rover. Jump to the specified MAV_CMD_JUMP_TAG item in the mission list. The jump tag command can be repeated, either a specified number of times before continuing the
mission, or it can be repeated indefinitely. Tip

Despite the name, this command is really a “NAV_” command rather
than a “DO_” command. Conditional commands like CONDITION_DELAY don’t
affect DO_JUMP (it will always perform the jump as soon as it reaches
the command). Note

There can be a maximum of 15 jump_tag commands in a mission after which new DO_JUMP_TAG commands are ignored. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
WP# 
The tag number of the JUMP_TAG item to jump to. param2 
Repeat# 
Number of times that the DO_JUMP_TAG command will execute before moving to
the next sequential command. If the value is zero the next command will
execute immediately. A value of -1 will cause the command to repeat
indefinitely. param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission Planner Settings for DO_JUMP_TAG command 

In the example above, the vehicle would fly back-and-forth between waypoints #3 and #4 a total of 3 times before completing the mission. This is because the DO_JUMP_TAG redirects the vehicle to JUMP_TAG #565 twice.

--- chunk_id: chunk-0074
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 396
content_hash: 32a4334661477a1e
prev_chunk_id: chunk-0073
next_chunk_id: chunk-0075
section_heading: Conditional commands
document_type: technical_reference

## Conditional commands 

Conditional commands control the execution of _DO_ commands. For
example, a conditional command can prevent DO commands from executing based
on a time delay, until the vehicle is at a certain altitude, or at a
specified distance from the next target position. A conditional command may not be complete before reaching the next
waypoint. In this case, any unexecuted _DO_ commands associated with
the last waypoint will be skipped. ### MAV_CMD_CONDITION_DELAY 

Supported by: All vehicles. After reaching a waypoint, delay the execution of the next conditional
“_DO_” command for the specified number of seconds (e.g. MAV_CMD_DO_SET_ROI ). Note

This command does not stop the vehicle. If the vehicle reaches the
next waypoint before the delay timer completes, the delayed “_DO_”
commands will never trigger. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Time (sec) 
Delay in seconds (decimal). param2 

Empty 

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission Planner Settings for CONDITION_DELAY command 

In the example above, Command #4 ( DO_SET_ROI ) is delayed so that it
starts 5 seconds after the vehicle has passed Waypoint #2. ### MAV_CMD_CONDITION_DISTANCE 

Supported by: All vehicles. Delays the start of the next “ _DO_ ” command until the vehicle is
within the specified number of meters of the next waypoint. Note

This command does not stop the vehicle: it only affects DO
commands. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Dist (m) 
Distance from the next waypoint before DO commands are executed (meters). param2 

Empty 

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission PlannerSettings for CONDITION_DISTANCE command 

In the example above, Command #4 ( DO_SET_ROI ) is delayed so that it
only starts once the vehicle is within 50m of waypoint #5.

--- chunk_id: chunk-0075
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: a4d437b8f69ae3a2
prev_chunk_id: chunk-0074
next_chunk_id: chunk-0076
section_heading: DO commands
document_type: technical_reference

## DO commands 

The “DO” or “Now” commands are executed once to perform some action. All
the DO commands associated with a waypoint are executed immediately. ### MAV_CMD_DO_CHANGE_SPEED 

Supported by: Copter, Plane, Rover. ### MAV_CMD_DO_SET_HOME 

Supported by: All vehicles. Sets the home location either as the current location or at the location
specified in the command. For SITL work, altitude input here needs to be with reference to absolute altitude, taking into account SRTM elevation. Note

For Plane and Rover, if a good GPS fix cannot be obtained the
location specified in the command is used. For Copter, the command will also try to use the current position if
all the location parameters are set to 0. The location information in
the command is only used if it is close to the EKF origin. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Current 
Set home location:

1=Set home as current location. 0=Use location specified in message parameters. param2 

Empty 

param3 

Empty 

param4 

Empty 

param5 
Lat 
Target home latitude (if param1=0 ) 

param6 
Lon 
Target home longitude (if param1=0 ) 

param7 
Alt 
Target home altitude (if param1=0 ) 

Mission planner screenshots 

Mission Planner Settings for DO_SET_HOME command 

### MAV_CMD_DO_SET_RELAY 

Supported by: All vehicles. Set a Relay pin’s voltage high (on) or low (off). Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Relay No 
Relay number. param2 
off(0)/on(1) 
Set relay state:

1: Set relay high/on (3.3V on Pixhawk, 5V on APM). 0: Set relay low/off (0v)
any other value toggles the relay

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

MissionPlanner Settings for DO_SET_RELAY command 

### MAV_CMD_DO_REPEAT_RELAY 

Supported by: All vehicles. Toggle the Relay pin’s voltage/state a specified
number of times with a given period. Toggling the Relay will turn an off
relay on and vice versa

Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Relay No 
Relay number. param2 
Repeat # 
Cycle count - the number of times the relay should be toggled 

param3 
Delay(s) 
Cycle time (seconds, decimal) - time between each toggle. param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission Planner Settings for DO_RELAY_REPEAT command 

In the example above, assuming the relay was off to begin with, it would
be set high and then after 3 seconds, it would be toggled low again.

--- chunk_id: chunk-0076
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 1666512e164ef1c1
prev_chunk_id: chunk-0075
next_chunk_id: chunk-0077
section_heading: DO commands
document_type: technical_reference

param2 
Repeat # 
Cycle count - the number of times the relay should be toggled 

param3 
Delay(s) 
Cycle time (seconds, decimal) - time between each toggle. param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission Planner Settings for DO_RELAY_REPEAT command 

In the example above, assuming the relay was off to begin with, it would
be set high and then after 3 seconds, it would be toggled low again. ### MAV_CMD_DO_SET_SERVO 

Supported by: All vehicles. Set a given servo pin output to a specific PWM value. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Ser No 
Servo number - target servo output pin/channel number. param2 
PWM 
PWM value to output, in microseconds (typically 1000 to 2000). param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission Planner Settingsfor DO_SET_SERVO command 

In the example above, the servo attached to output channel 8 would be
moved to PWM 1700 (servos generally accept PWM values between 1000 and
2000). Note

as of firmware versions 4.0 and later, this command can be used on any output configured by its SERVOx_FUNCTION command as 0,1, or 51-66 (disabled or RC pass-throughs)

### MAV_CMD_DO_REPEAT_SERVO 

Supported by: All vehicles. Cycle a servo PWM output pin between its mid-position
value and a specified PWM value, for a given number of cycles and with a
set period. The mid-position value is specified in the RCn_TRIM parameter for
the channel ( RC8_TRIM in the screenshot below). The default value is
1500.. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Ser No 
Servo number - target servo output pin/channel. param2 
PWM 
PWM value to output, in microseconds (typically 1000 to 2000). param3 
Repeat # 
Cycle count - number of times to move the servo to the specified PWM value 

param4 
Delay (s) 
Cycle time (seconds) - the delay in seconds between each servo movement. param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission Planner Settingsfor DO_REPEAT_SERVO command 

In the example above, the servo attached to output channel 8 would be
moved to PWM 1700, then after 4 second, back to mid, after another 4
seconds it would be moved to 1700 again, then finally after 4 more
seconds it would be moved back to mid. ### MAV_CMD_DO_SET_ROI, MAV_CMD_DOE_SET_ROI_LOOCATION, MAV_CMD_DO_SET_ROI_NONE 

Supported by: Copter, Plane, Rover,Sub.

--- chunk_id: chunk-0077
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: 9c53c55b8686f9a2
prev_chunk_id: chunk-0076
next_chunk_id: chunk-0078
section_heading: DO commands
document_type: technical_reference

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission Planner Settingsfor DO_REPEAT_SERVO command 

In the example above, the servo attached to output channel 8 would be
moved to PWM 1700, then after 4 second, back to mid, after another 4
seconds it would be moved to 1700 again, then finally after 4 more
seconds it would be moved back to mid. ### MAV_CMD_DO_SET_ROI, MAV_CMD_DOE_SET_ROI_LOOCATION, MAV_CMD_DO_SET_ROI_NONE 

Supported by: Copter, Plane, Rover,Sub. Currently, the DO_SET_ROI,DO_SET_ROI_LOCATION, and DO_SET_ROI_NONE commands all behave the same with DO_SET_ROI_NONE removing the ROI target, the same as setting the location to 0,0 in the other commands. ### MAV_CMD_DO_DIGICAM_CONFIGURE 

Supported by: All vehicles. Configure an on-board camera controller system. The parameters are forwarded to an on-board camera controller system
(like the 3DR Camera Control Board ),
if one is present. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Mode 
Set camera mode:
1: ProgramAuto

2: Aperture Priority

3: Shutter Priority

4: Manual

5: IntelligentAuto

6: SuperiorAuto

param2 
Shutter Speed 
Shutter speed (seconds divisor). So if the speed is 1/60 seconds, the
value entered would be 60. Slowest shutter trigger supported is 1 second. param3 
Aperture 
Aperture: F stop number 

param4 
ISO 
ISO number e.g. 80, 100, 200, etc. param5 
ExposureMode 
Exposure type enumerator 

param6 
CommandID 
Command Identity 

param7 
Engine Cut-Off 
Main engine cut-off time before camera trigger in seconds/10 (0 means no cut-off). ### MAV_CMD_DO_DIGICAM_CONTROL 

Supported by: All vehicles. Trigger the camera shutter once. This command takes no additional arguments. Command parameters 

In general, if a command field is set to 0 it is ignored. Command Field 
Mission Planner Field 
Description 

param1 
On/Off 
Session control (on/off or show/hide lens):

0: Turn off the camera / hide the lens

1: Turn on the camera /Show the lens

param2 
Zoom Position 
Zoom's absolute position. 2x, 3x, 10x, etc. param3 
Zoom Step 
Zooming step value to offset zoom from the current position 

param4 
Focus Lock 
Focus Locking, Unlocking or Re-locking:
0: Ignore

1: Unlock

2: Lock

param5 
Shutter Cmd 
Shooting Command. Any non-zero value triggers the camera. param6 
CommandID 
Command Identity 

param7 

Empty 

Mission planner screenshots 

Mission PlannerSettings for DO_DIGICAM_CONTROL command. ### MAV_CMD_DO_MOUNT_CONTROL 

Supported by: All vehicles. Mission command to control a camera or antenna mount. This command allows you to specify a roll, pitch and yaw angle which
will be sent to the camera gimbal .

--- chunk_id: chunk-0078
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: f5d6cb53c9af2c61
prev_chunk_id: chunk-0077
next_chunk_id: chunk-0079
section_heading: DO commands
document_type: technical_reference

Mission command to control a camera or antenna mount. This command allows you to specify a roll, pitch and yaw angle which
will be sent to the camera gimbal . This
can be used to point the camera in specific directions at various times
in the mission. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Pitch, in degrees. param2 

Roll, in degrees. param3 

Yaw, in degrees. param4 

reserved 

param5 

reserved 

param6 

reserved 

param7 

`MAV_MOUNT_MODE `__ enum value. Mission planner screenshots 

Mission Planner Settings for DO_MOUNT_CONTROL command 

### MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW 

Supported by: All vehicles. Mission command to move the gimbal to the desired pitch and yaw angles (in degrees). This command allows you to specify a pitch and yaw angle which
will be sent to the camera gimbal . This
can be used to point the camera in specific directions at various times
in the mission. Positive pitch angles are up, Negative are down. Positive yaw angles are clockwise, negative are counter clockwise. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Pitch, in degrees. param2 

Yaw, in degrees. param3 

PitchRate, in deg/s. param4 

YawRate, in deg/s 

param5 

Flags: 0=boddyframe, 16=earthframe 

param6 

reserved 

param7 

Gimbal instance ID 

Mission planner screenshots 

Mission PlannerSettings for DO_GIMBAL_MANAGE_PITCHYAW command 

### MAV_CMD_DO_SET_CAM_TRIGG_DIST 

Supported by: All vehicles. Trigger the camera shutter at
regular distance intervals. This command is useful in camera survey missions . To trigger the camera once, immediately after passing the DO command, set param3 to 1. Note

Providing a distance of zero will stop the camera shutter from being triggered. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Dist (m) 
Camera trigger distance interval (meters). Zero to turn off distance triggering. param2 

Empty 

param3 
? Trigger once instantly. One is on, zero is off. param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Mission planner screenshots 

Mission PlannerSettings for DO_SET_CAM_TRIGG_DIST command 

The above configuration will cause the camera shutter to trigger
after every 5m that the vehicle travels. ### MAV_CMD_DO_FENCE_ENABLE 

Supported by: All vehicles. Mission commands to enable the Plane GeoFence , Copter/Rover Cylindrical Fence and/or Inclusion and Exclusion Fences . Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Set GeoFence enable state (0=disable, 1=enable, 2= disable only floor (Plane only)). param2 
bitmask 
The target fence is specified by the bitmask value of FENCE_TYPE. 0 is ALL configured fences.

--- chunk_id: chunk-0079
source_document: common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 349
content_hash: f34d16b525637067
prev_chunk_id: chunk-0078
next_chunk_id: chunk-0080
section_heading: DO commands
document_type: technical_reference

param2 
bitmask 
The target fence is specified by the bitmask value of FENCE_TYPE. 0 is ALL configured fences. param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

### MAV_CMD_DO_AUX_FUNCTION 

Supported by: All vehicles. Mission command to control an Auxiliary Function in the same manner as an RC channel switch. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Aux Function 
Auxiliary Function code,same as RCx_OPTIONS 

param2 
Switch Position 
0:Low, 1:Mid, 2:High 

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

### MAV_CMD_DO_SET_RESUME_REPEAT_DIST 

Supported by: All vehicles. Set the distance that the mission will be rewound when resuming after an interrupt (switching modes). A full explanation of this feature can be found on the Mission Rewind on Resume Page . After setting a rewind distance in a mission, setting the distance to zero will switch off the rewind feature from that point on the mission. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
? Rewind distance in meters 

param2 

Empty 

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

### MAV_CMD_STORAGE_FORMAT 

Supported by: All vehicles. Format SD Card. Useful for vehicles where SD card is inaccessible. Param1 and Param2 must be set to 1. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
? Must be 1 

param2 
? Must be 1 

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0080
source_document: common-measuring-vibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 332
content_hash: 5b3878f2d2798cb9
prev_chunk_id: chunk-0079
next_chunk_id: chunk-0081
section_heading: Common Measuring Vibration
document_type: technical_reference

# Common Measuring Vibration

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Copter

Introduction to Copter 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 
Pre-arm Safety Check 

Arming and Disarming 

Pre-Flight Checklist 

Getting Off the Ground – Tips for New Operators 

Tuning 

Measuring Vibration 
Real-Time view in Ground Station 

Vibe Dataflash Log message 

Looking for “The Leans” 

Advanced Analysis with FFT 

IMU Dataflash Log message 

Setting Hover Throttle 

Save Trim &amp; Auto Trim 

Thrust Loss and Yaw Imbalance Warnings 

Indoor Flying 

Aerobatic Multicopters 

Traditional Helicopters 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Copter 

First Flight with Copter 

Measuring Vibration

Edit on GitHub 

# Measuring Vibration 

Autopilots have accelerometers that are sensitive to vibrations. These accelerometer values are combined with barometer and
GPS data to estimate the vehicle’s position. With excessive
vibrations, the estimate can be thrown off and lead to very bad
performance in modes that rely on accurate positioning (e.g. on Copter:
AltHold, Loiter, RTL, Guided, Position and Auto flight modes). These instructions explain how to measure the vibration levels. If you
find they are out-of-tolerance then follow the advice found on the Vibration Damping page.

--- chunk_id: chunk-0081
source_document: common-measuring-vibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: 53da2cf9c7d065b6
prev_chunk_id: chunk-0080
next_chunk_id: chunk-0082
section_heading: Real-Time view in Ground Station
document_type: technical_reference

## Real-Time view in Ground Station 

Ground Stations can display a real-time view of vibration and clipping. If using the Mission Planner click on “Vibe” on the HUD to display the current vibration levels. Vibration levels below 30m/s/s are normally acceptable. Levels above 30m/s/s may have problems and levels above 60m/s/s nearly always have problems with position or altitude hold. ### Vibe Dataflash Log message 
Check the recorded Vibe levels are mostly below 30m/s/s

Perform a regular flight (i.e. not just a gentle hover) of at least a
few minutes and download the dataflash logs . Using the Mission Planner or other ground station graph the VIBE message’s
VibeX, VibeY and VibeZ values. These show the standard deviation of
the primary accelerometer’s output in m/s/s. The image below, taken
from a 3DR IRIS, shows normal levels which are below 15m/s/s but
occasionally peak to 30m/s/s. Maximum acceptable values appear to be
below 30m/s/s (see second picture below). Graph the Clip0, Clip1 and Clip2 values which increase each time one
of the accelerometers reaches its maximum limit (16G). Ideally
these should be zero for the whole flight but low numbers (&lt;100) are
likely ok especially if they occur during hard landings. A regularly
increasing number through the log indicates a serious vibration
problem that should be fixed . This is an example of a vehicle that had position estimate problems due
to high vibrations. The algorithm for calculating the vibration levels can be seen in the
AP_InertialSensor.cpp’s calc_vibration_and_clipping() 
method but in short it involves calculating the standard deviation of
the accelerometer readings like this:

Capture the raw x, y and z accelerometer values from the primary IMU

High-pass filter the raw values at 5hz to remove the vehicle’s
movement and create a “accel_vibe_floor” for x,y and z axis. Calculate the difference between the latest accel values and the
accel_vibe_floor. Square the above differences, filter at 2hz and then calculate the
square root (for x, y and z). These final three values are what
appear in the VIBE msg’s VibeX, Y and Z fields. When looking at vibrations in a log the first thing to look at is the clipping. If the clipping is 0 that’s good. That means the vibrations that are being detected aren’t overwhelming the IMU.

--- chunk_id: chunk-0082
source_document: common-measuring-vibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 222
content_hash: 6af48f5be83c8816
prev_chunk_id: chunk-0081
next_chunk_id: chunk-0083
section_heading: Real-Time view in Ground Station
document_type: technical_reference

If the clipping is 0 that’s good. That means the vibrations that are being detected aren’t overwhelming the IMU. When troubleshooting the vibration, consider the axis of the vibration as a staring point to find the problem:

If X AND Y are both high, then you may have an issue with a motor bearing or prop balance. Or you may need more/better overall vibration damping for your FC. If X OR Y is high then you may have an issue with your FC mounting. Maybe a wire is bouncing on the FC or restraining it. Or maybe your vibration damping works better in one axis than the other. If you have a Z vibration then you may have a track issue with propeller (bent blade) or vertical play in a motor. Also consider that some flight conditions/airframes will have different natural vibrations. If the vibrations look good in a hover, but they increase with speed, perhaps there is an aerodynamic issue with the airframe, or in wind,

--- chunk_id: chunk-0083
source_document: common-measuring-vibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 152
content_hash: 5543eccd9c40cabc
prev_chunk_id: chunk-0082
next_chunk_id: chunk-0084
section_heading: Looking for “The Leans”
document_type: technical_reference

## Looking for “The Leans” 

The Leans occurs when the vehicle’s attitude estimate becomes incorrect causing it to lean significantly even though the pilot is commanding level flight. The cause of the problem is often accelerometer aliasing which can be confirmed by comparing the Roll and Pitch attitude estimates from each of the estimation systems (i.e. each AHRSs or EKFs). The attitude estimates should be within a few degrees of each other

Download the dataflash log and open in the ground station’s log viewer

Compare the AHRS2.Roll, NKF1[0].Roll and NKF1[1].Roll if using EKF2, or AHRS2.Roll, XKF1[0].Roll and XKF1[1].Roll, if using EKF3

The image below shows a typical log in which the attitudes match well

--- chunk_id: chunk-0084
source_document: common-measuring-vibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 183ac98dfb736205
prev_chunk_id: chunk-0083
next_chunk_id: chunk-0085
section_heading: Advanced Analysis with FFT
document_type: technical_reference

## Advanced Analysis with FFT 

Refer to the Measuring Vibration with “Raw IMU Logging” page for instructions on how to collect large amounts of IMU data and perform an FFT analysis to determine the frequencies with the most vibration. ### IMU Dataflash Log message 
For very old versions of ArduPilot that do not include the Vibe message the IMU values can be checked directly

Ensure the LOG_BITMASK parameter is set to include IMU data so accelerometer values are recorded to the dataflash logs

Fly your copter in Stabilize mode and try to maintain a level hover (it doesn’t need to be perfectly stable or level)

Download the dataflash logs and 
after the download has completed, use the Mission Planner’s “Review a
Log” button to open the latest file in the log directory (it’s last
digit will be the Log number you downloaded so in the example above
we downloaded Log #1 so the filename will end in 1.log)

When the Log Browser appears, scroll down until you find any IMU
message. Click on the row’s AccX and push Graph this data Left
button. Repeat for the AccY and AccZ columns to produce a graph like
below. Check the scale on the left and ensure that your vibration levels for
the AccX and AccY are between -3 and +3. For AccZ the acceptable
range is -15 to -5. If it is very close or over these limits you
should refer back to the Vibration Damping page for possible solutions. After all the above is complete, go to the Mission Planner’s standard
parameters page (you may need to press the Connect button again)
and set the Log Bitmask back to “Default”. This is important because
especially on the APM logging requires significant CPU resources and
it’s a waste to log these if they’re not really needed. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0085
source_document: common-power-module-configuration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 452
content_hash: ae735eff31e96fd5
prev_chunk_id: chunk-0084
next_chunk_id: chunk-0086
section_heading: Common Power Module Configuration In Mission Planner
document_type: technical_reference

# Common Power Module Configuration In Mission Planner

Power Monitor/Module Configuration in Mission Planner &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 
ADS-B Receiver 

Airspeed Sensor 

AIS (Automatic Identification System) 

Barometer (external) 

BlackBox Logger using an AutoPilot 

Button Inputs 

Buzzer 

Cameras &amp; Gimbals 

Companion Computers 

Crop Sprayer 

Display (Onboard) 

Drive Calculator Motor/Propeller Analyzer 

DroneCAN Adapter Node 

DroneCAN Peripherals 

ESCs and Motors 

Ethernet Adapters and Switches 

External AHRS Systems 

First Person View Video 

Fuel Flow and Level Sensors 

Generators 

GPS/Compass 

Grippers 

Joystick or Gamepad 

Landing Gear/ Retractable Camera Mount 

LEDs (external) 

On-Screen Display (OSD) 

Optical Flow Sensor 

Parachute 

Power Modules 
Power Monitor Configuration 
Mission Planner Setup 

Connecting power monitor to alternative pins 

Power Monitors Connecting to AutoPilot Power Monitor Port 

CAN/DroneCAN Power Monitors and Batteries 

DroneCAN Battery Tag 

I2C Power Monitor 

Power Monitoring Via Telemetry Equipped AM32/BLHeli32/S ESCs 

EFI Fuel Monitoring 

Liquid Fuel Monitors 

Substituting a Battery Monitor’s Data into an ESC’s telemetry stream 

Power Tether 

PPM Encoder 

Radio Control Systems 

Rangefinders (Sonar, Lidar, Depth Cameras) 

Relay Switch 

Remote Id (aka Drone Id) 

RPM Sensor 

Safety Switch 

Servos and Actuators 

Smart Batteries 

Telemetry Radio 

Temperature Sensors 

Video (High Definition) 

Winch 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Peripheral Hardware 

Battery Monitors (aka Power Monitors/Modules) 

Power Monitor/Module Configuration in Mission Planner

Edit on GitHub 

# Power Monitor/Module Configuration in Mission Planner 

Note

Up to 16 battery monitors may be used in ArduPilot, with parameter groups named BATT_ through BATT9_ for the first 10, and BATTA_ thru BATTF_ for the last 6 monitors.

--- chunk_id: chunk-0086
source_document: common-power-module-configuration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: ba355cdca96d8fd8
prev_chunk_id: chunk-0085
next_chunk_id: chunk-0087
section_heading: Common Power Module Configuration In Mission Planner
document_type: technical_reference

# Common Power Module Configuration In Mission Planner

Power Monitor/Module Configuration in Mission Planner &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 
ADS-B Receiver 

Airspeed Sensor 

AIS (Automatic Identification System) 

Barometer (external) 

BlackBox Logger using an AutoPilot 

Button Inputs 

Buzzer 

Cameras &amp; Gimbals 

Companion Computers 

Crop Sprayer 

Display (Onboard) 

Drive Calculator Motor/Propeller Analyzer 

DroneCAN Adapter Node 

DroneCAN Peripherals 

ESCs and Motors 

Ethernet Adapters and Switches 

External AHRS Systems 

First Person View Video 

Fuel Flow and Level Sensors 

Generators 

GPS/Compass 

Grippers 

Joystick or Gamepad 

Landing Gear/ Retractable Camera Mount 

LEDs (external) 

On-Screen Display (OSD) 

Optical Flow Sensor 

Parachute 

Power Modules 
Power Monitor Configuration 
Mission Planner Setup 

Connecting power monitor to alternative pins 

Power Monitors Connecting to AutoPilot Power Monitor Port 

CAN/DroneCAN Power Monitors and Batteries 

DroneCAN Battery Tag 

I2C Power Monitor 

Power Monitoring Via Telemetry Equipped AM32/BLHeli32/S ESCs 

EFI Fuel Monitoring 

Liquid Fuel Monitors 

Substituting a Battery Monitor’s Data into an ESC’s telemetry stream 

Power Tether 

PPM Encoder 

Radio Control Systems 

Rangefinders (Sonar, Lidar, Depth Cameras) 

Relay Switch 

Remote Id (aka Drone Id) 

RPM Sensor 

Safety Switch 

Servos and Actuators 

Smart Batteries 

Telemetry Radio 

Temperature Sensors 

Video (High Definition) 

Winch 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Peripheral Hardware 

Battery Monitors (aka Power Monitors/Modules) 

Power Monitor/Module Configuration in Mission Planner

Edit on GitHub 

# Power Monitor/Module Configuration in Mission Planner 

Note

Up to 16 battery monitors may be used in ArduPilot, with parameter groups named BATT_ through BATT9_ for the first 10, and BATTA_ thru BATTF_ for the last 6 monitors. For this article all parameter name references will be shown for the first monitor, BATT_

A power monitor can be used to measure the battery voltage and current for use in the battery failsafe and a power module can also provide a stable power supply to the autopilot.

--- chunk_id: chunk-0087
source_document: common-power-module-configuration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 529
content_hash: 52247fb8b2cee2fc
prev_chunk_id: chunk-0086
next_chunk_id: chunk-0088
section_heading: Common Power Module Configuration In Mission Planner
document_type: technical_reference

# Common Power Module Configuration In Mission Planner

Power Monitor/Module Configuration in Mission Planner &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 
ADS-B Receiver 

Airspeed Sensor 

AIS (Automatic Identification System) 

Barometer (external) 

BlackBox Logger using an AutoPilot 

Button Inputs 

Buzzer 

Cameras &amp; Gimbals 

Companion Computers 

Crop Sprayer 

Display (Onboard) 

Drive Calculator Motor/Propeller Analyzer 

DroneCAN Adapter Node 

DroneCAN Peripherals 

ESCs and Motors 

Ethernet Adapters and Switches 

External AHRS Systems 

First Person View Video 

Fuel Flow and Level Sensors 

Generators 

GPS/Compass 

Grippers 

Joystick or Gamepad 

Landing Gear/ Retractable Camera Mount 

LEDs (external) 

On-Screen Display (OSD) 

Optical Flow Sensor 

Parachute 

Power Modules 
Power Monitor Configuration 
Mission Planner Setup 

Connecting power monitor to alternative pins 

Power Monitors Connecting to AutoPilot Power Monitor Port 

CAN/DroneCAN Power Monitors and Batteries 

DroneCAN Battery Tag 

I2C Power Monitor 

Power Monitoring Via Telemetry Equipped AM32/BLHeli32/S ESCs 

EFI Fuel Monitoring 

Liquid Fuel Monitors 

Substituting a Battery Monitor’s Data into an ESC’s telemetry stream 

Power Tether 

PPM Encoder 

Radio Control Systems 

Rangefinders (Sonar, Lidar, Depth Cameras) 

Relay Switch 

Remote Id (aka Drone Id) 

RPM Sensor 

Safety Switch 

Servos and Actuators 

Smart Batteries 

Telemetry Radio 

Temperature Sensors 

Video (High Definition) 

Winch 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Peripheral Hardware 

Battery Monitors (aka Power Monitors/Modules) 

Power Monitor/Module Configuration in Mission Planner

Edit on GitHub 

# Power Monitor/Module Configuration in Mission Planner 

Note

Up to 16 battery monitors may be used in ArduPilot, with parameter groups named BATT_ through BATT9_ for the first 10, and BATTA_ thru BATTF_ for the last 6 monitors. For this article all parameter name references will be shown for the first monitor, BATT_

A power monitor can be used to measure the battery voltage and current for use in the battery failsafe and a power module can also provide a stable power supply to the autopilot. ArduPilot is compatible with a number of power modules/monitors .

--- chunk_id: chunk-0088
source_document: common-power-module-configuration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 93
content_hash: d491e417a61bc122
prev_chunk_id: chunk-0087
next_chunk_id: chunk-0089
section_heading: Common Power Module Configuration In Mission Planner
document_type: technical_reference

For this article all parameter name references will be shown for the first monitor, BATT_

A power monitor can be used to measure the battery voltage and current for use in the battery failsafe and a power module can also provide a stable power supply to the autopilot. ArduPilot is compatible with a number of power modules/monitors . Note

Boards with integrated power monitors have their parameters setup by default.

--- chunk_id: chunk-0089
source_document: common-power-module-configuration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 4db81663cda8b44b
prev_chunk_id: chunk-0088
next_chunk_id: chunk-0090
section_heading: Mission Planner Setup
document_type: technical_reference

## Mission Planner Setup 

Battery measurement is primarily set up in the Mission Planner ’s
INITIAL SETUP | Optional Hardware | Battery Monitor screen. Note that currently Mission Planner only supports the first two Battery Monitors in the system (a total of 10 are available in firmware versions 4.0 and later). More would need to be configured directly by directly setting their parameters in the CONFIG/TUNING| Full Parameter List screen. MissionPlanner: Battery Monitor Configuration 

### Enable voltage and current sensing 

Enter the properties your monitor can measure, the type of monitor, the
type of autopilot, and the battery capacity:

Monitor: Voltage and Current or Battery Volts 

Sensor: Supported power module, or “Other”

APM ver: Autopilot (e.g. Pixhawk )

Battery Capacity: Battery capacity in mAh

The Sensor selection list offers a number of analog Power Modules
(including popular models from 3DR and AttoPilot) which you can select
to automatically configure your module. If your PM is not on the list
then you can select Other , enter its recommended values, or
perform a manual calibration as described below. ### Other Types of Power Modules/Smart Batteries 

In addition to normal analog voltage and current sensing modules, ArduPilot supports a wide range of SMBus, DroneCAN/CAN power modules and Smart Batteries. (In the following, the first monitor’s parameters are shown. Each of the other monitors have their own parameters.)

These are selected via the BATTx_MONITOR parameter for each battery monitor. These can be set directly via the CONFIG/Parameter Tree tab for each battery monitor. Here are the monitor types supported:

BATT_MONITOR 

TYPE

0

Disabled

3

Analog Voltage Only

4

Analog Voltage and Current

5

Solo

6

Bebop

7

SMBus-Generic 

8

DroneCAN-BatteryInfo

9

ESC 

10

Sum Of Selected Monitors, see BATTx_SUM_MASK parameter

11

FuelFlow 

12

FuelLevelPWM 

13

SMBUS-SUI3 

14

SMBUS-SUI6 

15

NeoDesign

16

SMBus-Maxell

17

Generator-Elec 

18

Generator-Fuel 

19

Rotoye 

20

MPPT

21

INA2XX

22

LTC2946

23

Torqeedo Motor Controller

24

FuelLevelAnalog 

Note

Once a specific monitor type is selected, parameters associated with that type of monitor will be revealed once parameters are refreshed. Scales and offsets, bus addresses, etc. will be displayed, as appropriate, for that monitor. ### Other Parameters 

BATT_OPTIONS bit 0, if set, will ignore the State Of Charge field in DroneCAN monitors, since some do not populate this field with meaningful data.

--- chunk_id: chunk-0090
source_document: common-power-module-configuration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: 8a2849d2bc452adc
prev_chunk_id: chunk-0089
next_chunk_id: chunk-0091
section_heading: Mission Planner Setup
document_type: technical_reference

will be displayed, as appropriate, for that monitor. ### Other Parameters 

BATT_OPTIONS bit 0, if set, will ignore the State Of Charge field in DroneCAN monitors, since some do not populate this field with meaningful data. Also various options for MPPT type monitors are provided. Bit 6 allows the resting voltage to be sent in place of battery voltage, which is sometime more useful. Bit 7 allows the Battery Auxiliary info from another DroneCAN monitor with the same BATT_SERIAL_NUM to be used for this monitor instance. For Bit 9 if set, the Sum monitor type measures minimum voltage instead of average. Bit 10 allows telemetry to conttinue if a DroneCAN battery with a different id is hotswapped. BATT_SUM_MASK is used if the monitor is type “10” (Sum Of Selected Monitors) to select which monitors’ reported voltages will be averaged, and current values will be summed, and reported for this monitor. Selecting this monitor’s own instance number has no effect. If no bits are set, it will average all higher numbered instance’s reports. BATT_ARM_VOLT is the minimum voltage reported from this monitor that will allow arming to occur. BATT_ARM_MAH is the minimum capacity remaining reported from this monitor that will allow arming to occur. BATT_CURR_MULT allows adjusting the current scale for DroneCAN(UAVCAN) monitors which do not have a CAN parameter exposed for adjustment. BATT_SERIAL_NUM is used to designate which battery an SMBUS or DroneCAN monitor is associated, since multiple instances of these monitors are possible. BATT_MAX_AMPS applies only to INA2xx sensors. Controls the maximum current which can be reported. This sensor is usually integrated onto the autopilot board and this value preset appropriately in the firmware. Normally, the user would only adjust this if the power monitor OEM suggest that it be set to a certain value. ### Failsafe 

Failsafes can be implemented for low battery/fuel conditions. For Plane see Plane Failsafe Function , for Copter see Battery Failsafe , or for Rover see Failsafes 

### Analog Monitor Calibration 

The bottom section of the Battery Monitor screen allows you to
calibrate the voltage/current measurement in order to verify that the
measured voltage of the battery is correct. You can also set the
Sensor selection list to Other and use the calibration process
to configure an “unknown” power monitor/module.

--- chunk_id: chunk-0091
source_document: common-power-module-configuration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 480
content_hash: e355cf61e41a72e6
prev_chunk_id: chunk-0090
next_chunk_id: chunk-0092
section_heading: Mission Planner Setup
document_type: technical_reference

For Plane see Plane Failsafe Function , for Copter see Battery Failsafe , or for Rover see Failsafes 

### Analog Monitor Calibration 

The bottom section of the Battery Monitor screen allows you to
calibrate the voltage/current measurement in order to verify that the
measured voltage of the battery is correct. You can also set the
Sensor selection list to Other and use the calibration process
to configure an “unknown” power monitor/module. To calibrate the voltage reading:

Check the voltage of your LiPo battery with a hand-held volt meter or
a power analyzer 

Connect your Pixhawk-series to your computer and plug in the LiPo battery

Check the voltage through the Mission Planner ’s INITIAL SETUP |
Optional Hardware | Battery Monitor screen or on the Flight Data
screen’s HUD or Status tab. If you find the voltage is not correct (i.e. if off from the hand-held
volt meter’s reading by more than perhaps 0.2V) you can calibrate it by doing the following:

On Mission Planner ’s INITIAL SETUP | Optional Hardware | Battery Monitor screen set the “Sensor” to “Other”. Enter the voltage according to the hand-held volt meter in the
“Measured Battery Voltage” field

Press tab or click out of the field and the “Voltage Divider
(Calced)” value will update and the “Battery voltage (Calced)” should
now equal the measured voltage

Using the power analyser you can also measure the current and compare to
results displayed in the Mission Planner. You can also empirically adjust the current scale and offset parameters as explained in Analog Current Monitor Calibration . Note

Most current sensors are not very accurate at low currents (less
than 3 Amps). Typically you should perform current calibration at around
10A. The exception is PMs that use hall-effect sensors, like those from Mauch . This video shows the voltage and current calibration process using a
Turnigy Power Analyser. ### Enable Low Battery Alert 

You can set Mission Planner to alert you verbally when your battery is
low (using a computerized voice). Simply check the MP Alert on Low Battery checkbox and enter the
warning you wish to hear, the voltage level and finally the percentage
of remaining current.

--- chunk_id: chunk-0092
source_document: common-power-module-configuration-in-mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 157
content_hash: faf73e8caccf7f89
prev_chunk_id: chunk-0091
next_chunk_id: chunk-0093
section_heading: Connecting power monitor to alternative pins
document_type: technical_reference

## Connecting power monitor to alternative pins 

The power monitor is generally plugged into the default port on the
autopilot (ie. Pixhawk). If you wish to change where the power
monitor is plugged into the controller, the pins used can be modified
using the BATT_VOLT_PIN and BATT_CURR_PIN parameters. The list of available analog input pins that can be used are listed on
the Hardware Options page for the Pixhawk board or its board description linked from the Choosing an Autopilot page

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0093
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 370
content_hash: a8cc54f41d4121e6
prev_chunk_id: chunk-0092
next_chunk_id: chunk-0094
section_heading: Common Prearm Safety Checks
document_type: technical_reference

# Common Prearm Safety Checks

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 
Center of Gravity 

Starting up and calibrating Plane 

Pre-Arm Safety Checks 
Recognising which Pre-Arm Check has failed using the GCS 

Other Failure messages 
Failsafes: 

Barometer failures: 

Compass failures: 

GPS related failures: 

INS checks (i.e. Accelerometer and Gyro checks): 

Board Voltage checks: 

Parameter checks: 

Battery/Power Monitor: 

Airspeed: 

Logging: 

Safety Switch: 

System: 

Mission: 

Rangefinder: 

Disabling the Pre-arm Safety Check 

Arming Plane 

Takeoff 

Tuning Quickstart 

Automatic Tuning 

Tuning in Detail 

Tuning Configuration Values for Common Airframes 

Measuring Vibration 

Transmitter based tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

First Flight 

Pre-Arm Safety Checks

Edit on GitHub 

# Pre-Arm Safety Checks 

ArduPilot includes a suite of Pre-arm Safety Checks which will prevent the
vehicle from arming its propulsion system if any of a fairly large number of issues are
discovered before movement including missed calibration, configuration
or bad sensor data. These checks help prevent crashes or fly-aways but
some can also be disabled if necessary. Warning

Never disable arming checks (ie ARMING_SKIPCHK not = “0”, except for bench testing. Always resolve any prearm or arming failures BEFORE attempting to fly. Doing otherwise may result in the loss of the vehicle.

--- chunk_id: chunk-0094
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: 9b40f26fa65519b8
prev_chunk_id: chunk-0093
next_chunk_id: chunk-0095
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

## Recognising which Pre-Arm Check has failed using the GCS 

The pilot will notice a pre-arm check failure because he/she will be
unable to arm the vehicle and the notification LED, if available, will be flashing yellow. To
determine exactly which check has failed:

Connect the Autopilot to the ground station using a USB cable
or Telemetry . Ensure the GCS is connected to the vehicle (i.e. on Mission
Planner and push the “Connect” button on the upper right). Turn on your radio transmitter and attempt to arm the vehicle
(regular procedure is using throttle down, yaw right or via an RCx_OPTION switch)

The first cause of the Pre-Arm Check failure will be displayed in red
on the HUD window

Pre-arm checks that are failing will also be sent as messages to the GCS while disarmed, about every 30 seconds. If you wish to disable this and have them sent only when an attempt arm fails, then set the ARMING_OPTIONS bit 1 (value 1). Pre-Arm Failure Messages (All vehicle types) 

Message

Cause

Solution

3D Accel calibration needed

Accelerometer calibration has not been done

Complete the accel calibration 

Accels calibrated requires reboot

Autopilot must be rebooted after accel calibration

Reboot autopilot

Accels inconsistent

Two accelerometers are inconsistent by 0.75 m/s/s

Re-do the accel calibration . Allow autopilot to warm-up and reboot. If failure continues replace autopilot. If ICE engine runs before arming, see ARMING_OPTIONS bit 2 as a possible solution. ADSB out of memory

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

Accels not healthy

At least one accelerometer is not providing data

Reboot autopilot. If failure continues replace autopilot

AHRS: not using configured AHRS type

EKF3 is not ready yet and vehicle is using DCM

If indoors, go outside. Ensure good GPS lock. Check for misconfiguration of EKF (see AHRS_EKF_TYPE )

AHRS: waiting for home

GPS has not gotten a fix

If indoors, go outside. Ensure compass and accelerometer calibrations have been completed. Eliminate radio-frequency sources that could interfere with the GPS

Airspeed 1 not healthy

Autopilot is unable to retrieve data from sensor

Check the physical connection and configuration 

AP_Relay not available

Parachute misconfigured

Parachute is controlled via Relay but the relay feature is missing.

--- chunk_id: chunk-0095
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: c9e10b24d5dc5843
prev_chunk_id: chunk-0094
next_chunk_id: chunk-0096
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Ensure compass and accelerometer calibrations have been completed. Eliminate radio-frequency sources that could interfere with the GPS

Airspeed 1 not healthy

Autopilot is unable to retrieve data from sensor

Check the physical connection and configuration 

AP_Relay not available

Parachute misconfigured

Parachute is controlled via Relay but the relay feature is missing. Custom build server was probably used, rebuild with relay enabled

Auxiliary authorisation refused

External system has disallowed authorisation

Check external authorisation system

Batch sampling requires reboot

Batch sampling feature requires Autopilot reboot

Reboot autopilot or check Batch sampling configuration

Battery below minimum arming capacity

Battery capacity is below BATT_ARM_MAH

Replace battery or adjust BATT_ARM_MAH 

Battery below minimum arming voltage

Battery voltage is below BATT_ARM_VOLT

Replace battery or adjust BATT_ARM_VOLT 

Battery capacity failsafe critical &gt;= low

Battery failsafe misconfiguration

Check BATT_LOW_MAH is higher than BATT_CRT_MAH 

Battery critical capacity failsafe

Battery capacity is below BATT_CRT_MAH

Replace battery or adjust BATT_CRT_MAH 

Battery critical voltage failsafe

Battery voltage is below BATT_CRT_VOLT

Replace battery or adjust BATT_CRT_VOLT 

Battery low capacity failsafe

Battery capacity is below BATT_LOW_MAH

Replace battery or adjust BATT_LOW_MAH 

Battery low voltage failsafe

Battery voltage is below BATT_LOW_VOLT

Replace battery or adjust BATT_LOW_VOLT 

Battery unhealthy

Battery is not providing data

Check battery monitors physical connect and configuration 

Battery voltage failsafe critical &gt;= low

Battery failsafe misconfiguration

Check BATT_LOW_VOLT is higher than BATT_CRT_VOLT 

BendyRuler OA requires reboot

Object avoidance config change requires reboot

Reboot autopilot. See Object Avoidance configuration 

Board (Xv) out of range 4.3-5.8v

Board voltage below BRD_VBUS_MIN or too high

Check power supply. If powering via USB plug in a battery or replace USB cable

BTN_PINx=y invalid

Button misconfigured

BTNx_PIN is set to an invalid value. Check Button setup instructions 

BTN_PINx=y, set SERVOz_FUNCTION=-1

Button misconfigured

Set SERVOz_FUNCTION to -1

Can’t check rally without position

EKF does not have a position estimate yet

Wait or move to location with better GPS reception

Check fence

Fence feature has failed to be initialised

Reboot autopilot

Check mag field (xy diff:x&gt;875)

Compass horiz field strength is too large or small

Relocate vehicle away from metal in the environment. Move compass away from metal in the frame. repeat compass calibration . Disable internal compass. Check mag field (z diff:x&gt;875)

Compass vert field strength is too large or small

Relocate vehicle away from metal in the environment. Move compass away from metal in the frame.

--- chunk_id: chunk-0096
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: 3e71966fa33dc264
prev_chunk_id: chunk-0095
next_chunk_id: chunk-0097
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Check mag field (z diff:x&gt;875)

Compass vert field strength is too large or small

Relocate vehicle away from metal in the environment. Move compass away from metal in the frame. repeat compass calibration . Disable internal compass. Check mag field: x, max y, min z

Compass field strength is too large or small

Relocate vehicle away from metal in the environment. Move compass away from metal in the frame. repeat compass calibration . Disable internal compass. Chute has no channel

Parachute misconfigured

Parachute is controlled using PWM but no servo output function has been configured (e.g. need SERVOx_FUNCTION = 27). see Parachute setup instructions 

Chute has no relay

Parachute misconfigured

Parachute is controlled via Relay but no relay output has been configured. see Parachute setup instructions 

Chute is released

Parachute has been released

Reboot autopilot

Compass calibrated requires reboot

Autopilot must be rebooted after compass cal

Reboot autopilot

Compass calibration running

Compass calibration is running

Complete or cancel the compass calibration 

Compass X not healthy

Compass X is not providing data

Check the connection between compass X and the autopilot, and review the configuration 

Compass offsets too high

Compass offset params are too large

Relocate compass away from metal in the frame and repeat compass calibration . Disable internal compass. Increase COMPASS_OFFS_MAX . Compasses inconsistent

Two compasses angles or field strength disagree

Check compass orientations (e.g. COMPASS_ORIENT ). Move compass away from metal in the frame. repeat compass calibration . Disable internal compass. CrashDump data detected

Crash Dump data has been logged

A CPU crash has occurred and data logged. Plane is probably unsafe to fly! See Reporting a Watchdog / Crash Dump 

Dijkstra OA requires reboot

Object avoidance config change requires reboot

Reboot autopilot. See Object Avoidance configuration 

Disarm Switch on

Disarm auxiliary switch is in the high position

Move Disarm switch to the low position or check auxiliary functions setup

Downloading logs

Vehicle cannot be armed while logs are downloading

Wait until logs are downloaded, cancel download or reboot autopilot

DroneCAN: Duplicate Node x../y! DroneCAN sees same node ids used by two devices

Clear DroneCAN DNS server by setting CAN_D1_UC_OPTION = 1 and reboot

DroneCAN: Failed to access storage! Possible hardware issue

Reboot autopilot

DroneCAN: Failed to add Node x!

--- chunk_id: chunk-0097
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 345
content_hash: d8bb2e6557656645
prev_chunk_id: chunk-0096
next_chunk_id: chunk-0098
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

DroneCAN sees same node ids used by two devices

Clear DroneCAN DNS server by setting CAN_D1_UC_OPTION = 1 and reboot

DroneCAN: Failed to access storage! Possible hardware issue

Reboot autopilot

DroneCAN: Failed to add Node x! DroneCAN could not init connection to a device

Check sensor’s physical connection and power supply

DroneCAN: Node x unhealthy! A DroneCAN device is not providing data

Check sensor’s physical connection and power supply

Duplicate Aux Switch Options

Two auxiliary function switches for same feature

Check auxiliary function setup. Check for RCx_OPTION parameters with same values

EKF3 Roll/Pitch inconsistent by x degs

Roll or Pitch lean angle estimates are inconsistent

Normally due to EKF3 not getting good enough GPS accuracy, but could be due to other sensors producing errors. Go outdoors, wait or reboot autopilot. EKF3x vel error y

EKF3 has velocity innovation of “y”

EKF3 getting high position velocity innovations. Check GPS, wait or reboot. EKF3 waiting for GPS config data

automatic GPS configuration has not completed

Check GPS connection and configuration especially if using DroneCAN GPS

EKF3 Yaw inconsistent by x degs

Yaw angle estimates are inconsistent

Wait or reboot autopilot

Failed to open mission.stg

Failed to load mission from SD Card

Check SD card. Try to re-save mission to SD card

Failed to create log directory /APM/LOGS : ENOMEM

Failed to create log directory on SD card

Decrease LOG_FILE_BUFSIZE or disable other features to reduce memory usage

Fence requires position

If fences are enabled, position estimate required

Wait or move vehicle to a location with a clear view of the sky.

--- chunk_id: chunk-0098
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 592
content_hash: 6279a425b1714e03
prev_chunk_id: chunk-0097
next_chunk_id: chunk-0099
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

EKF3 waiting for GPS config data

automatic GPS configuration has not completed

Check GPS connection and configuration especially if using DroneCAN GPS

EKF3 Yaw inconsistent by x degs

Yaw angle estimates are inconsistent

Wait or reboot autopilot

Failed to open mission.stg

Failed to load mission from SD Card

Check SD card. Try to re-save mission to SD card

Failed to create log directory /APM/LOGS : ENOMEM

Failed to create log directory on SD card

Decrease LOG_FILE_BUFSIZE or disable other features to reduce memory usage

Fence requires position

If fences are enabled, position estimate required

Wait or move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

FENCE_ALT_MAX &lt; FENCE_ALT_MIN

FENCE_ALT_MAX must be greater than FENCE_ALT_MIN

Increase FENCE_ALT_MAX or lower FENCE_ALT_MIN 

FENCE_MARGIN is less than FENCE_RADIUS

FENCE_MARGIN must be larger than FENCE_RADIUS

Increase FENCE_RADIUS or reduce FENCE_MARGIN 

FENCE_MARGIN too big

FENCE_ALT_MAX - FENCE_ALT_MIN &lt; 2x FENCE_MARGIN

Decrease FENCE_MARGIN or increase difference between FENCE_ALT_MAX and FENCE_ALT_MIN 

Fences enabled, but none selected

Fences are enabled but none are defined

Disable some or all fences using FENCE_ENABLE or FENCE_TYPE or define the missing fences

Fences invalid

Polygon fence is invalid

Check polygon fence does not have overlapping lines

FETtec: Invalid motor mask

FETtec misconfiguration

See FETtec configuration 

FETtec: Invalid pole count x

FETtec misconfiguration

See FETtec configuration 

FETtec: No uart

FETtec misconfiguration

See FETtec configuration 

FETtec: Not initialised

FETtec ESCs are not communicating with autopilot

See FETtec configuration 

FETtec: x of y ESCs are not running

FETtec ESCs are not spinning

See FETtec configuration 

FETtec: x of y ESCs are not sending telem

FETtec ESCs are not communicating with autopilot

See FETtec configuration 

FFT calibrating noise

FFT Harmonic Notch analysis has not completed

Wait until In-Flight FFT analysis completes

FFT config MAXHZ xHz &gt; yHz

FFT Harmonic Notch misconfiguration

See In-Flight FFT Harmonic Notch Setup completes

FFT self-test failed, max error Hz

FFT Harmonic Notch failed

See In-Flight FFT Harmonic Notch Setup completes

FFT still analyzing

FFT Harmonic Notch analysis has not completed

Wait until In-Flight FFT analysis completes

FFT: calibrated xHz/xHz/xHz

FFT Harmonic Notch issue

See In-Flight FFT Harmonic Notch Setup completes

FFT: resolution is xHz, increase length

FFT Harmonic Notch misconfiguration

See In-Flight FFT Harmonic Notch Setup completes

Generator: Not healthy

Generator is not communicating with autopilot

Check generator configuration 

Generator: No backend driver

Firmware does not include selected generator

Build version of firmware with desired generator using custom.ardupilot.org

GPS alt error xm (see BARO_ALTERR_MAX)

GPS and BARO alt disagree by a large amount

Read the BARO_ALTERR_MAX parameter description

GPS and AHRS differ by Xm

GPS and EKF positions differ by at least 10m

Wait until GPS quality improves.

--- chunk_id: chunk-0099
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 540
content_hash: 21b2d911df7c2c47
prev_chunk_id: chunk-0098
next_chunk_id: chunk-0100
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Try to re-save mission to SD card

Failed to create log directory /APM/LOGS : ENOMEM

Failed to create log directory on SD card

Decrease LOG_FILE_BUFSIZE or disable other features to reduce memory usage

Fence requires position

If fences are enabled, position estimate required

Wait or move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

FENCE_ALT_MAX &lt; FENCE_ALT_MIN

FENCE_ALT_MAX must be greater than FENCE_ALT_MIN

Increase FENCE_ALT_MAX or lower FENCE_ALT_MIN 

FENCE_MARGIN is less than FENCE_RADIUS

FENCE_MARGIN must be larger than FENCE_RADIUS

Increase FENCE_RADIUS or reduce FENCE_MARGIN 

FENCE_MARGIN too big

FENCE_ALT_MAX - FENCE_ALT_MIN &lt; 2x FENCE_MARGIN

Decrease FENCE_MARGIN or increase difference between FENCE_ALT_MAX and FENCE_ALT_MIN 

Fences enabled, but none selected

Fences are enabled but none are defined

Disable some or all fences using FENCE_ENABLE or FENCE_TYPE or define the missing fences

Fences invalid

Polygon fence is invalid

Check polygon fence does not have overlapping lines

FETtec: Invalid motor mask

FETtec misconfiguration

See FETtec configuration 

FETtec: Invalid pole count x

FETtec misconfiguration

See FETtec configuration 

FETtec: No uart

FETtec misconfiguration

See FETtec configuration 

FETtec: Not initialised

FETtec ESCs are not communicating with autopilot

See FETtec configuration 

FETtec: x of y ESCs are not running

FETtec ESCs are not spinning

See FETtec configuration 

FETtec: x of y ESCs are not sending telem

FETtec ESCs are not communicating with autopilot

See FETtec configuration 

FFT calibrating noise

FFT Harmonic Notch analysis has not completed

Wait until In-Flight FFT analysis completes

FFT config MAXHZ xHz &gt; yHz

FFT Harmonic Notch misconfiguration

See In-Flight FFT Harmonic Notch Setup completes

FFT self-test failed, max error Hz

FFT Harmonic Notch failed

See In-Flight FFT Harmonic Notch Setup completes

FFT still analyzing

FFT Harmonic Notch analysis has not completed

Wait until In-Flight FFT analysis completes

FFT: calibrated xHz/xHz/xHz

FFT Harmonic Notch issue

See In-Flight FFT Harmonic Notch Setup completes

FFT: resolution is xHz, increase length

FFT Harmonic Notch misconfiguration

See In-Flight FFT Harmonic Notch Setup completes

Generator: Not healthy

Generator is not communicating with autopilot

Check generator configuration 

Generator: No backend driver

Firmware does not include selected generator

Build version of firmware with desired generator using custom.ardupilot.org

GPS alt error xm (see BARO_ALTERR_MAX)

GPS and BARO alt disagree by a large amount

Read the BARO_ALTERR_MAX parameter description

GPS and AHRS differ by Xm

GPS and EKF positions differ by at least 10m

Wait until GPS quality improves. Move vehicle to a location with a clear view of the sky.

--- chunk_id: chunk-0100
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: 3403604c9975067a
prev_chunk_id: chunk-0099
next_chunk_id: chunk-0101
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Reduce sources of radio-frequency interference

FENCE_ALT_MAX &lt; FENCE_ALT_MIN

FENCE_ALT_MAX must be greater than FENCE_ALT_MIN

Increase FENCE_ALT_MAX or lower FENCE_ALT_MIN 

FENCE_MARGIN is less than FENCE_RADIUS

FENCE_MARGIN must be larger than FENCE_RADIUS

Increase FENCE_RADIUS or reduce FENCE_MARGIN 

FENCE_MARGIN too big

FENCE_ALT_MAX - FENCE_ALT_MIN &lt; 2x FENCE_MARGIN

Decrease FENCE_MARGIN or increase difference between FENCE_ALT_MAX and FENCE_ALT_MIN 

Fences enabled, but none selected

Fences are enabled but none are defined

Disable some or all fences using FENCE_ENABLE or FENCE_TYPE or define the missing fences

Fences invalid

Polygon fence is invalid

Check polygon fence does not have overlapping lines

FETtec: Invalid motor mask

FETtec misconfiguration

See FETtec configuration 

FETtec: Invalid pole count x

FETtec misconfiguration

See FETtec configuration 

FETtec: No uart

FETtec misconfiguration

See FETtec configuration 

FETtec: Not initialised

FETtec ESCs are not communicating with autopilot

See FETtec configuration 

FETtec: x of y ESCs are not running

FETtec ESCs are not spinning

See FETtec configuration 

FETtec: x of y ESCs are not sending telem

FETtec ESCs are not communicating with autopilot

See FETtec configuration 

FFT calibrating noise

FFT Harmonic Notch analysis has not completed

Wait until In-Flight FFT analysis completes

FFT config MAXHZ xHz &gt; yHz

FFT Harmonic Notch misconfiguration

See In-Flight FFT Harmonic Notch Setup completes

FFT self-test failed, max error Hz

FFT Harmonic Notch failed

See In-Flight FFT Harmonic Notch Setup completes

FFT still analyzing

FFT Harmonic Notch analysis has not completed

Wait until In-Flight FFT analysis completes

FFT: calibrated xHz/xHz/xHz

FFT Harmonic Notch issue

See In-Flight FFT Harmonic Notch Setup completes

FFT: resolution is xHz, increase length

FFT Harmonic Notch misconfiguration

See In-Flight FFT Harmonic Notch Setup completes

Generator: Not healthy

Generator is not communicating with autopilot

Check generator configuration 

Generator: No backend driver

Firmware does not include selected generator

Build version of firmware with desired generator using custom.ardupilot.org

GPS alt error xm (see BARO_ALTERR_MAX)

GPS and BARO alt disagree by a large amount

Read the BARO_ALTERR_MAX parameter description

GPS and AHRS differ by Xm

GPS and EKF positions differ by at least 10m

Wait until GPS quality improves. Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

GPS blending unhealthy

At least one GPS is not providing good data

Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference.

--- chunk_id: chunk-0101
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: 41b4c518a624fe58
prev_chunk_id: chunk-0100
next_chunk_id: chunk-0102
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Reduce sources of radio-frequency interference

GPS blending unhealthy

At least one GPS is not providing good data

Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference. Check GPS blending configuration 

GPS Node x not set as instance y

DroneCan GPS configuration error

Check GPS1_CAN_NODEID and GPS2_CAN_NODEID 

GPS positions differ by Xm

Two GPSs reported positions differ by 50m or more

Wait until GPS quality improves. Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

GPS x still configuring this GPS

Automatic GPS configuration has not completed

Wait until configuration completes. Check GPS connection and configuration especially if using DroneCAN GPS

GPS x: Bad fix

GPS does not have a good lock

Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

GPS x: not healthy

GPS is not providing data

Check GPSs physical connection to autopilot and configuration 

GPS x: primary but TYPE 0

Primary GPS has not been configured

Check GPS_PRIMARY and confirm corresponding GPS1_TYPE or GPS2_TYPE matches type of GPS used

GPS x: was not found

GPS disconnected or incorrectly configured

Check GPSs physical connection to autopilot and configuration 

GPSx yaw not available

GPS-for-yaw configured but not working

Move to location with better GPS reception. Check GPS-for-yaw configuration

Gyro x rate yHz &lt; loop rate z Hz

Loop rate is faster than Gyro data

Lower SCHED_LOOP_RATE 

Gyros inconsistent

Two gyros are inconsistent by at least 5 deg/sec

Reboot autopilot and hold vehicle still until gyro calibration completes. Allow autopilot to warm-up and reboot. If failure continues replace autopilot. If ICE engine runs before arming, see ARMING_OPTIONS bit 2 as a possible solution. Gyros not calibrated

Gyro calibration normally run at startup failed

Reboot autopilot and hold vehicle still until gyro calibration completes

Gyros not healthy

At least one gyro is not providing data

Reboot autopilot. If failure continues replace autopilot

Hardware safety switch

Hardware safety switch has not been pushed

Push safety switch (normally on top of GPS) or disable by setting BRD_SAFETY_DEFLT to zero and reboot autopilot

heater temp low (x &lt; 45)

Board heater temp is below BRD_HEAT_TARG

Wait for board to heat up.

--- chunk_id: chunk-0102
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 289
content_hash: e6b5ab8bb9682323
prev_chunk_id: chunk-0101
next_chunk_id: chunk-0103
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Gyros not calibrated

Gyro calibration normally run at startup failed

Reboot autopilot and hold vehicle still until gyro calibration completes

Gyros not healthy

At least one gyro is not providing data

Reboot autopilot. If failure continues replace autopilot

Hardware safety switch

Hardware safety switch has not been pushed

Push safety switch (normally on top of GPS) or disable by setting BRD_SAFETY_DEFLT to zero and reboot autopilot

heater temp low (x &lt; 45)

Board heater temp is below BRD_HEAT_TARG

Wait for board to heat up. Target temperature can be adjust using BRD_HEAT_TARG 

In OSD menu

OSD is being configured

Complete OSD configuration. Check OSD configuration 

Internal errors 0x%x l:%u %s

An internal error has occurred

Reboot the autopilot. Report error to the development team

Invalid FENCE_ALT_MAX value

FENCE_ALT_MAX must be positive

Increase FENCE_ALT_MAX 

Invalid FENCE_ALT_MIN value

FENCE_ALT_MIN must be higher than -100

Increase FENCE_ALT_MIN 

Invalid FENCE_MARGIN value

FENCE_MARGIN must be positive

Increase FENCE_MARGIN 

Invalid FENCE_RADIUS value

FENCE_RADIUS must be positive

Increase FENCE_RADIUS 

Logging failed

Logs could not be written. Maybe hardware failure

Reboot autopilot. Replace autopilot

Logging not started

Logs could not be written. Maybe hardware failure

Reboot autopilot. Replace autopilot

Main loop slow (xHz &lt; 400Hz)

Autopilot’s CPU is overloaded

Wait to see if the error is temporary. Disable features or replace with a higher powered autopilot.

--- chunk_id: chunk-0103
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 498
content_hash: ce68065791a64861
prev_chunk_id: chunk-0102
next_chunk_id: chunk-0104
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Replace autopilot

Main loop slow (xHz &lt; 400Hz)

Autopilot’s CPU is overloaded

Wait to see if the error is temporary. Disable features or replace with a higher powered autopilot. Reduce SCHED_LOOP_RATE 

Margin is less than inclusion circle radius

A circular fence has radius below FENCE_MARGIN

Increase the size of the circular fence involved or decrease FENCE_MARGIN 

memory low for auxiliary authorisation

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

Missing mission item: do land start

Auto mission needs a DO_LAND_START command

Add a DO_LAND_START command to the mission or adjust the ARMING_MIS_ITEMS parameter

Missing mission item: land

Auto mission needs a LAND command

Add a LAND command to the mission or adjust the ARMING_MIS_ITEMS parameter

Missing mission item: RTL

Auto mission needs an RTL command

Add an RTL command to the mission or adjust the ARMING_MIS_ITEMS parameter

Missing mission item: takeoff

Auto mission needs a TAKEOFF command

Add a TAKEOFF command to the mission or adjust the ARMING_MIS_ITEMS parameter

Missing mission item: vtol land

Auto mission needs a VTOL_LAND command

Add a VTOL_LAND command to the mission or adjust the ARMING_MIS_ITEMS parameter

Missing mission item: vtol takeoff

Auto mission needs a VTOL_TAKEOFF command

Add a VTOL_TAKEOFF command to the mission or adjust the ARMING_MIS_ITEMS parameter

Mode channel and RCx_OPTION conflict

RC flight mode switch also used for an aux function

Change FLTMODE_CH (or MODE_CH for Rover) or RCx_OPTION to remove conflict

Mode requires mission

Attempting to arm in Auto mode but no mission

Arm in an other mode or create and upload an Auto mission

Motors Emergency Stopped

Motors emergency stopped

Release emergency stop. See auxiliary functions 

Mount: check TYPE

Mount (aka camera gimbal) misconfiguration

Check MNT1_TYPE is valid. Check Gimbal configuration 

Mount: not healthy

Mount is not communicating with autopilot

Check physical connection between autopilot and gimbal and check Gimbal configuration 

Multiple SERIAL ports configured for RC input

RC misconfiguration

see Multiple Radio Control Receivers 

No mission library present

Auto mission feature has been disabled

Custom build server was probably used to produce the firmware without auto missions. Rebuild with auto missions enabled

No rally library present

Rally point feature has been disabled

Custom build server was probably used to produce the firmware without rally point.

--- chunk_id: chunk-0104
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 320
content_hash: 44ec79c569c0fbb7
prev_chunk_id: chunk-0103
next_chunk_id: chunk-0105
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Check Gimbal configuration 

Mount: not healthy

Mount is not communicating with autopilot

Check physical connection between autopilot and gimbal and check Gimbal configuration 

Multiple SERIAL ports configured for RC input

RC misconfiguration

see Multiple Radio Control Receivers 

No mission library present

Auto mission feature has been disabled

Custom build server was probably used to produce the firmware without auto missions. Rebuild with auto missions enabled

No rally library present

Rally point feature has been disabled

Custom build server was probably used to produce the firmware without rally point. Rebuild with Rally points included

No SD card

SD card is corrupted or missing

Format or replace SD card

No sufficiently close rally point located

Rally points are further than RALLY_LIMIT_KM

Move rally points closer to vehicle’s current location or increase RALLY_LIMIT_KM 

OA requires reboot

Object avoidance config change requires reboot

Reboot autopilot. See Object Avoidance configuration 

OpenDroneID: ARM_STATUS not available

OpenDroneID misconfiguration

see Remote ID configuration 

OpenDroneID: operator location must be set

Operator location is not available

see Remote ID configuration 

OpenDroneID: SYSTEM not available

OpenDroneID misconfiguration

see Remote ID configuration 

OpenDroneID: UA_TYPE required in BasicID

OpenDroneID misconfiguration

see Remote ID configuration 

OSD_TYPE2 not compatible with first OSD

OSD1 and OSD2 configurations are incompatible

Disable 2nd OSD (set OSD_TYPE2 to zero) or check OSD configuration 

Param storage failed

Eeprom hardware failure

Check power supply or replace autopilot

parameter storage full

Eeprom storage full

Save params. Reset to defaults. Reload saved parameters.

--- chunk_id: chunk-0105
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: ed08f6b481b365e4
prev_chunk_id: chunk-0104
next_chunk_id: chunk-0106
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Reset to defaults. Reload saved parameters. PiccoloCAN: Servo x not detected

PiccoloCAN misconfiguration or servo issue

Check Currawong Velocity ESC setup instructions 

Pin x disabled (ISR flood)

Sensor connected to GPIO pin is rapidly changing

Check sensor attached to specified pin

Pitch (RCx) is not neutral

RC transmitter’s pitch stick is not centered

Move RC pitch stick to center or repeat radio calibration 

Pitch radio max too low

RC pitch channel max below 1700

Repeat the radio calibration procedure or increase RC2_MAX above 1700

Pitch radio min too high

RC pitch channel min above 1300

Repeat the radio calibration procedure or reduce RC2_MIN below 1300

PRXx: No Data

Proximity sensor is not providing data

Check proximity sensor physical connection and configuration 

PRXx: Not Connected

Proximity sensor is not providing data

Check proximity sensor physical connection and configuration 

Radio failsafe on

RC failsafe has triggered

Turn on RC transmitter or check RC failsafe configuration

Rangefinder x: Not Connected

Rangefinder is not providing data

Check rangefinder’s physical connection to autopilot and configuration . Also check that the rangefinder is actually included in the firmware, many are not and require addition via the custom firmware server 

RC calibrating

RC calibration is in progress

Complete the radio calibration procedure

RC not calibrated

RC calibration has not been done

Complete the radio calibration . RC3_MIN and RC3_MAX must have been changed from their default values (1100 and 1900), and for channels 1 to 4, MIN value must be 1300 or less, and MAX value 1700 or more. RC not found

RC failsafe enabled but no RC signal

Turn on RC transmitter or check RC transmitters connection to autopilot. If operating with only a GCS, see Operation Using Only a Ground Control Station (GCS) 

RCx_MAX is less than RCx_TRIM

RC misconfiguration

Adjust RCx_TRIM to be lower than RCx_MAX or repeat radio calibration 

RCx_MIN is greater than RCx_TRIM

RC misconfiguration

Adjust RCx_TRIM to be higher than RCx_MIN or repeat radio calibration 

RELAYx_PIN=y invalid

Relay misconfigured

RELAYx_PIN is set to an invalid value. Check Relay setup instructions 

RELAYx_PIN=y, set SERVx_FUNCTION=-1

Relay misconfigured

Set SERVOx_FUNCTION to -1

RNGFNDx_PIN not set

Rangefinder misconfigured

Set RNGFNDx_PIN to a non-zero value. See rangefinder configuration 

RNGFNDx_PIN=y invalid

Rangefinder misconfigured

RNGFNDx_PIN is set to an invalid value.

--- chunk_id: chunk-0106
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: c09d772f1d09c553
prev_chunk_id: chunk-0105
next_chunk_id: chunk-0107
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Check Relay setup instructions 

RELAYx_PIN=y, set SERVx_FUNCTION=-1

Relay misconfigured

Set SERVOx_FUNCTION to -1

RNGFNDx_PIN not set

Rangefinder misconfigured

Set RNGFNDx_PIN to a non-zero value. See rangefinder configuration 

RNGFNDx_PIN=y invalid

Rangefinder misconfigured

RNGFNDx_PIN is set to an invalid value. Check rangefinder configuration 

RNGFNDx_PIN=y, set SERVOx_FUNCTION=-1

Rangefinder misconfigured

Set SERVOx_FUNCTION to -1

Roll (RCx) is not neutral

RC transmitter’s roll stick is not centered

Move RC roll stick to center or repeat radio calibration 

Roll radio max too low

RC roll channel max below 1700

Repeat the radio calibration procedure or increase RC1_MAX above 1700

Roll radio min too high

RC roll channel min above 1300

Repeat the radio calibration procedure or reduce RC1_MIN below 1300

RPMx_PIN not set

RPM sensor misconfigured

Check RPMx_PIN value. Check RPM setup instructions 

RPMx_PIN=y invalid

RPM sensor misconfigured

RPMx_PIN is set to an invalid value. Check RPM setup instructions 

RPMx_PIN=y, set SERVOx_FUNCTION=-1

RPM sensor misconfigured

Set SERVOz_FUNCTION to -1

Same Node Id x set for multiple GPS

DroneCan GPS configuration error

Check GPS1_CAN_NODEID and GPS2_CAN_NODEID are different. Set one to zero and reboot autopilot

Same rfnd on different CAN ports

Two rangefinders appearing on different CAN ports

Check USD1, TOFSensP, NanoRadar or Benewake setup instructions

Scripting: loaded CRC incorrect want: x

Script has incorrect CRC

Replace Lua script with expected version

Scripting: running CRC incorrect want: x

Script has incorrect CRC

Replace Lua script with expected version

Scripting: xxx failed to start

A Lua script failed to start

Autopilot out of memory or Lua script misconfiguration. See Lua scripts 

Scripting: xxx out of memory

A Lua script ran out of memory

Increase SCR_HEAP_SIZE or check Lua script configuration 

Servo voltage to low (Xv &lt; 4.3v)

Servo rail voltage below 4.3V

Check power supply to rear servo rail

SERVOx_FUNCTION=y on disabled channel

PWM output misconfigured

SERVOx_FUNCTION is set for a servo output that has been disabled.

--- chunk_id: chunk-0107
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 416
content_hash: a0b4bb00b8512aee
prev_chunk_id: chunk-0106
next_chunk_id: chunk-0108
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Set one to zero and reboot autopilot

Same rfnd on different CAN ports

Two rangefinders appearing on different CAN ports

Check USD1, TOFSensP, NanoRadar or Benewake setup instructions

Scripting: loaded CRC incorrect want: x

Script has incorrect CRC

Replace Lua script with expected version

Scripting: running CRC incorrect want: x

Script has incorrect CRC

Replace Lua script with expected version

Scripting: xxx failed to start

A Lua script failed to start

Autopilot out of memory or Lua script misconfiguration. See Lua scripts 

Scripting: xxx out of memory

A Lua script ran out of memory

Increase SCR_HEAP_SIZE or check Lua script configuration 

Servo voltage to low (Xv &lt; 4.3v)

Servo rail voltage below 4.3V

Check power supply to rear servo rail

SERVOx_FUNCTION=y on disabled channel

PWM output misconfigured

SERVOx_FUNCTION is set for a servo output that has been disabled. See BLHeli setup 

SERVOx_MAX is less than SERVOx_TRIM

PWM output misconfigured

Set SERVOx_TRIM to be lower than SERVOx_MAX

SERVOx_MIN is greater than SERVOx_TRIM

PWM output misconfigured

Set SERVOx_TRIM to be higher than SERVOx_MIN

System not Initialized

System still booting up

Wait, if not resolved shortly there may be a sensor problem not caught by other diagnostics

temperature cal running

Temperature calibration is running

Wait until temp calibration completes or reboot autopilot

terrain data expired, possible errors

Old terrain data that might have errors

Update terrain data on SD card

terrain disabled

Auto mission uses terrain but terrain disabled

Enable the terrain database (set TERRAIN_ENABLE = 1) or remove auto mission items that use terrain altitudes. For Copters also check RTL_ALT_TYPE. Terrain out of memory

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

terrain required but disabled

Auto mission uses terrain but not in firmware

Use custom build server and include the terrain database or remove auto mission items that use terrain altitudes. For Copters also check RTL_ALT_TYPE.

--- chunk_id: chunk-0108
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: 7acf1d413e86ee4e
prev_chunk_id: chunk-0107
next_chunk_id: chunk-0109
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Terrain out of memory

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

terrain required but disabled

Auto mission uses terrain but not in firmware

Use custom build server and include the terrain database or remove auto mission items that use terrain altitudes. For Copters also check RTL_ALT_TYPE. Throttle (RCx) is not neutral

RC transmitter’s throttle stick is too high

Lower throttle stick or repeat radio calibration 

Throttle radio max too low

RC throttle channel max below 1700

Repeat the radio calibration procedure or increase RC2_MAX above 1700

Throttle radio min too high

RC throttle channel min above 1300

Repeat the radio calibration procedure or reduce RC1_MIN below 1300

Too many auxiliary authorisers

More than 3 external systems controlling arming

Check external authorisation system

vehicle outside fence

Vehicle is outside the fence

Move vehicle within the fence

VisOdom: not healthy

VisualOdometry sensor is not providing data

Check visual odometry physical connection and configuration 

VisOdom: out of memory

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

VTOL Fwd Throttle iz not zero

RC transmitter’s VTOL Fwd throttle stick is high

Lower VTOL Fwd throttle stick or repeat radio calibration 

waiting for terrain data

Waiting for GCS to provide required terrain data

Wait or move to location with better GPS reception;check TERRAIN_OPTIONS is correctly set. Yaw (RCx) is not neutral

RC transmitter’s yaw stick is not centered

Move RC yaw stick to center or repeat radio calibration 

Yaw radio max too low

RC yaw channel max below 1700

Repeat the radio calibration procedure or increase RC2_MAX above 1700

Yaw radio min too high

RC yaw channel min above 1300

Repeat the radio calibration procedure or reduce RC1_MIN below 1300

Pre-Arm Failure Messages (Plane Only) 

Message

Cause

Solution

ADSB threat detected

ADSB failsafe. Manned vehicles nearby

See ADSB configuration 

AHRS not healthy

AHRS/EKF is not yet ready

Wait. Reboot autopilot. AIRSPEED_MIN too low x&lt;5 m/s

Parameter set too low, under 5m/s

Raise to at least 20% above stall speed

Bad parameter: ATC_ANG_PIT_P must be &gt; 0

Attitude controller misconfiguration

Increase specified parameter value to be above zero. See Tuning Process Instructions 

Bad parameter: PSC_POSXY_P must be &gt; 0

Position controller misconfiguration

Increase specified parameter value to be above zero.

--- chunk_id: chunk-0109
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: 3feb84c46e4ed892
prev_chunk_id: chunk-0108
next_chunk_id: chunk-0110
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

AIRSPEED_MIN too low x&lt;5 m/s

Parameter set too low, under 5m/s

Raise to at least 20% above stall speed

Bad parameter: ATC_ANG_PIT_P must be &gt; 0

Attitude controller misconfiguration

Increase specified parameter value to be above zero. See Tuning Process Instructions 

Bad parameter: PSC_POSXY_P must be &gt; 0

Position controller misconfiguration

Increase specified parameter value to be above zero. See Tuning Process Instructions 

Check Q_ANGLE_MAX

Set above 80 degrees

Reduce Q_A_ANGLE_MAX below 80; 30 degrees is typical

In landing sequence

Trying to arm while still in landing sequence

Reset mission;change to mission item not in a landing sequence

Invalid THR_FS_VALUE for reversed throttle input

THR_FS_VALUE pwm is not ABOVE the max throttle

Set THR_FS_VALUE above throttle maximum pwm

ROLL_LIMIT_DEG too small x

Parameter set under 3 degrees

Increase, 45 deg recommended minimum for adequate control

PTCH_LIM_MAX_DEG too small x

Parameter set under 3 degrees

Increase, 45 deg recommended minimum for adequate control

PTCH_LIM_MIN_DEG too large x

Parameter set over 3 degrees

Increase, 45 deg recommended minimum for adequate control

Mode not armable

Cannot arm from this mode

Change Mode

Mode not QMODE

Q_OPTION set to prevent arming except in QMODE/AUTO

Change Mode or reset Q_OPTIONS bit 18

Motors: Check frame class and type

Unknown or misconfigured frame class or type

Enter valid frame class and/or type

Motors: Check MOT_PWM_MIN and MOT_PWM_MAX

MOT_PWM_MIN or MOT_PWM_MAX misconfigured

Set MOT_PWM_MIN = 1000 and MOT_PWM_MAX = 2000 and repeat the ESC calibration 

Motors: MOT_SPIN_ARM &gt; MOT_SPIN_MIN

MOT_SPIN_ARM is too high or MOT_SPIN_MIN is too low

Reducse MOT_SPIN_ARM to below MOT_SPIN_MIN . See Setting motor range 

Motors: MOT_SPIN_MIN too high x &gt; 0.3

MOT_SPIN_MIN parameter value is too high

Reduce MOT_SPIN_MIN to below 0.3. See Setting motor range 

Motors: no SERVOx_FUNCTION set to MotorX

At least one motor output has not been configured

Check SERVOx_FUNCTION values for “Motor1”, “Motor2”, etc.

--- chunk_id: chunk-0110
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 340
content_hash: 301a365452309957
prev_chunk_id: chunk-0109
next_chunk_id: chunk-0111
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

See Setting motor range 

Motors: MOT_SPIN_MIN too high x &gt; 0.3

MOT_SPIN_MIN parameter value is too high

Reduce MOT_SPIN_MIN to below 0.3. See Setting motor range 

Motors: no SERVOx_FUNCTION set to MotorX

At least one motor output has not been configured

Check SERVOx_FUNCTION values for “Motor1”, “Motor2”, etc. Check ESC and motor configuration 

Q_ASSIST_SPEED is not set

Q_ASSIST_SPEED has not been set

Set Q_ASSIST_SPEED , See Assisted Fixed-Wing Flight 

Quadplane enabled but not running

Q_ENABLE is set, but QuadPlane code has not started

Reboot

quadplane needs SCHED_LOOP_RATE &gt;= 100

Quadplane needs faster loop times for performance

Increase SCHED_LOOP_RATE ; 300 is typical

set Q_FWD_THR_USE to 0

Trying to use FWD Throttle on Tailsitter

Set Q_FWD_THR_USE = 0 on tailsitters

set TAILSIT_ENABLE 0 or TILT_ENABLE 0

Cannot have simultaneous tiltrotor and tailsitter

Pick one to match your vehicle configuration and reboot

tailsitter setup not complete, reboot

Enabled tiltrotor but have not rebooted yet

Reboot

tiltrotor setup not complete, reboot

Enabled tailsitter but have not rebooted yet

Reboot

Throttle trim not near center stick %x

RC trim for centered throttle stick use incorrect

Set throttle channels RC trim to center position (idle) if FLIGHT_OPTIONS bit 10 is set. unset one of RTL_AUTOLAND or Q_RTL_MODE

Have both parameters set

Only use one or the other parameter to set RTL behavior in VTOLs

Waiting for RC

RC failsafe enabled but no RC signal

Turn on RC transmitter or check RC transmitters connection to autopilot. If operating with only a GCS, see Operation Using Only a Ground Control Station (GCS)

--- chunk_id: chunk-0111
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 520
content_hash: 911aee9f6f8d4389
prev_chunk_id: chunk-0110
next_chunk_id: chunk-0112
section_heading: Other Failure messages
document_type: technical_reference

## Other Failure messages 
### Failsafes: 

Any failsafe (RC, Battery, GCS,etc.) will display a message and prevent arming. ### Barometer failures: 

Baro not healthy : the barometer sensor is reporting that it is
unhealthy which is normally a sign of a hardware failure. Alt disparity : the barometer altitude disagrees with the inertial
navigation (i.e. Baro + Accelerometer) altitude estimate by more than 1
meters. This message is normally short-lived and can occur when the
autopilot is first plugged in or if it receives a hard jolt
(i.e. dropped suddenly). If it does not clear the accelerometers may need to be calibrated or there may
be a barometer hardware issue. ### Compass failures: 

Compass X not healthy : the compass X sensor is reporting that it is
unhealthy, which is a sign of a possible hardware failure. Compass not calibrated : the compass(es) has not been calibrated . the
COMPASS_OFS_X, _Y, _Z parameters are zero or the number or type of
compasses connected has been changed since the last compass calibration
was performed. Compass offsets too high : the primary compass’s offsets length
(i.e. sqrt(x^2+y^2+z^2)) are larger than 500. This can be caused by
metal objects being placed too close to the compass. If only an
internal compass is being used (not recommended), it may simply be the
metal in the board that is causing the large offsets and this may not
actually be a problem in which case you may wish to disable the compass
check. Check mag field : This can result from failing two different checks. First, the sensed magnetic field in the area is 35%
higher or lower than the expected value. The expected length is 530 so
it’s &gt; 874 or &lt; 185. Also, besides this rough check, when the vehicle’s position has been obtained (GPS lock), another check against the field strength predicted using the internal World Magnetic Field database is done with much tighter limits. If you are failing this, either the compass calibration has not calculated good offsets and calibration should be repeated, or your vehicle is near a large metallic or magnetic disturbance and will need to be relocated. Compasses inconsistent : the internal and external compasses are
pointing in different directions (off by &gt;45 degrees). This is normally
caused by the external compasses orientation (i.e. COMPASS_ORIENT 
parameter) being set incorrectly.

--- chunk_id: chunk-0112
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: eb70af8fe974ec76
prev_chunk_id: chunk-0111
next_chunk_id: chunk-0113
section_heading: Other Failure messages
document_type: technical_reference

This is normally
caused by the external compasses orientation (i.e. COMPASS_ORIENT 
parameter) being set incorrectly. ### GPS related failures: 

GPS Glitch : the GPS is glitching and the vehicle
is in a flight mode that requires GPS (i.e. Loiter, PosHold, etc) and/or
the cylindrical fence is enabled. Need 3D Fix : the GPS does not have a 3D fix and the vehicle is in a
flight mode that requires the GPS and/or the cylindrical fence is enabled. Bad Velocity : the vehicle’s velocity (according to inertial
navigation system) is above 50cm/s. Issues that could lead to this
include the vehicle actually moving or being dropped, bad accelerometer
calibration, GPS updating at below the expected 5hz. High GPS HDOP : the GPS’s HDOP value (a measure of the position
accuracy) is above 2.0 and the vehicle is in a flight mode that requires
GPS and/or the cylindrical fence is enabled. This may be resolved by simply waiting a few minutes, moving to a
location with a better view of the sky or checking sources of GPS
interference (i.e. FPV equipment) are moved further from the GPS. Alternatively the check can be relaxed by increasing the GPS_HDOP_GOOD 
parameter to 2.2 or 2.5. Worst case the pilot may disable the fence and
take-off in a mode that does not require the GPS (i.e. Stabilize,
AltHold) and switch into Loiter after arming but this is not
recommended. Note: the GPS HDOP can be readily viewed through the Mission Planner’s
Quick tab as shown below. ### INS checks (i.e. Accelerometer and Gyro checks): 

INS not calibrated : some or all of the accelerometer’s offsets are
zero. The accelerometers need to be calibrated . Accels not healthy : one of the accelerometers is reporting it is not
healthy which could be a hardware issue. This can also occur
immediately after a firmware update before the board has been restarted. Accels inconsistent : the accelerometers are reporting accelerations
which are different by at least 1m/s/s. The accelerometers need to be re-calibrated or there is a
hardware issue. Gyros not healthy : one of the gyroscopes is reporting it is
unhealthy which is likely a hardware issue. This can also occur
immediately after a firmware update before the board has been restarted. Gyro cal failed : the gyro calibration failed to capture offsets.

--- chunk_id: chunk-0113
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: ca7fa221df117a79
prev_chunk_id: chunk-0112
next_chunk_id: chunk-0114
section_heading: Other Failure messages
document_type: technical_reference

This can also occur
immediately after a firmware update before the board has been restarted. Gyro cal failed : the gyro calibration failed to capture offsets. This is most often caused by the vehicle being moved during the gyro
calibration (when red and blue lights are flashing) in which case
unplugging the battery and plugging it in again while being careful not
to jostle the vehicle will likely resolve the issue. Sensors hardware
failures (i.e. spikes) can also cause this failure. Gyros inconsistent : two gyroscopes are reporting vehicle rotation
rates that differ by more than 20deg/sec. This is likely a hardware
failure or caused by a bad gyro calibration. ### Board Voltage checks: 

Check Board Voltage : the board’s internal voltage is below 4.3 Volts
or above 5.8 Volts. If powered through a USB cable (i.e. while on the bench) this can be
caused by the desktop computer being unable to provide sufficient
current to the autopilot - try replacing the USB cable. If powered from a battery this is a serious problem and the power system
(i.e. Power Module, battery, etc) should be carefully checked before
flying. ### Parameter checks: 

Ch7&amp;Ch8 Opt cannot be same : Auxiliary Function Switches are set to the same option which is not permitted because it could lead to confusion. Check FS_THR_VALUE : the radio failsafe pwm value has been set too close to the throttle channels (i.e. ch3) minimum. Check ANGLE_MAX : the ATC_ANGLE_MAX parameter which controls the
vehicle’s maximum lean angle has been set below 10 degrees (i.e. 10)
or above 80 degrees (i.e. 80). ACRO_BAL_ROLL/PITCH : the ACRO_BAL_ROLL parameter is higher than
the Stabilize Roll P and/or ACRO_BAL_PITCH parameter is higher than
the Stabilize Pitch P value. This could lead to the pilot being unable
to control the lean angle in ACRO mode because the Acro Trainer stabilization would overpower the pilot’s
input. ### Battery/Power Monitor: 

If a power monitor voltage is below its failsafe low or critical voltages or failsafe remaining capacity low or critical set points, this check will fail and indicate which set point it is below. It will also fail if these set points are inverted, ie critical point is higher than low point. See Battery Failsafe for Copter, Plane Failsafe Function for Plane, or Failsafes for Rover for more information on these.

--- chunk_id: chunk-0114
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 333
content_hash: b671f54ee1375035
prev_chunk_id: chunk-0113
next_chunk_id: chunk-0115
section_heading: Other Failure messages
document_type: technical_reference

It will also fail if these set points are inverted, ie critical point is higher than low point. See Battery Failsafe for Copter, Plane Failsafe Function for Plane, or Failsafes for Rover for more information on these. In addition, minimum arming voltage and remaining capacity parameters for each battery/power monitor can be set, for example BATT_ARM_VOLT and BATT_ARM_MAH for the first battery, to provide a check that the battery is not only above failsafe levels, but also has enough capacity for operation. ### Airspeed: 

If an airspeed sensor is configured, and it is not providing a reading or failed to calibrate, this check will fail. Airspeed not healthy 

### Logging: 

Logging failed : Logging pre-armed was enabled but failed to write to the log. No SD Card : Logging is enabled, but no SD card is detected. ### Safety Switch: 

Hardware safety switch : Hardware safety switch has not been pushed. ### System: 

Param storage failed : A check of reading the parameter storage area failed. Internal errors (0xx) : An internal error has occurred. Report to ArduPilot development team here 

KDECAN Failed : KDECAN system failure. DroneCAN Failed : DroneCAN system failure. ### Mission: 

See ARMING_MIS_ITEMS 

No mission library present : Mission checking is enabled, but no mission is loaded. No rally library present : Rally point checking is enabled, but no rally points loaded. Missing mission item: xxxx : A required mission items is missing. ### Rangefinder: 

IF a rangefinder has been configured, a reporting error has occurred.

--- chunk_id: chunk-0115
source_document: common-prearm-safety-checks.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 193
content_hash: 430d79cb516325f4
prev_chunk_id: chunk-0114
next_chunk_id: chunk-0116
section_heading: Disabling the Pre-arm Safety Check
document_type: technical_reference

## Disabling the Pre-arm Safety Check 

Warning

Disabling pre-arm safety checks is not recommended. The cause of the pre-arm failure should be corrected before operation of the vehicle if at all possible. If you are confident that the pre-arm check failure is not a real problem, it is possible to skip a failing check. Arming checks can be individually skipped by setting the ARMING_SKIPCHK parameter to something other than 0. For example, setting to 4 skips the checks that the GPS has lock. In extremely unusual circumstances, setting the parameter to -1 can be used to skip all current and future pre-arm checks (though mandatory checks still remain). Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0116
source_document: common-radio-control-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 280
content_hash: 152c82bbaeaae402
prev_chunk_id: chunk-0115
next_chunk_id: chunk-0117
section_heading: Common Radio Control Calibration
document_type: technical_reference

# Common Radio Control Calibration

Radio Control Calibration &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 
Install Ground Station Software 

Autopilot System Assembly 

Loading Firmware to boards with existing ArduPilot firmware 

Loading Firmware to boards without existing ArduPilot firmware 

Connect Mission Planner to AutoPilot 

Configuration 
Basic System Overview 

Choosing Servo Output Functions 

RC Input Throw and Trim 

Radio Control Calibration 
Overview 

Accelerometer Calibration 

Compass Calibration 

Flight Modes 

RC Transmitter Mode Setup 

ESC Calibration 

Automatic Trim 

Failsafe Function 

Airspeed Parameters Setup 

Basic FPV Plane 

Airframe Specific Setup Guides 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Setup for Plane 

Plane Configuration 

Radio Control Calibration

Edit on GitHub 

# Radio Control Calibration 

This article shows how to perform radio control calibration using Mission Planner

--- chunk_id: chunk-0117
source_document: common-radio-control-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 484
content_hash: 341a6298580f0cd9
prev_chunk_id: chunk-0116
next_chunk_id: chunk-0118
section_heading: Overview
document_type: technical_reference

## Overview 

RC transmitters allow the pilot to set the flight mode, control the vehicle’s movement and orientation and also turn on/off auxiliary functions (i.e. raising and lowering landing gear, etc). RC Calibration involves capturing each RC input channel’s minimum, maximum and “trim” values so that ArduPilot can correctly interpret the input. ### Check the Transmitter’s Setup 

Ensure the battery is disconnected (this is important because it is possible to accidentally arm the vehicle during the RC calibration process)

Ensure the RC receiver is connected to the autopilot

Turn on your RC transmitter and if it has “trim tabs” ensure they are in the middle

Connect the autopilot to the PC using a USB cable

On the Mission Planner press the “Connect” button and open Mission Planner’s INITIAL SETUP | Mandatory Hardware | Radio Calibration screen

Some green bars should appear showing the ArduPilot is receiving input from the Transmitter/Receiver. If no bars appear check the receiver’s LED:

No lights may indicate that it is incorrectly wired to the autopilot. Look for connectors that may have been inserted upside down

A Red or flashing LED may indicate that your RC transmitter/receiver need be bound. See the manual that came with your RC equipment for instructions

Check the channel mapping in the transmitter (ie. check which inputs channels are controlled by the transmitter’s sticks, switches and knobs) by moving the sticks, knobs and switches and observing which (if any) green bars move. If this is the first time the transmitter is being used with ArduPilot it is likely that the transmitter’s channel mapping will need to be changed and normally this is done on the transmitter itself using its built-in configuration menu

Determine if your transmitter is Mode1 or Mode2 (see below)

Roll stick should control channel 1

Pitch stick should control channel 2

Throttle stick should control channel 3

Yaw stick should control channel 4

A 3 or 6 position switch (to control the flight mode) should be setup to control Channel 5 (default,if using Copter) or Channel 8 (default, if using Rover or Plane). This channel can be moved by setting the FLTMODE_CH parameter in Plane or Copter, or MODE_CH in Rover.

--- chunk_id: chunk-0118
source_document: common-radio-control-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 1c9752e2b97afe2d
prev_chunk_id: chunk-0117
next_chunk_id: chunk-0119
section_heading: Overview
document_type: technical_reference

If this is the first time the transmitter is being used with ArduPilot it is likely that the transmitter’s channel mapping will need to be changed and normally this is done on the transmitter itself using its built-in configuration menu

Determine if your transmitter is Mode1 or Mode2 (see below)

Roll stick should control channel 1

Pitch stick should control channel 2

Throttle stick should control channel 3

Yaw stick should control channel 4

A 3 or 6 position switch (to control the flight mode) should be setup to control Channel 5 (default,if using Copter) or Channel 8 (default, if using Rover or Plane). This channel can be moved by setting the FLTMODE_CH parameter in Plane or Copter, or MODE_CH in Rover. On Copter, a tuning knob should control Channel 6

On Copter and Rover, any remaining two or three position switches can be setup to control auxiliary functions by mapping them to channels 7 to 12

Note that for reversing motor controls on Plane and Rover, the throttle range is range is normally divided into two parts:
- Reverse throttle control: From RCx_TRIM (typically 1500us) to RCx_MIN , where x is usually “3” for normal RC throttle input channel. This corresponds to motor outputs from SERVOx_TRIM to SERVOx_MIN , where “x” is the output controlling the motor, and assumes the SERVOx_REVERSE bit is not set. - Forward throttle control: From RCx_TRIM (typically 1500us) to RCx_MAX , where x is usually “3” for normal RC throttle input channel. This corresponds to motor outputs from SERVOx_TRIM to SERVOx_MAX , where “x” is the output controlling the motor, and assumes the SERVOx_REVERSE bit is not set. Using a spring-loaded stick may be most convenient, as it naturally returns to the neutral (stopped) position at RCx_TRIM . Note

For Plane, it is possible to use an AUX RC switch to provide easie reverse thrust control using the entire throttle stick range on non-sprung throttle sticks. Also, many set up a switch controlled mix in their RC transmitter to map throttle low stick position to output RCx_TRIM after calibration and either output RC as the stick is raised for reverse or forward operation depending on the TX switch position, giving full throttle stick range to forward or reverse operation.

--- chunk_id: chunk-0119
source_document: common-radio-control-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: dd629efa6a4bbff6
prev_chunk_id: chunk-0118
next_chunk_id: chunk-0120
section_heading: Overview
document_type: technical_reference

Note

For Plane, it is possible to use an AUX RC switch to provide easie reverse thrust control using the entire throttle stick range on non-sprung throttle sticks. Also, many set up a switch controlled mix in their RC transmitter to map throttle low stick position to output RCx_TRIM after calibration and either output RC as the stick is raised for reverse or forward operation depending on the TX switch position, giving full throttle stick range to forward or reverse operation. Move the transmitter’s roll, pitch, throttle, and yaw sticks and ensure the green bars move in the correct direction:

For roll, throttle and yaw channels, the green bars should move in the same direction as the transmitter’s physical sticks. For pitch, the green bar should move in the opposite direction to the transmitter’s physical stick. This is not the default for many transmitters. If one of the green bars moves in the incorrect direction, reverse the channel in the transmitter itself so that logging and outputs etc. are consistent. You may instead reverse the channel in ArduPilot by checking the “Reversed” checkbox (if shown), or directly changing the RCx_REVERSED parameter (where “x” is the input channel from 1 to 4). ### Calibration 

Open Mission Planner’s INITIAL SETUP | Mandatory Hardware | Radio Calibration screen

Click on the green “Calibrate Radio” button on the bottom right

Press “OK” when prompted to check the radio control equipment is on, battery is not connected, and propellers are not attached

Move the transmitter’s control sticks, knobs and switches to their limits. Red lines will appear across the calibration bars to show minimum and maximum values seen so far

Select Click when Done 

A window will appear with the prompt, “Ensure all your sticks are centered and throttle is down and click ok to continue”. Move the throttle to zero and press “OK”. Mission Planner will show a summary of the calibration data. Normal values are around 1100 for minimums and 1900 for maximums. If when testing your throttle stick you notice that the motor turns in a single direction, check in the full parameters list that RCx_TRIM for the throttle channel is set to the motor controller’s neutral value (usually about 1500 us).

--- chunk_id: chunk-0120
source_document: common-radio-control-calibration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 429
content_hash: fd975b7afec83e53
prev_chunk_id: chunk-0119
next_chunk_id: chunk-0121
section_heading: Overview
document_type: technical_reference

Normal values are around 1100 for minimums and 1900 for maximums. If when testing your throttle stick you notice that the motor turns in a single direction, check in the full parameters list that RCx_TRIM for the throttle channel is set to the motor controller’s neutral value (usually about 1500 us). This should be detected and set automatically during calibration if you followed the procedure without forgetting to center your throttle in the last calibration step instead of the normal low position. ### Mode1 and Mode2 Transmitters 

There are two main transmitter configurations:

Mode 1 : left stick controls pitch and yaw, the right stick will
control throttle and roll. Mode 2 : left stick controls throttle and yaw; the right stick will
control pitch and roll. There are two alternative configurations:

Mode 3 : left stick controls pitch and roll, the right stick will
control throttle and yaw. Mode 4 : left stick controls throttle and roll; the right stick will
control pitch and yaw. Mode 3 is the opposite of Mode 2 and Mode 4 is the opposite of Mode 1, giving complete right handed/left handed user options. ### Channel mappings 

Plane default channel mappings are:

Channel 1 : Roll

Channel 2 : Pitch

Channel 3 : Throttle

Channel 4 : Yaw

Channel 8 (default): Flight modes. Mode selection can be mapped to any RC channel using the FLTMODE_CH parameter

Unused channels can be mapped to control additional peripherals. ### Further Reading 

Roll, pitch, throttle and yaw channel mappings can be changed using RCMAP Input Channel Mapping 

Flight mode switch setup to specify which vehicle modes are enabled by each switch position can be found on the RC Transmitter Flight Mode Configuration page

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0121
source_document: common-telemetry-landingpage.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: 11e4edf88d25ae20
prev_chunk_id: chunk-0120
next_chunk_id: chunk-0122
section_heading: Common Telemetry Landingpage
document_type: technical_reference

# Common Telemetry Landingpage

Telemetry (landing page) &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 
ADS-B Receiver 

Airspeed Sensor 

AIS (Automatic Identification System) 

Barometer (external) 

BlackBox Logger using an AutoPilot 

Button Inputs 

Buzzer 

Cameras &amp; Gimbals 

Companion Computers 

Crop Sprayer 

Display (Onboard) 

Drive Calculator Motor/Propeller Analyzer 

DroneCAN Adapter Node 

DroneCAN Peripherals 

ESCs and Motors 

Ethernet Adapters and Switches 

External AHRS Systems 

First Person View Video 

Fuel Flow and Level Sensors 

Generators 

GPS/Compass 

Grippers 

Joystick or Gamepad 

Landing Gear/ Retractable Camera Mount 

LEDs (external) 

On-Screen Display (OSD) 

Optical Flow Sensor 

Parachute 

Power Modules 

Power Tether 

PPM Encoder 

Radio Control Systems 

Rangefinders (Sonar, Lidar, Depth Cameras) 

Relay Switch 

Remote Id (aka Drone Id) 

RPM Sensor 

Safety Switch 

Servos and Actuators 

Smart Batteries 

Telemetry Radio 
Short Range (&lt;10KM) 
Bluetooth 

CUAV PW-Link 

DroneBridge for ESP32 

ESP8266 wifi telemetry 

FrSky telemetry 

i-BUS telemetry 

Yaapu Bi-Directional Telemetry GCS 

HOTT telemetry 

MSP (version 4.2) 

SiK Radio v1 

SiK Radio v2 

SiK Radio configuration 

SiK Radio advanced configuration 

Teravolt AeroTel-24 

XBee 

Long Range 
Andruav Android Cellular 

Blicube RLINK P900 

ClearSky Airlink 4G LTE Telemetry 

CRSF/ELRS Telemetry 

CUAV P8 Radio 

CUAV P9 Radio 

DragonLink 

Herelink 

Holybro SiK Telemetry Radio - Long Range 

Holybro 900Mhz XBP9X Telemetry Radio 

Holybro Microhard Radio Telemetry Radio (P900/P840/P400-C1S) 

Holybro Microhard Radio Telemetry Radio V2 (P400/P900) 

LTE Modems using Lua driver 

LTM telemetry 

mLRS 

RFD900 

Rockblock Satellite Modem 

SPL Satellite Telemetry 

UAVCast 3G/4G Cellular 

XBStation 4G LTE Link 

Applications and Info 
FlightDeck FrSky Transmitter App 

MAVLink2 Packet Signing (Security) 

MAVLink High Latency Protocol 

Repeater for Wireless Ground Station Connections 

Telemetry Radio Regional Regulations 

Temperature Sensors 

Video (High Definition) 

Winch 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Peripheral Hardware 

Telemetry (landing page)

Edit on GitHub 

# Telemetry (landing page) 

Copter/Plane/Rover/Blimp support sharing information with a ground station (or
transmitter) using telemetry.

--- chunk_id: chunk-0122
source_document: common-telemetry-landingpage.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 526
content_hash: 57ae97f90d7320a7
prev_chunk_id: chunk-0121
next_chunk_id: chunk-0123
section_heading: Common Telemetry Landingpage
document_type: technical_reference

# Common Telemetry Landingpage

Telemetry (landing page) &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 
ADS-B Receiver 

Airspeed Sensor 

AIS (Automatic Identification System) 

Barometer (external) 

BlackBox Logger using an AutoPilot 

Button Inputs 

Buzzer 

Cameras &amp; Gimbals 

Companion Computers 

Crop Sprayer 

Display (Onboard) 

Drive Calculator Motor/Propeller Analyzer 

DroneCAN Adapter Node 

DroneCAN Peripherals 

ESCs and Motors 

Ethernet Adapters and Switches 

External AHRS Systems 

First Person View Video 

Fuel Flow and Level Sensors 

Generators 

GPS/Compass 

Grippers 

Joystick or Gamepad 

Landing Gear/ Retractable Camera Mount 

LEDs (external) 

On-Screen Display (OSD) 

Optical Flow Sensor 

Parachute 

Power Modules 

Power Tether 

PPM Encoder 

Radio Control Systems 

Rangefinders (Sonar, Lidar, Depth Cameras) 

Relay Switch 

Remote Id (aka Drone Id) 

RPM Sensor 

Safety Switch 

Servos and Actuators 

Smart Batteries 

Telemetry Radio 
Short Range (&lt;10KM) 
Bluetooth 

CUAV PW-Link 

DroneBridge for ESP32 

ESP8266 wifi telemetry 

FrSky telemetry 

i-BUS telemetry 

Yaapu Bi-Directional Telemetry GCS 

HOTT telemetry 

MSP (version 4.2) 

SiK Radio v1 

SiK Radio v2 

SiK Radio configuration 

SiK Radio advanced configuration 

Teravolt AeroTel-24 

XBee 

Long Range 
Andruav Android Cellular 

Blicube RLINK P900 

ClearSky Airlink 4G LTE Telemetry 

CRSF/ELRS Telemetry 

CUAV P8 Radio 

CUAV P9 Radio 

DragonLink 

Herelink 

Holybro SiK Telemetry Radio - Long Range 

Holybro 900Mhz XBP9X Telemetry Radio 

Holybro Microhard Radio Telemetry Radio (P900/P840/P400-C1S) 

Holybro Microhard Radio Telemetry Radio V2 (P400/P900) 

LTE Modems using Lua driver 

LTM telemetry 

mLRS 

RFD900 

Rockblock Satellite Modem 

SPL Satellite Telemetry 

UAVCast 3G/4G Cellular 

XBStation 4G LTE Link 

Applications and Info 
FlightDeck FrSky Transmitter App 

MAVLink2 Packet Signing (Security) 

MAVLink High Latency Protocol 

Repeater for Wireless Ground Station Connections 

Telemetry Radio Regional Regulations 

Temperature Sensors 

Video (High Definition) 

Winch 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Peripheral Hardware 

Telemetry (landing page)

Edit on GitHub 

# Telemetry (landing page) 

Copter/Plane/Rover/Blimp support sharing information with a ground station (or
transmitter) using telemetry. Follow the links below for configuration
information based upon your set-up.

--- chunk_id: chunk-0123
source_document: common-telemetry-landingpage.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 566
content_hash: 64750add89fb41d1
prev_chunk_id: chunk-0122
next_chunk_id: chunk-0124
section_heading: Common Telemetry Landingpage
document_type: technical_reference

# Common Telemetry Landingpage

Telemetry (landing page) &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 
ADS-B Receiver 

Airspeed Sensor 

AIS (Automatic Identification System) 

Barometer (external) 

BlackBox Logger using an AutoPilot 

Button Inputs 

Buzzer 

Cameras &amp; Gimbals 

Companion Computers 

Crop Sprayer 

Display (Onboard) 

Drive Calculator Motor/Propeller Analyzer 

DroneCAN Adapter Node 

DroneCAN Peripherals 

ESCs and Motors 

Ethernet Adapters and Switches 

External AHRS Systems 

First Person View Video 

Fuel Flow and Level Sensors 

Generators 

GPS/Compass 

Grippers 

Joystick or Gamepad 

Landing Gear/ Retractable Camera Mount 

LEDs (external) 

On-Screen Display (OSD) 

Optical Flow Sensor 

Parachute 

Power Modules 

Power Tether 

PPM Encoder 

Radio Control Systems 

Rangefinders (Sonar, Lidar, Depth Cameras) 

Relay Switch 

Remote Id (aka Drone Id) 

RPM Sensor 

Safety Switch 

Servos and Actuators 

Smart Batteries 

Telemetry Radio 
Short Range (&lt;10KM) 
Bluetooth 

CUAV PW-Link 

DroneBridge for ESP32 

ESP8266 wifi telemetry 

FrSky telemetry 

i-BUS telemetry 

Yaapu Bi-Directional Telemetry GCS 

HOTT telemetry 

MSP (version 4.2) 

SiK Radio v1 

SiK Radio v2 

SiK Radio configuration 

SiK Radio advanced configuration 

Teravolt AeroTel-24 

XBee 

Long Range 
Andruav Android Cellular 

Blicube RLINK P900 

ClearSky Airlink 4G LTE Telemetry 

CRSF/ELRS Telemetry 

CUAV P8 Radio 

CUAV P9 Radio 

DragonLink 

Herelink 

Holybro SiK Telemetry Radio - Long Range 

Holybro 900Mhz XBP9X Telemetry Radio 

Holybro Microhard Radio Telemetry Radio (P900/P840/P400-C1S) 

Holybro Microhard Radio Telemetry Radio V2 (P400/P900) 

LTE Modems using Lua driver 

LTM telemetry 

mLRS 

RFD900 

Rockblock Satellite Modem 

SPL Satellite Telemetry 

UAVCast 3G/4G Cellular 

XBStation 4G LTE Link 

Applications and Info 
FlightDeck FrSky Transmitter App 

MAVLink2 Packet Signing (Security) 

MAVLink High Latency Protocol 

Repeater for Wireless Ground Station Connections 

Telemetry Radio Regional Regulations 

Temperature Sensors 

Video (High Definition) 

Winch 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Peripheral Hardware 

Telemetry (landing page)

Edit on GitHub 

# Telemetry (landing page) 

Copter/Plane/Rover/Blimp support sharing information with a ground station (or
transmitter) using telemetry. Follow the links below for configuration
information based upon your set-up. Note

Some RC systems incorporate telemetry in addition to RC control

Note

most pure telemetry radios connect to the autopilot via a serial UART using MAVLink 1 or 2 protocol.

--- chunk_id: chunk-0124
source_document: common-telemetry-landingpage.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 84
content_hash: 8a40227c0cf2ff7a
prev_chunk_id: chunk-0123
next_chunk_id: chunk-0125
section_heading: Common Telemetry Landingpage
document_type: technical_reference

Follow the links below for configuration
information based upon your set-up. Note

Some RC systems incorporate telemetry in addition to RC control

Note

most pure telemetry radios connect to the autopilot via a serial UART using MAVLink 1 or 2 protocol. See Telemetry / Serial Port Setup 

Note

High value systems using RC control over a telemetry link should consider Redundant Telemetry Links

--- chunk_id: chunk-0125
source_document: common-telemetry-landingpage.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: 828e243969e25b26
prev_chunk_id: chunk-0124
next_chunk_id: chunk-0126
section_heading: Short Range (&lt;10KM)
document_type: technical_reference

## Short Range (&lt;10KM) 

Bluetooth 

CUAV PW-Link 

DroneBridge for ESP32 

ESP8266 wifi telemetry 

FrSky telemetry 

i-BUS telemetry 

Yaapu Bi-Directional Telemetry GCS 

HOTT telemetry 

MSP (version 4.2) 

SiK Radio v1 

SiK Radio v2 

SiK Radio configuration 

SiK Radio advanced configuration 

Teravolt AeroTel-24 

XBee

### Long Range 
Andruav Android Cellular 

Blicube RLINK P900 

ClearSky Airlink 4G LTE Telemetry 

CRSF/ELRS Telemetry 

CUAV P8 Radio 

CUAV P9 Radio 

DragonLink 

Herelink 

Holybro SiK Telemetry Radio - Long Range 

Holybro 900Mhz XBP9X Telemetry Radio 

Holybro Microhard Radio Telemetry Radio (P900/P840/P400-C1S) 

Holybro Microhard Radio Telemetry Radio V2 (P400/P900) 

LTE Modems using Lua driver 

LTM telemetry 

mLRS 

RFD900 

Rockblock Satellite Modem 

SPL Satellite Telemetry 

UAVCast 3G/4G Cellular 

XBStation 4G LTE Link

### Applications and Info 
FlightDeck FrSky Transmitter App 

MAVLink2 Packet Signing (Security) 

MAVLink High Latency Protocol 

Repeater for Wireless Ground Station Connections 

Telemetry Radio Regional Regulations 

Yaapu Telemetry Scripts for OpenTX 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0126
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: bb1f08a9496541cc
prev_chunk_id: chunk-0125
next_chunk_id: chunk-0127
section_heading: Common Uavcan Setup Advanced
document_type: technical_reference

# Common Uavcan Setup Advanced

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 
Analog Pins 

Advanced Failsafe 

Autopilot Output Mapping 

Auxiliary Functions 

Battery Voltage Compensation 

Bootloader Update 

BLHeli ESCs 

CAN Bus Setup 

Compass Setup (Advanced) 

Compass-less Operation 

Crash Detection 

Damaged Motor/Prop RPM Checks 

DisplayPort 

DroneCAN Setup 
Overview 

DroneCAN Peripheral Types Supported 

DroneCAN Setup Parameters 

DroneCAN Adapter Node 

DroneCAN ESC and Servo Configuration settings 

GPS configuration settings 

DroneCAN LED configuration 

DroneCAN Rangefinder configuration 

DroneCAN Options 

DroneCAN Node ID Conflicts 

CAN FD (Flexible Data rate) 

Mixed Protocols on a DroneCAN CAN bus 

SLCAN 
SLCAN Access on F4 Based Autopilots 

SLCAN Access on F7/H7 Based Autopilots 

DroneCAN GUI 

EKF (Extended Kalman Filter) 

EKF Affinity &amp; Lane Switching 

EKF Sources and Selection 

Ethernet/Network Setup 

Network Capture 

Flight Time Recorder 

Flight Options 

Fly-By-Wire Low Altitude Limit 

FPort Setup 

GeoFencing Failsafe 

GPIOs 

GPS for Yaw (aka Moving Baseline) 

GPS for Altitude 

GPS/Non-GPS Transitions 

Ground Control Station Only Operation 

IMU Temperature Calibration 

Independent Watchdog 

In-Flight FTT and filter control 

Limiting Maximum Power Draw 

Limit Cycle Prevention 

LUA Scripting 

Magnetic Interference 

Magnetometer GeoPhys Array 

MAVLink 

MAVLink2 Packet Signing (Security) 

Moving Vehicle Initialization 

Multiple Radio Control Receivers 

Non-GPS Navigation 

Notification Devices (LEDs,Buzzer,etc.) 

Notch Filter Configuration 

Object Avoidance 

Optical Flow Sensor 

On Screen Displays (OSD) 

OSD Parameter Editor 

Parameter List (Full) 

Parameter Lockdown 

Parameter Reset 

RC Input Channel Mapping (RCMAP) 

RC Options 

Received Signal Strength Indication (RSSI) 

Redundant Telemetry 

Reverse Thrust Setup 

RunCam Camera Configuration and Control 

Safety Switch 

Sensor Position Offset Compensation 

Sensor Testing 

Serial Forwarding to DroneCAN 

Serial Port to Port Passthrough 

Serial Port Configuration 

Ship(Moving Vehicle) Takeoff/Landing 

Telemetry Port Setup 

Terrain Following 

Transmitter Based Tuning 

Video Stabilization (Gyroflow) 

Video Transmitter Control 

UBlox GPS Configuration 

Vibration Damping 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Advanced Configuration 

DroneCAN Setup

Edit on GitHub 

# DroneCAN Setup 

DroneCAN was created to continue the development of the widely used UAVCAN v0 protocol.

--- chunk_id: chunk-0127
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 554
content_hash: 9af09a9ff9df15e7
prev_chunk_id: chunk-0126
next_chunk_id: chunk-0128
section_heading: Common Uavcan Setup Advanced
document_type: technical_reference

# Common Uavcan Setup Advanced

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 
Analog Pins 

Advanced Failsafe 

Autopilot Output Mapping 

Auxiliary Functions 

Battery Voltage Compensation 

Bootloader Update 

BLHeli ESCs 

CAN Bus Setup 

Compass Setup (Advanced) 

Compass-less Operation 

Crash Detection 

Damaged Motor/Prop RPM Checks 

DisplayPort 

DroneCAN Setup 
Overview 

DroneCAN Peripheral Types Supported 

DroneCAN Setup Parameters 

DroneCAN Adapter Node 

DroneCAN ESC and Servo Configuration settings 

GPS configuration settings 

DroneCAN LED configuration 

DroneCAN Rangefinder configuration 

DroneCAN Options 

DroneCAN Node ID Conflicts 

CAN FD (Flexible Data rate) 

Mixed Protocols on a DroneCAN CAN bus 

SLCAN 
SLCAN Access on F4 Based Autopilots 

SLCAN Access on F7/H7 Based Autopilots 

DroneCAN GUI 

EKF (Extended Kalman Filter) 

EKF Affinity &amp; Lane Switching 

EKF Sources and Selection 

Ethernet/Network Setup 

Network Capture 

Flight Time Recorder 

Flight Options 

Fly-By-Wire Low Altitude Limit 

FPort Setup 

GeoFencing Failsafe 

GPIOs 

GPS for Yaw (aka Moving Baseline) 

GPS for Altitude 

GPS/Non-GPS Transitions 

Ground Control Station Only Operation 

IMU Temperature Calibration 

Independent Watchdog 

In-Flight FTT and filter control 

Limiting Maximum Power Draw 

Limit Cycle Prevention 

LUA Scripting 

Magnetic Interference 

Magnetometer GeoPhys Array 

MAVLink 

MAVLink2 Packet Signing (Security) 

Moving Vehicle Initialization 

Multiple Radio Control Receivers 

Non-GPS Navigation 

Notification Devices (LEDs,Buzzer,etc.) 

Notch Filter Configuration 

Object Avoidance 

Optical Flow Sensor 

On Screen Displays (OSD) 

OSD Parameter Editor 

Parameter List (Full) 

Parameter Lockdown 

Parameter Reset 

RC Input Channel Mapping (RCMAP) 

RC Options 

Received Signal Strength Indication (RSSI) 

Redundant Telemetry 

Reverse Thrust Setup 

RunCam Camera Configuration and Control 

Safety Switch 

Sensor Position Offset Compensation 

Sensor Testing 

Serial Forwarding to DroneCAN 

Serial Port to Port Passthrough 

Serial Port Configuration 

Ship(Moving Vehicle) Takeoff/Landing 

Telemetry Port Setup 

Terrain Following 

Transmitter Based Tuning 

Video Stabilization (Gyroflow) 

Video Transmitter Control 

UBlox GPS Configuration 

Vibration Damping 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Advanced Configuration 

DroneCAN Setup

Edit on GitHub 

# DroneCAN Setup 

DroneCAN was created to continue the development of the widely used UAVCAN v0 protocol. This protocol has proven itself as robust and feature rich and has been widely deployed in the commercial drone industry and enjoys broad support among industry partners.

--- chunk_id: chunk-0128
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 589
content_hash: d55d331d625929dc
prev_chunk_id: chunk-0127
next_chunk_id: chunk-0129
section_heading: Common Uavcan Setup Advanced
document_type: technical_reference

# Common Uavcan Setup Advanced

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 
Analog Pins 

Advanced Failsafe 

Autopilot Output Mapping 

Auxiliary Functions 

Battery Voltage Compensation 

Bootloader Update 

BLHeli ESCs 

CAN Bus Setup 

Compass Setup (Advanced) 

Compass-less Operation 

Crash Detection 

Damaged Motor/Prop RPM Checks 

DisplayPort 

DroneCAN Setup 
Overview 

DroneCAN Peripheral Types Supported 

DroneCAN Setup Parameters 

DroneCAN Adapter Node 

DroneCAN ESC and Servo Configuration settings 

GPS configuration settings 

DroneCAN LED configuration 

DroneCAN Rangefinder configuration 

DroneCAN Options 

DroneCAN Node ID Conflicts 

CAN FD (Flexible Data rate) 

Mixed Protocols on a DroneCAN CAN bus 

SLCAN 
SLCAN Access on F4 Based Autopilots 

SLCAN Access on F7/H7 Based Autopilots 

DroneCAN GUI 

EKF (Extended Kalman Filter) 

EKF Affinity &amp; Lane Switching 

EKF Sources and Selection 

Ethernet/Network Setup 

Network Capture 

Flight Time Recorder 

Flight Options 

Fly-By-Wire Low Altitude Limit 

FPort Setup 

GeoFencing Failsafe 

GPIOs 

GPS for Yaw (aka Moving Baseline) 

GPS for Altitude 

GPS/Non-GPS Transitions 

Ground Control Station Only Operation 

IMU Temperature Calibration 

Independent Watchdog 

In-Flight FTT and filter control 

Limiting Maximum Power Draw 

Limit Cycle Prevention 

LUA Scripting 

Magnetic Interference 

Magnetometer GeoPhys Array 

MAVLink 

MAVLink2 Packet Signing (Security) 

Moving Vehicle Initialization 

Multiple Radio Control Receivers 

Non-GPS Navigation 

Notification Devices (LEDs,Buzzer,etc.) 

Notch Filter Configuration 

Object Avoidance 

Optical Flow Sensor 

On Screen Displays (OSD) 

OSD Parameter Editor 

Parameter List (Full) 

Parameter Lockdown 

Parameter Reset 

RC Input Channel Mapping (RCMAP) 

RC Options 

Received Signal Strength Indication (RSSI) 

Redundant Telemetry 

Reverse Thrust Setup 

RunCam Camera Configuration and Control 

Safety Switch 

Sensor Position Offset Compensation 

Sensor Testing 

Serial Forwarding to DroneCAN 

Serial Port to Port Passthrough 

Serial Port Configuration 

Ship(Moving Vehicle) Takeoff/Landing 

Telemetry Port Setup 

Terrain Following 

Transmitter Based Tuning 

Video Stabilization (Gyroflow) 

Video Transmitter Control 

UBlox GPS Configuration 

Vibration Damping 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Advanced Configuration 

DroneCAN Setup

Edit on GitHub 

# DroneCAN Setup 

DroneCAN was created to continue the development of the widely used UAVCAN v0 protocol. This protocol has proven itself as robust and feature rich and has been widely deployed in the commercial drone industry and enjoys broad support among industry partners. The proposed introduction of the UAVCAN v1 protocol involved changes to UAVCAN that increased complexity and did not offer a smooth migration path for existing deployments.

--- chunk_id: chunk-0129
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 148
content_hash: 6b4cfa2d8bab84b8
prev_chunk_id: chunk-0128
next_chunk_id: chunk-0130
section_heading: Common Uavcan Setup Advanced
document_type: technical_reference

This protocol has proven itself as robust and feature rich and has been widely deployed in the commercial drone industry and enjoys broad support among industry partners. The proposed introduction of the UAVCAN v1 protocol involved changes to UAVCAN that increased complexity and did not offer a smooth migration path for existing deployments. After extended discussions within the UAVCAN consortium it was decided that the best solution was to continue development of UAVCAN v0 under the name DroneCAN. This article provides guidance to setup DroneCAN protocol on ArduPilot. Tip

The physical CAN port, and its driver selected as DroneCAN protocol, should be enabled first. Please refer to the
CAN Bus Setup

--- chunk_id: chunk-0130
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 168
content_hash: a73a481cfe48cbad
prev_chunk_id: chunk-0129
next_chunk_id: chunk-0131
section_heading: Overview
document_type: technical_reference

## Overview 

DroneCAN is a lightweight protocol designed for reliable communication
in aerospace and robotic applications via CAN bus. The DroneCAN network is a decentralized peer network, where each peer
(node) has a unique numeric identifier - node ID and that is only one
parameter needs to be set for basic setup. Detailed description of protocol can be found at https://dronecan.github.io/

### DroneCAN Peripheral Types Supported 
ArduPilot currently supports the following types of DroneCAN peripherals:

GPS

Compass

Barometer

Rangefinder

ADSB Receiver

Power Module

LED

Buzzer

Airspeed

Safety Switch/LED

DroneCAN Adapter Node

DroneCAN device type is selected by:

GPS,Compass, Barometer, ADSB Receiver, LED, Buzzer, Safety Switch/LED, and Airspeed devices are automatically identified in the DroneCAN protocol

Rangefinder: RNGFNDx_TYPE = 24

Power Module: BATT_MONITOR or BATTx_MONITOR = 8

--- chunk_id: chunk-0131
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 482
content_hash: 7c823571d72072c7
prev_chunk_id: chunk-0130
next_chunk_id: chunk-0132
section_heading: DroneCAN Setup Parameters
document_type: technical_reference

## DroneCAN Setup Parameters 

shown for the first DroneCAN driver, second driver has identical parameters

CAN_D1_PROTOCOL if set for DroneCAN(1) has the following associated parameters:

CAN_D1_UC_POOL : a memory pool for the driver of this size will be allocated if possible. The default size can usually be reduced, saving RAM for other functions and features, if the CAN traffic is light, as with GPSes or Compass, as opposed to ESCs. ### DroneCAN Adapter Node 
These devices are general purpose DroneCAN nodes with I/O ports that allow the attachment of non-DroneCAN ArduPilot peripherals to the DroneCAN bus via UART ports, I2C, SPI, and/or GPIOs. See DroneCAN Adapter Nodes . ### DroneCAN ESC and Servo Configuration settings 
See DroneCAN ESCs for information on DroneCAN ESCs. Each DroneCAN ESC or Servo will have an programmed ID or channel address corresponding to the autopilot’s servo/motor output channel. These are set by switches on the ESC or via a setup/configuration program, depending on the ESC. There are three parameters that determine which autopilot servo/motor channels are sent to the CAN ESC and/or Servos:
For the examples below, the values are shown for CAN driver #1. CAN_D1_UC_NODE - which is the node ID of the autopilot sending the commands to the ESCs so that there can be differentiation between multiple sources on the CAN bus

CAN_D1_UC_ESC_BM - bitmask that determines which autopilot servo/motor output signals are sent to the DroneCAN ESCs. CAN_D1_UC_SRV_BM - bitmask that determines which autopilot servo/motor output signals are sent to the Servos on DroneCAN Servos

In the bitmap masks, each bit position represents an ESC or servo ID number
that the corresponding autopilot servo/motor channel command will be directed to. For example, 00001111 (15 decimal) would send commands to ESC or SERVO IDs 0 through 3. Note

When using DroneCAN ESCs/Servos, you can set the SERVOx_FUNCTION for those, but still use those outputs on the autopilot for GPIOs using the SERVO_GPIO_MASK parameter. The autopilot outputs will become GPIOS and the corresponding SERVOx_FUNCTION will be sent out DroneCAN. To reduce bandwidth, the CAN_D1_UC_ESC_BM and CAN_D1_UC_SRV_BM params should be set
to enable only the motor and servo channels you need CAN signals to be sent to.

--- chunk_id: chunk-0132
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 166
content_hash: 4accdc863ce77051
prev_chunk_id: chunk-0131
next_chunk_id: chunk-0133
section_heading: DroneCAN Setup Parameters
document_type: technical_reference

The autopilot outputs will become GPIOS and the corresponding SERVOx_FUNCTION will be sent out DroneCAN. To reduce bandwidth, the CAN_D1_UC_ESC_BM and CAN_D1_UC_SRV_BM params should be set
to enable only the motor and servo channels you need CAN signals to be sent to. In addition, the CAN_D1_UC_ESC_OF parameter lets you further maximize bandwidth by offsetting the ESC position to the first time slots on the bus, eliminating empty time slots. For example, if the ESCs are on outputs 5 to 8, an offset of 4 will transport them in the first 4 timeslots which would otherwise be empty and consume bandwidth. Example: For a configuration of CAN servos on channels 1,2,4 and ESC motor on channel 3, set:

Example: CAN_D1_UC_SRV_BM = 0x0B

Example: CAN_D1_UC_ESC_BM = 0x04

--- chunk_id: chunk-0133
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 314
content_hash: badb7f744400bf2c
prev_chunk_id: chunk-0132
next_chunk_id: chunk-0134
section_heading: GPS configuration settings
document_type: technical_reference

## GPS configuration settings 

If there is a DroneCAN GPS device, it has to be enabled in GPS 
subgroup of parameters. The TYPE parameter should be set to 9 for corresponding GPS receiver in autopilot. ### DroneCAN LED configuration 
DroneCAN LEDs are enabled by setting bit 5 in the NTF_LED_TYPES bitmask. The CAN_D1_UC_NTF_RT sets the rate that notification messages are transmitted in DroneCAN. ### DroneCAN Rangefinder configuration 
Set RNGFNDx_TYPE = 24 to enable DroneCAN rangefinder type. Rangefinder data received over DroneCAN will only be used if the received sensor_id matches the parameter RNGFNDx_ADDR . For AP_Periph firmware based adaptor nodes, this value is 0, so RNGFNDx_ADDR must be set to 0. Other DroneCAN rangefinders may differ. See also DroneCAN Adaptor Node instructions. ### DroneCAN Options 
Several options for each DroneCAN driver can be selected via the CAN_D1_UC_OPTION and CAN_D2_UC_OPTION bitmask parameters. Default is not set:

CAN_Dx_UC_OPTION bit

Function when set

0

ClearDNADatabase, see below 

1

IgnoreDNANodeConflicts, see below 

2

EnableCanfd, CANFD below 

3

IgnoreDNANodeUnhealthy, ignore disconnected node ids

4

SendServoAsPWM, instead of sending servo positions as -1 to -1, send as PWM values in us

5

SendGNSS, send GPS fix and status info over DroneCAN, used by some gimbals

6

UseHimarkServo, enable Himark Servo command set

7

HobbyWingESC, enable command set for this esc

8

EnableStats, enable peripheral to send bus stats

9

EnableFlexDebug, enable flexible debugging via LUA, see this example 

10

SecondaryAllowExtendedFrames, see https://github.com/ArduPilot/ardupilot/blob/master/libraries/AP_Scripting/applets/CAN_playback.lua

--- chunk_id: chunk-0134
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 178
content_hash: 04c54bfb7a8165a4
prev_chunk_id: chunk-0133
next_chunk_id: chunk-0135
section_heading: DroneCAN Node ID Conflicts
document_type: technical_reference

## DroneCAN Node ID Conflicts 

When a device is attached and recognized, it’s node ID and hardware ID are entered into a database which is stored between power cycles. If multiple devices with the same node ID and different hardware IDs are used (swapping smart batteries, for example, with the same node ID), a conflict will arise in the database. This will require the use of the CAN_D1_UC_OPTION parameter to allow the database to be reset on the next boot, or conflicts in the database to be ignored. ### CAN FD (Flexible Data rate) 
If the DroneCAN port is attached to CAN FD peripherals, setting CAN_D1_UC_OPTION bit 2 (+ value 4) will enable this mode. Note

CAN FD requires a larger memory pool allocation than normal. Default is 24KB instead of the normal 12KB.

--- chunk_id: chunk-0135
source_document: common-uavcan-setup-advanced.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 233
content_hash: b061d8059047368c
prev_chunk_id: chunk-0134
next_chunk_id: chunk-0136
section_heading: Mixed Protocols on a DroneCAN CAN bus
document_type: technical_reference

## Mixed Protocols on a DroneCAN CAN bus 

If the CAN_Dx_PROTOCOL is DroneCAN, then the following other devices with differing protocols can also reside on that bus by setting the CAN_Dx_PROTOCOL2 parameter:

ID

Device Protocol

7

USD1

10

Scripting

11

Benewake

12

Scripting2

13

TOFSenseP

14

NanoRadar_NRA24

### SLCAN 
Note

SLCAN access via COM port is disabled when armed to lower cpu load. Use SLCAN via MAVLink instead. This method is generally preferred, in any case. ArduPilot and DroneCAN provide a means to directly communicate with DroneCAN devices on the CAN BUS attached to the autopilot: SLCAN. Enabling SLCAN and communicating with the DroneCAN devices is dependent on the autopilot’s processor. F7/H7 processors use one method and F4, a different method. Mission Planner SLCAN 

SLCAN Access on F4 Based Autopilots 

SLCAN Access on F7/H7 Based Autopilots 

DroneCAN GUI 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0136
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 486
content_hash: 9703f2db930548d7
prev_chunk_id: chunk-0135
next_chunk_id: chunk-0137
section_heading: Common Vibration Damping
document_type: technical_reference

# Common Vibration Damping

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 

First Time Setup 
Install Ground Station Software 

Autopilot System Assembly 
Mounting the Autopilot 

Autopilot Wiring 

NAVIO2 (Linux based) Wiring QuickStart 
Attaching NAVIO2 to a Raspberry Pi 

Powering NAVIO2 

Connect remote control inputs 

GNSS Antenna 

Connect Motors 

Connect other peripherals 

Related information 

Installing GPS + Compass Module 

Detailed Vehicle Builds 

Loading Firmware to boards with existing ArduPilot firmware 

Loading Firmware to boards without existing ArduPilot firmware 

Connect Mission Planner to AutoPilot 

Configuration 

Airframe Specific Setup Guides 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Setup for Plane 

Autopilot System Assembly Instructions for Plane 

NAVIO2 Assembly and Wiring Quick Start 

Vibration Damping

Edit on GitHub 

# Vibration Damping 

Autopilots have accelerometers that are sensitive to vibrations. These accelerometer values are combined with barometer and
GPS data to estimate the vehicle’s position. With excessive
vibrations, the estimate can be thrown off and lead to very bad
performance in modes that rely on accurate positioning (e.g. on Copter:
AltHold, Loiter, RTL, Guided, Position and Auto flight modes). Please refer to the Measuring Vibration page for details of
how to measure your vehicle’s vibration levels and confirm they are within the acceptable range

The goal of vibration damping is to reduce high and medium frequency
vibrations while still allowing low frequency actual board movement to
take place in concert with the airframe. Double sided foam tape or Velcro has traditionally been used to attach
the autopilot to the frame. In many cases foam tape or Velcro
does not provide adequate vibration isolation because the mass of the
autopilot is so small. Note

The examples and images in this article refer to Copter, but the
information is also largely applicable to Plane and Rover.

--- chunk_id: chunk-0137
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 168
content_hash: f73be8c8bd82cb18
prev_chunk_id: chunk-0136
next_chunk_id: chunk-0138
section_heading: 3M, Du-Bro or HobbyKing Foam
document_type: technical_reference

## 3M, Du-Bro or HobbyKing Foam 

One of the following three types of foam should be cut into small 1cm ~ 2cm squares and attached to each of the four corners of the autopilot as described on the Mounting the Autopilot wiki page :

3M Foam is sticky on both sides and comes pre-cut so that individual squares can be easily attached to the autopilot 
sold by mRobotics 

sold by Holybro 

Du-Bro 1/4” R/C foam 

HobbyKing orange foam (discontinued)

For the last two options “carpet fixing tape” will be required to attach the foam to the autopilot and vehicle frame. For vehicles with internal combustion engines , the autopilot should be mounted on an intermediate plate with self adhesive lead weights added to increase its mass.

--- chunk_id: chunk-0138
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 224
content_hash: a72d0e6f2d7003fd
prev_chunk_id: chunk-0137
next_chunk_id: chunk-0139
section_heading: Gel pads
document_type: technical_reference

## Gel pads 

Cut one of the recommended gels into 1cm ~ 2cm squares and attach to each corner of the autopilot. Possible gels include:

Kyosho Zeal Gel Tape performs best and is available from Amazon, E-Bay and A-Main Hobbies

United States Silicone Gel Tape and Pads (V10Z62MGT5 tape recommended) 

United Kingdom Silicone Gel Tape, Pads and
grommets 

Moon Gel Pads 
(also available in music stores). Caution: Moon Gel has been shown
to fail in heat above 100 degrees Fahrenheit so it should be used
cautiously. Secure the autopilot to the frame with 1cm) wide velcro retaining
strap or a rubber band. Be careful the strap does not hold down the
controller so securely that it interferes with the damping of the
pads. Consider putting a layer of soft foam between the strap and the
autopilot. FlameWheel F330 with PX4FMU Mounted on Intermediate platform 

The blog Testing simple anti-vibration solutions for GoPro on an ArduCopter 
has a video demonstrating vibration isolation using Moon Gel on a Go-Pro camera.

--- chunk_id: chunk-0139
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 396
content_hash: a00ac295737746fc
prev_chunk_id: chunk-0138
next_chunk_id: chunk-0140
section_heading: 3D Printed Anti-Vibration Platform
document_type: technical_reference

## 3D Printed Anti-Vibration Platform 

GuyMcCaldin’s 3D Printed vibration mount on Thingiverse using dampers like these . The mount can be installed using double sided tape, or M3 screws. ### 3D Printed Anti-Vibration Platform for NAVIO2 
Anti-vibration for NAVIO2 can be easily 3D printed. It significantly simplifies mounting and eliminates vibrations. You can find STL files here . Anti-vibration with Navio2 mounted on frame:

### O-ring Suspension Mount 
Create a platform upon which to mount your autopilot with
holes or screws on the four corners. Mount your autopilot on
this board with double sided foam tape. Mount 4 standoffs on the top of your frame spaced 1/10” to 1/8”
further apart than the width of the platform upon which the control
board has been mounted. Insert 1/16” nylon O-rings through each corner of the autopilot and the standoffs so that the autopilot has no hard
connections to the frame. Link (Here!) 

The overall O-ring diameter should be chosen to firmly retain the
board while providing for light to moderate initial but rapidly
snubbed movement of the board (generally 1/2” to 3/4” OD) and
Silicone O-rings should generally damp better than Buna-N O-rings
(Sizes 15 - 21) if you can acquire them. FlameWheel F450 O-Ring Suspension Platform Mount 

Vibrations are short coupled, so all that leaving excess corner
clearance does is to require higher initial O-ring tension which reduces
vibration damping responsiveness and allows the board to physically tilt
more (which is undesirable as it throws the sensor to airframe
relationship off). The disadvantage to O-ring suspension versus Gel pads is that it is
mechanically more complex and it requires tuning of both of O-ring
diameter and cross section. You can combine O-ring and gel pad design by using an intermediate plate
and benefit from dual rate damping.

--- chunk_id: chunk-0140
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: 79a298b591228319
prev_chunk_id: chunk-0139
next_chunk_id: chunk-0141
section_heading: Ear Plug Mount
document_type: technical_reference

## Ear Plug Mount 

Purchase slow response silicon or urethane foam or PVC foam earplugs
such as these from 3M . Create a platform upon which to mount your autopilot with
holes at the four corners. The holes should be large enough to allow
the ear plugs to be inserted into them but not so loose that the
board comes loose during hard landings. Ensure the holes are smooth
so they do not cut into the ear plugs. Also keep the holes near the
corners of your electronic module plate as possible to minimize
unnecessary module movement. Mount your autopilot on this board with double sided foam
tape. Extra mass added to the board may improve vibration damping. Squeeze the earplugs through existing holes in the frame (or cut new
holes) and the holes in the board upon which the autopilot is
mounted. “Tuning” is possible by varying the amount of earplug left
exposed in the middle. Ear Plug Vibration Mount

--- chunk_id: chunk-0141
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 261
content_hash: 89f654097cae3fe6
prev_chunk_id: chunk-0140
next_chunk_id: chunk-0142
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

## Bulb Damper + Ear Plug Vibration Mount 

Mounting plate with a 100g soft rubber bulb type
“gimbal” damper at each corner and a half a urethane foam earplug
placed inside each one. Gimbal bulb type dampers themselves can work in tension or
compression. The earplugs provide an additional damping medium with a different
frequency damping range than the bulb dampers by themselves. The ear plugs also stiffen the bulb mounts up a bit preventing
excessive free motion being caused by normal flight maneuvers. This was successful at damping a Flamewheel clone with flexible arms
and over size 12” propellers into the .05 G range. The autopilot is also mounted on anti-vibration grommets available from McMaster Carr (package of 25 each part #9311K64 recommended). The 100G bulb type gimbal vibration dampers can be ordered direct
from a variety of vendors: copter-rc.com 

### Advice for reducing vibrations 

For copters the largest source of vibration is normally the blades passing over the arms but other sources of vibration also exist and may be reduced by following this advice:

Frame flex especially arm flex is a big cause of asynchronous
vibration, Frame arms should be as rigid as possible.

--- chunk_id: chunk-0142
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 481
content_hash: 2c423f0639bb5de9
prev_chunk_id: chunk-0141
next_chunk_id: chunk-0143
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

The autopilot is also mounted on anti-vibration grommets available from McMaster Carr (package of 25 each part #9311K64 recommended). The 100G bulb type gimbal vibration dampers can be ordered direct
from a variety of vendors: copter-rc.com 

### Advice for reducing vibrations 

For copters the largest source of vibration is normally the blades passing over the arms but other sources of vibration also exist and may be reduced by following this advice:

Frame flex especially arm flex is a big cause of asynchronous
vibration, Frame arms should be as rigid as possible. Original DJI Flamewheel copters have sufficiently rigid injection molded arms, the many clones do not

Aluminum or carbon fibre arms twist and bend less which reduces vibrations

Copters with injection molded exoskeletons or arms like the Iris are sufficiently rigid

Cheap, light frames tend to flex more than high quality stronger ones and the heavier you load the copter the more flex it gets (not good)

Motor to frame arm and frame arm to central hub mounts need to be secure and flex free (sometimes a problem for carbon tube arms)

Motors need to run smoothly (bearings not worn-out or “screeching”)

Prop adapters connecting the propellers to the motors need to be concentric and very straight

Propellers should be fully balanced using a good manual prop balancer

Motor balancing (or really well factory balanced motors like T-Motor) can have a major effect

Propellers that are not well matched to the frame and weight or do not have the same flex for CCW and CW are very problematic

Good propellers vibrate less

Carbon fiber props are rigid and vibrate less which reduces vibration but are very sharp which is a major safety hazard

### Summary of the vibrations that should be damped 

The vibration frequency and amplitude we primarily need to reduce is
a characteristic of the motor / prop units turning at flight speed. That is, it is a fairly high frequency with fairly low amplitude. This requires that we provide a short coupled damping and isolation range. The board itself does not need to have nor benefit from a range of
motion that exceeds the amplitude of the vibration.

--- chunk_id: chunk-0143
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: b7052a324029b7f9
prev_chunk_id: chunk-0142
next_chunk_id: chunk-0144
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

This requires that we provide a short coupled damping and isolation range. The board itself does not need to have nor benefit from a range of
motion that exceeds the amplitude of the vibration. Because the board does not apply any force to the airframe, the only
thing we need to be concerned with Damping / Isolating is the weight
(mass) of the board itself plus the forces applied to it by
airframe’s normal flight maneuvering. Since excellent broad frequency range, high damping materials are
available our biggest concern will be to use the proper amount of
them to optimally damp our autopilot (too much is just as
bad as too little). Combining the autopilot and receiver onto a separate
vibration damped electronics module “plate” or enclosure can increase
the mass of the module making it easier to damp effectively as well
as reducing the interconnecting wiring and making the whole system
more modular. ### Additional Vibration Reduction Considerations 

Hard Disk Drive Anti-Vibration Grommets . can provide sufficient or supplemental vibration reduction

Significant gains in vibration isolation can also be realized by
using a high flex wire and strain relief approach to all wires
connected to the autopilot (and using the minimum number
of wires necessary as well). Some frames have lower than normal vibration characteristics due to
frame stiffness / flex and isolated centralized mass can greatly
influence motor/prop vibration transfer to the central fight
controller. Isolation and damping can be improved somewhat by sandwiching the
autopilot / enclosure between damping pads on both sides
in about twenty percent compression. 30 durometer Sorbothane is
actually specified at 15 to 20 percent compression for optimal
damping. Although 30 durometer Sorbothane seems an excellent candidate,
experience indicates that it becomes permanently compressed
and is not as effective at vibration reduction as the Gel solutions. A link to a Blog about the first APM anti-vibration mounting system
to achieve 0.05 G damping (2/20/2013 improved to 0.02 G), a dual zone
isolation system, combining O-ring suspension and silicone pad is
(Here!) 

Motor balancing can also reduce vibration and especially so for
cheaper or larger motors. Balancing involves:

Tightly fasten a small tie wrap around a motor (WITH NO PROP),
trim off the extended tab and spin it up.

--- chunk_id: chunk-0144
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: b5960c662639a5d0
prev_chunk_id: chunk-0143
next_chunk_id: chunk-0145
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

A link to a Blog about the first APM anti-vibration mounting system
to achieve 0.05 G damping (2/20/2013 improved to 0.02 G), a dual zone
isolation system, combining O-ring suspension and silicone pad is
(Here!) 

Motor balancing can also reduce vibration and especially so for
cheaper or larger motors. Balancing involves:

Tightly fasten a small tie wrap around a motor (WITH NO PROP),
trim off the extended tab and spin it up. Try multiple times, each time turning the tie wrap on the motor
housing a bit until the vibration reduces or goes away. A small piece of Scotch tape can be re-positioned instead of the
tie wrap if desired or for smaller motors. When you locate the spot where there is the least vibration (and
you should be able to hear it), mark the spot directly under the
clasp of the tie-wrap with a felt pen. Add a small dot of hot glue gun glue where the Tie-Wrap clasp was
and increase the glue a bit at a time till the vibration is
minimized. If you put too much glue on it can be removed with an X-acto knife. Camera Mounts also need to be effectively isolated and damped from
vibration, but they already have a number of “soft” mounting
solutions. The camera servos need to be vibration isolated as well, either in
the isolated camera mount itself or with their own vibration
reduction solution. You should use high quality ball joints on your camera servo arms and
adequate bearings or bushings in the mount itself with zero free play
to prevent inertial slop. Quality servos without free play are also a must for precision camera
work. At this point in time it seems that the more rigid the frame the
better because frame flex introduces undesirable mechanical delay
(hysteresis) in translating motor induced actions to the centrally
located autopilot. (Do NOT shock mount the motor Arms). The amount and type of damping medium needs to be carefully matched
to the weight (mass) of the item we are trying to isolate as well as
the frequency and amplitude of the vibrations we are seeking to
damp. We are trying to isolate an autopilot that weighs
less than 2 ounces and this is a very small mass.

--- chunk_id: chunk-0145
source_document: common-vibration-damping.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 368
content_hash: a3aa0a76b3e01c1b
prev_chunk_id: chunk-0144
next_chunk_id: chunk-0146
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

The amount and type of damping medium needs to be carefully matched
to the weight (mass) of the item we are trying to isolate as well as
the frequency and amplitude of the vibrations we are seeking to
damp. We are trying to isolate an autopilot that weighs
less than 2 ounces and this is a very small mass. Virtually all off the shelf solutions (either pad or stud type) are
designed for an isolated mass that would weigh at least 5 to 10 times
what an average autopilot weighs for optimal effectiveness. This
includes all pre-made Sorbothane, Alpha gel, EAR, memory foam or
other silicone or urethane gel or foam mounts as well as Lord Micro
mounts. A threaded stud or sleeve type mount gel mount properly designed for
the mass of our autopilot or electronics module undergoing
the stress’s of normal flight would be a much better long term
solution. ### Terminology 

The methods used will typically incorporate both damping and isolation:

Isolation is simple undamped (spring or rubber band support) which
allows the movement of the isolated object largely separate from the
containing object (Automobile spring for instance). Damping is the conversion of vibration into heat energy by a shock
absorbing medium (automobile shock absorber for instance). ### Links to related discussions 

RC Groups page on Vibration Effects relating to a camera mounts 

DIYDrones discussion related to Vibration Control 

Gary McCray’s DIYDrones BLOG re Vibration Control 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0146
source_document: mission-planner-flight-data.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 209
content_hash: 820156aaa4f6c21d
prev_chunk_id: chunk-0145
next_chunk_id: chunk-0147
section_heading: Mission Planner Flight Data
document_type: technical_reference

# Mission Planner Flight Data

Mission Planner Flight Data Screen &mdash; Mission Planner documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Mission Planner

Mission Planner Overview 

Installing Mission Planner 

Loading Firmware onto boards with existing ArduPilot firmware 

Loading Firmware onto boards without existing ArduPilot firmware (first time only) 

Connect Mission Planner to AutoPilot 

Mission Planning 

Mission Planner Features/Screens 
Flight DATA Screen Overview 
Overview 

Flight Data Screen Details 
Flight Data Screen Details 

Guided Mode 

Flight PLAN Screen 

SETUP Screen 

CONFIGuration and Tuning Screens 

SIMULATION Screen 

Logs 

Advanced Mission Planner Features 

Language Translations 

Compass Calibration 

Accelerometer Calibration 

Radio Control Calibration 

RC Transmitter Flight Mode Configuration 

Live Video 

OpenDroneID Panel 

Mission Planner Building

--- chunk_id: chunk-0147
source_document: mission-planner-flight-data.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 93
content_hash: aed882439362f579
prev_chunk_id: chunk-0146
next_chunk_id: chunk-0148
document_type: technical_reference

Appendix 

Individual 
Partners 
SWAG Shop 

Mission Planner 

Mission Planner Features/Screens 

Flight Data Screen Overview 

Mission Planner Flight Data Screen

Edit on GitHub 

# Mission Planner Flight Data Screen 

This section covers the information you will need to use the features in
the Mission Planner Flight DATA screen - selected in the Top menu of Mission
Planner. An Introduction provides a brief overview with pointers to the various areas of information.

--- chunk_id: chunk-0148
source_document: mission-planner-flight-data.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 456
content_hash: 4ace0cef691d420c
prev_chunk_id: chunk-0147
next_chunk_id: chunk-0149
section_heading: Heads Up Area (HUD)
document_type: technical_reference

## Heads Up Area (HUD) 

This is the area in the upper left corner of the Mission Planner Data screen. Details of what each item is can be found here 

Note

You can detach the HUD to a separate window by double clicking anywhere in the window. Close the window to put it back in the main Mission Planner window. ### Options 

Several Options are available by right-clicking the HUD. Video: 
You can start or stop recording the HUD as an .avi video stored in the logs folder. Set MJPEG Source: Connect and display MJPEG video source from the network. Start Camera: If a video source has been selected in the CONFIG/Planner page, start displaying it in the HUD window. Set GStreamer Source: Connect and display Gstreamer video stream. HereLink Video: Display HereLink video, use the same IP as when connecting MP via UDPCL to Herelink for telemetry. See Herelink documentation. GStreamer Stop: Stop GStreamer video. Note

In the CONFIG/Planner screen, you can select to display video from a capture source on the PC in the HUD window, and have the HUD display overlaid or not on that video. Set Aspect Ratio: clicking this alternates between 4:1 and 16:9 aspect ratio. User Items: You can add any of the telemetry parameters to the display by right-clicking on the HUD, clicking User Items, and checking the items you want to display. Note that you can also view all of the telemetry in the Control and Status area by clicking the Status button. If Scripting is sending NAMED_VALUE_FLOAT values, these will also appear as an item that you can display in the HUD. Russian HUD: Toggle to/from a Russian style HUD (i.e. ground horizon fixed). Swap with Map: swap map to this window and vice versa. Ground Color: Click to change the ground color. HUD Items: Toggle which items are displaying on the HUD such as heading, speed, altitude, etc. Show icons/text: Toggle between using icons or text for the lower HUD items such as battery capacity, EKF status, VIBE status, and GPS status.

--- chunk_id: chunk-0149
source_document: mission-planner-flight-data.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: 4000be64f0ac1f3c
prev_chunk_id: chunk-0148
next_chunk_id: chunk-0150
section_heading: Control and Status (Lower Left)
document_type: technical_reference

## Control and Status (Lower Left) 

The Control and Status area of the Flight Data screen is in the lower left-hand portion of Mission Planner. In this area, you can select any of several different tabs. Some tabs provide information (e.g. Status) and other items allow control of the vehicle (e.g. Actions) using the telemetry uplink. (Telemetry radio connection is required)

Quick: This allows a quick look at just a few telemetry values in large text. Double-click to add items. Right-click to change the number of rows/columns and move the tab to a separate window. Actions: Use this area to control your Auto Pilot either for testing (using USB and no motor battery) or for controlling your vehicle. You can switch modes, arm/disarm (while on the ground), enable an attached joystick, restart a mission in the air, control a camera mount, etc. The dropdown menus on the left are for (in order from top to bottom) choosing a MAVLink action, choosing a waypoint to set, choosing a mode to set, and choosing the state of the camera mount. The buttons directly to the right of each dropdown send the selected action to the connected vehicle. There are shortcut buttons for Auto, Loiter, and RTL modes

Joystick: Allows the user to set up a joystick attached to the ground station. See Joystick/Gamepad for more information. Set Home Alt: Set current altitude to zero

Restart Mission: Set the current waypoint to the start of the current mission

Raw Sensor View: Shows roll, pitch, and yaw angles. Also shows gyro, accelerometer, 8 RC input channels, and 8 servo output channels. Arm/Disarm: Arm and disarm the vehicle. Resume Mission: Change to Auto mode at the previous waypoint. Change Speed: This value is always in m/s and performs a DO_CHANGE_SPEED command

Change Alt: This value is in the user-selected altitude units. The default units are meters. Set Loiter Rad: This changes the loiter radius when in Loiter mode in meters. Clear Track: Clears the purple track line shown on the map. Abort Landing: Commands the vehicle-specific abort landing procedure. Messages: Messages from the vehicle that can range in importance from informational to critical. Important messages also appear on the HUD. Gauges: This shows four popular telemetry gauges. Double click the speed gauge to change the top speed.

--- chunk_id: chunk-0150
source_document: mission-planner-flight-data.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 224
content_hash: 8651072591251be0
prev_chunk_id: chunk-0149
next_chunk_id: chunk-0151
section_heading: Control and Status (Lower Left)
document_type: technical_reference

Gauges: This shows four popular telemetry gauges. Double click the speed gauge to change the top speed. Status: Clicking the Status menu button will display all of the telemetry parameters

Servos/Relay: This allows the setting of any relay pins or setting/overriding RC values for channels 5 thru 14. (Use servo settings with caution, you could change flight modes)

Telemetry Logs : Use this section to view, analyze, convert, and playback telemetry logs that are recorded by Mission Planner. See Playing Back Missions with Tlogs for specifics on playing back your mission and viewing the mission in the map area. Data Flash Logs: This provides a means to download data flash logs, analyze them, or create KML/gpx files from them. Click Review a Log to open a log file and establish a new window to view/analyze the log. Details here . Scripts: : Automation using Python scripts and vehicle state

Note

the ability to change modes from the ground station can be restricted, by mode, using the FLTMODE_GCSBLOCK parameter.

--- chunk_id: chunk-0151
source_document: mission-planner-flight-data.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 310
content_hash: d707d00b16099e9a
prev_chunk_id: chunk-0150
next_chunk_id: chunk-0152
section_heading: Map Area
document_type: technical_reference

## Map Area 

The map area on the right side of the Flight Data screen displays the vehicle track as it moves, provides other information, and allows the user to enter some control actions - which send commands to the vehicle (telemetry required)

Right-click on the map area to select one of these options. Fly to here: (Command) This is guided mode (see bottom of this page Guided Mode )

Fly to here Alt: (Command) Lets you enter an altitude. Fly to Coords: (Command) Lets you fly to a latitude and longitude

Add POI: Lets you set, delete, save, and load Points of Interest to display on the map

Point Camera Here: (Command) Points vehicle and camera at the location of the cursor

Point Camera Coords: (Command) Point vehicle and camera at a location using latitude and longitude coordinates

Trigger Camera Now (Command): Triggers camera if setup . Flight Planner: You can open the flight planner window in the map window area and leave the rest of the Flight Data Screen as is. Click the “CLOSE” button at top to return. Set Home Here: (Command) Set new HOME position for RTL

TakeOff: (Command) Takeoff and loiter at input altitude. Copter and QuadPlane only. Camera Overlap: If checked will show camera overlaps on the map during a survey mission

Altitude Angel Settings: Allows reporting and connection to Altitude Angel services 

Stats : (in development)

--- chunk_id: chunk-0152
source_document: mission-planner-flight-data.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 208
content_hash: 0eed3891a9eda2dd
prev_chunk_id: chunk-0151
next_chunk_id: chunk-0153
section_heading: Information/options at the bottom of the map
document_type: technical_reference

## Information/options at the bottom of the map 

hdop, sats: shows information about the GPS reception quality and the number of satellites in view. Legend: Each color corresponds to the color of the corresponding line showing directions and headings. Black is the GPS track as your vehicle travels. Tuning: Opens/closes the tuning window. Any value in the Status list (double click) can be graphed in real-time. Auto Pan: Checking this box will make the map follow the vehicle and thus keep the vehicle in the center of the screen. Zoom: Shows or selects the current zoom level of the map. You can also use the:

Scroll bar: Use the scroll bar to change the zoom level of the map. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0153
source_document: mission-planner-flight-plan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: 6ce42800468d27b8
prev_chunk_id: chunk-0152
next_chunk_id: chunk-0154
section_heading: Mission Planner Flight Plan
document_type: technical_reference

# Mission Planner Flight Plan

Mission Planner Flight PLAN &mdash; Mission Planner documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Mission Planner

Mission Planner Overview 

Installing Mission Planner 

Loading Firmware onto boards with existing ArduPilot firmware 

Loading Firmware onto boards without existing ArduPilot firmware (first time only) 

Connect Mission Planner to AutoPilot 

Mission Planning 

Mission Planner Features/Screens 
Flight DATA Screen Overview 

Flight PLAN Screen 
The Flight PLAN Screen 
Right Click Menu 

Advanced Mission Creation Tools 

Mission Planning Details 

FENCES Creation 

Rally Points Creation 

SETUP Screen 

CONFIGuration and Tuning Screens 

SIMULATION Screen 

Logs 

Advanced Mission Planner Features 

Language Translations 

Compass Calibration 

Accelerometer Calibration 

Radio Control Calibration 

RC Transmitter Flight Mode Configuration 

Live Video 

OpenDroneID Panel 

Mission Planner Building

--- chunk_id: chunk-0154
source_document: mission-planner-flight-plan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 89
content_hash: 7886e6478ceaf143
prev_chunk_id: chunk-0153
next_chunk_id: chunk-0155
document_type: technical_reference

Appendix 

Individual 
Partners 
SWAG Shop 

Mission Planner 

Mission Planner Features/Screens 

Mission Planner Flight PLAN

Edit on GitHub 

# Mission Planner Flight PLAN 

This section covers what you see and what you can do when in the Flight
PLAN screen of Mission Planner - selected in the menu at the top of the
Mission Planner application. This section provides for planning and
executing flight plans - called missions.

--- chunk_id: chunk-0155
source_document: mission-planner-flight-plan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 472
content_hash: b27be0a0695fbef9
prev_chunk_id: chunk-0154
next_chunk_id: chunk-0156
section_heading: The Flight PLAN Screen
document_type: technical_reference

## The Flight PLAN Screen 

Upper left corner : Displays the distance from HOME, the heading and distance from the last entered waypoint (HOME if one does not exist), and total mission trip distance

Right side : Displays the Waypoints list for the mission. See Planning a Mission with Waypoints and Events for more details. Above this you can set the WPradius, Loiter Radius,and default altitude for waypoints. Altitudes can be entered in Relative (above HOME altitude),Absolute (ASL), and above Terrain. Units are set in the CONFIG/Planner page. Bottom :At the bottom of the planner view you will see the latitude and longitude of the mouse cursor, its ASL (from SRTM, ie Terrain, data). You can select different map providers, Load or Save waypoints files, Read or Write the mission to the autopilot. In addition, the details of the HOME position on the map is shown. Any left mouse click adds a waypoint to the mission. ### Right Click Menu 

Many options are available with a right mouse click:

Delete WP: left click a waypoint, Ineright click and select this, deletes it. Insert WP: adds a waypoint to the mission list at the current vehicle location

Insets Spline WP: Inserts a spline waypoint at current mouse position into the mission list. See here for more info on spline paths. (valid only for Copter, will insert normal waypoint in other vehicles)

Loiter: Adds a Loiter waypoint to the mission at the cursor

Jump: Adds a JUMP command to the mission

RTL: Adds an RTL to the mission at the cursor

Land: Adds a Land point to the mission at the cursor

Takeoff: Adds a TAKEOFF point to the mission at the cursor

DO_SET_ROI: Adds a SET_ROI mission command

Clear Mission: Clears the displayed mission, but only in the workspace, not the autopilot. To clear the autopilot mission, WRITE a cleared workspace to the autopilot

### Advanced Mission Creation Tools 

Mission Planner has the ability to auto-generate numerous survey and grid type missions. Most are based on a drawn polygon on the map. Polygon: 
Draw a Polygon: Clicking this starts drawing a polygon between mouse clicks.

--- chunk_id: chunk-0156
source_document: mission-planner-flight-plan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: 858fbb3d74592f78
prev_chunk_id: chunk-0155
next_chunk_id: chunk-0157
section_heading: The Flight PLAN Screen
document_type: technical_reference

Most are based on a drawn polygon on the map. Polygon: 
Draw a Polygon: Clicking this starts drawing a polygon between mouse clicks. Clear Polygon: Clears the displayed polygon

Save Polygon: Save points to a file

Load Polygon: Load polygon points from a file

From SHP: Load polygon shape from a .shp file

Area: Displays area of drawn polygon

Once drawn, many different surveys,fences, or waypoint grids can be generated with:

GeoFence (Plane only): Plane uses a different method for loading and reading its GeoFence to/from the autopilot, than Copter and Rover use, so this submenu is provided. See below, under Fence Creation, for details. Rally Points (Plane only): Plane uses a different method for loading and reading its Rally points to/from the autopilot, than Copter and Rover use, so this submenu is provided. See below, under Rally Points Creation, for details. Auto WP: 
Create WP Circle: Creates a circle of waypoints

Create Spline WP Circle: Creates a circle of spline waypoints. Area:Displays area of polygon

Text:(in development)

Create Circle Survey: Creates a circular survey. A survey is a set of spaced waypoints designed to allow a camera to take overlapping photos of the survey area. This does not require a drawn polygon. Survey (Grid): Creates a survey mission based on drawn polygon. Face Map: (in development)

Survey(Gridv2): Creates a box survey mission with a different user interface. No pre-drawn polygon required. Simple Grid: Creates a simple grid of waypoints within the drawn polygon. Map Tools: Provides several map tools for measuring distances, pre-fetching map areas for off line use in the field, the ability to plot the mission altitude vs terrain, etc. File Load and Save: Load and Save waypoint, KML, and SHP files

POI: This provides a means to create map markers for points of interest. This allows an easy method to be able to point the camera or fly to points of interest on the map. You can add, delete,save them to a file or load them from a file you have created. They will appear on the map. Tracker Home: Set or retrieve an Antenna Trackers HOME position. Modify Alt: Quickly change all mission altitudes. Enter UTM Coord: Sets your current location to a UTM location in the absence of GPS lock

Set Home Here: Sets the HOME position at current cursor location.

--- chunk_id: chunk-0157
source_document: mission-planner-flight-plan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 52
content_hash: d3411844794b04c1
prev_chunk_id: chunk-0156
next_chunk_id: chunk-0158
section_heading: The Flight PLAN Screen
document_type: technical_reference

Modify Alt: Quickly change all mission altitudes. Enter UTM Coord: Sets your current location to a UTM location in the absence of GPS lock

Set Home Here: Sets the HOME position at current cursor location. Fix mission top/bottom: experimental

--- chunk_id: chunk-0158
source_document: mission-planner-flight-plan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: bada45afd1e20aaf
prev_chunk_id: chunk-0157
next_chunk_id: chunk-0159
section_heading: Mission Planning Details
document_type: technical_reference

## Mission Planning Details 

Here is where you will find the details for mission planning:

Planning a Mission with Way points and Events 

Using Python Scripts in Mission Planner

### FENCES Creation 
In the upper right of the map panel is a drop-down box, normally showing MISSION. If the FENCES option, is selected, then instead of mission/waypoint planning, fence creation is enabled. Fences can be circular, or polygons. In Plane only polygon fences are allowed. In Copter and Rover, circular and polygon, or both superimposed, are possible. Also, exclusion zones (normally a fence is an inclusion zone), are possible. For Plane, the right click menu item, has the GeoFence sub-menu:

Geo-Fence:

Upload: Upload a fence based on drawn polygon

Download: Retrieve fence from autopilot

Set Return Location: Plane fences require a return location. See geofencing . Load from File: Load a geo-fence from a file

Save to File: Save the geo-fence points and return point to a file

Clear: Clear the geo-fence on the map. This does clear the fence in the autopilot as well as the map workspace. For Copter and Rover, the polygon drawing icon in the upper left of the screen is used to create fences. This is an expanded version of the Polygon tools in the right click menu. To create a polygon fence, select “Draw a Polygon”, and left click the points desired. Then select “Fence Inclusion”. You will see a list of items in the mission list area. These are fence items and can be loaded to the autopilot with the “Write” button below, like waypoint lists were. Similarly, they can be read from the autopilot, saved or loaded from a file. To create a circular fence, simply left click. An item will be placed in the mission list. You can adjust the radius of the zone. This may be either an inclusion zone, where flight is allowed, or an exclusion zone, where flight will be prevented. Note

These circular zones may only be shown as blue markers in the PLAN and DATA view at certain zoom levels. In Copter, various parameters of the fences can be set in the CONFIG/GeoFence screen. You can have different types of geo-fences loaded in the autopilot, but elect only to use combinations or altitude, circular, and/or polygon fences loaded by selecting the “Type” on this page.

--- chunk_id: chunk-0159
source_document: mission-planner-flight-plan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 78
content_hash: e315046da77f712d
prev_chunk_id: chunk-0158
next_chunk_id: chunk-0160
section_heading: Mission Planning Details
document_type: technical_reference

In Copter, various parameters of the fences can be set in the CONFIG/GeoFence screen. You can have different types of geo-fences loaded in the autopilot, but elect only to use combinations or altitude, circular, and/or polygon fences loaded by selecting the “Type” on this page. For Rover, these parameters must be set manually in the CONFIG/Full Parameter List screen

--- chunk_id: chunk-0160
source_document: mission-planner-flight-plan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 264
content_hash: d38597f16c569a69
prev_chunk_id: chunk-0159
next_chunk_id: chunk-0161
section_heading: Rally Points Creation
document_type: technical_reference

## Rally Points Creation 

The third option in the MISSION/FENCES/RALLY drop-down box, RALLY, allows creation of a RALLY points list. For use of RALLY points, see Rally Points . Left clicking will create a Rally Point at the cursor, and it will appear in the mission list to the right. Just like waypoints, these can be written to and read from, the autopilot, as well as being saved or loaded to/from a file using the “Read”, “Write”, “Load File”, and “Save File” buttons. In Plane only, saving and loading, is done from the right-click menu:

Rally Points:

Set Rally Point: Create rally point at cursor location

Download: Retrieve rally points from autopilot

Upload: Save rally points to autopilot

Clear Rally Points: Clear the rally points. This does clear the points in the autopilot as well as the map workspace. Save Rally to File: Save the rally points to a file

Load Rally from File: Load the rally points from a file

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0161
source_document: mission-planner-initial-setup.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: 7d19b414a44e063d
prev_chunk_id: chunk-0160
next_chunk_id: chunk-0162
section_heading: Mission Planner Initial Setup
document_type: technical_reference

# Mission Planner Initial Setup

Mission Planner Initial SETUP &mdash; Mission Planner documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Mission Planner

Mission Planner Overview 

Installing Mission Planner 

Loading Firmware onto boards with existing ArduPilot firmware 

Loading Firmware onto boards without existing ArduPilot firmware (first time only) 

Connect Mission Planner to AutoPilot 

Mission Planning 

Mission Planner Features/Screens 
Flight DATA Screen Overview 

Flight PLAN Screen 

SETUP Screen 
Install Firmware 

Install Firmware Legacy 

Mandatory Hardware 

Optional Hardware 
DroneCAN/UAVCAN SLCAN 

DroneCAN Firmware Flashing Video 

Advanced 

CONFIGuration and Tuning Screens 

SIMULATION Screen 

Logs 

Advanced Mission Planner Features 

Language Translations 

Compass Calibration 

Accelerometer Calibration 

Radio Control Calibration 

RC Transmitter Flight Mode Configuration 

Live Video 

OpenDroneID Panel 

Mission Planner Building

--- chunk_id: chunk-0162
source_document: mission-planner-initial-setup.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 142
content_hash: 05d678cd2992610b
prev_chunk_id: chunk-0161
next_chunk_id: chunk-0163
document_type: technical_reference

Appendix 

Individual 
Partners 
SWAG Shop 

Mission Planner 

Mission Planner Features/Screens 

Mission Planner Initial SETUP

Edit on GitHub 

# Mission Planner Initial SETUP 

This section of Mission Planner, invoked by the Menu item SETUP at the top of Mission Planner, has several subsections. The subsections are where you set up and configure your autopilot to prepare it for your particular vehicle. Typically these sections are “must do” actions that are required before first flight. What you see when you enter this section depends on whether or not you
are connected. Each menu item will bring up a new screen, each is
discussed below with links to more detail.

--- chunk_id: chunk-0163
source_document: mission-planner-initial-setup.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 190
content_hash: 6cc4bc6eb16c6256
prev_chunk_id: chunk-0162
next_chunk_id: chunk-0164
section_heading: Install Firmware
document_type: technical_reference

## Install Firmware 

You will see this menu item if the autopilot is both connected or not; however, this menu will only be functional when disconnected. If you have a new autopilot or if you want to update the control software that resides in your autopilot, you must install (upload) the firmware into it. The firmware is located at firmware.ardupilot.org . If the autopilot has ArduPilot firmware already installed, you can use this page to upload firmware for different vehicles or versions. See this Loading firmware page. Otherwise, you must use other methods than Mission Planner for getting ArduPilot installed for the first time, see this section . From this screen you can also select “All Options” allowing you to select and load any variation of the firmware, or “Load custom firmware”, most often used when a developer has trial code to load.

--- chunk_id: chunk-0164
source_document: mission-planner-initial-setup.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 217
content_hash: 3040770c9f4dfac7
prev_chunk_id: chunk-0163
next_chunk_id: chunk-0165
section_heading: Install Firmware Legacy
document_type: technical_reference

## Install Firmware Legacy 

Yet another way to load older versions of the firmware. Again, shown only when not connected. ### Mandatory Hardware 
You will only see this menu item if the autopilot is connected. Click this menu item to see the items you must set up before you attempt to operate your vehicle. Specifics are located in the ArduPilot.org documents which cover your specific vehicle (Copter, Plane, Rover, Blimp). Before operating the vehicle, you must setup:

Accel Calibration 

Compass (optional for Plane) 

Radio Calibration 

Servo Output : configure each output’s function . Default values get loaded upon initial firmware installation, but be sure to check them here. ESC Calibration for Copter only (not required for ESCs running DShot protocol, but must be configured in ArduPilot) Plane and Rover use their own ESC Calibration technique, but is also a mandatory setup item. Flight Modes: Refer to Plane , Copter or Rover mode pages. Failsafe: Refer to Plane , Copter or Rover failsafe pages.

--- chunk_id: chunk-0165
source_document: mission-planner-initial-setup.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: edb154d74a43a5d9
prev_chunk_id: chunk-0164
next_chunk_id: chunk-0166
section_heading: Optional Hardware
document_type: technical_reference

## Optional Hardware 

This submenu allows the configuration of optional devices, many of which can be configured while Mission Planner is unconnected. Programming of the Sik Telemetry Radio, UAVCAN setup, PX4 Optical Flow sensor, and Antenna Tracker can be done here, as well as the setup of a joystick to be used in conjunction with Mission Planner. When connected, peripherals such as Battery Monitors, Integrated OSD, Airspeed Sensors, and Rangefinders can be configured. Also, this submenu has a Motor Test function allowing you to test the direction and order of Copter and QuadPlane Motors. ### DroneCAN/UAVCAN SLCAN 

The SLCAN tool inside Mission Planner allows viewing, configuration, and software updates of DroneCAN nodes connected to the CAN bus port of the autopilot. There are two ways to connect to the DroneCAN node:

Using SLCAN directly

Using SLCAN over MAVLink

Connecting to the DroneCAN node 

If using the direct SLCAN connection method, autopilot parameters have to be configured first. See SLCAN Access on F4 based Autopilots or SLCAN Access on F7/H7 Based Autopilots for setup information. Mission Planner should be in the disconnected state, and make sure the SLCAN port is shown as the selected COM port in the dropdown box in the upper right corner of Mission Planner. If using the MAVLink method, nothing is required for setup and Mission Planner should be in the connected state via the normal MAVLink connection to the autopilot. In Mission Planner, navigate to Initial Setup-&gt;Optional Hardware-&gt;DroneCAN/UAVCAN click on the highlighted red button if connecting using the direct SLCAN method, or the appropriate green button for MAVLink communication over either CAN bus port 1 or port 2, depending on which port the node is attached. The autopilot will connect to Mission Planner using SLCAN, the window will populate with DroneCAN nodes connected. If the node has a bootloader only installed, then the firmware will need to be uploaded. MAINTENANCE will be displayed. Click on update firmware. Firmware can be found here and downloaded for the node. A pop-up will open. Select no and then find firmware for your node previously downloaded and select it. The window will show the firmware being uploaded and a pop-up will show the status. Once complete mode will change to OPERATIONAL . Press the Parameters button to access node settings.

--- chunk_id: chunk-0166
source_document: mission-planner-initial-setup.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 84
content_hash: 2d210b8edf5d1a42
prev_chunk_id: chunk-0165
next_chunk_id: chunk-0167
section_heading: Optional Hardware
document_type: technical_reference

Once complete mode will change to OPERATIONAL . Press the Parameters button to access node settings. From here DroneCAN device parameters can be accessed or changed. Clicking on Inspector will open a popup window to view messages on the CAN bus. To return to normal Mission Planner operation, change to another tab, and re-connect. You may need to wait 2 seconds before re-connecting.

--- chunk_id: chunk-0167
source_document: mission-planner-initial-setup.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 361
content_hash: f065c9d800bb38aa
prev_chunk_id: chunk-0166
next_chunk_id: chunk-0168
section_heading: DroneCAN Firmware Flashing Video
document_type: technical_reference

## DroneCAN Firmware Flashing Video 
### Advanced 
This section is for advanced users. Warning Manager: You can create custom warning messages to be displayed on the HUD and in the messages tab of the DATA screen, based on the values of the status items. MAVLink Inspector: allows monitoring, real-time, of the various MAVLink status messages being received. Proximity: View the data from a 360 lidar, if equipped

Mavlink Signing: This allows you to setup secure communications with the vehicle. Mavlink mirror: This allows you to forward the MAVLink traffic to another network-connected location for monitoring. Also see MAVProxy Forwarding for another method. NMEA: Output the vehicle location as a NMEA GPS string over the network or to a COM port

Follow Me: If using an attached NEMA mode GPS on a COM port to establish the MP GPS location, can send Guided Mode waypoints to the vehicle to follow the GCS. Param Gen: Regenerates Mission Planners parameter list. Occasionally required if new firmware parameters are not being displayed. Moving Base: if NMEA GPS is attached to PC, shows PCs location as moving on the map display

Anon Log: Allows you to hide your location when sharing log files by creating a version with scrambled locations

FFT: Plot an FFT from a log that has IMU batch sampling enabled. See Managing Gyro Noise with the Dynamic Harmonic Notch Filters for an example of its use. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0168
source_document: mission-planner-installation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 169
content_hash: 4b2edd747d770c04
prev_chunk_id: chunk-0167
next_chunk_id: chunk-0169
section_heading: Mission Planner Installation
document_type: technical_reference

# Mission Planner Installation

Installing Mission Planner &mdash; Mission Planner documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Mission Planner

Mission Planner Overview 

Installing Mission Planner 
Windows Installation 
Open Mission Planner 

Updating Mission Planner 
Mission Planner Advanced Installation 

Mission Planner on Android 

Mission Planner on Linux 

Loading Firmware onto boards with existing ArduPilot firmware 

Loading Firmware onto boards without existing ArduPilot firmware (first time only) 

Connect Mission Planner to AutoPilot 

Mission Planning 

Mission Planner Features/Screens 

OpenDroneID Panel 

Mission Planner Building

--- chunk_id: chunk-0169
source_document: mission-planner-installation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 62
content_hash: 8370dfafa80b8e84
prev_chunk_id: chunk-0168
next_chunk_id: chunk-0170
document_type: technical_reference

Appendix 

Individual 
Partners 
SWAG Shop 

Mission Planner 

Installing Mission Planner

Edit on GitHub 

# Installing Mission Planner 

Mission Planner was designed for native Windows installation. However, it is possible to use it under Linux (with some occasional issues) and there is a Beta version for Android OS.

--- chunk_id: chunk-0170
source_document: mission-planner-installation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 322
content_hash: 0297eeae6d553dc0
prev_chunk_id: chunk-0169
next_chunk_id: chunk-0171
section_heading: Windows Installation
document_type: technical_reference

## Windows Installation 

The following instructions show how to install Mission Planner on Windows. These instructions will be suitable for most users. For advanced users and non-standard installations, instructions are found here: . A useful video guide for advanced installation of Mission Planner is located here . Download the latest Mission Planner installer from here 

Double click on the downloaded .msi file to run the installer

Follow the instructions to complete the setup process. The installation utility will automatically install any necessary software drivers. If you receive a DirectX installation error,
please update your DirectX plug-in from the Windows Download Center . If you receive the warning pictured below, select Install this driver software anyway to continue. Mission Planner is normally installed in the C:\Program Files (x86)\Mission Planner folder. An icon to open the Mission Planner is created according to your instructions during the installation. ### Open Mission Planner 

Once installation is complete, open Mission Planner by clicking on its system icon. Then you can either:

Connect Mission Planner to AutoPilot in order to receive telemetry and control the vehicle OR

Load Firmware OR plan autonomous missions . Note

If ArduPilot firmware is not already installed on the autopilot, see Loading Firmware to boards without existing ArduPilot firmware . ### Updating Mission Planner 

Mission Planner automatically notifies you about available updates (when it is connected to the Internet). Please always run the most current version of Mission Planner. Mission Planner Advanced Installation

--- chunk_id: chunk-0171
source_document: mission-planner-installation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 249
content_hash: 6ed855852cf6f837
prev_chunk_id: chunk-0170
next_chunk_id: chunk-0172
section_heading: Mission Planner on Android
document_type: technical_reference

## Mission Planner on Android 

A version for Android is in development and can be downloaded from the Google Play Store here . The latest version is also available here . Download to device, and double click on it to install. ### Mission Planner on Linux 
It is possible to run most Windows based programs on many Linux Distributions using MONO. Mission Planner does run under MONO but will have occasional issues and/or crashes. QGC and MAVProxy are alternatives that run stably in Linux, but if Mission Planner is really desired, you can follow these steps:

Download and install the latest version of MONO from here 

Download Mission Planner as a zip file from here and unzip to a directory. Change to that directory and execute:

mono MissionPlanner . exe 

Note

Zorin OS users: If you see errors with .exe
files during build, run:

sudo apt install mono - complete 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0172
source_document: mission-planner-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 154
content_hash: 047b9ddaeeca1f56
prev_chunk_id: chunk-0171
next_chunk_id: chunk-0173
section_heading: Mission Planner Overview
document_type: technical_reference

# Mission Planner Overview

Mission Planner Overview &mdash; Mission Planner documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Mission Planner

Mission Planner Overview 
What is Mission Planner 

History 

Support 

Navigating the Documentation 

Installing Mission Planner 

Loading Firmware onto boards with existing ArduPilot firmware 

Loading Firmware onto boards without existing ArduPilot firmware (first time only) 

Connect Mission Planner to AutoPilot 

Mission Planning 

Mission Planner Features/Screens 

OpenDroneID Panel 

Mission Planner Building

--- chunk_id: chunk-0173
source_document: mission-planner-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 64
content_hash: 4f51af1d40fd0093
prev_chunk_id: chunk-0172
next_chunk_id: chunk-0174
document_type: technical_reference

Appendix 

Individual 
Partners 
SWAG Shop 

Mission Planner 

Mission Planner Overview

Edit on GitHub 

# Mission Planner Overview 

Mission Planner is a full-featured ground station application for the
ArduPilot open source autopilot project. This page contains information
on the background of Mission Planner and the organization of this site.

--- chunk_id: chunk-0174
source_document: mission-planner-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 226
content_hash: ac9f92913d8b589c
prev_chunk_id: chunk-0173
next_chunk_id: chunk-0175
section_heading: What is Mission Planner
document_type: technical_reference

## What is Mission Planner 

Mission Planner is a ground control station for Plane, Copter and Rover. It is compatible with Windows only. Mission Planner can be used as a
configuration utility or as a dynamic control supplement for your
autonomous vehicle. Here are just a few things you can do with Mission
Planner:

Load the firmware (the software) into the
autopilot board (i.e. Pixhawk series) that controls your vehicle. Setup, configure, and tune your vehicle for optimum performance. Plan, save and load autonomous missions into you autopilot with
simple point-and-click way-point entry on Google or other maps. Download and analyze mission logs created by your autopilot. Interface with a PC flight simulator to create a full
hardware-in-the-loop UAV simulator. With appropriate telemetry hardware you can:

Monitor your vehicle’s status while in operation. Record telemetry logs which contain much more information about the
on-board autopilot logs. View and analyze the telemetry logs. Operate your vehicle in FPV (first person view)

All of these and many more features are covered here.

--- chunk_id: chunk-0175
source_document: mission-planner-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 4e9ef9e7918702e9
prev_chunk_id: chunk-0174
next_chunk_id: chunk-0176
section_heading: History
document_type: technical_reference

## History 

Mission Planner is a free, open-source, community-supported application
developed by Michael Oborne for the open-source APM autopilot project. If you would like to donate to the ongoing development of Mission
Planner, please refer to the following link. Donate

### Support 
The Help Screen: 

Clicking the Help icon at the top of the Mission Planner interface will
open a screen with general information about help with Mission Planner. The “Check for Updates” button will check for available updates to
Mission Planner manually. Mission Planner automatically checks for
updates upon start up and notifies you if an update is available. Please
always run the most current version of Mission Planner, although it is
not necessary to check for updates more often than upon start up. The “Check for BETA Updates” button will install the current development version of Mission Planner. This contains all the latest features and updates, but also might have bugs, since it does not have extensive community testing. At the bottom of the HELP screen is the check box “Show Console Window (restart)” , which enables the console window during Mission Planner operation. That window shows Mission Planner
activity and is primarily for diagnostic purposes. It sometimes shows
some interesting information. A restart of Mission Planner is required
for the option to take effect. Getting Help: 

The support for Mission Planner comes from the community of users like
you. All of the documentation is created by users who volunteer their
time. If you have questions, first look through the table of contents
(upper left of every page) for a topic that may address your question. Next, try a search of the website. If you still need help, then the
community forums are the place to go. There you will find may friendly
users, developers and often, even Michael will chime in. The ArduPilot forum here has existed
for years and has a very large community and numerous general and vehicle specific topics. Reporting Issues: 

You can often resolve a question on a forum. Sometimes you will discover
a bug and use the forums to request it be logged as an official
issue. One of the developers will normally be glad to do so. If you see a need to change or enhance the documentation, please let us
know - again using the forums.

--- chunk_id: chunk-0176
source_document: mission-planner-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 60
content_hash: a65200095d718b4a
prev_chunk_id: chunk-0175
next_chunk_id: chunk-0177
section_heading: History
document_type: technical_reference

One of the developers will normally be glad to do so. If you see a need to change or enhance the documentation, please let us
know - again using the forums. We welcome your suggestions and there
are qualified editors who can implement your suggestions.

--- chunk_id: chunk-0177
source_document: mission-planner-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 194
content_hash: 327e4822938a1d1f
prev_chunk_id: chunk-0176
next_chunk_id: chunk-0178
section_heading: Navigating the Documentation
document_type: technical_reference

## Navigating the Documentation 

Use the table of contents at the top of each page to navigate the
Mission Planner Manual - and the contents of the vehicle specific areas. This section of our website contains information on how to use Mission
Planner as a “general” application. However, some of the pages will also
have some vehicle specific information. Those pages will also be
contained in the specific vehicle’s section of the website. Information
that is primarily specific to a particular vehicle will only be located
in that vehicles section so, if you cannot find information here, try
the section of the website for the vehicle you are using. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0178
source_document: mission-planner-simulation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 204
content_hash: 13d89e026dcd2ba7
prev_chunk_id: chunk-0177
next_chunk_id: chunk-0179
section_heading: Mission Planner Simulation
document_type: technical_reference

# Mission Planner Simulation

Mission Planner Simulation &mdash; Mission Planner documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Mission Planner

Mission Planner Overview 

Installing Mission Planner 

Loading Firmware onto boards with existing ArduPilot firmware 

Loading Firmware onto boards without existing ArduPilot firmware (first time only) 

Connect Mission Planner to AutoPilot 

Mission Planning 

Mission Planner Features/Screens 
Flight DATA Screen Overview 

Flight PLAN Screen 

SETUP Screen 

CONFIGuration and Tuning Screens 

SIMULATION Screen 
Setup and Use 
Extra Command Line 

Simulating Custom Code Branches 

Logs 

Advanced Mission Planner Features 

Language Translations 

Compass Calibration 

Accelerometer Calibration 

Radio Control Calibration 

RC Transmitter Flight Mode Configuration 

Live Video 

OpenDroneID Panel 

Mission Planner Building

--- chunk_id: chunk-0179
source_document: mission-planner-simulation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 128
content_hash: 011ee373b38ac8a3
prev_chunk_id: chunk-0178
next_chunk_id: chunk-0180
document_type: technical_reference

Appendix 

Individual 
Partners 
SWAG Shop 

Mission Planner 

Mission Planner Features/Screens 

Mission Planner Simulation

Edit on GitHub 

# Mission Planner Simulation 

The Simulation tab provides a SITL (Software in the Loop) simulation capability. Many typical frame types for each Vehicle type have been created. This allows you to see the expected behavior for vehicles in missions, or with a joystick attached, actually be able to fly/drive the vehicle simulation as if with RC. This allows you to see potential effects of parameter changes on vehicle behavior or explore mission generation, without risking your vehicle first. Demonstration Video

--- chunk_id: chunk-0180
source_document: mission-planner-simulation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 466
content_hash: 76630ac7840eaaea
prev_chunk_id: chunk-0179
next_chunk_id: chunk-0181
section_heading: Setup and Use
document_type: technical_reference

## Setup and Use 

The Simulation uses the same SITL models as those used in the Linux sim_vehicle.py script (see SITL Simulator (Software in the Loop) , and uses the current master development branch of the code for firmware. Open Mission Planner’s Simulation tab. Choose your vehicle type and frame (the “Model” drop down box). First select the “Model” frame type, then click the vehicle it corresponds to. If no “Model” (frame) is selected, then a normal plane will be used no matter what vehicle is clicked. If a frame is selected and a vehicle clicked that does NOT correspond to it, undefined results may occur. Default parameters for that vehicle/frame will be loaded and the simulation started. Mission Planner can be used to control the vehicle, setup missions, alter parameters, etc. In addition to the normal vehicle parameters, you can also now see and change the “SIM_x” (simulation) parameters via the CONFIG/Full Parameter Tree page. See SITL Parameters for a list of these. ### Extra Command Line 

The Extra command line box on the SIMULATION tab, you can start the SITL with various options:

Home Location : start simulation at any given location using the command --home={location} where location can be either gps coordinates,altitude ASL and vehicle initial heading, or a named location in the Autotest locations file 

-- home = CMAC 
-- home =- 35.363261 , 149.165230 , 584 , 353 

Different Default Parameter File: allows using a different default parameter file. If used in conjunctions with the Wipe checkbox (which wipes any previously changed parameters while running simulations on the chosen vehicle), these parameters will be loaded at simulation start. This avoids having to load and store any parameters desired to be changed for the simulation from the normal defaults. -- defaults =&lt; path to param file &gt; working dir is the sitl folder in Mission Planners documents folder 

Attach a physical device to a SERIALx port in the sim: You can attach actual devices (GPS, RC, Rangefinder,etc.) to a Windows serial COM port and have it attached to a SERIALx port in the simulation for testing.

--- chunk_id: chunk-0181
source_document: mission-planner-simulation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: 96b205de5e44c17e
prev_chunk_id: chunk-0180
next_chunk_id: chunk-0182
section_heading: Setup and Use
document_type: technical_reference

This avoids having to load and store any parameters desired to be changed for the simulation from the normal defaults. -- defaults =&lt; path to param file &gt; working dir is the sitl folder in Mission Planners documents folder 

Attach a physical device to a SERIALx port in the sim: You can attach actual devices (GPS, RC, Rangefinder,etc.) to a Windows serial COM port and have it attached to a SERIALx port in the simulation for testing. -- serialx = uart : COMy 

Note

Although not shown in the above video, current version of Mission Plannner will ask if you want to simulate using the Development(master aka “latest”) or Stable version of the vehicle firmware when you click the vehicle to download the model and parameters and begin the simulation.

--- chunk_id: chunk-0182
source_document: mission-planner-simulation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 118
content_hash: c7cfe244a5d5f804
prev_chunk_id: chunk-0181
next_chunk_id: chunk-0183
section_heading: Simulating Custom Code Branches
document_type: technical_reference

## Simulating Custom Code Branches 

In addition, if you are code developer, you can run SITL using your custom code branch using Mission Planner, either with or without, the physics and visualizations of RealFlight. See the Using Your Code Branch with Mission Planner SITL and RealFlightM section of Using SITL with RealFlight 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0183
source_document: mission-planner-telemetry-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 257
content_hash: 71fc47d5175d63a6
prev_chunk_id: chunk-0182
next_chunk_id: chunk-0184
section_heading: Mission Planner Telemetry Logs
document_type: technical_reference

# Mission Planner Telemetry Logs

Telemetry Logs &mdash; Mission Planner documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Mission Planner

Mission Planner Overview 

Installing Mission Planner 

Loading Firmware onto boards with existing ArduPilot firmware 

Loading Firmware onto boards without existing ArduPilot firmware (first time only) 

Connect Mission Planner to AutoPilot 

Mission Planning 

Mission Planner Features/Screens 
Flight DATA Screen Overview 

Flight PLAN Screen 

SETUP Screen 

CONFIGuration and Tuning Screens 

SIMULATION Screen 

Logs 

Advanced Mission Planner Features 
Telemetry Logs 
When and where tlogs are created 

Setting the datarate 

Playing back missions 

Creating 3d images of the flight path 

Extracting parameters and Waypoints 

Graphing data from a flight 

Video overview of tlogs 

Images with Mission Planner 

MAVLink2 Signing (security) 

Using Python Scripts in Mission Planner 

Swarming 

Advanced Tools 

Language Translations 

Compass Calibration 

Accelerometer Calibration 

Radio Control Calibration 

RC Transmitter Flight Mode Configuration 

Live Video 

OpenDroneID Panel 

Mission Planner Building

--- chunk_id: chunk-0184
source_document: mission-planner-telemetry-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 94
content_hash: 4ccfa2a0c9b206f8
prev_chunk_id: chunk-0183
next_chunk_id: chunk-0185
document_type: technical_reference

Appendix 

Individual 
Partners 
SWAG Shop 

Mission Planner 

Mission Planner Features/Screens 

Other Mission Planner Features 

Telemetry Logs

Edit on GitHub 

# Telemetry Logs 

Telemetry logs (also known as “tlogs”) are recorded by the ground station when you connect ArduPilot to your
computer via a telemetry link . This topic explains how to configure and access tlogs. Note

Dataflash logs 
collect similar information to tlogs (see Diagnosing problems using Logs for more information).

--- chunk_id: chunk-0185
source_document: mission-planner-telemetry-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 248
content_hash: 451de296828b4b28
prev_chunk_id: chunk-0184
next_chunk_id: chunk-0186
section_heading: When and where tlogs are created
document_type: technical_reference

## When and where tlogs are created 

Tlogs are recordings of the MAVLink telemetry messages sent between the
autopilot and the ground station and are automatically created the moment
you press the connect button on the ground station. If using the Mission Planner, files of the
format YYYY-MM-DD hh-mm-ss.tlog appear in the “logs” subfolder in your
Mission Planner installation folder or to the location you select in the
Planner options [Config/Tuning] [Planner]. Besides the “.tlog” files, “.rlog” files are also created. These
contain all the .tlog data plus additional debug output from the mission
planner. but cannot be parsed or played back so they should be ignored. ### Setting the datarate 
The desired rate at which data is sent from the autopilot to the ground station can be controlled through the mission planner’s Config/Tuning &gt; Planner screen’s Telemetry drop-downs. Because all data sent over the telemetry link is also recorded in the tlog, this also controls the rate of data saved to the tlogs. Note that due to bandwidth limitations, the actual rate of the data sent and saved may be lower than the rate requested.

--- chunk_id: chunk-0186
source_document: mission-planner-telemetry-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 209
content_hash: 38a1bcd7fea46f74
prev_chunk_id: chunk-0185
next_chunk_id: chunk-0187
section_heading: Playing back missions
document_type: technical_reference

## Playing back missions 

It is possible to play back a tlog by doing the following:

Open the mission planner’s Flight Data screen

click on the Telemetry Logs tab

Press “Load Log” and find the flight’s tlog file

Press “Play”

You can also jump to the point of interest in the log using the slider
and control the speed of the playback with the predefined Speed buttons. While the log is replaying, the HUD will move and the vehicles location
on the map will update as it did during the flight. Individual data
values can be seen through the Status tab and you can even display them
in a graph by clicking on the “Tuning” checkbox under the map and then
double clicking on the data legend to bring up a box from which you can
choose exactly which data fields are graphed as shown below. This will
show the recorded data changing as the flight progresses.

--- chunk_id: chunk-0187
source_document: mission-planner-telemetry-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 278
content_hash: 0a5086df4ebf1ad8
prev_chunk_id: chunk-0186
next_chunk_id: chunk-0188
section_heading: Creating 3d images of the flight path
document_type: technical_reference

## Creating 3d images of the flight path 

You can create KMZ files by doing this:

Open the mission planner’s Flight Data screen

Click on the Telemetry Logs tab

Press the “Tlog &gt; Kml or Graph” button

Press the “Create KML + GPX” button

select the flight tlog

A .kmz and .kml file will be created along side the original .tlog and
this can be opened in google earth to interactively view the 3d flight
path. You can open the kmz file in Google Earth to view the flight or
path. Just double click the file or drag it and drop into Google Earth. The different flight modes used during the flight will appear as
different colored tracks. You can change some details about how the
flight paths are displayed including their color and whether the paths
extend to the ground by doing this:

Find the log file’s name in the “Places” pane on the left. It should
appear in a “Temporary Places” folder. Right click on an individual path and select “Properties” to open the
Edit Path window. The color can be changed on the “Style, Color” tab

The area below the path can be removed (added) on the “Altitude” tab
by un-checking (checking) “Extend path to ground”

--- chunk_id: chunk-0188
source_document: mission-planner-telemetry-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 180
content_hash: 98f8164e7054db37
prev_chunk_id: chunk-0187
next_chunk_id: chunk-0189
section_heading: Extracting parameters and Waypoints
document_type: technical_reference

## Extracting parameters and Waypoints 

You can extract the parameters and waypoints from the tlog by following
the same steps as for creating the KML file except that at the last step
select “Extract Params” or “Extract WPs”. Extract Params will cause a .param file to be created along side the
tlog. This file is tab separated and contains a full list of parameters
(in the same order as they appear in the eeprom) along with their values
during the flight. This can be opened in excel or a text editor. Extract WPs will create one or more .txt files containing any missions
uploaded to the autopilot. These files can be opened in the Mission
Planner by switching to the Flight Plan screen, right-mouse-button
clicking on the map and selecting “File Load/Save”, “Load WP File”.

--- chunk_id: chunk-0189
source_document: mission-planner-telemetry-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: fd08efd35eb67341
prev_chunk_id: chunk-0188
next_chunk_id: chunk-0190
section_heading: Graphing data from a flight
document_type: technical_reference

## Graphing data from a flight 

Data from the flight can be graphed by doing the following:

Open the mission planner’s Flight Data screen

Click on the Telemetry Logs tab

Press the “Tlog &gt; Kml or Graph” button

Press the “Graph Log” button

select the flight tlog

When the “Graph This” screen appears, use the left or right mouse
button to click on the checkboxes beside the items you wish to
graph. Note that the items are grouped into categories like
“RC_CHANNELS” and “RAW_IMU” although it’s still often difficult to
find exactly the item you wish to graph

If you use the left mouse button the scale for the item will appear
on the left of the graph. If you use the right mouse button it will
appear on the right

Click the checkbox multiple times to cycle through all the possible
colours

Change the zoom of the graph with your mouse’s middle wheel, by
select an area of the graph with the left mouse button held down or
by right-mouse-button clicking on the graph and selecting “Set Scale
To Default”

--- chunk_id: chunk-0190
source_document: mission-planner-telemetry-logs.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 56
content_hash: f26c3a10738eaaad
prev_chunk_id: chunk-0189
next_chunk_id: null
section_heading: Video overview of tlogs
document_type: technical_reference

## Video overview of tlogs 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.
