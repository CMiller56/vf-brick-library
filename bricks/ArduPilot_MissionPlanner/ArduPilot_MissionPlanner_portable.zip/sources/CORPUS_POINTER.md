# Mission Planner GCS corpus

- Snapshot: `docs/corpus/ardupilot_gcs_mission_planner/docs_snapshot/`
- Structured MD: `docs/corpus/ardupilot_gcs_mission_planner/structured_md/`
- No .bin/.tlog samples yet (FC media pending)
