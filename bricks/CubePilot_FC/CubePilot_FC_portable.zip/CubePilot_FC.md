---
kb_id: cubepilot-flight-controllers-cube-orange-cube-red-lizard-brain-hw
title: CubePilot Flight Controllers — Cube Orange / Cube Red (Lizard Brain HW)
author: Unknown Author
created_date: 2026-07-18
classification: Internal
confidence_level: High
domain_tags: ["cubepilot", "cube-orange", "cube-red", "flight-controller", "fmu", "ardupilot", "lizard-brain", "here-gnss"]
entity_mentions: ["System Features"]
document_type: Technical Reference
primary_subject: CubePilot autopilot hardware: Cube Red, The Cube / Orange lineage, carrier boards, power/architecture, service bulletins, HERE GNSS, ArduPilot install on Cube
intended_audience: Integrators building ArduPilot Plane systems; Hybrid Brain hardware layer
sources: [{"filename": "ardupilot_common-pixhawk-overview.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/ardupilot_common-pixhawk-overview.md", "page_count": 1}, {"filename": "ardupilot_common-thecubeorange-overview.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/ardupilot_common-thecubeorange-overview.md", "page_count": 1}, {"filename": "here-3-stand.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/3d-printing/here-3-stand.md", "page_count": 1}, {"filename": "herepro-istand.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/3d-printing/herepro-istand.md", "page_count": 1}, {"filename": "tips-for-new-pilots.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/conducting-the-first-flight/tips-for-new-pilots.md", "page_count": 1}, {"filename": "conducting-the-first-flight.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/conducting-the-first-flight.md", "page_count": 1}, {"filename": "carrier-board-information.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/cube-red/carrier-board-information.md", "page_count": 1}, {"filename": "operating-conditions-and-performance.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/cube-red/operating-conditions-and-performance.md", "page_count": 1}, {"filename": "ports-standard-and-definition.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/cube-red/ports-standard-and-definition.md", "page_count": 1}, {"filename": "specifications.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/cube-red/specifications.md", "page_count": 2}, {"filename": "system-architecture.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/cube-red/system-architecture.md", "page_count": 2}, {"filename": "cube-red.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/cube-red.md", "page_count": 1}, {"filename": "cosmetic-change-notification.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/cosmetic-change-notification.md", "page_count": 1}, {"filename": "eol-and-replacement.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction/eol-and-replacement.md", "page_count": 1}, {"filename": "flight-management-unit-fmu.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction/flight-management-unit-fmu.md", "page_count": 1}, {"filename": "interface-specifications.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction/interface-specifications.md", "page_count": 1}, {"filename": "power-architecture.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction/power-architecture.md", "page_count": 1}, {"filename": "specifications.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction/specifications.md", "page_count": 2}, {"filename": "system-architecture.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction/system-architecture.md", "page_count": 2}, {"filename": "the-cube-operating-conditions-and-performance.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction/the-cube-operating-conditions-and-performance.md", "page_count": 1}, {"filename": "vibration-damped-imu-board-versions.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction/vibration-damped-imu-board-versions.md", "page_count": 1}, {"filename": "introduction.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/introduction.md", "page_count": 1}, {"filename": "mandatory-hardware-basic-configuration.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/mandatory-hardware-basic-configuration.md", "page_count": 1}, {"filename": "optional-hardware-basic-configuration.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/optional-hardware-basic-configuration.md", "page_count": 1}, {"filename": "autopilot-module.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/setup/autopilot-module.md", "page_count": 1}, {"filename": "installing-ardupilot.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/setup/firmware/installing-ardupilot.md", "page_count": 1}, {"filename": "installing-secure-firmware.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/setup/firmware/installing-secure-firmware.md", "page_count": 1}, {"filename": "firmware.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/setup/firmware.md", "page_count": 1}, {"filename": "ground-control-station.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/setup/ground-control-station.md", "page_count": 1}, {"filename": "mission-planner.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/setup/mission-planner.md", "page_count": 1}, {"filename": "setup.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube/setup.md", "page_count": 1}, {"filename": "the-cube-faq.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube-faq.md", "page_count": 1}, {"filename": "the-cube.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/autopilot/the-cube.md", "page_count": 1}, {"filename": "ads-b-carrier-board.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/ads-b-carrier-board.md", "page_count": 1}, {"filename": "carrier-boards-faq.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/carrier-boards-faq.md", "page_count": 1}, {"filename": "cube-red-standard-carrier-board-pinout.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/cube-red-standard-carrier-board-pinout.md", "page_count": 1}, {"filename": "edu450-carrier-board.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/edu450-carrier-board.md", "page_count": 1}, {"filename": "kore-carrier-board.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/kore-carrier-board.md", "page_count": 1}, {"filename": "airbot-mini-carrier-board-set-user-guide.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/mini-carrier-board/airbot-mini-carrier-board-set-user-guide.md", "page_count": 1}, {"filename": "mini-carrier-board.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/mini-carrier-board.md", "page_count": 1}, {"filename": "overview.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/overview.md", "page_count": 1}, {"filename": "standard-carrier-board-footprint-and-dimensions.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/carrier-boards/standard-carrier-board-footprint-and-dimensions.md", "page_count": 1}, {"filename": "2023-cubepilot-ecosystem-autopilot-wiring-diagram.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/cubepilot-ecosystem/2023-cubepilot-ecosystem-autopilot-wiring-diagram.md", "page_count": 1}, {"filename": "2025-cubepilot-ecosystem-autopilot-wiring-diagram.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/cubepilot-ecosystem/2025-cubepilot-ecosystem-autopilot-wiring-diagram.md", "page_count": 1}, {"filename": "cubepilot-ecosystem-autopilot-wiring-diagram.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/cubepilot-ecosystem/cubepilot-ecosystem-autopilot-wiring-diagram.md", "page_count": 1}, {"filename": "here+v2-user-manual.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/here+/here+v2-user-manual.md", "page_count": 1}, {"filename": "here-2-can-mode-instruction.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/here-2/here-2-can-mode-instruction.md", "page_count": 1}, {"filename": "here-2-firmware-update-troubleshooting.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/here-2/here-2-firmware-update-troubleshooting.md", "page_count": 1}, {"filename": "updating-here-2-firmware.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/here-2/updating-here-2-firmware.md", "page_count": 1}, {"filename": "here-3-manual.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/here-3/here-3-manual.md", "page_count": 1}, {"filename": "here-4-base.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/here-4/here-4-base.md", "page_count": 1}, {"filename": "here-4-blue.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/here-4/here-4-blue.md", "page_count": 1}, {"filename": "here-4-manual.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/here-4/here-4-manual.md", "page_count": 1}, {"filename": "herepro-manual.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/herepro/herepro-manual.md", "page_count": 1}, {"filename": "readme.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/readme.md", "page_count": 1}, {"filename": "powering-telemetry-radios-externally.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/critical-notices/powering-telemetry-radios-externally.md", "page_count": 1}, {"filename": "critical-notices.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/critical-notices.md", "page_count": 1}, {"filename": "sb_0000001-critical-service-bulletin-for-beta-cube-2.1-2016.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000001-critical-service-bulletin-for-beta-cube-2.1-2016.md", "page_count": 1}, {"filename": "sb_0000002-critical-service-bulletin-for-cubes-purchased-between-jan-2019-to-jul-2019.-do-not-fly.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000002-critical-service-bulletin-for-cubes-purchased-between-jan-2019-to-jul-2019.-do-not-fly.md", "page_count": 1}, {"filename": "sb_0000003-flight-with-arming-checks-set-anything-other-than-1-prohibited.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000003-flight-with-arming-checks-set-anything-other-than-1-prohibited.md", "page_count": 1}, {"filename": "sb_0000004-limited-power-capacity-of-the-rcin-power-rail-on-pixhawk-autopilots.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000004-limited-power-capacity-of-the-rcin-power-rail-on-pixhawk-autopilots.md", "page_count": 1}, {"filename": "sb_0000005-i2c-storm-can-cause-inflight-reboots-chibios-only-not-nuttx-all-cube-and-pixhawk-hardw.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000005-i2c-storm-can-cause-inflight-reboots-chibios-only-not-nuttx-all-cube-and-pixhawk-hardw.md", "page_count": 1}, {"filename": "sb_0000006-time-to-go-orange.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000006-time-to-go-orange.md", "page_count": 1}, {"filename": "sb_0000007-ethernet-on-herelink-one-a-siyi-camera.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000007-ethernet-on-herelink-one-a-siyi-camera.md", "page_count": 1}, {"filename": "sb_0000008-here4-magnetometer-flight-status-restored.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000008-here4-magnetometer-flight-status-restored.md", "page_count": 1}, {"filename": "sb_0000009-cube-red-free-upgrade-for-beta-hardware.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000009-cube-red-free-upgrade-for-beta-hardware.md", "page_count": 1}, {"filename": "sb_0000010-mandatory-here4-bootloader-update-before-further-flight.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000010-mandatory-here4-bootloader-update-before-further-flight.md", "page_count": 1}, {"filename": "safety-service-bulletins.md", "path": "docs/corpus/cubepilot_fc/docs_snapshot/md_clean/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-07-18T18:24:19.272351", "page_count": 68, "extraction_methods": {"txt": 68}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "confidence_level", "created_date", "entity_mentions", "ingest_provenance", "kb_id", "sources"]
brick_role: fc_hardware_lizard_brain
out_of_scope: ["Plane mode/failsafe *doctrine* (ArduPilot_Plane)", "Full param dictionary (ArduPilot_Plane_Params)", "MAVLink message catalog (ArduPilot_MAVLink)", "Mission Planner deep UI (ArduPilot_MissionPlanner)", "Full Herelink product line (not primary; only if pages included)", "Companion computer / ROS autonomy (higher brain)"]
usage_notes: This brick is the **lizard brain hardware** layer: each Cube is both a **sensor suite** (IMUs, baros, compass, I/O) and a **lizard brain** FMU that runs ArduPilot control loops — not companion AI. **Cube Orange** and **Cube Red** are peer lizard brains; Red is the latest-generation dual-FMU / Ethernet-forward tech, Orange the mature widely-deployed lineage. Either can be the vehicle's lizard brain alone. Sources: AP wiki (Orange) + docs.cubepilot.org (Red, The Cube, carriers, SBs, HERE). Pair with DroneCAN for CAN peripherals and ArduPilot_Plane for vehicle behavior. Extraction shape differs from params/MAVLink/ops bricks (GitBook MD + long pinout tables + dual product SKUs + SBs).
routing_policy: Cube Orange/Red sensor suite, ports, power, IMU architecture, dual-FMU (Red), setup, service bulletins → this brick. How the plane should fly → ArduPilot_Plane. Params → Params. GCS UI → MissionPlanner. CAN node types → DroneCAN. Serial protocol → MAVLink.
adjacent_bricks: [{"brick_id": "ArduPilot_Plane", "role": "ops_doctrine", "status": "built", "when_to_use": ["modes, failsafes, TECS doctrine"]}, {"brick_id": "ArduPilot_Plane_Params", "role": "params_reference", "status": "built", "when_to_use": ["parameter values"]}, {"brick_id": "ArduPilot_MissionPlanner", "role": "gcs_mission_planner", "status": "built", "when_to_use": ["MP calibration / firmware load UI"]}, {"brick_id": "ArduPilot_MAVLink", "role": "mavlink_protocol", "status": "built", "when_to_use": ["MAVLink messages"]}, {"brick_id": "DroneCAN", "role": "dronecan_protocol", "status": "built", "when_to_use": ["CAN peripherals / AP_Periph"]}, {"brick_id": "UAVCAN_cvra", "role": "uavcan_protocol", "status": "built", "when_to_use": ["legacy UAVCAN stack notes"]}]
kb_name: CubePilot_FC
created: 2026-07-18T18:24:19.276851
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 273
template: technical_reference
domain: general
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-18T18:24:37.280466
  chunk_count: 273
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 410
content_hash: 5a1c59ad3aae6b4f
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: Common Pixhawk Overview
document_type: technical_reference

# Common Pixhawk Overview

Pixhawk Overview — Plane documentation

 Home

 Copter

 Plane

 Rover

 Blimp

 Sub

 AntennaTracker

 Mission Planner

 APM Planner 2

 MAVProxy

 Companion Computers

 Developer

 Downloads

 Mission Planner

 APM Planner 2

 Advanced User Tools

 Developer Tools

 Firmware

 Community

 Support Forums

 Facebook

 Developer Chat (Discord)

 Developer Voice (Discord)

 Contact us

 Getting involved

 Commercial Support

 Development Team

 UAS Training Centers

 Stores

 About

 News

 History

 License

 Trademark

 Acknowledgments

 Wiki Editing Guide

 Partners Program

 Plane

 Introduction to Plane

 Choosing an Autopilot
 Open Hardware
 AcctonGodwit GA1

 ARKV6X DS-10 Pixhawk6

 CUAV V5 Plus

 CUAV V5 Nano

 CUAV Nora

 CUAV Pixhawk v6X

 CUAV Pixhawk v6X V2

 CUAV X7/X7Pro/X7+/X7+ Pro

 CUAV-7-Nano

 F4BY

 CubePilot Cube Black

 CubePilot Cube Orange/+

 CubePilot Cube Purple

 CubePilot Cube Yellow

 CubePilot Cube Green

 Holybro Durandal H7

 Holybro Pix32 v5

 Holybro Pixhawk 4

 Holybro Pixhawk6X/6X Pro

 Holybro Pixhawk6C/ 6C Mini

 Holybro Pix32v6(Pixhawk6C variant)

 mRo Pixhawk
 Specifications

 Purchase

 Pixhawk connector assignments

 Pixhawk top connectors

 Pixhawk PWM connectors for servos and ESCs and PPM-SUM in and SBUS out

 Pixhawk connector diagram

 Pixhawk connector pin assignments

 Connecting and disconnecting DF13 connectors

 Pixhawk analog input pins

 Pixhawk digital outputs and inputs (Virtual Pins 50-55)

 Powering

 See also

 mRo Pixracer

 mRo X2.1

 mRo X2.1-777

 OpenPilot Revolution

 SULIGH7

 TauLabs Sparky2

 ZeroOneX6/X6 Pro

 ZeroOneX6-Air/Air+

 Closed Hardware

 Linux Based Autopilots

 Firmware Limitations

 Discontinued Boards

 Schematics

 Ground Control Stations

 First Time Setup

 First Flight and Tuning

 QuadPlane Setup and Operation

 Mission Planning

 If A Problem Arises

 Advanced Configuration

 Peripheral Hardware

 Additional Information

 User Alerts

 Individual
 Partners
 SWAG Shop

 Plane

 Choosing an Autopilot

 Pixhawk Overview

 Edit on GitHub

# Pixhawk Overview

 Note

 Older versions of Pixhawk use an early version of the STM32F427 chip (RevA, RevY and Rev1). A hardware bug is present in these chips that limit the flash memory to 1 MB. Any boards
containing this chip cannot include all ArduPilot features due to this limitation. See
 Firmware Limitations for details.

--- chunk_id: chunk-0001
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 161
content_hash: fd26e449b95594fb
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Specifications
document_type: technical_reference

## Specifications

Processor

 32-bit ARM Cortex M4 core with FPU

 168 Mhz/256 KB RAM/2 MB Flash

 32-bit failsafe co-processor

 Sensors

 MPU6000 as main accel and gyro

 ST Micro 16-bit gyroscope

 ST Micro 14-bit accelerometer/compass (magnetometer)

 MEAS barometer

 Power

 Ideal diode controller with automatic failover

 Servo rail high-power (7 V) and high-current ready

 All peripheral outputs over-current protected, all inputs ESD
protected

 Interfaces

 5x UART serial ports, 1 high-power capable, 2 with HW flow
control

 Spektrum DSM/DSM2/DSM-X Satellite input

 Futaba S.BUS input (output not yet implemented)

 PPM sum signal

 RSSI (PWM or voltage) input

 I2C, SPI, 2x CAN, USB

 3.3V and 6.6V ADC inputs

 Dimensions

 Weight 38 g (1.3 oz)

 Width 50 mm (2.0”)

 Height 15.5 mm (.6”)

 Length 81.5 mm (3.2”)

--- chunk_id: chunk-0002
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 278
content_hash: ae2922049f7e421d
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: Purchase
document_type: technical_reference

## Purchase

The Pixhawk 1 was originally manufactured and sold by 3DR. A slightly improved but fully compatible variant can now be obtained from mRo:
 mRo Pixhawk 2.4.6 Essential Kit! ### Pixhawk connector assignments
Warning

 Many Pixhawk clones use Molex picoblade connectors instead of DF13 connectors. They have rectangular pins, rather than square ones, and cannot be assumed compatible. ### Pixhawk top connectors
### Pixhawk PWM connectors for servos and ESCs and PPM-SUM in and SBUS out
### Pixhawk connector diagram
For all connectors pin 1 is on the right in the above image

 Serial 1 (Telem 1) and Serial 2 (Telem 2) Pins: 6 = GND, 5 =
RTS, 4 = CTS, 3 = RX, 2 = TX, 1 = 5V. ### Pixhawk connector pin assignments
### TELEM1, TELEM2 ports

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 CTS
 +3.3V

 5 (blk)
 RTS
 +3.3V

 6 (blk)
 GND
 GND

### GPS port

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 CAN2 TX
 +3.3V

 5 (blk)
 CAN2 RX
 +3.3V

 6 (blk)
 GND
 GND

### SERIAL 4/5 port - due to space constraints two ports are on one connector.

--- chunk_id: chunk-0003
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 498
content_hash: 83639312ca1a047b
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: Purchase
document_type: technical_reference

### Pixhawk top connectors
### Pixhawk PWM connectors for servos and ESCs and PPM-SUM in and SBUS out
### Pixhawk connector diagram
For all connectors pin 1 is on the right in the above image

 Serial 1 (Telem 1) and Serial 2 (Telem 2) Pins: 6 = GND, 5 =
RTS, 4 = CTS, 3 = RX, 2 = TX, 1 = 5V. ### Pixhawk connector pin assignments
### TELEM1, TELEM2 ports

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 CTS
 +3.3V

 5 (blk)
 RTS
 +3.3V

 6 (blk)
 GND
 GND

### GPS port

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 CAN2 TX
 +3.3V

 5 (blk)
 CAN2 RX
 +3.3V

 6 (blk)
 GND
 GND

### SERIAL 4/5 port - due to space constraints two ports are on one connector. Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (#4)
 +3.3V

 3 (blk)
 RX (#4)
 +3.3V

 4 (blk)
 TX (#5)
 +3.3V

 5 (blk)
 RX (#5)
 +3.3V

 6 (blk)
 GND
 GND

### ADC 6.6V

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 ADC IN
 up to +6.6V

 3 (blk)
 GND
 GND

### ADC 3.3V

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 ADC IN
 up to +3.3V

 3 (blk)
 GND
 GND

 4 (blk)
 ADC IN
 up to +3.3V

 5 (blk)
 GND
 GND

### I2C

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 SCL
 +3.3 (pullups)

 3 (blk)
 SDA
 +3.3 (pullups)

 4 (blk)
 GND
 GND

### CAN

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 CAN_H
 +12V

 3 (blk)
 CAN_L
 +12V

 4 (blk)
 GND
 GND

### SPI

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 SPI_SCK
 3.3V

 3 (blk)
 SPI_MISO
 +3.3V

 4 (blk)
 SPI_MOSI
 +3.3V

 5 (blk)
 !SPI_NSS
 +3.3V

 6 (blk)
 !GPIO
 +3.3V

 7 (blk)
 GND
 GND

### POWER

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 VCC
 +5V

 3 (blk)
 CURRENT
 up to +3.3V

 4 (blk)
 VOLTAGE
 up to +3.3V

 5 (blk)
 GND
 GND

 6 (blk)
 GND
 GND

### SWITCH

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +3.3V

 2 (blk)
 !IO_LED_SAFETY
 GND

 3 (blk)
 SAFETY
 GND

### Console Port
 The system’s serial console runs on the port labeled SERIAL4/5.

--- chunk_id: chunk-0004
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: d686a4453b9399fc
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: Purchase
document_type: technical_reference

### Pixhawk connector pin assignments
### TELEM1, TELEM2 ports

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 CTS
 +3.3V

 5 (blk)
 RTS
 +3.3V

 6 (blk)
 GND
 GND

### GPS port

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 CAN2 TX
 +3.3V

 5 (blk)
 CAN2 RX
 +3.3V

 6 (blk)
 GND
 GND

### SERIAL 4/5 port - due to space constraints two ports are on one connector. Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (#4)
 +3.3V

 3 (blk)
 RX (#4)
 +3.3V

 4 (blk)
 TX (#5)
 +3.3V

 5 (blk)
 RX (#5)
 +3.3V

 6 (blk)
 GND
 GND

### ADC 6.6V

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 ADC IN
 up to +6.6V

 3 (blk)
 GND
 GND

### ADC 3.3V

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 ADC IN
 up to +3.3V

 3 (blk)
 GND
 GND

 4 (blk)
 ADC IN
 up to +3.3V

 5 (blk)
 GND
 GND

### I2C

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 SCL
 +3.3 (pullups)

 3 (blk)
 SDA
 +3.3 (pullups)

 4 (blk)
 GND
 GND

### CAN

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 CAN_H
 +12V

 3 (blk)
 CAN_L
 +12V

 4 (blk)
 GND
 GND

### SPI

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 SPI_SCK
 3.3V

 3 (blk)
 SPI_MISO
 +3.3V

 4 (blk)
 SPI_MOSI
 +3.3V

 5 (blk)
 !SPI_NSS
 +3.3V

 6 (blk)
 !GPIO
 +3.3V

 7 (blk)
 GND
 GND

### POWER

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 VCC
 +5V

 3 (blk)
 CURRENT
 up to +3.3V

 4 (blk)
 VOLTAGE
 up to +3.3V

 5 (blk)
 GND
 GND

 6 (blk)
 GND
 GND

### SWITCH

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +3.3V

 2 (blk)
 !IO_LED_SAFETY
 GND

 3 (blk)
 SAFETY
 GND

### Console Port
 The system’s serial console runs on the port labeled SERIAL4/5. The
pinout is standard serial pinout, to connect to a standard FTDI cable
(3.3V, but it’s 5V tolerant). Pixhawk

 FTDI

 1
 +5V (red)

 N/C

 2
 Tx

 N/C

 3
 Rx

 N/C

 4
 Tx
 5
 Rx (yellow)

 5
 Rx
 4
 Tx (orange)

 6
 GND
 1
 GND (black)

### Spektrum/DSM Port
 The Spektrum/DSM port is for connecting Spektrum DSM-2/DSMX receiver
modules. Pin
 Signal
 Volt

 1 (white)
 Signal
 +3.3V

 2 (black)
 GND
 GND

 3 (red)
 VCC
 +3.3V

--- chunk_id: chunk-0005
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: 6b4791e1fbc8c249
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: Connecting and disconnecting DF13 connectors
document_type: technical_reference

## Connecting and disconnecting DF13 connectors
### Pixhawk analog input pins
This section lists the analog pins available on the Pixhawk. These are
virtual pins, defined in the firmware. Virtual Pin 2 and Power connector Pin 4 : power
management connector voltage pin, accepts up to 3.3V, usually attached
to a power module with 10.1:1 scaling

 Virtual Pin 3 and Power connector Pin 3 : power management connector
current pin, accepts up to 3.3V, usually attached to a power module
with 17:1 scaling

 Virtual Pin 4 and (No connector Pin) : VCC 5V rail sensing. This
virtual pin reads the voltage on the 5V supply rail. It is used to
provide the HWSTATUS.Vcc reading that ground stations use to display 5V
status

 Virtual Pin 13 and ADC 3.3V connector Pin 4 : This takes a max of
3.3V. May be used for sonar or other analog sensors. Virtual Pin 14 and ADC 3.3V connector Pin 2 : This takes a max of
3.3V. May be used for second sonar or other analog sensor. Virtual Pin 15 and ADC 6.6V connector Pin 2 : analog airspeed sensor
port. This has 2:1 scaling builtin, so can take up to 6.6v analog
inputs. Usually used for analog airspeed, but may be used for analog
sonar or other analog sensors. Virtual Pin 102 : Servo power rail voltage. This is an internal
measurement of the servo rail voltage made by the IO board within the
Pixhawk. It has 3:1 scaling, allowing it to measure up to 9.9V. Virtual Pin 103 : RSSI (Received Signal Strength Input) input pin
voltage (SBus connector output pin). This is the voltage measured by the
RSSI input pin on the SBUS-out connector (the bottom pin of the 2nd last
servo connector on the 14 connector servo rail). This can alternatively serve as SBus out by setting the
 BRD_SBUS_OUT parameter ( Copter ,
 Plane , Rover ).

--- chunk_id: chunk-0006
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: 4899cc577da03d5c
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: Pixhawk digital outputs and inputs (Virtual Pins 50-55)
document_type: technical_reference

## Pixhawk digital outputs and inputs (Virtual Pins 50-55)

The Pixhawk has no dedicated digital output or input pins on its DF13
connectors, but you can assign up to 6 of the “AUX SERVO” connectors to
be digital GPIO outputs/inputs. These are the first 6 of the 14 three-pin
servo connectors on the end of the board. They are marked as AUX servo
pins 1 - 6 on the silkscreen as seen above. To set the number of these pins that are available as digital
inputs/outputs, set the BRD_PWM_COUNT parameter. On Pixhawk this
defaults to 4, which means the first 4 AUX connectors are for servos
(PWM) and the last 2 are for digital inputs/outputs. If you set
 BRD_PWM_COUNT to 0 then you would have 6 virtual digital pins and
still have 8 PWM outputs on the rest of the connector. Note

 in firmware versions 4.2 and later, the method for setting a PWM/SERVO/MOTOR output to be a GPIO function is changed. Instead of BRD_PWM_COUNT being used, the individual SERVOx_FUNCTION parameter is merely set to “-1”. If set to “0”, it remains a PWM output, unassigned to a function, and outputs that output’s trim value when board safety is not active. If the servo function is being “mirrored” to a remote device, as in the case of a DroneCAN or KDECAN ESC, then in order to change the autopilot board’s corresponding output pin to be a GPIO, but allow the SERVOx_FUNCTION to still be assigned to the remote device, the SERVO_GPIO_MASK parameter can be used to assign the board pin to be a GPIO without affecting the SERVOx_FUNCTION assignment for the remote device. The 6 possible pins are available for PIN variables as pin numbers 50 to
55 inclusive. In summary:

 If BRD_PWM_CNT = 2 then

 50 = RC9

 51 = RC10

 52 = Aux 3

 53 = Aux 4

 54 = Aux 5

 55 = Aux 6

 If BRD_PWM_CNT = 4 then

 50 = RC9

 51 = RC10

 52 = RC11

 53 = RC12

 54 = Aux 5

 55 = Aux 6

 If BRD_PWM_CNT = 6 then

 50 = RC9

 51 = RC10

 52 = RC11

 53 = RC12

 54 = RC13

 55 = RC14

 By default, the pins are digital outputs as outlined above.

--- chunk_id: chunk-0007
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 200
content_hash: d0e31378f3a434d6
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Pixhawk digital outputs and inputs (Virtual Pins 50-55)
document_type: technical_reference

The 6 possible pins are available for PIN variables as pin numbers 50 to
55 inclusive. In summary:

 If BRD_PWM_CNT = 2 then

 50 = RC9

 51 = RC10

 52 = Aux 3

 53 = Aux 4

 54 = Aux 5

 55 = Aux 6

 If BRD_PWM_CNT = 4 then

 50 = RC9

 51 = RC10

 52 = RC11

 53 = RC12

 54 = Aux 5

 55 = Aux 6

 If BRD_PWM_CNT = 6 then

 50 = RC9

 51 = RC10

 52 = RC11

 53 = RC12

 54 = RC13

 55 = RC14

 By default, the pins are digital outputs as outlined above. A digital
pin will instead be a digital input if it is assigned to a parameter
that represents a digital input. For example, setting CAM1_FEEDBAK_PIN
to 50 will make pin 50 the digital input that receives a signal from the
camera when a picture has been taken.

--- chunk_id: chunk-0008
source_document: ardupilot_common-pixhawk-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 86
content_hash: 27f6928579711330
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: Powering
document_type: technical_reference

## Powering

The topic Powering the Pixhawk
explains both simple and advanced power-supply options for the Pixhawk. ### See also
Schematics

 LEDs

 Safety Switch

 Sounds

 Pixhawk Serial Names

 Previous
 Next

 Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . © Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0009
source_document: ardupilot_common-thecubeorange-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 328
content_hash: 59756e7162ab2d62
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Common Thecubeorange Overview
document_type: technical_reference

# Common Thecubeorange Overview

The Cube Orange/+ With ADSB-In Overview — Plane documentation

 Home

 Copter

 Plane

 Rover

 Blimp

 Sub

 AntennaTracker

 Mission Planner

 APM Planner 2

 MAVProxy

 Companion Computers

 Developer

 Downloads

 Mission Planner

 APM Planner 2

 Advanced User Tools

 Developer Tools

 Firmware

 Community

 Support Forums

 Facebook

 Developer Chat (Discord)

 Developer Voice (Discord)

 Contact us

 Getting involved

 Commercial Support

 Development Team

 UAS Training Centers

 Stores

 About

 News

 History

 License

 Trademark

 Acknowledgments

 Wiki Editing Guide

 Partners Program

 Plane

 Introduction to Plane

 Choosing an Autopilot
 Open Hardware
 AcctonGodwit GA1

 ARKV6X DS-10 Pixhawk6

 CUAV V5 Plus

 CUAV V5 Nano

 CUAV Nora

 CUAV Pixhawk v6X

 CUAV Pixhawk v6X V2

 CUAV X7/X7Pro/X7+/X7+ Pro

 CUAV-7-Nano

 F4BY

 CubePilot Cube Black

 CubePilot Cube Orange/+
 System Features

 ADS-B Carrier Board

 Cube Orange/+ Features

 Specifications

 The Cube connector pin assignments

 CubePilot Ecosystem

 More Information

 Carrier Board Design

 Where to Buy

 More Images

 CubePilot Cube Purple

 CubePilot Cube Yellow

 CubePilot Cube Green

 Holybro Durandal H7

 Holybro Pix32 v5

 Holybro Pixhawk 4

 Holybro Pixhawk6X/6X Pro

 Holybro Pixhawk6C/ 6C Mini

 Holybro Pix32v6(Pixhawk6C variant)

 mRo Pixhawk

 mRo Pixracer

 mRo X2.1

 mRo X2.1-777

 OpenPilot Revolution

 SULIGH7

 TauLabs Sparky2

 ZeroOneX6/X6 Pro

 ZeroOneX6-Air/Air+

 Closed Hardware

 Linux Based Autopilots

 Firmware Limitations

 Discontinued Boards

 Schematics

 Ground Control Stations

 First Time Setup

 First Flight and Tuning

 QuadPlane Setup and Operation

 Mission Planning

 If A Problem Arises

 Advanced Configuration

 Peripheral Hardware

 Additional Information

 User Alerts

 Individual
 Partners
 SWAG Shop

 Plane

 Choosing an Autopilot

 The Cube Orange/+ With ADSB-In Overview

 Edit on GitHub

# The Cube Orange/+ With ADSB-In Overview

--- chunk_id: chunk-0010
source_document: ardupilot_common-thecubeorange-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 249
content_hash: 0535b02399d4fcbf
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: System Features
document_type: technical_reference

## System Features

The Cube Orange autopilot is the latest and most powerful model in the CubePilot ecosystem. Designed for hobby users, commercial system integrators and UAS manufacturers the Cube Orange autopilot is part of a wide ecosystem of autopilot modules and carrier boards. All Cube models are compatible with all carriers which allows users to choose an off the shelf carrier board that best suits their needs. System designers are able to integrate the Cube directly into their designs via published carrier board specifications. The Cube Orange is available as a standalone module or as a package with a new updated version of the original carrier board that now includes an integrated ADS-B In module from uAvionics. ### ADS-B Carrier Board
The new ADS-B carrier boards overall footprint is identical to the standard versions and the main changes compared to the original carrier are as follows:

 Integration of uAvonix ADS-B IN Receiver on Serial 5

 Built-In ADS-B Antenna

 Removal of Intel Edison Bay and Debug USB Ports

 All other specification and external connections remain identical to the original board as listed on the Cube Black page.

--- chunk_id: chunk-0011
source_document: ardupilot_common-thecubeorange-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 400
content_hash: bacc9c11eac65af6
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Cube Orange/+ Features
document_type: technical_reference

## Cube Orange/+ Features

Faster H7 SOC with 1MB ram

 Upgraded triple redundant IMU sensors for extra redundancy

 2 sets of IMU are vibration-isolated mechanically, reducing the effect of frame vibration to state estimation

 IMUs are temperature-controlled by onboard heating resistors, allowing optimum working temperature of IMUs

 The entire flight management unit(FMU) and inertial management unit(IMU) are housed in a reatively small form factor (a cube). Fully CubePilot carrierboard compatible, all inputs and outputs go through a 80-pin DF17 connector, allowing a plug-in solution for manufacturers of commercial systems. Manufacturers can design their own carrier boards to suit their specific needs now and in the future. ### Specifications
Processor

 32bit ARM® STM32H753 Cortex®-M7（with DP-FPU; Cube Orange+ uses ARM® STM32H757

 400 Mhz/1 MB RAM/2 MB Flash

 32 bit STM32F103 failsafe co-processor

 Sensors

 Three redundant IMUs (Accelerometers/Gyroscopes), Two Barometers, One Magnetometer

 All sensors connected via SPI. ICM 20649 integrated accelerometer / gyro, MS5611 barometer on base board

 CubeOrange:
- InvenSense ICM20602 IMU,ICM20948 IMU/MAG, MS5611 barometer on temperature controlled, vibration isolated board

 CubeOrange+:
- Invensense ICM42688 IMU, ICM20948 IMU/MAG, MS5611 barometer on temperature controlled, vibration isolated board

 AK099916 MAG

 Power

 Redundant power supply with automatic failover

 Servo rail high-power (7 V) and high-current ready

 All peripheral outputs over-current protected, all inputs ESD
protected

 Interfaces

 14x PWM servo outputs (8 from IO, 6 from FMU)

 S.Bus servo output

 R/C inputs for CPPM, Spektrum / DSM and S.Bus

 Analogue / PWM RSSI input

 5x general purpose serial ports, 2 with full flow control

 2x I2C ports

 SPI port (un-buffered, for short cables only not recommended for use)

 2x CAN Bus interface

 3x Analogue inputs (3.3V and 6.6V)

 High-powered piezo buzzer driver (on expansion board)

 High-power RGB LED (I2C driver compatible connected externally only)

 Safety switch / LED

 Optional carrier board for Intel Edison (now obsolete)

--- chunk_id: chunk-0012
source_document: ardupilot_common-thecubeorange-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 370
content_hash: da53779f404633ad
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: The Cube connector pin assignments
document_type: technical_reference

## The Cube connector pin assignments

TELEM1, TELEM2 ports

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 CTS
 +3.3V

 5 (blk)
 RTS
 +3.3V

 6 (blk)
 GND
 GND

 GPS1 port

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 SCL I2C2
 +3.3V

 5 (blk)
 SDA I2C2
 +3.3V

 6 (blk)
 Button
 GND

 7 (blk)
 button LED
 GND

 8 (blk)
 GND
 GND

 GPS2 port

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 TX (OUT)
 +3.3V

 3 (blk)
 RX (IN)
 +3.3V

 4 (blk)
 SCL I2C1
 +3.3V

 5 (blk)
 SDA I2C1
 +3.3V

 6 (blk)
 GND
 GND

 ADC

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 ADC IN
 6.6Vmax,pin 8

 3 (blk)
 GND
 GND

 I2C2

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 SCL
 +3.3 (pullups)

 3 (blk)
 SDA
 +3.3 (pullups)

 4 (blk)
 GND
 GND

 CAN1&2

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 CAN_H
 +12V

 3 (blk)
 CAN_L
 +12V

 4 (blk)
 GND
 GND

 POWER1

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (red)
 VCC
 +5V

 3 (blk)
 CURRENT
 up to +3.3V,pin 15

 4 (blk)
 VOLTAGE
 up to +3.3V,pin 14

 5 (blk)
 GND
 GND

 6 (blk)
 GND
 GND

 POWER2

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (red)
 VCC
 +5V

 3 (blk)
 CURRENT
 up to +3.3V,pin 4

 4 (blk)
 VOLTAGE
 up to +3.3V,pin 13

 5 (blk)
 GND
 GND

 6 (blk)
 GND
 GND

 USB

 Pin
 Signal
 Volt

 1 (red)
 VCC
 +5V

 2 (blk)
 D_plus
 +3.3V

 3 (blk)
 D_minus
 +3.3V

 4 (blk)
 GND
 GND

 5 (blk)
 BUZZER
 battery voltage

 6 (blk)
 Boot/Error LED

 RSSI Input

 Analog/PWM RSSI Input is pin 103

--- chunk_id: chunk-0013
source_document: ardupilot_common-thecubeorange-overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 174
content_hash: 93fe9c0e90a5c0c4
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: CubePilot Ecosystem
document_type: technical_reference

## CubePilot Ecosystem
### More Information
For more information and instructions on setting up and using the CubePilot system see CubePilot Docs

 For technical help and support on the CubePilot system see CubePilot Forum

 Company information on CubePilot can be found at www.cubepilot.com

### Carrier Board Design
The reference design files of the standard carrier board are available in github , or here ,this serves as a starting point for designers to design their own system based on The Cube autopilot. ### Where to Buy
Official retailers are listed here . ### More Images
Previous
 Next

 Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . © Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0014
source_document: here-3-stand.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 12
content_hash: ddeb7dfc1950aaba
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: Here 3 Istand
document_type: technical_reference

# Here 3 Istand

![](/files/-MgoCyPRTHgJnCL8oqLZ)

{% file src="/files/-MgoD2vPJr6WieN77RuY" %}

--- chunk_id: chunk-0015
source_document: herepro-istand.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 9
content_hash: f79c69fe6154c1c6
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: HerePro Istand
document_type: technical_reference

# HerePro Istand

{% file src="/files/MjCUqT1LoKHjWMFN4Rvk" %}

--- chunk_id: chunk-0016
source_document: tips-for-new-pilots.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: 0e3cc24bea8e0f35
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: Tips for New Pilots
document_type: technical_reference

# Tips for New Pilots

**Stabilize mode** is recommended for the first flight. This is because the throttle is linear, which results in lower sensitivity. After becoming more familiar with **Stabilize mode**, maintain the unmanned aerial vehicle (UAV) at an altitude above 1 m and try more advanced modes, such as **ALT Hold** or **Loiter**. Keep in mind the following as the control logic for these more advanced modes differ from **Stabilize** **mode**:

* Releasing the throttle stick will maintain the UAV's current altitude. * Pushing the throttle up will cause the vehicle to climb while pushing it down will make it descend. > The UAV is not a toy and could cause injury if not properly controlled. Ensure there are no people or obstacles within 50m when operating the UAV. > It is important to understand the features and capabilities of the various flight modes before using them. For more details about the different flight modes, refer to the ArduPilot documentation:

*
*

--- chunk_id: chunk-0017
source_document: conducting-the-first-flight.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 205
content_hash: 908463822fef6ef4
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: Pre-Arm Safety Check
document_type: technical_reference

## Pre-Arm Safety Check

*Conducting the First Flight*


Mission Planner has a list of pre-arm safety checks that prevent the unmanned aerial vehicle (UAV) from arming if any issues are detected before take-off. This could include missed calibrations, improper configurations, bad sensor data, etc. The safety checks help prevent crashes and fly-aways. If necessary, the safety checks can be disabled. Use the following guidance:

* **When the LED flashes blue or green**, it means the UAV can be armed. During the arming process, a low-pitch tone is emitted from the buzzer. The motors start to rotate and the UAV is ready to take off. * **When the LED flashes yellow**, disarm the UAV. The failure messages are shown on the HUD. Use the displayed failure message to resolve the error. For more details on the failure messages and solutions, go to  . For more details on the LED indicators, refer to the table below.

--- chunk_id: chunk-0018
source_document: conducting-the-first-flight.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 376
content_hash: 046dd79f8365f2d8
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: LED Indicators
document_type: technical_reference

## LED Indicators | LED Indicator                    | Description                                                                                                                                                                         |
| -------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Flashing red and blue            | Initializing sensors. Keep the UAV stationary and level while the sensors are being initialized.                                                                                    |
| Flashing blue                    | Disarmed with no GPS lock. Auto-mission, loiter, and return-to-launch flight modes require GPS lock. | | Solid blue                       | Armed with no GPS lock.                                                                                                                                                             |
| Flashing green                   | Disarmed (but ready to arm) and GPS lock acquired. Rapid double tone when disarming from the armed state.                                                                           |
| Flashing green rapidly           | Same as above, but GPS uses Satellite Based Augmentation System (SBAS). The position estimation should be better.                                                                   |
| Solid green                      | Single long tone during arming. When armed and GPS lock is acquired, UAV is ready to fly. | | Double flashing yellow           | Failed pre-arm checks (system refuses to arm).                                                                                                                                      |
| Single flashing yellow           | Radio failsafe activated.                                                                                                                                                           |
| Flashing yellow                  | Rapid beeping tone. Battery failsafe activated. | | Flashing yellow and blue         | High-high-high-low tone sequence (dah-dah-dah-doh). GPS glitch or GPS failsafe activated. | | Flashing red and yellow          | Extended Kalman Filter (EKF) or inertial navigation failure.                                                                                                                        |
| Flashing purple and yellow       | Barometer glitch.                                                                                                                                                                   |
| Solid Red                        | Error, usually due to SD card, MTD, or IMU. To resolve the issue, remove and insert the SD card. Additionally, check the SD card and analyze the boot message in the BOOT.txt file. |
| Solid red with SOS tone sequence | SD card missing or bad SD card.                                                                                                                                                     |
| No light when powered on         | No firmware, firmware lost, SD card missing or bad format (ac3.4 or higher version).                                                                                                |

--- chunk_id: chunk-0019
source_document: conducting-the-first-flight.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 104
content_hash: f8f2dd79b8dcbde8
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: Arming The Cube
document_type: technical_reference

## Arming The Cube

The Cube can be armed by the following methods:

#### **Remote controlle**r

Hold the throttle down and keep the rudder to the right for five seconds. > Do not keep the rudder right for more than 15 seconds, as this will enable the AutoTrim feature. #### **Ground Control Station (GCS)**

1. Connect The Cube to the GCS. 2. Open Mission Planner. 3. Click **Action** under the HUD. 4. Click **Arm/Disarm** to arm the vehicle.

--- chunk_id: chunk-0020
source_document: carrier-board-information.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 22
content_hash: cd88ec28aa9e9804
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
section_heading: Carrier Board Information
document_type: technical_reference

# Carrier Board Information

Click the following link to view the Cube Red carrier board pinout information.

--- chunk_id: chunk-0021
source_document: operating-conditions-and-performance.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 156
content_hash: ced90d96bb32071b
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: Operating Conditions and Performance
document_type: technical_reference

# Operating Conditions and Performance | **Parameter**                                      | **Description**                                                                                                                                                                                                                      |
| -------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Power Input Voltage / Max Current                  | 4.1V \~ 5.5V/350mA when 5V input                                                                                                                                                                                                     |
| Waterproof Performance                             | Not waterproof. External waterproof protection is needed                                                                                                                                                                             |
| Ideal Operating Temperature                        | -10°C \~ 55°C                                                                                                                                                                                                                        |
| Maximum Operating Temperature during Emergencies   | 100°C                                                                                                                                                                                                                                |
| Minimum Temperature Tested for Storage             | -70°C                                                                                                                                                                                                                                |
| Maximum Temperature Tested and Rebooted (survived) | 120°C                                                                                                                                                                                                                                |
| Minimum Temperature for Power On                   | Approximately -40°C\~-50°C

Be cautious of condensation when using in freezing conditions. It is strongly recommended to preheat the module first to ensure the system operates within an acceptable temperature range. |

--- chunk_id: chunk-0022
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 348
content_hash: f0c0c54b86c8df39
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 1 of 5 (continued)**
| Pin Number | Pin Type | Pin Name | Function |
| --- | --- | --- | --- |
| 1 | I/O | FMU_SWDIO | FMU serial wire debug I/O |
| 2 | O | FMU_LED_AMBER | Boot error LED (drive only, controlled by FET) |
| 3 | O | FMU_SWCLK | FMU serial wire debug clock |
| 4 | I/O | I2C_2_SDA | I2C serial data Tx/Rx |
| 5 | O | EXTERN_CS | Chip select for external SPI (NC, just for debugging) |
| 6 | O | I2C_2_SCL | I2C serial clock signal |
| 7 | I | FMU_!RESET | Reset pin for the FMU |
| 8 | I/O | CAN_L_3 | CAN bus low signal driver |
| 9 | I | VDD_SERVO_IN | Power for last resort I/O failsafe |
| 10 | I/O | CAN_H_3 | CAN bus high signal driver |
| 11 | I | EXTERN_DRDY | Interrupt pin for external SPI (NC, just for debugging) |
| 12 | I | SERIAL_5_RX | UART 5 RX (receive data) |
| 13 |  | GND | System GND |
| 14 | O | SERIAL_5_TX | UART 5 TX (transmit data) |
| 15 |  | GND | System GND |
| 16 | I | SERIAL_4_RX | UART 4 RX (receive data) |
| 17 |  | SAFETY | Safety button input |
| 18 | O | SERIAL_4_TX | UART 4 TX (transmit data) |

--- chunk_id: chunk-0023
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 354
content_hash: 6f8f8ad15dcda7da
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 2 of 5 (continued)**
| Pin Number | Pin Type | Pin Name | Function |
| --- | --- | --- | --- |
| 19 | O | VDD_3V3_SPEKTRUM_EN | Enable for the Spektrum voltage regulator |
| 20 | I | SERIAL_3_RX | UART 3 RX (receive data) |
| 21 | AI | PRESSURE_SENS_IN | Analog signal port, for pressure sensor, laser range finder, or sonar |
| 22 | O | SERIAL_3_TX | UART 3 TX (transmit data) |
| 23 | AI | AUX_BATT_VOLTAGE_SENS | Voltage sense for Aux battery input |
| 24 | O | ALARM | Buzzer PWM signal |
| 25 | AI | AUX_BATT_CURRENT_SENS | Current sense for Aux battery input |
| 26 | I | IO_VDD_3V3 | IO chip power, pinned through for debug |
| 27 | O | VDD_5V_PERIPH_EN | Enable voltage supply for peripherals |
| 28 | O | IO_LED_SAFET_PROT | IO-LED_SAFETY (safety LED) pinned out for IRIS |
| 29 | I | VBUS | USB VBus (VDD) |
| 30 |  | SERIAL_2_RTS | UART 2 RTS (request to send) |
| 31 | I/O | OTG_DP1 | USB Data+ (D) |
| 32 |  | SERIAL_2_CTS | UART 2 CTS (clear to send) |
| 33 | I/O | OTG_DM1 | USB Data- (M) |
| 34 | I | SERIAL_2_RX | UART 2 RX (receive data) |
| 35 | I/O | I2C_1_SDA | I2C serial data Tx/Rx |
| 36 | O | SERIAL_2_TX | UART 2 TX (transmit data) |

--- chunk_id: chunk-0024
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 356
content_hash: 4c6dc69370ab4e70
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 3 of 5 (continued)**
| Pin Number | Pin Type | Pin Name | Function |
| --- | --- | --- | --- |
| 37 | O | I2C_1_SCL | I2C serial clock signal |
| 38 | I | SERIAL_1_RX | UART 1 RX (receive data) |
| 39 | I/O | CAN_L_2 | FMU CAN bus low signal driver |
| 40 | O | SERIAL_1_TX | UART 1 TX (transmit data) |
| 41 | I/O | CAN_H_2 | FMU CAN bus high signal driver |
| 42 |  | SERIAL_1_RTS | UART 1 RTS (request to send) |
| 43 | I | VDD_5V_PERIPH_OC | Error state message from peripheral power supply |
| 44 |  | SERIAL_1_CTS | UART 1 CTS (clear to send) |
| 45 | I | VDD_5V_HIPOWER_OC | Error state message from high power peripheral power supply |
| 46 | O | IO_USART_1_TX | I/O USART 1 TX |
| 47 | AI | BATT_VOLTAGE_SENS_PROT | Voltage sense from main battery |
| 48 | O | IO_USART1_RX_SPECTRUM_DSM | Signal from Spectrum receiver |
| 49 | AI | BATT_CURRENT_SENS_PROT | Current sense from main battery |
| 50 | O | FMU_CH1_PROT | FMU PWM Output Channel 1 |
| 51 | O | SPI_EXT_MOSI | External SPI, for debug only |
| 52 | O | FMU_CH2_PROT | FMU PWM Output Channel 2 |
| 53 | I | VDD_SERVO | VDD_Servo, for monitoring servo bus |
| 54 | O | FMU_CH3_PROT | FMU PWM Output Channel 3 |

--- chunk_id: chunk-0025
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: fa1b8eb156140af1
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 4 of 5 (continued)**
| Pin Number | Pin Type | Pin Name | Function |
| --- | --- | --- | --- |
| 55 | I | VDD_BRICK_VALID | Main power valid signal |
| 56 | O | FMU_CH4_PROT | FMU PWM Output Channel 4 |
| 57 | I | VDD_BACKUP_VALID | Backup power valid signal |
| 58 | O | FMU_CH5_PROT | FMU PWM Output Channel 5 |
| 59 | I | VBUS_VALID | USB bus valid signal |
| 60 | O | FMU_CH6_PROT | FMU PWM Output Channel 6 |
| 61 | I | VDD_5V_IN_PROT | Main power (5V) into FMU from power selection |
| 62 | I | PPM_SBUS_PROT | PPM / S.Bus signal input |
| 63 | I | VDD_5V_IN_PROT | Main power (5V) into FMU from power selection |
| 64 | O | S.BUS_OUT | S.Bus signal output |
| 65 | O | IO_VDD_5V5 | IO VDD 5.5V |
| 66 | O | IO_CH8_PROT | I/O PWM Output Channel 8 |
| 67 | I | SPI_EXT_MISO | External SPI, for debug only |
| 68 | O | IO_CH7_PROT | I/O PWM Output Channel 7 |
| 69 | I/O | IO_SWDIO | I/O serial wire debug |
| 70 | O | IO_CH6_PROT | I/O PWM Output Channel 6 |
| 71 | O | IO_SWCLK | I/O serial wire debug clock |
| 72 | O | IO_CH5_PROT | I/O PWM Output Channel 5 |

--- chunk_id: chunk-0026
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: f1dfe931ab8985d8
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 5 of 5 (continued)**
| Pin Number | Pin Type | Pin Name | Function |
| --- | --- | --- | --- |
| 73 | O | SPI_EXT_SCK | External SPI, for debug only |
| 74 | O | IO_CH4_PROT | I/O PWM Output Channel 4 |
| 75 | I | IO_!RESET | I/O reset pin |
| 76 | O | IO_CH3_PROT | I/O PWM Output Channel 3 |
| 77 | I/O | CAN_L_1 | FMU CAN bus low signal driver |
| 78 | O | IO_CH2_PROT | I/O PWM Output Channel 2 |
| 79 | I/O | CAN_H_1 | FMU CAN bus high signal driver |
| 80 | O | IO_CH1_PROT | I/O PWM Output Channel 1 |

--- chunk_id: chunk-0027
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 280
content_hash: adbc52b8c429de0a
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 1 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 1          |          | GND                 | System GND                                    |
| 2          | I        | FMU_BOOT           | FMU boot                                      |
| 3          | I/O      | FC_NET_TX+        | Ethernet TX+,Auto-MDIX support                |
| 4          |          | NC                  | For future use                                |
| 5          |          | GND                 | System GND                                    |
| 6          |          | IO_BOOT            | IO MCU boot                                   |
| 7          | I/O      | FC_NET_TX-        | Ethernet TX-, Auto-MDIX support               |
| 8          |          | NC                  | For future use                                |
| 9          |          | GND                 | System GND                                    |
| 10         |          | NC                  | For future use                                |
| 11         | I/O      | FC_NET_RX+        | Ethernet RX+, Auto-MDIX support               |
| 12         |          | NC                  | For future use                                |
| 13         |          | GND                 | System GND                                    |
| 14         |          | NC                  | For future use                                |
| 15         | I/O      | FC_NET_RX-        | Ethernet RX-, Auto-MDIX support               |
| 16         |          | NC                  | For future use                                |
| 17         |          | GND                 | System GND                                    |
| 18         |          | NC                  | For future use                                |

--- chunk_id: chunk-0028
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 302
content_hash: 164c56aaac7ba2af
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 2 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 19         | O        | FC_NET_LEDY       | Link speed LED indication                     |
| 20         |          | NC                  | For future use                                |
| 21         | O        | FC_NET_LEDG       | Ethernet link activity LED indication         |
| 22         |          | NC                  | For future use                                |
| 23         | I        | FC_NET_VCC        | Ethernet 3.3V power in                        |
| 24         |          | NC                  | For future use                                |
| 25         | I        | Timestamp rtc       | Timestamp RTC                                 |
| 26         |          | NC                  | For future use                                |
| 27         |          | GND                 | System GND                                    |
| 28         |          | NC                  | For future use                                |
| 29         | I/O      | CAN_L_1           | CAN bus low signal driver                     |
| 30         |          | NC                  | For future use                                |
| 31         | I/O      | CAN_H_1           | CAN bus high signal driver                    |
| 32         |          | NC                  | For future use                                |
| 33         | I/O      | CAN_L_2           | CAN bus low signal driver                     |
| 34         |          | NC                  | For future use                                |
| 35         | I/O      | CAN_H_2           | CAN bus high signal driver                    |
| 36         |          | NC                  | For future use                                |

--- chunk_id: chunk-0029
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 300
content_hash: 8b2caeaff2e78b21
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 3 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 37         | I/O      | CAN_L_3           | CAN bus low signal driver                     |
| 38         |          | NC                  | For future use                                |
| 39         | I/O      | CAN_H_3           | CAN bus high signal driver                    |
| 40         |          | NC                  | For future use                                |
| 41         |          | GND                 | System GND                                    |
| 42         |          | NC                  | For future use                                |
| 43         | I        | UART8_RX           | IO UART 8 RX (receive data)                   |
| 44         |          | NC                  | For future use                                |
| 45         | O        | UART8_TX           | IO UART 8 TX (transmit data)                  |
| 46         |          | NC                  | For future use                                |
| 47         |          | GND                 | System GND                                    |
| 48         |          | NC                  | For future use                                |
| 49         | O        | DSI_CKP            | MIPI DSI host clock postive                   |
| 50         |          | NC                  | For future use                                |
| 51         | O        | DSI_CKN            | MIPI DSI host clock negative                  |
| 52         |          | NC                  | For future use                                |
| 53         |          | GND                 | System GND                                    |
| 54         |          | NC                  | For future use                                |

--- chunk_id: chunk-0030
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 292
content_hash: 740ed1fefbda226d
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 4 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 55         | O        | DSI_D0P            | MIPI DSI host DATA0 postive                   |
| 56         |          | NC                  | For future use                                |
| 57         | O        | DSI_D0N            | MIPI DSI host DATA0 negative                  |
| 58         |          | NC                  | For future use                                |
| 59         |          | GND                 | System GND                                    |
| 60         |          | NC                  | For future use                                |
| 61         | O        | DSI_D1P            | MIPI DSI host DATA1 postive                   |
| 62         |          | NC                  | For future use                                |
| 63         | O        | DSI_D1N            | MIPI DSI host DATA1 negative                  |
| 64         |          | NC                  | For future use                                |
| 65         |          | GND                 | System GND                                    |
| 66         |          | NC                  | For future use                                |
| 67         | O        | FMU_DAC            | FMU analog output                             |
| 68         |          | NC                  | For future use                                |
| 69         |          | GND                 | System GND                                    |
| 70         |          | NC                  | For future use                                |
| 71         | O        | IO_DAC             | IO analog output                              |
| 72         |          | NC                  | For future use                                |

--- chunk_id: chunk-0031
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: 0e74b3c5656b3083
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
section_heading: Ports Standard and Definition
document_type: technical_reference

**Table — Part 5 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 73         | I        | VDD_5V_IN_backup | Main power (5V) into FMU from power selection |
| 74         |          | NC                  | For future use                                |
| 75         | I        | VDD_5V_IN_backup | Main power (5V) into FMU from power selection |
| 76         |          | NC                  | For future use                                |
| 77         | I        | VDD_5V_IN_backup | Main power (5V) into FMU from power selection |
| 78         |          | NC                  | For future use                                |
| 79         | I        | VDD_5V_IN_backup | Main power (5V) into FMU from power selection |
| 80         |          | NC                  | For future use                                |

--- chunk_id: chunk-0032
source_document: ports-standard-and-definition.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 196
content_hash: c967128901a51e99
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
section_heading: Ports Standard and Definition
document_type: technical_reference

# Ports Standard and Definition
### **Standard Carrier Board Ports Standard** | Connector | Connector Type              |
| --------- | --------------------------- |
| `GPS1`    | JST-GH 1.25 mm (8-pin)      |
| `GPS2`    | JST-GH 1.25 mm (6-pin)      |
| `TELEM1`  | JST-GH 1.25 mm (6-pin)      |
| `TELEM2`  | JST-GH 1.25 mm (6-pin)      |
| `I2C2`    | JST-GH 1.25 mm (4-pin)      |
| `USB`     | JST-GH 1.25 mm (6-pin)      |
| `CAN1`    | JST-GH 1.25 mm (4-pin)      |
| `CAN2`    | JST-GH 1.25 mm (4-pin)      |
| `CAN3`    | JST-GH 1.25 mm (4-pin)      |
| `POWER1`  | Molex CLIK-Mate 2mm (6-pin) |
| `POWER2`  | Molex CLIK-Mate 2mm (6-pin) |
| `ADC`     | JST-GH 1.25 mm (3-pin)      |
| `DSI`     | JST-GH 1.25 mm (15-pin)     |
| `ETH`     | TE Multi-purp pluh(8P)      | ### Cube Red 80-Pin DF17 Connector
### **Connector 1 Assignments** ### **Connector 2 Assignments**

--- chunk_id: chunk-0033
source_document: specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 593
content_hash: 0ff4a4999c86b555
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
section_heading: Specifications
document_type: specification

# Specifications

* **Microcontroller**
  * 2 x STM32H7 series microcontrollers (primary controller + secondary controller)
  * Dual-core (Cortex®-M7 + Cortex®-M4) processors
  * Double-precision floating point unit (FPU)
  * Embedded flash memory based on nonvolatile memory (NVM)
  * Primary controller includes external flash memory
  * Supports ambient temperature between 125°C to - 40°C
* **4 x Inertial Measurement Units (IMUs)**
  * 3 x IMUs connected to primary microcontroller
  * 1 x IMU connected to secondary microcontroller
* **1 x Compass**
  * Sensitivity: 13nT
  * Noise: 15nT
  * Linearity over +/- 200 uT: 0.50%
  * Field Measurement Range: +/- 1100 uT
  * Current @ 8Hz, 3 Axes: 260 uA
  * SPI and I2C interface
  * Operating Temperature: -40°C to +85°C
* **Barometric pressure sensor**
  * 3 x barometers
    * 2 x barometer connected to primary microcontroller
    * 1 x barometer connected to secondary microcontroller
  * Altitude resolution of 10 cm
  * Conversion rate down to 1 ms
  * Low power, 1 μA (standby < 0.15 μA)
  * QFN package: 5.0 x 3.0 x 1.0 mm3
  * Supply voltage: 1.8 to 3.6 V
  * Integrated digital pressure sensor (24 bit ΔΣ ADC)
  * Operating range: 10 to 1200 mbar, -40 to +85 °C
  * I2C and SPI interface, up to 20 MHz
  * No external components (internal oscillator)
* **CAN FD Transceiver**
  * 3 x CAN FD ports
    * 1 x CAN FD connected to primary microcontroller
    * 1 x CAN FD connected to secondary microcontroller
    * 1 x CAN FD connected to both primary and secondary microcontroller (serves as a backup if a failure occurs)
  * Optimized for CAN FD (flexible data rate) at 2, 5, and 8 Mbps Operation
  * Meets the latest ISO/DIS 11898-2:2015 specification
  * Supports Wake-up pattern
  * AEC-Q100 Grade 0 Very Low Standby Current (5 µA, typical)
  * VIO supply pin to interface directly to CAN controllers and microcontrollers with 1.7V to 5.5V I/O
  * An unpowered node or brown-out event will not load the CAN bus
  * Permanent dominant detection on TXD
  * Permanent dominant detection on Bus
  * Power-on reset and voltage brown-out protection on VDD pin
  * Protection against damage from short-circuit conditions (positive or negative battery voltage)
  * Protection against high-voltage transients in automotive environments
  * Automatic thermal shutdown protection
  * Suitable for 12V and 24V systems
  * Temperature range: -40°C to +150°C
* USB FS compatible with USB Type C connector
* 10/100BaseT Ethernet interface
* Display Serial Interface (DSI)
* Isolated static air port
* Replaceable, fully closed upper lid and isolated static air ducts provide stable pressure for the barometers, ensuring accurate altitude measurements
* Foams with different hardness options tailored to various flight purposes

--- chunk_id: chunk-0034
source_document: system-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: f0a8075fc3b30b7c
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: System Architecture
document_type: technical_reference

# System Architecture

The Cube Red continues with the flight management unit (FMU) + I/O architecture, where the two functional blocks are incorporated in a single physical module. **PWM Outputs**

The Cube Red has eight pulse width modulation (PWM) outputs that are connected to the secondary FMU. Multiple update rates can be supported on these outputs in three groups: one group of four and two groups of two. PWM signal rates reaching up to 400 Hz can be supported. These eight PWMs can drive up to 50 mA each, but with a total of 100 mA for the eight outputs combined. Six PWM outputs are connected to the primary FMU and feature reduced update latency. Multiple update rates can be supported on these outputs in two groups: one group of four and one group of two. PWM signal rates up to 400 Hz can be supported. All PWM outputs are electro-static discharge (EDS) protected and designed to survive accidental miss-connection of servos without being damaged. The servo drivers are specified to drive a 50 pF servo input load over 2 m of 26 AWG servo cable. The I/O PWM outputs can also be configured as individual general-purpose input/output (GPIO). > The GPIOs are not high-power outputs. The PWM drivers are only designed for driving servos and similar logic inputs, not relays or LEDs. **Peripheral Ports**

All peripherals are connected through two 80-pin connectors, and the peripherals are connected via a baseboard that can be customized for each application. **FMU and I/O Power Supplies**

The primary FMU and secondary FMU both operate at 3.3V, each with a private dual-channel regulator. Each regulator features a power-on reset output tied to the regulator’s internal power-up and drop-out sequencing. **Power Sources**

Power may be supplied to the Cube Red via USB, the power brick port, or the second brick port. Each power source is protected against reverse-polarity connections and back-powering from other sources. **Power Brick Port**

The brick port is the preferred power source for the Cube Red. Brick power will always be selected when available. **Servo Power**

The Cube Red supports both standard (5 V) and high-voltage (up to 10V) servo power, with some restrictions. The secondary FMU can accept power from the servo connector up to 10V.

--- chunk_id: chunk-0035
source_document: system-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 9c063b89c35a4301
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: System Architecture
document_type: technical_reference

**Servo Power**

The Cube Red supports both standard (5 V) and high-voltage (up to 10V) servo power, with some restrictions. The secondary FMU can accept power from the servo connector up to 10V. This allows the I/O to failover to servo power if the main power supply is lost or interrupted. > The FMU and peripherals will NOT accept power from the servo connector. **Aux Power**

The Cube Red includes a backup power port, which is set up like the primary power input. Input voltages above 5.7V power are blocked. The Cube Red and its peripherals may draw up to a total of 2.75A when operating on Aux power, provided that the power brick or another power source can supply the required current. Servos are never powered directly by the Cube Red. **Servo Rail**

The I/O chip draws power up to 10.5V from the servo rail. This allows reverting to manual mode in case the 5V main input or 5V backup input from the power selection module (PSM) located on the carrier board fails. It is specifically applicable to planes and requires correct mapping of the I/O chip. **USB-Type C Power**

Power from USB-Type C is supported for software updates, testing, and development purposes. USB-Type C power is supplied to the peripheral ports for testing; however, total current consumption must typically be **limited to 3A**, including the peripherals, to avoid overloading the host USB port. **Multiple Power Sources**

When more than one power source is connected, power will be drawn from the highest-priority source with a valid input voltage. In most cases, the FMU should be powered via the power brick or a compatible off-board regulator through the brick port or auxiliary power rail. In desktop testing scenarios, drawing power from the USB avoids the need for a battery eliminator circuit (BEC) or similar servo power source (though the servos will still need an external power source). **Capacitor Backup**

Both the FMU and I/O microcontrollers feature capacitor-backed real-time clocks and SRAM. The on-board backup capacitor has sufficient capacity for the intended use of the clock and SRAM, which is to provide storage to allow orderly recovery from unintended power loss or other causes of in-air restarts. The capacitors are recharged from the FMU 3.3V rail. This feature will only be available if software is present to support it.

--- chunk_id: chunk-0036
source_document: system-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 200
content_hash: 9c8a7a94f01d7485
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
section_heading: System Architecture
document_type: technical_reference

The capacitors are recharged from the FMU 3.3V rail. This feature will only be available if software is present to support it. **EMI Filtering and Transient Protection**

A filter and a Transient Voltage Suppressor (TVS) have been added to the carrier board for EMI filtering and transient protection. When designing your own carrier board, you must also include these features. EMI filtering is provided at key points in the system using high-insertion-loss pass-through filters. These filters are paired with TVS diodes at the peripheral connectors to suppress power transients. Reverse polarity protection is provided at each of the power inputs. USB signals are filtered and terminated with a combined termination/TVS array. Most digital peripheral signals (including all PWM outputs, serial ports, or I2C ports) are driven using ESD-enhanced buffers and feature series blocking resistors to reduce the risk of damage due to transients or accidental misconnections. ### Cube Red Connectors

--- chunk_id: chunk-0037
source_document: cube-red.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 96
content_hash: 2c69ccf3339d9482
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
section_heading: Cube Red
document_type: technical_reference

# Cube Red

The Cube Red is a dual flight management unit (FMU) that helps you easily manage unmanned exploration vehicle (UXV) operations. The module has two dual-core, double-precision FPU microprocessors for faster data processing. It includes an Ethernet interface for expanded networking capabilities. All the key components feature a redundancy system to ensure uninterrupted vehicle operations. Additionally, the module has an external flash memory to accommodate larger and more complex programs.

--- chunk_id: chunk-0038
source_document: cosmetic-change-notification.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: c349a2b7b684fa65
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: Cosmetic Change Notification
document_type: technical_reference

# Cosmetic Change Notification

The Cube Red, Cube Orange, and Cube Orange+ are currently shipped in two versions that differ only in the layout of the top and bottom covers. This difference is purely cosmetic and does not affect hardware functionality, components, performance, or specifications. No action is required from the user. See the following example using the Cube Orange+. **Version 1**

* Top cover: Has CubePilot single color logo with arrow facing forward, plus Cube+ mark. * Bottom cover: No additional wording. **Version 2**

* Top cover: Has CubePilot single color logo with arrow facing forward, plus Cube+ mark; along with the following:
  * DIU blue Listed NDAA Compliant. * Design in Australia ; Proudly made in Taiwan. * Bottom cover: Design in Australia ; Proudly made in Taiwan

--- chunk_id: chunk-0039
source_document: eol-and-replacement.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 66
content_hash: a0334efd0bc2b5fa
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: EOL and Replacement
document_type: technical_reference

# EOL and Replacement

The MPU9250, LSM303D, and L3GD20 have reached their End of Life (EOL). The newer designs use the STM32H7 microcontroller-based boards. CubeBlueH7, CubeOrange, and CubePurpleH7 are 100% plug-and-play with carrier boards that are compliant with CubePilot's reference design. > The CubePurpleF4 has been replaced by the CubePurpleH7.

--- chunk_id: chunk-0040
source_document: flight-management-unit-fmu.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 348
content_hash: f17397425c2c5611
prev_chunk_id: chunk-0039
next_chunk_id: chunk-0041
section_heading: Flight Management Unit (FMU)
document_type: technical_reference

# Flight Management Unit (FMU)

The following introduces the FMU for each colored cube. | The Cube Type                                                                 | Specifications                                                                                                                                                                                                                                                                                                                                                                                                     |
| ----------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Cube Black                                     | Microcontroller: STM32F427Flash Memory: 2MB RAM: 256KBInertial sensor: MPU9250 16G integrated accelerometer/gyroscopeBarometer: MS5611 All sensors connected via SPIMicro SD interfaces via SDIO                                           |
| **Cube Green**                              | Microcontroller: STM32F427Flash Memory: 2MB RAM: 256KBInertial sensor: MPU9250 16G integrated accelerometer/gyroscopeBarometer: MS5611 All sensors connected via SPIMicro SD interfaces via SDIO                                           |
| **Cube BlueF4**                              | Microcontroller: STM32F427Flash Memory: 2MB RAM: 256KBInertial sensor: MPU9250 16G integrated accelerometer/gyroscopeBarometer: MS5611 All sensors connected via SPIMicro SD interfaces via SDIO                                           |
| **Cube BlueH7**                              | Microcontroller: STM32H753Flash Memory: 2MB RAM: 1MBInertial sensor: ICM-20649 30G integrated accelerometer/gyroscope.Barometer: MS5611 All sensors connected via SPI Micro SD interfaces via SDIO                                         |
| **Cube PurpleF4**                          | Microcontroller: STM32F427Flash Memory: 2MB RAM: 256KBBarometer: MS5611 Inertial sensor: MPU9250 16G integrated accelerometer/gyroscopeBarometer: MS5611 All sensors connected via SPIMicro SD interfaces via SDIO |
| **Cube PurpleH7**                          | Microcontroller: STM32H753Flash Memory: 2MB RAM: 1MBInertial sensor: MPU9250 16G integrated accelerometer/gyroscopeBarometer: MS5611 All sensors connected via SPIMicro SD interfaces via SDIO                                             |
| **Cube Yellow**                            | Microcontroller: STM32F777Flash Memory: 2MB RAM: 512KBBarometer: MS5611 All sensors connected via SPI Micro SD interfaces via SDIO                                                                                                                                 |
| Cube Orange | Microcontroller: STM32H753Flash Memory: 2MB RAM: 1MBInertial sensor: ICM-20649 30G integrated accelerometer/gyroscopeBarometer: MS5611 All sensors connected via SPIMicro SD interfaces via SDIO                                           |
| **Cube Orange+**                           | Microcontroller: STM32H757Flash Memory: 2 MB RAM: 1 MBInertial sensor: ICM-20649 30G integrated accelerometer/gyroscopeBarometer: MS5611 All sensors connected via SPIMicro SD interfaces via SDIO                                         |

--- chunk_id: chunk-0041
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 61
content_hash: 3a6a0a7150b3e054
prev_chunk_id: chunk-0040
next_chunk_id: chunk-0042
section_heading: Interface Specifications
document_type: specification

# Interface Specifications

This section covers the complete interface standard and the core mechanical, electrical, and external connection options of The Cube. Areas marked as LT (long term) need to be kept stable to isolate any autopilot revisions being made to the unmanned aerial vehicle (UAV).

--- chunk_id: chunk-0042
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: f7f4aaa555842d2a
prev_chunk_id: chunk-0041
next_chunk_id: chunk-0043
section_heading: **Interface Standard**
document_type: specification

## **Interface Standard**
### Connector Series

**Low density**: 0.1” over mould keyed servo connectors

> Cabling: AWG24, ribbon or round, iconic color scheme

**Stack**: [Hirose DF17, 80pos](http://www.hirose.co.jp/cataloge_hp/en_DF17_20130411.pdf) , 4 mm stacking height, 0.5 mm pitch, drop-proof

**High density**: [JST-GH](http://www.jst-mfg.com/product/detail_e.php?series=105\\) 1.25 mm

> Cabling: AWG28, ribbon, iconic colour scheme

**Power Module**: [Molex Clik-Mate](https://www.molex.com/molex/products/family/clikmate_wiretoboard_connectors) 2 mm for both main and backup power (connector is not on The Cube, but on the carrier board). ### **The Cube**
* Mechanical**:** 30x30 mm M1.6 mounting hole pattern, 35x35 mm footprint. * 80 position DF17 connector: Carries all autopilot interface connections. * No power management, which means power modules cannot be selected. *  3.8 to 5.7V operation (absolute maximum ratings). * 4.0 to 5.5V operation (compliant rating). > Minimal electrical protection is provided to The Cube.

--- chunk_id: chunk-0043
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 570
content_hash: da8183b99ae8209d
prev_chunk_id: chunk-0042
next_chunk_id: chunk-0044
section_heading: **The Cube I/O**
document_type: specification

## **The Cube I/O**

Connecting Interfaces:

* Two I2C. * Two CAN: CAN1 and CAN2. * Four UART: TELEM1, TELEM2, GPS (I2C 1 embedded), SERIAL4(I2C 2 embedded). * One Console: CONSOLE (SERIAL5). * One HMI: USB extender. ### Serial Ports Parameters
### **Port Interface and Pin Label**
### **Main Power - | Connector: POWER1** | Pin Number | Name                | I/O | Voltage | Wire Colour | Description                   |
| ---------- | ------------------- | --- | ------- | ----------- | ----------------------------- |
| 1          | VDD_5V_BRICK      | IN  | 5 V     | RED/GRAY    | Supply To AP from Power Brick |
| 2          | VDD_5V_BRICK      | IN  | 5 V     | RED/GRAY    | Supply To AP from Power Brick |
| 3          | BATT_CURRENT_SENS | IN  | 3.3 V   | BLACK       | Battery Current Connecter     |
| 4          | BATT_VOLTAGE_SENS | IN  | 3.3 V   | BLACK       | Battery Voltage Connecter     |
| 5          | GND                 | -   | GND     | BLACK       | GND connection                |
| 6          | GND                 | -   | GND     | BLACK       | GND connection                | ### **Backup Power -  | Connector: POWER2** | Pin Number | Name                     | I/O | Voltage | Wire Colour | Description                   |
| ---------- | ------------------------ | --- | ------- | ----------- | ----------------------------- |
| 1          | VDD_5V_BRICK           | IN  | 5 V     | RED/GRAY    | Supply To AP from Power Brick |
| 2          | VDD_5V_BRICK           | IN  | 5 V     | RED/GRAY    | Supply To AP from Power Brick |
| 3          | AUX_BATT_CURRENT_SENS | IN  | 3.3 V   | BLACK       | Aux Battery Current Connecter |
| 4          | AUX_BATT_VOLTAGE_SENS | IN  | 3.3 V   | BLACK       | Aux Battery Voltage Connecter |
| 5          | GND                      | -   | GND     | BLACK       | GND connection                |
| 6          | GND                      | -   | GND     | BLACK       | GND connection                | ### **I2C - 4 pos (one fitted as a standalone, one as an old internal) | Connector: I2C2** | Pin Number | Name        | I/O    | Voltage         | Wire Colour | Description                  |
| ---------- | ----------- | ------ | --------------- | ----------- | ---------------------------- |
| 1          | VCC_5V     | OUT    | 5 V             | RED/GRAY    | Supply to peripheral from AP |
| 2          | I2C_2_SCL | IN/OUT | 3.3 V (PULLUPS) | BLUE/BLACK  | SCL, Pull-up on AP           |
| 3          | I2C_2_SDA | IN/OUT | 3.3 V (PULLUPS) | GREEN/BLACK | SDA, Pull-up on AP           |
| 4          | GND         |        | GND             | BLACK       | GND connection               |

--- chunk_id: chunk-0044
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 485
content_hash: 7a57daad9cefbb74
prev_chunk_id: chunk-0043
next_chunk_id: chunk-0045
section_heading: **The Cube I/O**
document_type: specification

### **I2C - 4 pos (one fitted as a standalone, one as an old internal) | Connector: I2C2** | Pin Number | Name        | I/O    | Voltage         | Wire Colour | Description                  |
| ---------- | ----------- | ------ | --------------- | ----------- | ---------------------------- |
| 1          | VCC_5V     | OUT    | 5 V             | RED/GRAY    | Supply to peripheral from AP |
| 2          | I2C_2_SCL | IN/OUT | 3.3 V (PULLUPS) | BLUE/BLACK  | SCL, Pull-up on AP           |
| 3          | I2C_2_SDA | IN/OUT | 3.3 V (PULLUPS) | GREEN/BLACK | SDA, Pull-up on AP           |
| 4          | GND         |        | GND             | BLACK       | GND connection               | ### **CAN (2 fitted) | Connector: CAN1, CAN2** | Pin Number | Name    | I/O    | Voltage | Wire Colour  | Description                  |
| ---------- | ------- | ------ | ------- | ------------ | ---------------------------- |
| 1          | VCC_5V | OUT    | 5 V     | RED/GRAY     | Supply to peripheral from AP |
| 2          | CAN_H  | IN/OUT | 12 V    | YELLOW/BLACK | CAN High                     |
| 3          | CAN_L  | IN/OUT | 12 V    | GREEN/BLACK  | CAN Low                      |
| 4          | GND     | -      | GND     | BLACK        | GND connection               | ### **UART GENERIC (autopilot side) | Connector: TELEM1, TELEM2** | Pin Number | Name          | I/O | Voltage           | Wire Colour  | Description                  |
| ---------- | ------------- | --- | ----------------- | ------------ | ---------------------------- |
| 1          | VCC_5V       | OUT | 5 V               | RED/GRAY     | Supply to peripheral from AP |
| 2          | MCU_TX       | OUT | 3.3 V - 5.0 V TTL | YELLOW/BLACK | TX of AP                     |
| 3          | MCU_RX       | IN  | 3.3 V - 5.0 V TTL | GREEN/BLACK  | RX of AP                     |
| 4          | MCU_CTS (TX) | OUT | 3.3 V - 5.0 V TTL | GRAY/BLACK   | CTS (Clear To Send)          |
| 5          | MCU_RTS (RX) | IN  | 3.3 V - 5.0 V TTL | GRAY/BLACK   | RTS (Request To Send)        |
| 6          | GND           | -   | GND               | BLACK        | GND connection               |

--- chunk_id: chunk-0045
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 8bb02f15516b8584
prev_chunk_id: chunk-0044
next_chunk_id: chunk-0046
section_heading: **The Cube I/O**
document_type: specification

### **UART GENERIC (autopilot side) | Connector: TELEM1, TELEM2** | Pin Number | Name          | I/O | Voltage           | Wire Colour  | Description                  |
| ---------- | ------------- | --- | ----------------- | ------------ | ---------------------------- |
| 1          | VCC_5V       | OUT | 5 V               | RED/GRAY     | Supply to peripheral from AP |
| 2          | MCU_TX       | OUT | 3.3 V - 5.0 V TTL | YELLOW/BLACK | TX of AP                     |
| 3          | MCU_RX       | IN  | 3.3 V - 5.0 V TTL | GREEN/BLACK  | RX of AP                     |
| 4          | MCU_CTS (TX) | OUT | 3.3 V - 5.0 V TTL | GRAY/BLACK   | CTS (Clear To Send)          |
| 5          | MCU_RTS (RX) | IN  | 3.3 V - 5.0 V TTL | GRAY/BLACK   | RTS (Request To Send)        |
| 6          | GND           | -   | GND               | BLACK        | GND connection               | ### **UART GPS (autopilot side, I2C is the original “External” bus), UART 3 | Connector: GPS1** | Pin Number | Name                 | I/O    | Voltage           | Wire Colour | Description                    |
| ---------- | -------------------- | ------ | ----------------- | ----------- | ------------------------------ |
| 1          | VCC_5V              | IN     | 5 V               | RED         | Supply to GPS from AP          |
| 2          | GPS_TX              | IN     | 3.3 V - 5.0 V TTL | BLACK       | TX of AP                       |
| 3          | GPS_RX              | OUT    | 3.3 V - 5.0 V TTL | BLACK       | RX of AP                       |
| 4          | SCL                  | IN     | 3.3 V             | BLACK       | I2C 1 SCL                      |
| 5          | SDA                  | IN/OUT | 3.3 V             | BLACK       | I2C 1 SDA                      |
| 6          | BUTTON               | OUT    | GND               | BLACK       | Signal shorted to GND on press |
| 7          | IO_LED_SAFET_PROT | OUT    | GND               | BLACK       | LED Driver For Safety Button   |
| 8          | GND                  | -      | GND               | BLACK       | GND connection                 |

--- chunk_id: chunk-0046
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: b590b3b0d66cede8
prev_chunk_id: chunk-0045
next_chunk_id: chunk-0047
section_heading: **The Cube I/O**
document_type: specification

### **UART GPS (autopilot side, I2C is the original “External” bus), UART 3 | Connector: GPS1** | Pin Number | Name                 | I/O    | Voltage           | Wire Colour | Description                    |
| ---------- | -------------------- | ------ | ----------------- | ----------- | ------------------------------ |
| 1          | VCC_5V              | IN     | 5 V               | RED         | Supply to GPS from AP          |
| 2          | GPS_TX              | IN     | 3.3 V - 5.0 V TTL | BLACK       | TX of AP                       |
| 3          | GPS_RX              | OUT    | 3.3 V - 5.0 V TTL | BLACK       | RX of AP                       |
| 4          | SCL                  | IN     | 3.3 V             | BLACK       | I2C 1 SCL                      |
| 5          | SDA                  | IN/OUT | 3.3 V             | BLACK       | I2C 1 SDA                      |
| 6          | BUTTON               | OUT    | GND               | BLACK       | Signal shorted to GND on press |
| 7          | IO_LED_SAFET_PROT | OUT    | GND               | BLACK       | LED Driver For Safety Button   |
| 8          | GND                  | -      | GND               | BLACK       | GND connection                 | ### **UART 4 (I2C2, the original “Internal” bus) | Port: GPS2** | Pin Number | Name    | I/O | Voltage           | Wire Colour  | Description           |
| ---------- | ------- | --- | ----------------- | ------------ | --------------------- |
| 1          | VCC_5V | OUT | 5 V               | RED/GRAY     | Supply to GPS from AP |
| 2          | MCU_TX | OUT | 3.3 V - 5.0 V TTL | YELLOW/BLACK | TX of AP              |
| 3          | MCU_RX | IN  | 3.3 V - 5.0 V TTL | GREEN/BLACK  | RX of AP              |
| 4          | SCL     | OUT | 3.3 V - 5.0 V     | GRAY/BLACK   | I2C 2 SCL             |
| 5          | SDA     | IN  | 3.3 V - 5.0 V     | GRAY/BLACK   | I2C 2 SDA             |
| 6          | GND     | -   | GND               | BLACK        | GND connection        |

--- chunk_id: chunk-0047
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 581
content_hash: 6c71c0397983343a
prev_chunk_id: chunk-0046
next_chunk_id: chunk-0048
section_heading: **The Cube I/O**
document_type: specification

### **UART 4 (I2C2, the original “Internal” bus) | Port: GPS2** | Pin Number | Name    | I/O | Voltage           | Wire Colour  | Description           |
| ---------- | ------- | --- | ----------------- | ------------ | --------------------- |
| 1          | VCC_5V | OUT | 5 V               | RED/GRAY     | Supply to GPS from AP |
| 2          | MCU_TX | OUT | 3.3 V - 5.0 V TTL | YELLOW/BLACK | TX of AP              |
| 3          | MCU_RX | IN  | 3.3 V - 5.0 V TTL | GREEN/BLACK  | RX of AP              |
| 4          | SCL     | OUT | 3.3 V - 5.0 V     | GRAY/BLACK   | I2C 2 SCL             |
| 5          | SDA     | IN  | 3.3 V - 5.0 V     | GRAY/BLACK   | I2C 2 SDA             |
| 6          | GND     | -   | GND               | BLACK        | GND connection        | ### **UART 5 (Debug), S.Bus out - FR-SKY TELEM or Debug | Port: CONS SBUSo** | Pin Number | Name       | I/O | Voltage           | Wire Colour | Description                   |
| ---------- | ---------- | --- | ----------------- | ----------- | ----------------------------- |
| 1          | S.Bus_Out | OUT |                   |             | S.Bus Signal Output, TX of AP |
| 2          | MCU_TX    | OUT | 3.3 V - 5.0 V TTL |             | TX of AP                      |
| 3          | VDD_SERVO | OUT | Servo Voltage     |             | Servo rail voltage            |
| 4          | MCU_RX    | IN  | 3.3 V - 5.0 V TTL |             | RX of AP                      |
| 5          | GND        | -   | GND               |             | GND connection                |
| 6          | GND        | -   | GND               |             | GND connection                | ### **Debug (New Standard Debug) (Digikey PN for housing SM06B-SURS-TF(LF)(SN)-ND)**
#### **IO DEBUG** | Pin Number | Name         | I/O | Voltage           | Wire Color | Description           |
| ---------- | ------------ | --- | ----------------- | ---------- | --------------------- |
| 1          | VDD 5V PEIPH | OUT | 5 V               |            | 5V                    |
| 2          | IO_TX       | OUT | 3.3 V - 5.0 V TTL |            | TX of AP IO_uart1 TX |
| 3          | IO_RX       | IN  | 3.3V - 5.0 V TTL  |            | RX of AP IO_uart1 RX |
| 4          | IO-SWDIO     | I/O | 3.3 V - 5.0 V TTL |            | Serial wire debug I/O |
| 5          | IO-SWCLK     | I/O | 3.3 V - 5.0 V TTL |            | Serial wire Clock     |
| 6          | GND          | OUT | GND               |            | GND connection        |

--- chunk_id: chunk-0048
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 477
content_hash: 6cee587884763e36
prev_chunk_id: chunk-0047
next_chunk_id: chunk-0049
section_heading: **The Cube I/O**
document_type: specification

### **Debug (New Standard Debug) (Digikey PN for housing SM06B-SURS-TF(LF)(SN)-ND)**
#### **IO DEBUG** | Pin Number | Name         | I/O | Voltage           | Wire Color | Description           |
| ---------- | ------------ | --- | ----------------- | ---------- | --------------------- |
| 1          | VDD 5V PEIPH | OUT | 5 V               |            | 5V                    |
| 2          | IO_TX       | OUT | 3.3 V - 5.0 V TTL |            | TX of AP IO_uart1 TX |
| 3          | IO_RX       | IN  | 3.3V - 5.0 V TTL  |            | RX of AP IO_uart1 RX |
| 4          | IO-SWDIO     | I/O | 3.3 V - 5.0 V TTL |            | Serial wire debug I/O |
| 5          | IO-SWCLK     | I/O | 3.3 V - 5.0 V TTL |            | Serial wire Clock     |
| 6          | GND          | OUT | GND               |            | GND connection        | #### **FMU Debug** | Pin Number | Name               | I/O | Voltage           | Wire Color | Description            |
| ---------- | ------------------ | --- | ----------------- | ---------- | ---------------------- |
| 1          | VDD 5V PEIPH       | OUT | 5 V               |            | 5V                     |
| 2          | FMU_TX (SERIAL 5) | OUT | 3.3 V - 5.0 V TTL |            | TX of AP FMU_uart5 TX |
| 3          | FMU_RX (SERIAL 5) | IN  | 3.3V - 5.0 V TTL  |            | RX of AP FMU_uart5 RX |
| 4          | FMU-SWDIO          | I/O | 3.3 V - 5.0 V TTL |            | Serial wire debug I/O  |
| 5          | FMU-SWCLK          | I/O | 3.3 V - 5.0 V TTL |            | Serial wire Clock      |
| 6          | GND                | OUT | GND               |            | GND connection         | #### **Analog | Port:`ADC`** | Pin Number | Name              | I/) | Voltage | Wire Color | Description    |
| ---------- | ----------------- | --- | ------- | ---------- | -------------- |
| 1          | VDD_5V_Periph   | OUT |         |            |                |
| 2          | Pressure sense in | IN  |         |            |                |
| 3          | GND               | -   |         |            | GND connection |

--- chunk_id: chunk-0049
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 860
content_hash: c42a5a36a4f80f93
prev_chunk_id: chunk-0048
next_chunk_id: chunk-0050
section_heading: **The Cube I/O**
document_type: specification

#### **Analog | Port:`ADC`** | Pin Number | Name              | I/) | Voltage | Wire Color | Description    |
| ---------- | ----------------- | --- | ------- | ---------- | -------------- |
| 1          | VDD_5V_Periph   | OUT |         |            |                |
| 2          | Pressure sense in | IN  |         |            |                |
| 3          | GND               | -   |         |            | GND connection | #### **IO USART 1/DSM/Spektrum | Port:`SPKT`** | Pin Number | Name                          | I/O | Voltage | Wire Colour | Description              |
| ---------- | ----------------------------- | --- | ------- | ----------- | ------------------------ |
| 1          | IO_USART1_RX_SPECTRUM_DSM | IN  |         |             | IO USART 1 RX, DSM INPUT |
| 2          | GND                           | -   | GND     |             | GND                      |
| 3          | VDD_3V3_Spektrum            | OUT | 3.3 V   |             | private Power Supply     | #### **HMI (Buzzer, USB, LEDs) | Port:`USB`** | Pin # | Name            | I/O    | Voltage         | Wire Colour | Description                   |
| ----- | --------------- | ------ | --------------- | ----------- | ----------------------------- |
| 1     | V BUS           | OUT    | 5 V             | RED/GRAY    | USB V BUS                     |
| 2     | OTG_DP1        | IN/OUT | 3.3 V           | GREEN/BLACK | USB Data Positive (D+)        |
| 3     | OTG_DM1        | IN/OUT | 3.3 V           | RED/BLACK   | USB Data Minus (D-)           |
| 4     | GND             | -      | GND             | BLACK       | GND                           |
| 5     | BUZZER_OUT     | OUT    | Battery Voltage | GRAY/BLACK  | VBAT (8.4 - 42 V)             |
| 6     | FMU_LED_AMBER | OUT    |                 | BLACK       | Boot / Error LED (FW updates) | #### **Back Edge (can be rearranged in accordance with PCB layout) | Port：`RCIN`** **`MAIN OUT`** **`AUX OUT`**
#### **SERVO HEADER (0.1”, 1/1/15 power layout)** | Pin Number | Name            | I/O    | Voltage                              | Wire Colour | Description        |
| ---------- | --------------- | ------ | ------------------------------------ | ----------- | ------------------ |
| S - 1      | FMU_CH1_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 2      | FMU_CH2_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 3      | FMU_CH3_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 4      | FMU_CH4_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 5      | FMU_CH5_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 6      | FMU_CH6_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 7      | IO_CH1_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 8      | IO_CH2_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 9      | IO_CH3_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 10     | IO_CH4_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 11     | IO_CH5_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 12     | IO_CH6_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 13     | IO_CH7_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 14     | IO_CH8_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 15     | PPM_SBUS_PROT | IN/OUT | 3.3 V / 4.5 V Powered                |             | PPM / S.Bus Signal |

--- chunk_id: chunk-0050
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 332
content_hash: b0dcc0d65b5a0e35
prev_chunk_id: chunk-0049
next_chunk_id: chunk-0051
section_heading: **The Cube I/O**
document_type: specification

**Table — Part 1 of 5 (continued)**
| Pin Number | Name                          | I/O | Description                                                             |
| ---------- | ----------------------------- | --- | ----------------------------------------------------------------------- |
| 1          | FMU_SWDIO                    | I/O | FMU serial wire debug I/O                                               |
| 2          | FMU_LED_AMBER               | O   | Boot error LED (drive only, controlled by FET)                          |
| 3          | FMU_SWCLK                    | O   | FMU serial wire debug clock                                             |
| 4          | I2C_2_SDA                   | I/O | I2C Serial Data Tx/Rx                                                   |
| 5          | EXTERN_CS                    | O   | Chip select for external SPI (NC, just for debugging)                   |
| 6          | I2C_2_SCL                   | O   | I2C Serial Clock Signal                                                 |
| 7          | FMU_!RESET                   | I   | Reset pin for the FMU                                                   |
| 8          | PROT_SPARE_1                |     | Spare                                                                   |
| 9          | VDD_SERVO_IN                | I   | Power for last resort I/O failsafe                                      |
| 10         | PROT_SPARE_2                |     | Spare                                                                   |
| 11         | EXTERN_DRDY                  | I   | Interrupt pin for external SPI (NC, just for debugging)                 |
| 12         | SERIAL_5_RX                 | I   | UART 5 RX (Receive Data)                                                |
| 13         | GND                           |     | System GND                                                              |
| 14         | SERIAL_5_TX                 | O   | UART 5 TX (Transmit Data)                                               |
| 15         | GND                           |     | System GND                                                              |
| 16         | SERIAL_4_RX                 | I   | UART 4 RX (Receive Data)                                                |
| 17         | SAFETY                        |     | Safety button input                                                     |
| 18         | SERIAL_4_TX                 | O   | UART 4 TX (Transmit Data)                                               |

--- chunk_id: chunk-0051
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 352
content_hash: d0194a710c514adf
prev_chunk_id: chunk-0050
next_chunk_id: chunk-0052
section_heading: **The Cube I/O**
document_type: specification

**Table — Part 2 of 5 (continued)**
| Pin Number | Name                          | I/O | Description                                                             |
| ---------- | ----------------------------- | --- | ----------------------------------------------------------------------- |
| 19         | VDD_3V3_SPEKTRUM_EN        | O   | Enable for the Spektrum voltage regulator                               |
| 20         | SERIAL_3_RX                 | I   | UART 3 RX (Receive Data)                                                |
| 21         | PRESSURE_SENS_IN            | AI  | Analogue Signal port, for pressure sensor, Laser range finder, or Sonar |
| 22         | SERIAL_3_TX                 | O   | UART 3 TX (Transmit Data)                                               |
| 23         | AUX_BATT_VOLTAGE_SENS      | AI  | Voltage sense for Aux battery input                                     |
| 24         | ALARM                         | O   | Buzzer PWM Signal                                                       |
| 25         | AUX_BATT_CURRENT_SENS      | AI  | Current sense for Aux battery input                                     |
| 26         | IO_VDD_3V3                  | I   | IO chip power, pinned through for debug                                 |
| 27         | VDD_5V_PERIPH_EN           | O   | Enable voltage supply for Peripherals                                   |
| 28         | IO_LED_SAFET_PROT          | O   | IO-LED_SAFETY (safety LED) pinned out for IRIS                         |
| 29         | VBUS                          | I   | USB VBus (VDD)                                                          |
| 30         | SERIAL_2_RTS                |     | UART 2 RTS (Request To Send)                                            |
| 31         | OTG_DP1                      | I/O | USB Data+ (D)                                                           |
| 32         | SERIAL_2_CTS                |     | UART 2 CTS (Clear To Send)                                              |
| 33         | OTG_DM1                      | I/O | USB Data- (M)                                                           |
| 34         | SERIAL_2_RX                 | I   | UART 2 RX (Receive Data)                                                |
| 35         | I2C_1_SDA                   | I/O | I2C Serial Data Tx/Rx                                                   |
| 36         | SERIAL_2_TX                 | O   | UART 2 TX (Transmit Data)                                               |

--- chunk_id: chunk-0052
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 353
content_hash: 2103cb396cf8c226
prev_chunk_id: chunk-0051
next_chunk_id: chunk-0053
section_heading: **The Cube I/O**
document_type: specification

**Table — Part 3 of 5 (continued)**
| Pin Number | Name                          | I/O | Description                                                             |
| ---------- | ----------------------------- | --- | ----------------------------------------------------------------------- |
| 37         | I2C_1_SCL                   | O   | I2C Serial Clock Signal                                                 |
| 38         | SERIAL_1_RX                 | I   | UART 1 RX (Receive Data)                                                |
| 39         | CAN_L_2                     | I/O | FMU CAN bus Low Signal Driver                                           |
| 40         | SERIAL_1_TX                 | O   | UART 1 TX (Transmit Data)                                               |
| 41         | CAN_H_2                     | I/O | FMU CAN bus High Signal Driver                                          |
| 42         | SERIAL_1_RTS                |     | UART 1 RTS (Request To Send)                                            |
| 43         | VDD_5V_PERIPH_OC           | I   | Error state message  from Peripheral power supply                       |
| 44         | SERIAL_1_CTS                |     | UART 1 CTS (Clear To Send)                                              |
| 45         | VDD_5V_HIPOWER_OC          | I   | Error state message  from High power Peripheral power supply            |
| 46         | IO_USART_1_TX              | O   | I/O USART 1 TX                                                          |
| 47         | BATT_VOLTAGE_SENS_PROT     | AI  | Voltage sense from main battery                                         |
| 48         | IO_USART1_RX_SPECTRUM_DSM | O   | Signal from Spectrum receiver                                           |
| 49         | BATT_CURRENT_SENS_PROT     | AI  | Current sense from main battery                                         |
| 50         | FMU_CH1_PROT                | O   | FMU PWM output channel 1                                                |
| 51         | SPI_EXT_MOSI                | O   | External SPI, for debug only                                            |
| 52         | FMU_CH2_PROT                | O   | FMU PWM output channel 2                                                |
| 53         | VDD_SERVO                    | I   | VDD_Servo, for monitoring servo bus                                    |
| 54         | FMU_CH3_PROT                | O   | FMU PWM Output Channel 3                                                |

--- chunk_id: chunk-0053
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 344
content_hash: 09c223d157bffb97
prev_chunk_id: chunk-0052
next_chunk_id: chunk-0054
section_heading: **The Cube I/O**
document_type: specification

**Table — Part 4 of 5 (continued)**
| Pin Number | Name                          | I/O | Description                                                             |
| ---------- | ----------------------------- | --- | ----------------------------------------------------------------------- |
| 55         | VDD_BRICK_VALID             | I   | Main Power valid signal                                                 |
| 56         | FMU_CH4_PROT                | O   | FMU PWM Output Channel 4                                                |
| 57         | VDD_BACKUP_VALID            | I   | Backup Power valid Signal                                               |
| 58         | FMU_CH5_PROT                | O   | FMU PWM Output Channel 5                                                |
| 59         | VBUS_VALID                   | I   | USB bus valid signal                                                    |
| 60         | FMU_CH6_PROT                | O   | FMU PWM Output Channel 6                                                |
| 61         | VDD_5V_IN_PROT             | I   | Main power (5V) into FMU from power selection                           |
| 62         | PPM_SBUS_PROT               | I   | PPM / S.Bus Signal Input                                                |
| 63         | VDD_5V_IN_PROT             | I   | Main power (5V) into FMU from power selection                           |
| 64         | S.BUS_OUT                    | O   | S.Bus Signal Output                                                     |
| 65         | IO_VDD_5V5                  | O   | IO VDD 5.5 V                                                            |
| 66         | IO_CH8_PROT                 | O   | I/O PWM Output Channel 8                                                |
| 67         | SPI_EXT_MISO                | I   | External SPI, for Debug only                                            |
| 68         | IO_CH7_PROT                 | O   | I/O PWM Channel 7                                                       |
| 69         | IO_SWDIO                     | I/O | I/O serial wire debug                                                   |
| 70         | IO_CH6_PROT                 | O   | I/O PWM Output Channel 6                                                |
| 71         | IO_SWCLK                     | O   | I/O Serial Wire Debug Clock                                             |
| 72         | IO_CH5_PROT                 | O   | I/O PWM Output Channel 5                                                |

--- chunk_id: chunk-0054
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: e79b13f18080d2c8
prev_chunk_id: chunk-0053
next_chunk_id: chunk-0055
section_heading: **The Cube I/O**
document_type: specification

**Table — Part 5 of 5 (continued)**
| Pin Number | Name                          | I/O | Description                                                             |
| ---------- | ----------------------------- | --- | ----------------------------------------------------------------------- |
| 73         | SPI_EXT_SCK                 | O   | External SPI, for Debug only                                            |
| 74         | IO_CH4_PROT                 | O   | I/O PWM Output Channel 4                                                |
| 75         | IO_!RESET                    | I   | I/O Reset Pin                                                           |
| 76         | IO_CH3_PROT                 | O   | I/O PWM Output Channel 3                                                |
| 77         | CAN_L_1                     | I/O | FMU CAN bus Low Signal Driver                                           |
| 78         | IO_CH2_PROT                 | O   | I/O PWM Output Channel 2                                                |
| 79         | CAN_H_1                     | I/O | FMU CAN bus High Signal Driver                                          |
| 80         | IO_CH1_PROT                 | O   | I/O PWM Output Channel 1                                                |

--- chunk_id: chunk-0055
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: b9d5438efb16dbfc
prev_chunk_id: chunk-0054
next_chunk_id: chunk-0056
section_heading: **The Cube I/O**
document_type: specification

#### **Back Edge (can be rearranged in accordance with PCB layout) | Port：`RCIN`** **`MAIN OUT`** **`AUX OUT`**
#### **SERVO HEADER (0.1”, 1/1/15 power layout)** | Pin Number | Name            | I/O    | Voltage                              | Wire Colour | Description        |
| ---------- | --------------- | ------ | ------------------------------------ | ----------- | ------------------ |
| S - 1      | FMU_CH1_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 2      | FMU_CH2_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 3      | FMU_CH3_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 4      | FMU_CH4_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 5      | FMU_CH5_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 6      | FMU_CH6_PROT  | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 7      | IO_CH1_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 8      | IO_CH2_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 9      | IO_CH3_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 10     | IO_CH4_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 11     | IO_CH5_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 12     | IO_CH6_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 13     | IO_CH7_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 14     | IO_CH8_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power |             | PWM Signal         |
| S - 15     | PPM_SBUS_PROT | IN/OUT | 3.3 V / 4.5 V Powered                |             | PPM / S.Bus Signal | #### **The Cube 80-pin DF17 Connector (long term standard)**

--- chunk_id: chunk-0056
source_document: interface-specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 601
content_hash: 49d3cf1ce03d8a4a
prev_chunk_id: chunk-0055
next_chunk_id: chunk-0057
section_heading: Differences between the Colored Cubes
document_type: specification

## Differences between the Colored Cubes | The Cube Series | Cube Orange+ | Cube Orange | Cube Blue H7 | Cube Purple H7 | Cube Yellow | Cube Black+ | Cube Black | Cube Green | Cube Blue | Cube Purple F4 |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| The Cube | Cube Orange+ | Cube Orange | Cube Blue H7 | Cube Purple H7 | Cube Yellow | Cube Black+ | Cube Black | Cube Green | Cube Blue | Cube Purple F4 |  |
| Processor | STM32H757 | STM32H753 | STM32H753 | STM32H753 | STM32F777 | STM32F427 V3 | STM32F427 V3 | STM32F427 V3 | STM32F427 V3 | STM32F427 V3 |  |
| Remote Signal | PPM/SBUS/DSM | PPM/SBUS/DSM | PPM/SBUS/DSM | PPM/SBUS/DSM | PPM/SBUS/DSM | PPM/SBUS/DSM | PPM/SBUS/DSM | PPM/SBUS/DSM | PPM/SBUS/DSM | PPM/SBUS/DSM |  |
| I/O PWN Voltage | 3.3V/5V software selectable | 3.3V/5V software selectable | 3.3V/5V software selectable | 3.3V/5V software selectable | 3.3V/5V software selectable | 3.3V | 3.3V | 5.4v | 3.3V | 3.3V |  |
| Redundancy | Triple Redundancy | Triple Redundancy | Triple Redundancy | N/A | Triple Redundancy | Triple Redundancy | Triple Redundancy | Triple Redundancy | Triple Redundancy | N/A |  |
| Isolation System | Y | Y | Y | N | Y | Y | Y | Y | Y | N |  |
| Temp Regulator | Y | Y | Y | N | Y | Y | Y | Y | Y | N |  |
| Number of Accelerometers | Three | Three | 3 | 1 | 3 | 3 | 3 | 3 | 3 | 1 |  |
| Number of Gyroscopes | Three | Three | 3 | 1 | 3 | 3 | 3 | 3 | 3 | 1 |  |
| Number of Magnetometers | One | One | 1 | N/A | 1 | 2 | 3 | 3 | 3 | 1 |  |
| Number of Barometers | Two | Two | 2 | 1 | 2 | 2 | 2 | 2 | 2 | 1 |  |
| Manufacturing Origin | Taiwan | Taiwan | U.S.A | Taiwan | Taiwan | Taiwan | Taiwan | Taiwan | U.S.A | Taiwan |  |
| Product Lifecycle | Available | Available | Available | Available | Available | EOL Use Cube Orange | EOL Use Cube Orange | EOL Use Cube Orange | EOL Use Cube Blue H7 | EOL Use Cube Purple H7 |  |

--- chunk_id: chunk-0057
source_document: power-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: aa5e616553159fff
prev_chunk_id: chunk-0056
next_chunk_id: chunk-0058
section_heading: Power Architecture
document_type: technical_reference

# Power Architecture

The Cube has removed the power management from the FMU. Thus, the servo rail is no longer the primary backup power source for the FMU. It remains there as a failsafe for I/O functions. ### Power Management Module (separate from the FMU)

Key features of The Cube power architecture:

* Single, independent 5V supply for the flight controller and peripherals. * Integration with two power bricks or compatible alternatives, including current and voltage sensing. * Low power consumption and heat dissipation. * Power distribution and monitoring for peripheral devices. * Protection against common wiring faults; under/over-voltage protection, overcurrent protection, and thermal protection. * Brown-out resilience and detection. ### FMU and I/O Power Supplies

Both the FMU and I/O operate at 3.3V, where each has its private dual-channel regulator. As in The Cube, each regulator features a power-on reset output tied to the regulator’s internal power-up and drop-out sequencing. ### Power Sources

Power may be supplied to The Cube via USB, the power brick port, or the second brick port. Each power source is protected against reverse-polarity connections and back-powering from other sources. Cube F4 series

* FMU + IO power budget, which includes all the LEDs and the Piezo buzzer, is 450mA. *  The total peripheral power is limited to 2.5A. Cube F7 and H7 series

* FMU + IO power budget, which includes all LEDs and the Piezo buzzer, is 550mA. * Peripheral power is limited to 2.5A. **Cube Orange**

* The power budget increase is due to the improved heater. > USB is not recommended in flight on Nuttx code. ### Power Brick Port

The brick port is the preferred power source for The Cube. It will be selected by default when available. ### Servo Power

The Cube supports both standard (5V) and high-voltage (up to 10V) servo power with some restrictions. The I/O will accept power from the servo connector reaching up to 10V. This allows the I/O to failover to servo power when the main power supply is lost or interrupted. > The FMU and peripherals will not accept power from the servo connector. ### Aux Power

The Cube backup power port is configured the same as the primary power input. When the input voltage exceeds 5.7V, the power is locked out.

--- chunk_id: chunk-0058
source_document: power-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 489
content_hash: 5de568ab65da2883
prev_chunk_id: chunk-0057
next_chunk_id: chunk-0059
section_heading: Power Architecture
document_type: technical_reference

### Aux Power

The Cube backup power port is configured the same as the primary power input. When the input voltage exceeds 5.7V, the power is locked out. The Cube and its peripherals may draw up to 2.75A in total when operating on Aux power, provided that the Brick or other power source can supply the required current. > The Cube never supplies power to the servos. ### Servo Rail

The I/O chip can draw power reaching up to 10.5V from the servo rail. The servo rail can be used to revert to manual mode when the other two main power sources fail. This is only useful for planes and when the I/O chip has been mapped correctly. ### USB Power

USB power can be used for software updates, testing, and development purposes. It can also be supplied to the peripheral ports for testing. However, the total current consumption (including the peripherals) must typically be limited to 500mA to avoid overloading the host USB port. ### Multiple Power Sources

When more than one power source is connected, The Cube will draw power from the highest-priority source with a valid input voltage. In most cases, the FMU should be powered by the power brick or a compatible off-board regulator via the brick port or auxiliary power rail. For desktop testing scenarios, power drawn from the USB avoids the need for a BEC or similar servo power source. However, the servos themselves will still require external power. ### Input Voltage Range

The input voltage range that each component can accept is shown below. |                 | **Brick port**   | **Aux port**     | **USB port**     | **Servo rail** |
| --------------- | ---------------- | ---------------- | ---------------- | -------------- |
| **FMU**         | 4 - 5.7V         | 4 - 5.7V         | 4 - 5.7V         | NIL            |
| **I/O**         | 4 - 5.7V         | 4 - 5.7V         | 4 - 5.7V         | 4 - 10.5V      |
| **Peripherals** | 4 - 5.7 2.5A max | 4 - 5.7 2.5A max | 4 - 5.7 2.5A max | NIL            | ### Power Management Peripherals

The Cube provides power routing, over/under voltage detection and protection, filtering, switching, current-limiting and transient suppression for peripherals.

--- chunk_id: chunk-0059
source_document: power-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: c831638f329ea387
prev_chunk_id: chunk-0058
next_chunk_id: chunk-0060
section_heading: Power Architecture
document_type: technical_reference

|                 | **Brick port**   | **Aux port**     | **USB port**     | **Servo rail** |
| --------------- | ---------------- | ---------------- | ---------------- | -------------- |
| **FMU**         | 4 - 5.7V         | 4 - 5.7V         | 4 - 5.7V         | NIL            |
| **I/O**         | 4 - 5.7V         | 4 - 5.7V         | 4 - 5.7V         | 4 - 10.5V      |
| **Peripherals** | 4 - 5.7 2.5A max | 4 - 5.7 2.5A max | 4 - 5.7 2.5A max | NIL            | ### Power Management Peripherals

The Cube provides power routing, over/under voltage detection and protection, filtering, switching, current-limiting and transient suppression for peripherals. Power outputs to peripherals feature ESD and EMI filtering, which ensures that no more than 5.5V is supplied to the peripheral devices. Power is disconnected from the peripherals when the following occurs:

* Available supply voltage falls below 2.7V
* Available supply voltage rises above approximately 5.7V. ### Peripheral Power Groups

The peripheral power is divided into two groups:

**Serial 1** (TELEM 1) has a private 1.5A current limit intended for powering low-power peripherals. This output has separate EMI filtering and draws power directly from the USB or Brick inputs. The peak power drawn from this port should not exceed 1.5A. > Never power the telemetry from this port under any circumstances. All other peripherals share a 1A current limit and a single power switch. The peak power drawn from this port should not exceed 1.5A. Each group is individually switched by software control. ### Spektrum/DSM R/C Interface

The Spektrum/DSM R/C interface draws power from its own regulator, and not from the two peripheral groups mentioned above. This port is switched by software control, allowing Spektrum/DSM binding to be implemented. Spektrum receivers generally draw roughly 25mA. ### S.Bus and CPPM Receivers

S.Bus and CPPM receivers are powered by a dedicated power supply. > Do not connect any servos to this power supply. It only provides power to the RX. ### Capacitor Backup

Both the FMU and I/O microcontrollers feature capacitor-backed real-time clocks and SRAM. The on-board backup capacitor has sufficient capacity to allow orderly recovery from unintended power loss or in-air restarts. The capacitors can be recharged from the FMU 3.3V rail if software is included to support this feature.

--- chunk_id: chunk-0060
source_document: power-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 325
content_hash: 8cf267cdbc4ac6eb
prev_chunk_id: chunk-0059
next_chunk_id: chunk-0061
section_heading: Power Architecture
document_type: technical_reference

The on-board backup capacitor has sufficient capacity to allow orderly recovery from unintended power loss or in-air restarts. The capacitors can be recharged from the FMU 3.3V rail if software is included to support this feature. ### Voltage, Current, and Fault Sensing

The battery voltage and current reported by both bricks can be measured by the FMU. In addition, the 5V unregulated supply rail can be measured (to detect brown-out conditions). The I/O can measure the servo power rail voltage. Over-current conditions on the peripheral power ports can be detected by the FMU. Hardware lock-out prevents damage due to persistent short circuits on these ports. The lock-out can be reset by the FMU software. The under/over voltage supervisor for the FMU provides an output that is used to hold the FMU in reset during brown-out events. ### EMI Filtering and Transient Protection (applies to the normal base board)

EMI filtering is provided at key areas in the system using high-insertion-loss pass-through filters. These filters are paired with TVS diodes at the peripheral connectors to suppress power transients. Reverse polarity protection is provided at each of the power inputs. USB signals are filtered and terminated with a combined termination/TVS array. Most digital peripheral signals (all PWM outputs, serial ports, and I2C ports) are driven using ESD-enhanced buffers and have series blocking resistors to reduce the risk of damage from transients or misconnections. > Ensure adequate ESD protection is provided to the externally supplied base boards.

--- chunk_id: chunk-0061
source_document: specifications.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 445
content_hash: 5230780e3c056ff8
prev_chunk_id: chunk-0060
next_chunk_id: chunk-0062
section_heading: Specifications
document_type: specification

# Specifications

The following shows the key specifications of The Cube. **Three IMUs (applies to all The Cubes)**

* Two on the IMU board. *  One fixed on the FMU. **Two onboard compasses** (**Cube Black**, **Cube Green**, and **Cube Blue**)

* One on the IMU board. * One fixed on the FMU. **One onboard compass** (**Cube Orange** and **Cube Yellow**)

**Two Barometers (applies to all The Cubes)**

* One on the IMU. * One on the FMU. **Dual Power Input (applies to all The Cubes)**

* Redundancy option from the servo rail removed and replaced with a dedicated second power plug. * A dedicated power protection Zener diode and Fet added for protection against voltages over 5.6V being applied to Aux input 2. * Available only on the "PRO" carrier board. The mini carrier board still draws the backup power from the servo rail. **Dual External I2C (applies to all The Cubes)**

* Allows connection to either I2C port, potentially allowing two GPS/Mag units to be plugged in without the Mags conflicting. **Power Monitoring (applies to all The Cubes)**

* Power monitoring pins are routed to the I/O chip. This allows power event logging during an inflight reboot. * Brick OK, Backup OK, and FMU 3.3V are all connected to a digital pin on the I/O via a 220Ohm resister. **I/O Ports (applies to all The Cubes excluding the CAN Bus interface)**

* 14 PWM servo outputs (eight from I/O and six from FMU). * R/C inputs for CPPM, Spektrum/DSM, and S.Bus. * Analog/PWM RSSI input. * S.Bus servo output. * Five general-purpose serial ports; two with full flow control. * Two I2C ports. * One SPI port (un-buffered, not recommended for use as it is only for short cables). * Two CAN Bus interfaces. > The **Cube BlueH7** and **Cube Orange** are equipped with the CAN FD interface. * Three analog inputs. * High-powered piezo buzzer driver on expansion board. * High-power RGB LED (I2C driver compatible; only connected externally). * Safety switch/LED.

--- chunk_id: chunk-0062
source_document: system-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: b789d37d626c3a4a
prev_chunk_id: chunk-0061
next_chunk_id: chunk-0063
section_heading: System Architecture
document_type: technical_reference

# System Architecture

The Cube system architecture incorporates two functional blocks into a single physical module. ![](/files/-LjxsTdhKg9DDaaJvR6v)

### PWM Outputs

Eight PWM outputs are connected to the I/O. * Can be directly controlled by the I/O via the R/C input and onboard mixing even if the FMU is not active (failsafe/manual mode). * Supports multiple update rates in three groups (one group of four outputs and two groups of two outputs). * Supports signal rates reaching up to 400Hz. * Output only. * Each PWM output can drive up to 50mA, but the total limit for all eight outputs is 100mA. Six PWM outputs are connected to the FMU. * Supports reduced update latency. * Cannot be controlled by the I/O in failsafe conditions. * Supports multiple update rates in two groups (one group of four and one group of two). All the PWM outputs are EDS-protected and are designed to survive accidental servo misconnection without damage. The servo drivers are specified to drive a 50pF servo input load over 2m of 26AWG servo cable. The I/O PWM outputs can also be configured as individual GPIOs. > The I/O PWM outputs are not high-power outputs. The PWM drivers are only designed to drive servos and similar logic inputs and do not include relays or LEDs. ### Peripheral Ports

All peripherals are connected through a single 80-pin connector. The peripherals are connected via a baseboard that can be customized for each application. ### Base Board

The initial base board features separate the connectors for each of the peripheral ports, but with a few exceptions. #### Serial Ports

* Five serial ports are provided. * The serial ports operate at a 3.3V CMOS logic level. They are 5V tolerant, buffered, and ESD-protected. * Serial 1 and 2 feature full flow control. * Serial 3 is recommended to function as a GPS port. A safety button and possibly a safety LED are included. An I2C for the compass and RGB LED is also provided. * Serial 4 has an I2C on the second bus, allowing two compass modules to be connected simultaneously. * Serial 5 is available as a header underneath the board. It is used for the onboard ADSB-IN receiver that is featured on newer carrier boards. #### SPI Port

* Not buffered. Should only be used with short cable runs.

--- chunk_id: chunk-0063
source_document: system-architecture.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: 7804c904dd408534
prev_chunk_id: chunk-0062
next_chunk_id: chunk-0064
section_heading: System Architecture
document_type: technical_reference

#### SPI Port

* Not buffered. Should only be used with short cable runs. * Signals are 3.3V CMOS logic level, but 5V tolerant. * SPI is only available to test points on the first base board, along with a CS and INT pin. #### Analog Inputs

* Analogue 1-3 are protected against inputs up to 12V, but scaled for 0-3.3V inputs. * The RSSI input supports either PWM or analog RSSI. As this input shares a pin with the S.Bus output, only one of them may be connected at a time. #### CPPM, S.Bus and DSM/Spektrum Input

These inputs remain unchanged from the previous versions. #### CAN Ports

The CAN ports are standard CAN Bus. Termination for one end of the bus is fixed on board. The drivers are onboard the FMU. #### Piezo Port

The piezo port drives most piezo elements in the 5 - 300nF range at up to 35V. It is extremely loud, where the achievable sound pressure level is limited by the sensitivity of the piezo element being driven. #### I2C

I2C is direct driven, un-buffered, and pulled up to 3.3v onboard the FMU. ### Sensors

All flight sensors in The Cube are connected via SPI. | Cube Type                                                                                                                                                                                                          | Life Cycle | IMU1                | IMU2                                 | IMU3                | Barometer1 | Barometer2 |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------- | ------------------- | ------------------------------------ | ------------------- | ---------- | ---------- |
| Cube Black Cube BlueF4 Cube Green                                       | EOL        | MPU9250             | LSM303D/L3GD20                       | MPU9250             | MS5611     | MS6511     |
| **Cube Black+**                                                                                                                                                                                                    | EOL        | MPU9250             | ICM20602                             | ICM20948            | MS5611     | MS5611     |
| **Cube PurpleF4**                                                                                                                                                                                                  | EOL        | MPU9250             | NA                                   | NA                  | MS5611     | NA         |
| **CubePurpleH7**                                                                                                                                                                | ACTIVE     | ICM20649            | NA                                   | NA                  | MS5611     | NA         |
| Cube Orange Cube Yellow Cube BlueH7 | ACTIVE     | ICM20649            | ICM20602                             | ICM20948            | MS5611     | MS5611     |
| **Cube Orange+**                                                                                                                                                                | ACTIVE     | ICM45686 / ICM20649 | ICM20948 / ICM42688 / ICM45686_EXT2 | ICM42688 / ICM45686 | MS5611     | MS5611     | > * IMU1 and IMU2 are isolated. * IMU3 is not isolated. * Data-ready signals from any of the sensors are **NOT ROUTED on the Isolated IMU.**

--- chunk_id: chunk-0064
source_document: the-cube-operating-conditions-and-performance.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 158
content_hash: 84ee8a376a9a88f6
prev_chunk_id: chunk-0063
next_chunk_id: chunk-0065
section_heading: The Cube Operating Conditions and Performance
document_type: technical_reference

# The Cube Operating Conditions and Performance | **Parameter**                                      | **Description**                                                                                                                                                                                                        |
| -------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Power Input Voltage / Max Current                  | 4.1V \~ 5.5V/350mA when 5V input                                                                                                                                                                                       |
| Waterproof Performance                             | Not waterproof. External waterproof protection is needed                                                                                                                                                               |
| Ideal Operating Temperature                        | -10°C \~ 55°C                                                                                                                                                                                                          |
| Maximum Operating Temperature during Emergencies   | 100°C                                                                                                                                                                                                                  |
| Minimum Temperature Tested for Storage             | -70°C                                                                                                                                                                                                                  |
| Maximum Temperature Tested and Rebooted (survived) | 120°C                                                                                                                                                                                                                  |
| Minimum Temperature for Power On                   | Approximately -40°C\~-50°C Be cautious of condensation when using in freezing conditions. It is strongly recommended to preheat the module first to ensure the system operates within an acceptable temperature range. |

--- chunk_id: chunk-0065
source_document: vibration-damped-imu-board-versions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 134
content_hash: c5084a00770c95db
prev_chunk_id: chunk-0064
next_chunk_id: chunk-0066
section_heading: Vibration Damped IMU Board Versions
document_type: technical_reference

# Vibration Damped IMU Board Versions

The following introduces the different vibration damped IMU board versions. ### Version 1 (found in the Cube Black, Cube BlueF4, or Cube Green)

* LSM303D integrated accelerometer/magnetometer. * L3GD20 gyroscope. * MPU9250 gyroscope/accelerometer. * MS5611 barometer. * All sensors connected via SPI. ### Version 2 (found in the Cube Orange, Cube BlueH7 or Cube Yellow)

* ICM20602. * ICM 20948. * MS5611 barometer. * All sensors connected via SPI. ### Version 3 (found in the Cube Orange+)

* ICM45686/ICM20649. * ICM20948/ICM42688 / ICM45686_EXT2 . * ICM42688/ICM45686. * MS5611 barometer. * All sensors connected via SPI.

--- chunk_id: chunk-0066
source_document: introduction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 26
content_hash: f1584a58cc878c9d
prev_chunk_id: chunk-0065
next_chunk_id: chunk-0067
section_heading: Introduction
document_type: technical_reference

# Introduction

The following sections provide an overview of The Cube and highlight the key features of each colored cube.

--- chunk_id: chunk-0067
source_document: mandatory-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 41
content_hash: bc4c4200c51ccacf
prev_chunk_id: chunk-0066
next_chunk_id: chunk-0068
section_heading: Mandatory Hardware Basic Configuration
document_type: technical_reference

# Mandatory Hardware Basic Configuration

The following section explains the basic configurations that need to be made on the mandatory hardware. For more advanced configurations, refer to the ArduPilot documentation: .

--- chunk_id: chunk-0068
source_document: mandatory-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: d0fd5944ca4f02de
prev_chunk_id: chunk-0067
next_chunk_id: chunk-0069
section_heading: Calibrating the Accelerometer
document_type: technical_reference

## Calibrating the Accelerometer

To calibrate the accelerometer, complete the following steps:

1. Open Mission Planner. 2. Click **Setup ->** **Mandatory Hardware ->** **Accel Calibration**. 3. Click **Calibrate Accel**. 4. Place the unmanned aerial vehicle (UAV) level to the ground; then, click **Click when Done**. ![](/files/-LvseJ2PTQG5mddfvV5F)

5. Place the UAV with the nose pointing to the front and the left side touching the ground; then, click **Click when Done**. ![](/files/-Lvsf_0GcWqPNmwycYNs)

6. Place the UAV with the nose pointing to the back and the right side touching the ground; then, click **Click when Done**. 7. Place the UAV with the nose touching the ground; then, click **Click when Done**. ![](/files/-Lvsg6efnCVBAu8XYSeS)

8. Place the UAV with the nose pointing upward; then, click **Click when Done**. ![](/files/-LvsgX8FWk9Nz0kxe727)

9. Place the UAV with the nose pointing downwards; then, click **Click when Done**. ![](/files/-Lvsgp2ymn9MHs4-DGXV)

10. Verify that "**Calibration successful**" is shown. For more details on how to minimize the magnetic interference and improve the compass performance, refer to [http://ardupilot.org/copter/docs/common-magnetic-interference.html#common-magnetic-interference](https://ardupilot.org/copter/docs/common-magnetic-interference.html#common-magnetic-interference)

--- chunk_id: chunk-0069
source_document: mandatory-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 318
content_hash: 5ddc7025dadf9f62
prev_chunk_id: chunk-0068
next_chunk_id: chunk-0070
section_heading: Calibrating the Accelerometer Level
document_type: technical_reference

## Calibrating the Accelerometer Level

To calibrate the accelerometer level, complete the following steps:

1. Open Mission Planner. 2. Click **Setup** -> **Mandatory Hardware** -> **Accel Calibration**. 3. Place the vehicle level to the ground and click **Calibrate Level**. 4. Verify that "**Completed**" is shown. ### Calibrating the Accelerometer Scale Factors
To calibrate the accelerometer scale factors, complete the following steps:

1. Click **Setup** -> **Mandatory Hardware** -> **Accel Calibration.**
2. Place the vehicle level to the ground and click **Simple Accel Cal**. 3. Verify that "**Completed**" is shown. ### Calibrating the Compass
To calibrate the compass, complete the following steps:

1. Click **Setup** -> **Mandatory Hardware** -> **Compass.**
2. Select the priority for the three different compasses by clicking the up and down arrows. 3. Click **Start** to calibrate the compasses. 4. Hold the UAV in the air and slowly rotate it so that each side—front, back, left, right, top, and bottom—faces the ground for a few seconds. As the UAV is rotated, the green bars on the display begin to extend to the right. 5. Continue rotating the UAV until "**Success"** is shown. A rising tone will be emitted. 7. When the “**Please reboot the autopilot**” window appears, click **OK**. The autopilot needs to be rebooted before the UAV can be armed. ![](/files/-LvsjQyT5au3FSHTrFl5)

> If the compass cannot be calibrated, click **Cancel.** Then, click the **Fitness** drop-down menu and select a more relaxed setting to try again.

--- chunk_id: chunk-0070
source_document: mandatory-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: 460ca21d12e6bf31
prev_chunk_id: chunk-0069
next_chunk_id: chunk-0071
section_heading: Calibrating the Radio Control
document_type: technical_reference

## Calibrating the Radio Control

To calibrate the radio control, complete the following steps:

1. Open Mission Planner. 2. Click **Setup** -> **Mandatory Hardware** -> **Radio Calibration**. 3. Connect the RC receiver to the RCIN port on The Cube and turn on the RC transmitter. 4. Verify that the receiver displays a solid green light, which indicates a successful connection with the transmitter, and ensure the transmitter is set to the correct UAV. 5. Verify that the green bars move when adjusting the transmitter sticks. 6. When completed, click **Click when Done**. ### Calibrating the Electronic Speed Controller (ESC)
To calibrate the ESC, complete the following steps:

> Before calibrating the ESC, ensure the following: * No props on the UAV. * The Cube is not connected to the GCS via a USB cable. * The LiPo battery is disconnected. 1. Turn on the transmitter and adjust the throttle stick to maximum. 2. Connect the LiPo battery to the power module. When connected, The Cube's red, blue, and yellow LEDs will light up in a cyclical pattern. 3. With the transmitter throttle stick still adjusted to high, disconnect and reconnect the battery. 4. Press and hold the safety button until it displays a solid red color. The autopilot is now in ESC calibration mode. The red and blue LEDs will blink on and off. 5. Wait for the ESCs to emit a musical tone -> a series of beeps indicating the battery cell count (e.g., 3 beeps for 3S, 4 beeps for 4S), followed by two additional beeps to confirm maximum throttle capture. 6. Adjust the transmitter’s throttle stick to minimum. The ESCs will emit a long tone indicating the minimum throttle has been captured and the calibration is complete. 7. Verify a long tone is emitted, which indicates the ESCs are “live” now. 8. Test if the motors can spin by slightly raising the throttle and then lowering it. 9. Set the throttle to minimum and disconnect the battery to exit the ESC-calibration mode.

--- chunk_id: chunk-0071
source_document: mandatory-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 622
content_hash: 968795aeb5535006
prev_chunk_id: chunk-0070
next_chunk_id: chunk-0072
section_heading: Configuring the Flight Mode
document_type: technical_reference

## Configuring the Flight Mode

The flight mode channel (default is channel 5) is the input radio channel that ArduPilot monitors for mode changes. To change the channel number, complete the following steps:

1. Open Mission Planner. 2. Click **Config** -> **Full Parameter List**
3. Adjust the FLTMODE-CH parameter. To configure the flight mode, complete the following steps:

1. Open Mission Planner. 2. Click **Setup** -> **Flight Modes**. 3. Toggle the corresponding button to the desired flight mode position. 4. Move the transmitter’s flight mode switch and observe the green bar moving to a new position. 5. When finished, click **Save**. A total of six autopilot/flight modes can be enabled from the RC transmitter. See below for a brief description of the different flight modes. For a more detailed explanation, refer to the ArduPilot documentation:

*
* | **Manual**                                                                                        | **Circle**                                                                                     | **Stabilize**                                                                  |
| ------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------ |
| Manual control surface movement, passthrough                                                      | Automatically circles a point in front of the UAV.                                             | Self-levels the roll and pitch axis.                                           |
| **Training**                                                                                      | **Acro**                                                                                       | **FBWA**                                                                       |
| Manual control up to roll and pitch limits                                                        | Holds attitude, no self-level.                                                                 | Roll and pitch follow stick input, up to set limits                            |
| **FBWB**                                                                                          | **Cruise**                                                                                     | **Autotune**                                                                   |
| Like FBWA, but with automatic height and speed control                                            | Like FBWB, but with ground course tracking                                                     | Automated pitch and bank procedure to improve control loops                    |
| **Auto**                                                                                          | **RTL (Return to Launch)**                                                                     | **Loite**r                                                                     |
| Executes pre-defined mission                                                                      | Returns above takeoff location, may also include landing                                       | Holds altitude and position, uses GPS for movements                            |
| **Takeoff**                                                                                       | **Avoid ADSB**                                                                                 | **Guided**                                                                     |
| Automatic takeoff to specific altitude, and loiter at distance from takeoff until mode is changed | Avoid manned vehicles based on the ADS-B sensor's output.                                      | Navigates to single points commanded by GCS                                    |
| **Qstabilize**                                                                                    | **Qhover**                                                                                     | **Qloiter**                                                                    |
| Allows the UAV to be flownmanually, but self-levels the roll and pitch axis.                      | Maintains a consistent altitude while allowing roll, pitch, and yaw to be controlled normally. | Automatically attempts to maintain the current location, heading and altitude. |
| **Qland**                                                                                         | **QRTL**                                                                                       | **Qautotune**                                                                  |
| Attempts to bring the UAV straight down for landing.                                              | Navigates UAV from its current position to hover above the home position and then land.        | Supports autotuning PIDs.                                                      |
| **Qacro**                                                                                         | **Thermal**                                                                                    | **Loiter to Qland**                                                            |
| For advanced users that provides rate based stabilization.                                        | Mode entered to search for thermal lift by SOARING feature or manually if lift is encountered. | Performs a descending down action and then switches to QLand mode.             |
| **Initializing**                                                                                  |                                                                                                |                                                                                |
| Initializes the flight mode.                                                                      |                                                                                                |                                                                                |

--- chunk_id: chunk-0072
source_document: mandatory-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 78
content_hash: dc510c966802653d
prev_chunk_id: chunk-0071
next_chunk_id: chunk-0073
section_heading: Configuring the Servo Connection
document_type: technical_reference

## Configuring the Servo Connection

The servo rail is not powered by The Cube. Therefore, an external BEC or ESC that can provide 5V is needed. To configure the control channels for the servos, complete the following steps:

1. Open Mission Planner
2. Click **Setup** -> **Mandatory Hardware** -> **Servo Output**. 3. Adjust the parameters based on the requirements.

--- chunk_id: chunk-0073
source_document: optional-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 41
content_hash: 10cec053e8a2f73d
prev_chunk_id: chunk-0072
next_chunk_id: chunk-0074
section_heading: Optional Hardware Basic Configuration
document_type: technical_reference

# Optional Hardware Basic Configuration

The following section explains the basic configurations that need to be made on the optional hardware. For more advanced configurations, refer to the ArduPilot documentation: .

--- chunk_id: chunk-0074
source_document: optional-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 310
content_hash: 315f0a17edbc6a5b
prev_chunk_id: chunk-0073
next_chunk_id: chunk-0075
section_heading: Calibrating the Cube Power Module Voltage
document_type: technical_reference

## Calibrating the Cube Power Module Voltage

The power module inside The Cube package supports up to 8S voltage, 30A continuous current, and 100A burst current. If a higher load is needed, replace the power module with a higher current limit. ### Connecting the Power Module
To connect the power module, complete the following steps:

1. Connect the XT60 male connector to the battery (female on the other side for motors or ESC) and plug the JST connector into the POWER1 port on The Cube. 2. If necessary, connect the second battery to the POWER2 port on The Cube to monitor two batteries at the same time, as dual input redundant power is supported. ### Calibrating the Battery Monitor
To calibrate the Battery Monitor, complete the following steps:

1. Open Mission Planner. 2. Click **Setup** -> **Optional Hardware** -> **Battery Monitor**. 3. Connect The Cube to the power module and power it up. 4. Enter the properties the power module can measure, which include the module type, flight controller type, and battery capacity. Default parameters may return inaccurate voltage. When this happens, complete the following steps:

1. Use the following formula to calculate the correct Voltage Divider:

**Voltage Divider Value * Actual Battery Voltage/Voltage Measured by Power Module = Correct Voltage Divider Value**

2. Enter the new Voltage Divider value and reboot the flight controller. 3. Verify if the measured voltage is accurate.

--- chunk_id: chunk-0075
source_document: optional-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 210
content_hash: 1cc9bb76003c4409
prev_chunk_id: chunk-0074
next_chunk_id: chunk-0076
section_heading: Calibrating Battery Monitor 2
document_type: technical_reference

## Calibrating Battery Monitor 2

Battery Monitor 2 corresponds to the POWER2 port on The Cube. To calibrate Battery Monitor 2, complete the following steps:

1. Open Mission Planner. 2. Click **Config** -> **Full Parameter List** and adjust the parameters highlighted in green to enable battery _*_monitor 2:

![](/files/-Lvsy_hIkhFzJLAdqt67)

3. Enter the power module's properties and type, the flight controller type, and the battery capacity. The Voltage Divider calculation is the same as for the Battery Monitor. Monitor: Analog Voltage Only

Volt Pin: Pixhawk/Pixracer/Navio2/Pixhawk

Current Pin: Pixhawk/Pixracer/Navio2/Pixhawk

### Displaying Battery Monitor 2 Voltage on HUD

To display the Battery Monitor 2 voltage on the HUD, complete the following steps:

1. Open Mission Planner. 2. Click **Data**. 3. Move the cursor to the HUD and right-click mouse. 4. Select **User Items** to open the **Display This** window. 5. Select **battery-voltage2** and modify the display header. 6. Click **OK.** The Battery Monitor 2 voltage will be displayed on the HUD.

--- chunk_id: chunk-0076
source_document: optional-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 468
content_hash: ed25e2df5e618513
prev_chunk_id: chunk-0075
next_chunk_id: chunk-0077
section_heading: IMU Temperature Control
document_type: technical_reference

## IMU Temperature Control

The IMUs are temperature-controlled by onboard heating resistors. The pre-heating time will vary based on the environmental conditions and the set target temperature. To adjust the IMU temperature control, complete the following steps:

1. Open Mission Planner. 2. Click **Config** -> **Full Parameter List**. 3. Adjust the target temperature by changing the BRD_HEAT_TARG parameter. It is recommended to set BRD_HEAT_TARG to 60°C for the most accurate IMU measurements. 4. After the pre-heating is completed, reboot The Cube to let it re-log the IMU data. ### GPS Blending (Dual GPS)
Only GPS modules that report both position and speed accuracy can be used for GPS blending. The two GPS modules should be from the same manufacturer, as differences in how the accuracy is scaled can cause one GPS to be favored over the other. > If Copter-3.4.5 or older firmware is installed, do not use two GPS modules. Switching to the primary GPS module could result in sudden vehicle movements. The following firmware versions support GPS Blending: * Copter 3.5 or higher * Plane 3.8.0 or higher * Recent versions of Rover

### Connecting the GPS modules to The Cube

To connect the GPS modules to The Cube, complete the following steps:

1. Connect the 8-pin DF13 connector on one of the GPS modules to GPS1 port. 2. Connect the the 8-pin DF13 connector on the other GPS module to GPS2 port. The GPS module can be connected to other ports if that port has the supported protocols. For Here GPS modules, all the LEDs use the same I2C address. Thus, the LED on GPS2 will not light up. ### Enabling the GPS Blending Mode

To enable the GPS blending mode, change the following parameters in the ArduPilot firmware:

* SERIAL4_PROTOCOL = 5 /“GPS”. Alternatively, TELEM1 or TELEM2 can be used by setting SERIAL1_PROTOCOL or SERIAL2_PROTOCOL to 5. * GPS_TYPE2 = 1 /“AUTO” or the specific number corresponding to the GPS type. * GPS_AUTO_SWITCH = 2 / “Blend”. Alternatively, set to 1/“UseBest” to only use the better GPS, which is decided based on the GPS’s self reported accuracy.

--- chunk_id: chunk-0077
source_document: optional-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 401
content_hash: cd7f5ffde106816f
prev_chunk_id: chunk-0076
next_chunk_id: chunk-0078
section_heading: Automatic Dependent Surveillance Broadcast (ADS-B) Receiver
document_type: technical_reference

## Automatic Dependent Surveillance Broadcast (ADS-B) Receiver

ADS-B is an air traffic surveillance technology that enables the aircraft to be accurately tracked by air traffic controllers or pilots without a conventional radar. Some carrier boards come with the ADS-B antenna included. If it is not included, a ADS-B receiver can be bought, which includes the following two types:

* PingRX
* Ping2020

### Connecting the ADS-B Receiver to The Cube

To connect the receiver to The Cube, connect the DF13 serial cable to a serial port on The Cube. The sensor should be mounted with the antenna oriented vertically. ### Receiving Data from the ADS-B Receiver

To receive data from the ADS-B receiver, complete the following steps:

1. Open Mission Planner. 2. Click **Config** -> **Full Parameter List**. 3. Enable the ADSB_TYPE parameter to receive data from the ADSB sensor. For older Mission Planner versions, set the ADSB_ENABLE parameter to "1". 4. Check which UART port was used. * If TELEM1 or TELEM2 (UART) was connected, it means MAVLink is being used. No additional settings need to be made for the ADS-B Receiver. * If GPS UART serial 4/5 UART was connected, configure the UART to MAVLink with a baud rate of 57600. For example, if “serial4/5” was used, set the following:

SERIAL4_PROTOCOL =1 (meaning MAVLink) SERIAL4_BAUD =57 (baud rate is 57600)

5. Reboot the The Cube. 6. Open Mission Planner again. 7. Click **Config** -> **Full Parameter List**. 8. Adjust the StreamRate parameter (SR*_ADSB) to enable ADS-B data streaming to the GCS. The rate varies based on the telemetry, which is similar to having both a high-bandwidth and a low-bandwidth link attached. In most cases, this would be TELEM1. Thus, set SR1_ADSB = 5 (meaning 5Hz)

Once configured, operational aircraft within approximately 50km should appear on the Mission Planner map.

--- chunk_id: chunk-0078
source_document: optional-hardware-basic-configuration.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 70
content_hash: 662544c90eb20f53
prev_chunk_id: chunk-0077
next_chunk_id: chunk-0079
section_heading: On-Screen Display (OSD)
document_type: technical_reference

## On-Screen Display (OSD)

The OSD module receives real-time data from the UAV and overlays this information onto the video feed from the camera. The video is then streamed via the video transmitter to the GCS. To enable this function, connect the module's 6-pin DF13 cable to the TELEM2 port on The Cube.

--- chunk_id: chunk-0079
source_document: autopilot-module.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 170
content_hash: 7381c71c9699ebe6
prev_chunk_id: chunk-0078
next_chunk_id: chunk-0080
section_heading: Mounting
document_type: technical_reference

## Mounting

*AutoPilot Module*


Use the 3M double-layered tape and screws from the package to mount The Cube as close as possible to the unmanned aerial vehicle's (UAV) center of gravity. The carrier board screws are designed for 1.8 mm boards. The length of the customized M2.5 screws should be around 6 mm to 7.55 mm in order to mount The Cube onto the board. > Ensure that the arrow on The Cube is pointing towards the front of the UAV. > The Cube can be mounted in reverse or upside-down. For such situations, the parameters related to the orientation of The Cube may need to be modified accordingly. > The Cube is not waterproof. Ensure it is adequately protected when operating in a rainy or humid environment.

--- chunk_id: chunk-0080
source_document: autopilot-module.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: 056192103bbb11f7
prev_chunk_id: chunk-0079
next_chunk_id: chunk-0081
section_heading: Peripheral Connection
document_type: technical_reference

## Peripheral Connection

According to the peripheral type, size, dynamic structure, and load, the installation and parameter settings may vary. See the following for details. > Connect the GPS, sensors, telemetry, etc. to The Cube according to the connector pinout. Check the wiring order carefully, as most peripheral malfunctions are due to incorrect wiring. Since there are limitations on every interface on The Cube, connect your high-power peripheral to an external BEC. ### Installing the  MicroSD Card

Data flash logs are stored on the MicroSD card, which is inserted in the left slot of The Cube. It is recommended to use a Class 4 or higher MicroSD card. > The Cube cannot arm the UAV without a MicroSD card. An alarm with one high tone and two low tones will be played when The Cube arms the UAV. ### Power Supply

The Cube supports three different power sources, which include the following:

* Power module
* Servo rail
* USB cable

When more than one power source is connected, power is drawn from the highest-priority source with a valid input voltage. | Power Source | Priority | Regular Range | Limit | Protection Range |
| --- | --- | --- | --- | --- |
| Power Module Input | High | 4.8 V - 5.4 V | 4.1 V - 5.7 V | 0 V - 20 V |
| Servo Rail Input | Medium | 4.8 V - 5.4 V | 4.1 V - 10 V | 0 V - 20 V |
| USB Cable Input | Low | 4.8 V - 5.4 V | 4.1 V - 5.7 V | 0 V - 6 V | The I/O will accept power from the servo connector reaching up to 10V for manual override. The system will be unpowered when the servo input is above 5.7 V and the power module input is absent. The FMU and peripherals will not accept power from the servo rail. ### Power Module Connection

Connect the power module to the POWER1 port via the power cable. If there is a second battery monitor, connect it to the POWER2 port. The Cube will be turned on immediately after the battery is connected. Connect the XT60 on the other side of the power module to the motor system and loads.

--- chunk_id: chunk-0081
source_document: autopilot-module.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 256
content_hash: f3e3a1a27b5830bf
prev_chunk_id: chunk-0080
next_chunk_id: chunk-0082
section_heading: Peripheral Connection
document_type: technical_reference

The Cube will be turned on immediately after the battery is connected. Connect the XT60 on the other side of the power module to the motor system and loads. ![](/files/-LvrsJDGsUbi1p7i95xD)

### Connecting Electronic Speed Controllers (ESC) and Motors

Connect the power (+), ground (-), and signal (s) wires for each ESC to The Cube’s main output pins by the motor number. Find the corresponding frame type below to determine the assigned order of the motors. ECS malfunction is usually caused by incorrect wiring. Thus, always check the ESC model to ensure that the +5 V cable is connected correctly. On the APM2.x, the ground pin of the power supply can be used as the APM feedback signal. For The Cube, the signal pin and ground pin must be connected to operate the ESC. ### Motor Order Diagrams

The figures below show the motor order for each frame type. The numbers indicate which output pin from The Cube should be connected to each motor/propeller. The propeller direction is shown in green (clockwise, CW) or blue (counter-clockwise, CCW). Connect the cable from the ESC to the MAIN OUT port on The Cube. ![](/files/-Lvs7fl6cgx4rEoKvdmx)

![](/files/-Lvs9bnZSRjMNZct--Uz)

--- chunk_id: chunk-0082
source_document: autopilot-module.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 713c1fc27946bd12
prev_chunk_id: chunk-0081
next_chunk_id: chunk-0083
section_heading: Sensors Connection
document_type: technical_reference

## Sensors Connection
### Mounting the GPS Module

Follow these guidelines to ensure the GPS module always operates in an optimal environment:

* Mount the GPS module on the exterior of the UAV, ideally in an elevated position with a clear view of the sky. Ensure it is placed as far as possible from the motors and ESCs, with the arrow facing forward. * Ensure the module is positioned at least 10cm away from the DC power wiring and batteries. Using a GPS mast is highly recommended. * Avoid placing the module near metallic objects that contain iron. * Twist the power and ground wires when possible. A GPS module working in an outdoor environment with sufficient sky coverage will receive better satellite signals, which significantly improves the safety of autonomous missions. > Some high power wireless devices may interfere with the compass and GPS signal. Position these high power wireless devices as far as possible from the GPS module. ### GPS Modes

Single GPS

Use the 8-pin DF13 connector to connect the GPS module to the GPS1 port on The Cube. Most modules are plug-and-play. If the module includes a compass, it may need additional calibration. ### RC System Connection

The Cube supports the following signal receivers. Each signal type corresponds to a specific port on the carrier board. #### PWM/PPM/Futaba S.bus Receiver

* PWM Receiver: The Cube cannot directly process PWM signals. A PPM encoder is needed to encode multi-channel PWM to single-channel PPM signals. Thus, connect the PPM encoder to the RCIN port on The Cube. * PPM RC Receiver/Futaba S.Bus Receiver: These receivers are plugged into the RCIN port. #### Spektrum DSM/DSM2/DSM-X Satellite Receiver

For the Spektrum DSM, DSM2, or DSM-X Satellite receivers, they should be connected to the SPKT port on The Cube. ### Telemetry Connection

The function of the wireless telemetry is to establish two-way communication between the autopilot and ground control station (GCS). This enables real-time data to be displayed and the unmanned aerial vehicle (UAV) to be controlled by the GCS. #### **Telemetry Requirement: Mavlink protocol, Passthrough protocol, or TTL serial interface**

Ensure that the pin assignment of the cable matches the pinout of TELEM1 on The Cube. After confirming, the telemetry cable can be connected to either the TELEM1 or TELEM2 port.

--- chunk_id: chunk-0083
source_document: autopilot-module.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 114
content_hash: 7ab067541e7c9ce1
prev_chunk_id: chunk-0082
next_chunk_id: chunk-0084
section_heading: Sensors Connection
document_type: technical_reference

#### **Telemetry Requirement: Mavlink protocol, Passthrough protocol, or TTL serial interface**

Ensure that the pin assignment of the cable matches the pinout of TELEM1 on The Cube. After confirming, the telemetry cable can be connected to either the TELEM1 or TELEM2 port. Connect the other end of the cable to one of the COM ports on the GCS. The baud rate is typically 57600. > The default baud rate of TELEM1 port is 57600. It must match the telemetry baud rate. Last Update: 11th June 2019

--- chunk_id: chunk-0084
source_document: installing-ardupilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 213
content_hash: ba26b67253508a88
prev_chunk_id: chunk-0083
next_chunk_id: chunk-0085
section_heading: Installing ArduPilot
document_type: technical_reference

# Installing ArduPilot

To install ArduPilot, complete the following steps:

> Firmware cannot be installed when The Cube is connected to Mission Planner. 1. Open Mission Planner. 2. Click **Setup** -> **Install Firmware**. 3. Select **AUTO** or a specific port of The Cube. 4. Set the Baud rate to 115200. 5. Select the type of platform and firmware to install from the drop-down menu. 6. Click **Upload Firmware**. > If problems occur after installing the latest firmware, revert to an older version. > Customized firmware can be installed without an Internet connection by selecting the files from local folders. After ArduPilot has been successfully installed, a connection can now be established with The Cube. The following shows how to establish the connection for the different Cubes. **Cube Black**

Select the COM port, set the baud rate to 57600, and click **Connect**. **Cube Orange & Cube Yellow**

Select the Mavlink COM port, set the baud rate to 57600, and click **Connect**.

--- chunk_id: chunk-0085
source_document: installing-secure-firmware.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 285
content_hash: 658c1fd3dc9d0b54
prev_chunk_id: chunk-0084
next_chunk_id: chunk-0086
section_heading: Installing Secure Firmware
document_type: technical_reference

# Installing Secure Firmware

Securing firmware involves signing both the bootloader and firmware using the ECC Prime256v1 keypair. The keypair’s private key is securely generated and stored on CubePilot's server. Once a signed bootloader is installed, only firmware signed with an authorized public-private key pair can run on the autopilot. Any unsigned firmware will be blocked from being loaded. > Failure to follow the secure firmware installation steps could result in the hardware malfunctioning. To install the secure bootloader, complete the following steps:

1. Ensure the ArduPilot firmware build environment is installed using Linux or Windows WSL. For details, refer to the following website: [https://ardupilot.org/dev/docs/building-the-code.html](https://ardupilot.org/dev/docs/building-the-code.html#building-the-code)
2. Ensure the latest MAVProxy has been installed. For details, refer to the following website:
3. Create a branch to develop the firmware locally. 4. Open Mission Planner. 5. Click **Setup** -> **Secure**. 6. Click **Generate Key** to create a public-private key pair. 7. Build a securely signed bootloader for the autopilot via the instructions in the following link:

8. Build a securely signed firmware and load it onto the autopilot via the instructions in the following link:

9. Use MAVProxy to flash the securely signed bootloader as the new bootloader. 10. Verify that the new secure bootloader has been installed. For more details, refer to the following link:

--- chunk_id: chunk-0086
source_document: firmware.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 30
content_hash: 2b882d8938daee1e
prev_chunk_id: chunk-0085
next_chunk_id: chunk-0087
section_heading: Firmware
document_type: technical_reference

# Firmware

The Cube does not come with any autopilot software installed. See the following sections on how to install (flash) the firmware.

--- chunk_id: chunk-0087
source_document: ground-control-station.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: fa964e38927750d1
prev_chunk_id: chunk-0086
next_chunk_id: chunk-0088
section_heading: Ground Control Station
document_type: technical_reference

# Ground Control Station

The following section explains how to select the appropriate ground control station (GCS) and use it to set up and monitor the unmanned aerial vehicle (UAV). ### Selecting the Appropriate Ground Control Station

A GCS is a software application that runs on a ground-based computer and communicates with the UAV via wireless telemetry. It provides real-time data on the UAV's performance and position and can serve as a “virtual cockpit” by displaying instruments similar to those in a real plane. Different GCS are available based on the UAV and working environment. They can be used to upload mission commands, obtain real-time data, monitor live video streams, plan a mission, calibrate the UAV, configure parameters, etc. The functions and user interface can vary. Currently, the two most common GCS user interfaces are:

* **Mission Planner**: Suitable for ArduPilot firmware
* **QGroundControl**: Suitable for PX4 firmware

In this documentation, you will learn how to install Mission Planner and ArduPilot.

--- chunk_id: chunk-0088
source_document: mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: 6916273e67a030b3
prev_chunk_id: chunk-0087
next_chunk_id: chunk-0089
section_heading: Mission Planner
document_type: technical_reference

# Mission Planner

Mission Planner is a ground control software that is used to configure and control the UAV. The following section explains how to download, set up, or update Mission Planner. ### Installing Mission Planner

To download Mission Planner, complete the following steps:

1. Go to the following website . 2. Download the MSI Installer and run it. During the process, various drivers will be installed. > For older Mission Planner versions, the drivers need to be downloaded and installed separately. The drivers can be downloaded from the following link:

### Connecting Mission Planner to The Cube

To connect Mission Planner to The Cube, select one of the following options:

**USB Cable**

1. Open Mission Planner. 2. Connect one end of the USB cable to the USB port of The Cube, and the other end to the USB port (not a USB hub) of the ground-based computer. 3. Select the corresponding COM port from the drop-down list and choose 11200 for the baud rate. If **Auto** is chosen, the baud date will be automatically chosen. 4. Click **Connect**. **USB Telemetry**

1. Open Mission Planner. 2. Install The Cube to a carrier board. 3. The USB telemetry module typically features both a TELEM port and a USB port. Depending on the setup, choose one of the following options:
   * **Connect the TELEM port**: Use a telemetry cable to link the TELEM port on the module to the TELEM 1 or TELEM 2 port on the carrier board. * **Use the USB port**: Plug the module directly into the USB port of the ground-based computer and use the RF link. 4. Select the corresponding COM port from the drop-down list and choose 57600 for the baud rate. If **Auto** is chosen, the baud date will be automatically chosen. 5. Click **Connect**. **WiFi Telemetry**

1. Open Mission Planner. 2. Add Ethernet support to The Cube. See the CubeNode ETH section for details. {% content-ref url="/pages/wpM2wNIaCUm6YWw2bNUI" %}
[Broken mention](broken://pages/wpM2wNIaCUm6YWw2bNUI)
{% endcontent-ref %}

2. Use an Ethernet cable to connect The Cube to a router. 3. Pair the GCS to the same router. 4. Select **UDP** or **TCP** for the port. 5. Click **Connect** and enter 14550 for the port number. **Bluetooth Telemetry**

1. Open Mission Planner. 2. Install The Cube to a carrier board. 3.

--- chunk_id: chunk-0089
source_document: mission-planner.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 217
content_hash: 28915c279a6d5f52
prev_chunk_id: chunk-0088
next_chunk_id: chunk-0090
section_heading: Mission Planner
document_type: technical_reference

Install The Cube to a carrier board. 3. Connect a Bluetooth data link module such as the HC-06 module to the Telem 1 or Telem 2 port on The Cube. 4. Select the corresponding COM port from the drop-down list and choose 57600 for the baud rate. If **Auto** is chosen, the baud date will be automatically chosen. 5. Click **Connect**. ### Updating Mission Planner and its Drivers

To update the Mission Planner version, complete the following steps:

1. Open Mission Planner. 2. Click **Help** -> **Check for Updates.**

![Mission Planner Updates Screen](/files/-Lw0xPQ_rZOcfCACL-4b)

After updating Mission Planner, complete the following steps to update the drivers:

1. Disconnect The Cube from the USB port. 2. Open Mission Planner. 3. Press CTRL-F and click **Driver Clean** to remove the old drivers. 4. Download the latest drivers from the following website:
5. Run the MSI Installer. 6. When the installation is complete, reboot the system and reconnect The Cube to the GCS to install the drivers.

--- chunk_id: chunk-0090
source_document: setup.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 18
content_hash: d907b53c8b5548ee
prev_chunk_id: chunk-0089
next_chunk_id: chunk-0091
section_heading: Setup
document_type: technical_reference

# Setup

The following sections explain the setup process for the hardware and software.

--- chunk_id: chunk-0091
source_document: the-cube-faq.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: 2642034133e5af3c
prev_chunk_id: chunk-0090
next_chunk_id: chunk-0092
section_heading: 1. How do I Reset the Drivers on a Windows 10 when Attempting to Connect to The Cube?
document_type: technical_reference

### 1. How do I Reset the Drivers on a Windows 10 when Attempting to Connect to The Cube? *The Cube FAQ*


1. Open Mission Planner. 2. Press Ctrl + F; then, click **Driver Clean** to remove the previously installed drivers. 3. Close Mission Planner. 4. Download and install the drivers again from the following link: . 5. Reboot Windows. 6. Connect The Cube to the System via a USB port and wait for the drivers to be uploaded. 7. Open **Device Manager** and verify that both COM ports are correct. The following screenshot uses the **CubeOrange** as an example. ![](/files/-MQj2skqaaAsERa3VHc6)

For additional details, refer to the following link:\

### 2. How do I Resolve USB Connection Issues between The Cube and Mission Planner? Most USB connection issues are caused by outdated software or firmware. See below for the steps on how to resolve the problem:

**1.** Update Mission Planner and its drivers. For details, see the **Installing ArduPilot** section. If this does not work, go to the next step. {% content-ref url="/pages/PRGNYT96ktfizjUFGJYk" %}
[Broken mention](broken://pages/PRGNYT96ktfizjUFGJYk)
{% endcontent-ref %}

2. Update the Windows operating system to Windows 10 or above. If this does not work, go to the next step. 3. Open **Device Manager** and verify if the connected COM ports are correct. If not, reinstall the drivers from the following link: . The following shows the correct COM port connections for the different Cubes. * The **Cube Black**, **Cube Purple,** and **Cube Blue** should show a single COM port. The following screenshot uses the **Cube Black** as an example. ![Cube Black Com Ports in Device Manager ](/files/-Lw0xPQjfjTZI6olr6QP)

* Other colored Cubes should show two connected com ports. The following screenshot uses the **CubeOrange** as an example. ![Cube Orange Com Ports in Device Manager ](/files/-Lw0xPQlX8rDijToQMv2)

### 3. How do I Resolve the Driver Installation Issues for the Dual USB endpoint Cube Modules on a Windows 7 GCS? Excluding the **Cube Black** and **Cube Purple,** some issues could occur when installing drivers for dual USB endpoint Cube modules on a Windows 7 GCS. Using the **Cube Orange** as an example, see below on how to resolve the problem:

1. Connect The Cube to the GCS. 2. Open **Device Manager**. 3. Delete "CubePilot CUBE H7/F7" and then disconnect The Cube from the GCS. 4. Uninstall and reinstall the latest Cube drivers.

--- chunk_id: chunk-0092
source_document: the-cube-faq.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 165
content_hash: edb60ebca6f0e2c5
prev_chunk_id: chunk-0091
next_chunk_id: chunk-0093
section_heading: 1. How do I Reset the Drivers on a Windows 10 when Attempting to Connect to The Cube?
document_type: technical_reference

4. Uninstall and reinstall the latest Cube drivers. The drivers can be downloaded from the following link:
5. Reconnect the Cube to the GCS. The cube should appear as "CubeOrange-BL" in **Other Devices**. 6. Verify if the top entry changes to Cube and that Windows notifies you it is currently installing the device drivers. 7. Verify that "CubeOrange-BL" moves to **Ports** and is renamed as "Cube Orange Mavlink (COMx)". 8. If “CubeOrange-BL” does not move from **Other Devices** to **Ports,** right-click the mouse and go to **Properties**. 9. Click the driver icon in **Properties** and verify if the driver has moved to **Ports** and is named "Cube Orange SLCAN (COMx)". > It is highly recommended to run Mission Planner on Windows 10 or later.

--- chunk_id: chunk-0093
source_document: the-cube.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 141
content_hash: 00a88b382bbb8670
prev_chunk_id: chunk-0092
next_chunk_id: chunk-0094
section_heading: The Cube
document_type: technical_reference

# The Cube

The Cube comes in seven different colors. The features of each colored cube are different and designed for a particular purpose. > **Cube Red** has its own section in the documentation due to its extensive feature additions over the standard Cubes, such as Redundant Dual FMU processor configuration, which allows for two independent instances of ArduPilot to run. It is the first of a new type of autopilot for more critical flight operations. See the **Cube Red** section for details. {% content-ref url="/pages/0yW1R4LGDV9T2kEplSnD" %}
[Cube Red](/user-guides/autopilot/cube-red.md)
{% endcontent-ref %}

> The Cube Blue is manufactured in the USA with US and allied components.

--- chunk_id: chunk-0094
source_document: ads-b-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 104
content_hash: 0baca99818a496eb
prev_chunk_id: chunk-0093
next_chunk_id: chunk-0095
section_heading: ADS-B IN Carrier Board
document_type: technical_reference

# ADS-B IN Carrier Board

The Cube Orange Standard Kit + ADS-B includes the new Cube Orange autopilot and ADS-B IN-carrier board. The ADS-B IN-carrier board is an updated version of the original board. The specifications and external connections remain the same, but with the following changes:

* Integration of uAvionix ADS-B IN receiver
* Built-in ADS-B antenna
* Removal of Intel Edison bay and Debug USB ports
* New product design
* Correct labeling of CAN ports

--- chunk_id: chunk-0095
source_document: ads-b-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: f2c0cf2254f331ca
prev_chunk_id: chunk-0094
next_chunk_id: chunk-0096
section_heading: uAvionix ADS-B Receiver
document_type: technical_reference

## uAvionix ADS-B Receiver

The new carrier board has an integrated uAvionix 1090Mhz ADS-B IN receiver. This enables the detection of aircraft equipped with ADS-B OUT in the vicinity. The aircraft information, such as the position, altitude, speed, and ID, can be displayed on the connected ground station. Additionally, the alarm, sense, and avoid functions in ArduPilot can be configured. The ADS-B receiver is connected to the internal serial 5 port. It is compatible with ArduPilot and PX4. ### Enabling the ADS-B function in ArduPilot

To enable the ADS-B function in ArduPilot, complete the following steps:

1. Open Mission Planner. 2. Click **Setup** -> **Install Firmware**. 3. Install one of the **Plane** or **Copter-related** firmware. 4. Click **Config** -> **Full Parameter List.**
5. Set the following parameters to the values shown in the table. | Parameter                        | Value | Description                                                                                     |
| -------------------------------- | ----- | ----------------------------------------------------------------------------------------------- |
| SERIAL5_BAUD                    | 57    | Sets the baud rate                                                                              |
| SERIAL5_PROTOCOL                | 1     | Sets the protocol                                                                               |
| SR0_ADSB                        | 2     | Sets ADSB stream rate to the ground station                                                     | | SR1_ADSB or
SR2_ADSB | 2     | Enables the ground station to receive the detected aircraft information via Telem 1 or Telem 2. | 6. Click **Write Params**. ### Enabling the ADS-B Alarm, Sense, and Avoid Functions

To enable the ADS-B alarm, sense, and avoid functions, complete the following steps:

1. Follow Steps 1\~4 in the "Enabling the ADS-B function in ArduPilot" section. 2. Set AVD_Enable to "1". 3. Click **Write Params**. 4. Reboot The Cube. 5. Click **Config** -> **Full Parameter List.**
6. Set the following parameters to the values shown in the table. | Parameter | Value | Description |
| --- | --- | --- |
| AVD_ENABLE | 1 | Enable alarm and avoidance using ADSB |
| AVD_W_ACTION | 1 | Enable warning 0: Disable 1: Enable |
| AVD_F_ACTION | 1 | Controls how the vehicle should respond to a projected near-miss 0: No response1: Report 2: Climb or descend 3: Move horizontally 4: Move perpendicularly in 3D 5: RTL 6: Hover |
| AVD_F_RCVRY | 3 | Sets how the vehicle will behave after it has cleared the near-miss area. 0: Remain in EXCER_ADSB status1: Resume previous flight mode2: RTL3: Resume if AUTO else Loiter | 7. Click **Write Params**.

--- chunk_id: chunk-0096
source_document: ads-b-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 40
content_hash: 0eab13ffae4ebeda
prev_chunk_id: chunk-0095
next_chunk_id: chunk-0097
section_heading: uAvionix ADS-B Receiver
document_type: technical_reference

7. Click **Write Params**. For more information on these settings, go to . The following Github link can be used to revise and update the ADS-IN carrier board information**:** \

--- chunk_id: chunk-0097
source_document: carrier-boards-faq.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 48
content_hash: ae2d33f24d9603f3
prev_chunk_id: chunk-0096
next_chunk_id: chunk-0098
section_heading: 1. Is there a SBUS port on the Mini Carrier Board?
document_type: technical_reference

### 1. Is there a SBUS port on the Mini Carrier Board? *Carrier Boards FAQ*


**Ans**: There is no SBUS port on the Mini carrier board. For more details, refer to the following Github link: [**https://github.com/CubePilot/cubepilot-docs/blob/master/carrier-boards/carrier-boards-faq.md**](https://github.com/CubePilot/cubepilot-docs/blob/master/carrier-boards/carrier-boards-faq.md)

--- chunk_id: chunk-0098
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 341
content_hash: 33277d5aebf050b2
prev_chunk_id: chunk-0097
next_chunk_id: chunk-0099
section_heading: Operating Conditions and Performance
document_type: technical_reference

## Operating Conditions and Performance

*Cube Red Standard Carrier Board Pinout* | Parameter | Description |
| --- | --- |
| Power Input Voltage/Rated Input Current | 4.1 ~ 5.7V / 2.5A Note: 0 ~ 20 V is supported, but The Cube may not operate properly. |
| Power Rated Output/Input power | 14W |
| USB Port Input Voltage/Rated Input Current | 4 ~ 5.7V / 250mA |
| Servo Rail Input Voltage | 4 ~ 10.5V |
| Waterproof Performance | Not waterproof. External waterproof protection is needed |
| Operational Temperature | Recommended ambient temperature: -10°C ~ 55°C. Note: The Cube can operate within a wider range of -40°C ~ 100°C but with possible performance degradation or risks. | ### Ports Standard and Definition
### Standard Carrier Board Ports | Connector | Connector Type              |
| --------- | --------------------------- |
| `GPS1`    | JST-GH 1.25 mm (8-pin)      |
| `GPS2`    | JST-GH 1.25 mm (6-pin)      |
| `TELEM1`  | JST-GH 1.25 mm (6-pin)      |
| `TELEM2`  | JST-GH 1.25 mm (6-pin)      |
| `I2C2`    | JST-GH 1.25 mm (4-pin)      |
| `USB`     | JST-GH 1.25 mm (6-pin)      |
| `CAN1`    | JST-GH 1.25 mm (4-pin)      |
| `CAN2`    | JST-GH 1.25 mm (4-pin)      |
| `CAN3`    | JST-GH 1.25 mm (4-pin)      |
| `POWER1`  | Molex CLIK-Mate 2mm (6-pin) |
| `POWER2`  | Molex CLIK-Mate 2mm (6-pin) |
| `ADC`     | JST-GH 1.25 mm (3-pin)      |
| `DSI`     | JST-GH 1.25 mm (15-pin)     |
| `ETH`     | TE Multi-purp pluh (8P)     |

--- chunk_id: chunk-0099
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 348
content_hash: c9422cfbabde037a
prev_chunk_id: chunk-0098
next_chunk_id: chunk-0100
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 1 of 5 (continued)**
| Pin Number | Pin Type | Pin Name                      | Function                                                              |
| ---------- | -------- | ----------------------------- | --------------------------------------------------------------------- |
| 1          | I/O      | FMU_SWDIO                    | FMU serial wire debug I/O                                             |
| 2          | O        | FMU_LED_AMBER               | Boot error LED (drive only, controlled by FET)                        |
| 3          | O        | FMU_SWCLK                    | FMU serial wire debug clock                                           |
| 4          | I/O      | I2C_2_SDA                   | I2C serial data Tx/Rx                                                 |
| 5          | O        | EXTERN_CS                    | Chip select for external SPI (NC, just for debugging)                 |
| 6          | O        | I2C_2_SCL                   | I2C serial clock signal                                               |
| 7          | I        | FMU_!RESET                   | Reset pin for the FMU                                                 |
| 8          | I/O      | CAN_L_3                     | CAN bus low signal driver                                             |
| 9          | I        | VDD_SERVO_IN                | Power for last resort I/O failsafe                                    |
| 10         | I/O      | CAN_H_3                     | CAN bus high signal driver                                            |
| 11         | I        | EXTERN_DRDY                  | Interrupt pin for external SPI (NC, just for debugging)               |
| 12         | I        | SERIAL_5_RX                 | UART 5 RX (receive data)                                              |
| 13         |          | GND                           | System GND                                                            |
| 14         | O        | SERIAL_5_TX                 | UART 5 TX (transmit data)                                             |
| 15         |          | GND                           | System GND                                                            |
| 16         | I        | SERIAL_4_RX                 | UART 4 RX (receive data)                                              |
| 17         |          | SAFETY                        | Safety button input                                                   |
| 18         | O        | SERIAL_4_TX                 | UART 4 TX (transmit data)                                             |

--- chunk_id: chunk-0100
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 354
content_hash: a743943c1d0902d7
prev_chunk_id: chunk-0099
next_chunk_id: chunk-0101
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 2 of 5 (continued)**
| Pin Number | Pin Type | Pin Name                      | Function                                                              |
| ---------- | -------- | ----------------------------- | --------------------------------------------------------------------- |
| 19         | O        | VDD_3V3_SPEKTRUM_EN        | Enable for the Spektrum voltage regulator                             |
| 20         | I        | SERIAL_3_RX                 | UART 3 RX (receive data)                                              |
| 21         | AI       | PRESSURE_SENS_IN            | Analog signal port, for pressure sensor, laser range finder, or sonar |
| 22         | O        | SERIAL_3_TX                 | UART 3 TX (transmit data)                                             |
| 23         | AI       | AUX_BATT_VOLTAGE_SENS      | Voltage sense for Aux battery input                                   |
| 24         | O        | ALARM                         | Buzzer PWM signal                                                     |
| 25         | AI       | AUX_BATT_CURRENT_SENS      | Current sense for Aux battery input                                   |
| 26         | I        | IO_VDD_3V3                  | IO chip power, pinned through for debug                               |
| 27         | O        | VDD_5V_PERIPH_EN           | Enable voltage supply for peripherals                                 |
| 28         | O        | IO_LED_SAFET_PROT          | IO-LED_SAFETY (safety LED) pinned out for IRIS                       |
| 29         | I        | VBUS                          | USB VBus (VDD)                                                        |
| 30         |          | SERIAL_2_RTS                | UART 2 RTS (request to send)                                          |
| 31         | I/O      | OTG_DP1                      | USB Data+ (D)                                                         |
| 32         |          | SERIAL_2_CTS                | UART 2 CTS (clear to send)                                            |
| 33         | I/O      | OTG_DM1                      | USB Data- (M)                                                         |
| 34         | I        | SERIAL_2_RX                 | UART 2 RX (receive data)                                              |
| 35         | I/O      | I2C_1_SDA                   | I2C serial data Tx/Rx                                                 |
| 36         | O        | SERIAL_2_TX                 | UART 2 TX (transmit data)                                             |

--- chunk_id: chunk-0101
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 356
content_hash: cf95a61dac152f14
prev_chunk_id: chunk-0100
next_chunk_id: chunk-0102
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 3 of 5 (continued)**
| Pin Number | Pin Type | Pin Name                      | Function                                                              |
| ---------- | -------- | ----------------------------- | --------------------------------------------------------------------- |
| 37         | O        | I2C_1_SCL                   | I2C serial clock signal                                               |
| 38         | I        | SERIAL_1_RX                 | UART 1 RX (receive data)                                              |
| 39         | I/O      | CAN_L_2                     | FMU CAN bus low signal driver                                         |
| 40         | O        | SERIAL_1_TX                 | UART 1 TX (transmit data)                                             |
| 41         | I/O      | CAN_H_2                     | FMU CAN bus high signal driver                                        |
| 42         |          | SERIAL_1_RTS                | UART 1 RTS (request to send)                                          |
| 43         | I        | VDD_5V_PERIPH_OC           | Error state message from peripheral power supply                      |
| 44         |          | SERIAL_1_CTS                | UART 1 CTS (clear to send)                                            |
| 45         | I        | VDD_5V_HIPOWER_OC          | Error state message from high power peripheral power supply           |
| 46         | O        | IO_USART_1_TX              | I/O USART 1 TX                                                        |
| 47         | AI       | BATT_VOLTAGE_SENS_PROT     | Voltage sense from main battery                                       |
| 48         | O        | IO_USART1_RX_SPECTRUM_DSM | Signal from Spectrum receiver                                         |
| 49         | AI       | BATT_CURRENT_SENS_PROT     | Current sense from main battery                                       |
| 50         | O        | FMU_CH1_PROT                | FMU PWM Output Channel 1                                              |
| 51         | O        | SPI_EXT_MOSI                | External SPI, for debug only                                          |
| 52         | O        | FMU_CH2_PROT                | FMU PWM Output Channel 2                                              |
| 53         | I        | VDD_SERVO                    | VDD_Servo, for monitoring servo bus                                  |
| 54         | O        | FMU_CH3_PROT                | FMU PWM Output Channel 3                                              |

--- chunk_id: chunk-0102
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: 394a09d4f37209c0
prev_chunk_id: chunk-0101
next_chunk_id: chunk-0103
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 4 of 5 (continued)**
| Pin Number | Pin Type | Pin Name                      | Function                                                              |
| ---------- | -------- | ----------------------------- | --------------------------------------------------------------------- |
| 55         | I        | VDD_BRICK_VALID             | Main power valid signal                                               |
| 56         | O        | FMU_CH4_PROT                | FMU PWM Output Channel 4                                              |
| 57         | I        | VDD_BACKUP_VALID            | Backup power valid signal                                             |
| 58         | O        | FMU_CH5_PROT                | FMU PWM Output Channel 5                                              |
| 59         | I        | VBUS_VALID                   | USB bus valid signal                                                  |
| 60         | O        | FMU_CH6_PROT                | FMU PWM Output Channel 6                                              |
| 61         | I        | VDD_5V_IN_PROT             | Main power (5V) into FMU from power selection                         |
| 62         | I        | PPM_SBUS_PROT               | PPM / S.Bus signal input                                              |
| 63         | I        | VDD_5V_IN_PROT             | Main power (5V) into FMU from power selection                         |
| 64         | O        | S.BUS_OUT                    | S.Bus signal output                                                   |
| 65         | O        | IO_VDD_5V5                  | IO VDD 5.5V                                                           |
| 66         | O        | IO_CH8_PROT                 | I/O PWM Output Channel 8                                              |
| 67         | I        | SPI_EXT_MISO                | External SPI, for debug only                                          |
| 68         | O        | IO_CH7_PROT                 | I/O PWM Output Channel 7                                              |
| 69         | I/O      | IO_SWDIO                     | I/O serial wire debug                                                 |
| 70         | O        | IO_CH6_PROT                 | I/O PWM Output Channel 6                                              |
| 71         | O        | IO_SWCLK                     | I/O serial wire debug clock                                           |
| 72         | O        | IO_CH5_PROT                 | I/O PWM Output Channel 5                                              |

--- chunk_id: chunk-0103
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: bb7091a60a89006b
prev_chunk_id: chunk-0102
next_chunk_id: chunk-0104
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 5 of 5 (continued)**
| Pin Number | Pin Type | Pin Name                      | Function                                                              |
| ---------- | -------- | ----------------------------- | --------------------------------------------------------------------- |
| 73         | O        | SPI_EXT_SCK                 | External SPI, for debug only                                          |
| 74         | O        | IO_CH4_PROT                 | I/O PWM Output Channel 4                                              |
| 75         | I        | IO_!RESET                    | I/O reset pin                                                         |
| 76         | O        | IO_CH3_PROT                 | I/O PWM Output Channel 3                                              |
| 77         | I/O      | CAN_L_1                     | FMU CAN bus low signal driver                                         |
| 78         | O        | IO_CH2_PROT                 | I/O PWM Output Channel 2                                              |
| 79         | I/O      | CAN_H_1                     | FMU CAN bus high signal driver                                        |
| 80         | O        | IO_CH1_PROT                 | I/O PWM Output Channel 1                                              |

--- chunk_id: chunk-0104
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 280
content_hash: adbc52b8c429de0a
prev_chunk_id: chunk-0103
next_chunk_id: chunk-0105
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 1 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 1          |          | GND                 | System GND                                    |
| 2          | I        | FMU_BOOT           | FMU boot                                      |
| 3          | I/O      | FC_NET_TX+        | Ethernet TX+,Auto-MDIX support                |
| 4          |          | NC                  | For future use                                |
| 5          |          | GND                 | System GND                                    |
| 6          |          | IO_BOOT            | IO MCU boot                                   |
| 7          | I/O      | FC_NET_TX-        | Ethernet TX-, Auto-MDIX support               |
| 8          |          | NC                  | For future use                                |
| 9          |          | GND                 | System GND                                    |
| 10         |          | NC                  | For future use                                |
| 11         | I/O      | FC_NET_RX+        | Ethernet RX+, Auto-MDIX support               |
| 12         |          | NC                  | For future use                                |
| 13         |          | GND                 | System GND                                    |
| 14         |          | NC                  | For future use                                |
| 15         | I/O      | FC_NET_RX-        | Ethernet RX-, Auto-MDIX support               |
| 16         |          | NC                  | For future use                                |
| 17         |          | GND                 | System GND                                    |
| 18         |          | NC                  | For future use                                |

--- chunk_id: chunk-0105
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 302
content_hash: 164c56aaac7ba2af
prev_chunk_id: chunk-0104
next_chunk_id: chunk-0106
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 2 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 19         | O        | FC_NET_LEDY       | Link speed LED indication                     |
| 20         |          | NC                  | For future use                                |
| 21         | O        | FC_NET_LEDG       | Ethernet link activity LED indication         |
| 22         |          | NC                  | For future use                                |
| 23         | I        | FC_NET_VCC        | Ethernet 3.3V power in                        |
| 24         |          | NC                  | For future use                                |
| 25         | I        | Timestamp rtc       | Timestamp RTC                                 |
| 26         |          | NC                  | For future use                                |
| 27         |          | GND                 | System GND                                    |
| 28         |          | NC                  | For future use                                |
| 29         | I/O      | CAN_L_1           | CAN bus low signal driver                     |
| 30         |          | NC                  | For future use                                |
| 31         | I/O      | CAN_H_1           | CAN bus high signal driver                    |
| 32         |          | NC                  | For future use                                |
| 33         | I/O      | CAN_L_2           | CAN bus low signal driver                     |
| 34         |          | NC                  | For future use                                |
| 35         | I/O      | CAN_H_2           | CAN bus high signal driver                    |
| 36         |          | NC                  | For future use                                |

--- chunk_id: chunk-0106
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 300
content_hash: 8b2caeaff2e78b21
prev_chunk_id: chunk-0105
next_chunk_id: chunk-0107
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 3 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 37         | I/O      | CAN_L_3           | CAN bus low signal driver                     |
| 38         |          | NC                  | For future use                                |
| 39         | I/O      | CAN_H_3           | CAN bus high signal driver                    |
| 40         |          | NC                  | For future use                                |
| 41         |          | GND                 | System GND                                    |
| 42         |          | NC                  | For future use                                |
| 43         | I        | UART8_RX           | IO UART 8 RX (receive data)                   |
| 44         |          | NC                  | For future use                                |
| 45         | O        | UART8_TX           | IO UART 8 TX (transmit data)                  |
| 46         |          | NC                  | For future use                                |
| 47         |          | GND                 | System GND                                    |
| 48         |          | NC                  | For future use                                |
| 49         | O        | DSI_CKP            | MIPI DSI host clock postive                   |
| 50         |          | NC                  | For future use                                |
| 51         | O        | DSI_CKN            | MIPI DSI host clock negative                  |
| 52         |          | NC                  | For future use                                |
| 53         |          | GND                 | System GND                                    |
| 54         |          | NC                  | For future use                                |

--- chunk_id: chunk-0107
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 292
content_hash: 7fe56d8026f023f0
prev_chunk_id: chunk-0106
next_chunk_id: chunk-0108
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 4 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 55         | O        | DSI_D0P            | MIPI DSI host DATA0 postive                   |
| 56         |          | NC                  | For future use                                |
| 57         | O        | DSI_D0N            | MIPI DSI host DATA0 negative                  |
| 58         |          | NC                  | For future use                                |
| 59         |          | GND                 | System GND                                    |
| 60         |          | NC                  | For future use                                |
| 61         | O        | DSI_D1P            | MIPI DSI host DATA1 postive                   |
| 62         |          | NC                  | For future use                                |
| 63         | O        | DSI_D1N            | MIPI DSI host DATA1 negative                  |
| 64         |          | NC                  | For future use                                |
| 65         |          | GND                 | System GND                                    |
| 66         |          | NC                  | For future use                                |
| 67         | O        | FMU_DAC            | FMU analog output                             |
| 68         |          | NC                  | For future use                                |
| 69         | O        | IO_DAC             | IO analog output                              |
| 70         |          | NC                  | For future use                                |
| 71         |          | GND                 | System GND                                    |
| 72         |          | NC                  | For future use                                |

--- chunk_id: chunk-0108
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: 0e74b3c5656b3083
prev_chunk_id: chunk-0107
next_chunk_id: chunk-0109
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

**Table — Part 5 of 5 (continued)**
| Pin Number | Pin Type | Pin Name            | Description                                   |
| ---------- | -------- | ------------------- | --------------------------------------------- |
| 73         | I        | VDD_5V_IN_backup | Main power (5V) into FMU from power selection |
| 74         |          | NC                  | For future use                                |
| 75         | I        | VDD_5V_IN_backup | Main power (5V) into FMU from power selection |
| 76         |          | NC                  | For future use                                |
| 77         | I        | VDD_5V_IN_backup | Main power (5V) into FMU from power selection |
| 78         |          | NC                  | For future use                                |
| 79         | I        | VDD_5V_IN_backup | Main power (5V) into FMU from power selection |
| 80         |          | NC                  | For future use                                |

--- chunk_id: chunk-0109
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: a310a884b8319150
prev_chunk_id: chunk-0108
next_chunk_id: chunk-0110
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

## Cube Red 80-Pin DF17 Connector
### **Connector 1 Assignments** ### **Connector 2 Assignments** ### Ports and Protocols | Name | Function | Label |
| --- | --- | --- |
| SERIAL 1 / UART 1 | UART 1 with hardware flow control; 3.3V ~ 5V CMOS TTL level with ESD protection | TELEM1 |
| SERIAL 2 / UART 2 | UART 2 with hardware flow control; 3.3V ~ 5V CMOS TTL level with ESD protection | TELEM2 |
| SERIAL 3 / UART 3 / I2C 1 | 3.3V ~ 5V CMOS TTL level with ESD protection | GPS1 |
| SERIAL 4 / UART 4 / I2C 2 | UART 4 / I2C 2; 3.3V ~ 5V CMOS TTL level with ESD protection | GPS2 |
| SERIAL 8 / UART 8 (Debug Console) | UART 8 on IO; Debug Console | CONS |
| I2C 2 | Independent I2C 2 port. Drivers are on-board FMU. Un-buffered, and pulled up to 3.3V COMMS TTL level | I2C2 |
| CAN Bus | Standard CAN Bus. Drivers are on-board FMU | CAN1 CAN2 CAN3 |
| R/C IN | Support CPPM / Futaba S.Bus signal input or any protocols supported by ArduPilot | RCIN_FMU1 RCIN_FMU2 |
| DSM / USART | Support Spektrum DSM® Technology, Spektrum DSM2™ / DSMX™ compatible input; I/O USART 1 RX | SKPT |
| S.Bus OUT / RSSI IN | S.Bus Servo I/O. PPM Output. Can be used as RSSI input | SBUSo |
| POWER | Main power source and Backup power source input | POWER1 POWER2 |
| MAIN OUT | Secondary FMU 8 x PWM/BDSHOT/RELAY | MAIN OUT |
| AUX OUT | Primary FMU 6 x PWM/BDSHOT/RELAY | AUX OUT |
| USB | LED, speaker, and USB extension | USB |
| ADC | 3.3 V ADC Input | ADC |
| SPI | Built-in SPI port, with NO buffer, can only use short cable for connection. Not recommended for use. | Built-in contact point |
| Debug | I/O and FMU testing port | Built-in port |
| ETH | Ethernet port |  |
| DSI | MIPI DSI output and timestamp; FMU/IO BOOT |  |

--- chunk_id: chunk-0110
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 693
content_hash: ce8e5e8e9a0eb813
prev_chunk_id: chunk-0109
next_chunk_id: chunk-0111
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### Ports and Protocols | Name | Function | Label |
| --- | --- | --- |
| SERIAL 1 / UART 1 | UART 1 with hardware flow control; 3.3V ~ 5V CMOS TTL level with ESD protection | TELEM1 |
| SERIAL 2 / UART 2 | UART 2 with hardware flow control; 3.3V ~ 5V CMOS TTL level with ESD protection | TELEM2 |
| SERIAL 3 / UART 3 / I2C 1 | 3.3V ~ 5V CMOS TTL level with ESD protection | GPS1 |
| SERIAL 4 / UART 4 / I2C 2 | UART 4 / I2C 2; 3.3V ~ 5V CMOS TTL level with ESD protection | GPS2 |
| SERIAL 8 / UART 8 (Debug Console) | UART 8 on IO; Debug Console | CONS |
| I2C 2 | Independent I2C 2 port. Drivers are on-board FMU. Un-buffered, and pulled up to 3.3V COMMS TTL level | I2C2 |
| CAN Bus | Standard CAN Bus. Drivers are on-board FMU | CAN1 CAN2 CAN3 |
| R/C IN | Support CPPM / Futaba S.Bus signal input or any protocols supported by ArduPilot | RCIN_FMU1 RCIN_FMU2 |
| DSM / USART | Support Spektrum DSM® Technology, Spektrum DSM2™ / DSMX™ compatible input; I/O USART 1 RX | SKPT |
| S.Bus OUT / RSSI IN | S.Bus Servo I/O. PPM Output. Can be used as RSSI input | SBUSo |
| POWER | Main power source and Backup power source input | POWER1 POWER2 |
| MAIN OUT | Secondary FMU 8 x PWM/BDSHOT/RELAY | MAIN OUT |
| AUX OUT | Primary FMU 6 x PWM/BDSHOT/RELAY | AUX OUT |
| USB | LED, speaker, and USB extension | USB |
| ADC | 3.3 V ADC Input | ADC |
| SPI | Built-in SPI port, with NO buffer, can only use short cable for connection. Not recommended for use. | Built-in contact point |
| Debug | I/O and FMU testing port | Built-in port |
| ETH | Ethernet port |  |
| DSI | MIPI DSI output and timestamp; FMU/IO BOOT |  | ### **Carrier Board Port Interface and Pin Label**
### **SERIAL 1 / UART 1 | Port: `TELEM1`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC |
| 2 | SERIAL_1_TX | OUT | 3.3 V ~ 5.0 V TTL | Orange/Black | UART 1 TX (Transmit Data) |
| 3 | SERIAL_1_RX | IN | 3.3 V ~ 5.0 V TTL | Green/Black | UART 1 RX (Receive Data) |
| 4 | SERIAL_1_CTS (TX) | OUT | 3.3 V ~ 5.0 V TTL | Gray/Black | UART 1 CTS (Clear to Send) |
| 5 | SERIAL_1_RTS (RX) | IN | 3.3 V ~ 5.0 V TTL | Gray/Black | UART 1 RTS (Request to Send) |
| 6 | GND |  | GND | Black | GND |

--- chunk_id: chunk-0111
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 642
content_hash: 4ee4a89467051eaf
prev_chunk_id: chunk-0110
next_chunk_id: chunk-0112
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### **Carrier Board Port Interface and Pin Label**
### **SERIAL 1 / UART 1 | Port: `TELEM1`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC |
| 2 | SERIAL_1_TX | OUT | 3.3 V ~ 5.0 V TTL | Orange/Black | UART 1 TX (Transmit Data) |
| 3 | SERIAL_1_RX | IN | 3.3 V ~ 5.0 V TTL | Green/Black | UART 1 RX (Receive Data) |
| 4 | SERIAL_1_CTS (TX) | OUT | 3.3 V ~ 5.0 V TTL | Gray/Black | UART 1 CTS (Clear to Send) |
| 5 | SERIAL_1_RTS (RX) | IN | 3.3 V ~ 5.0 V TTL | Gray/Black | UART 1 RTS (Request to Send) |
| 6 | GND |  | GND | Black | GND | ### **SERIAL 3 / UART 3 (GPS) / I2C 1 | Port: `GPS1`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | IN | 5 V | Red | VCC Power Supply to GPS from AP |
| 3 | SERIAL_3_TX | OUT | 3.3 V ~ 5.0 V TTL | Black | UART 3 TX (Transmit Data) |
| 2 | SERIAL_3_RX | IN | 3.3 V ~ 5.0 V TTL | Black | UART 3 RX (Receive Data) |
| 4 | I2C_1_SCL | IN | 3.3 V | Black | I2C 1 Clock Signal |
| 5 | I2C_1_SDA | IN/OUT | 3.3 V | Black | I2C 1 Serial Data |
| 6 | BUTTON |  | GND | Black | Signal shorted to GND on press |
| 7 | IO_LED_SAFET_PROT |  | GND | Black | LED Driver for Safety Button |
| 8 | GND |  | GND | Black | GND | ### **Buzzer / USB / LED | Port: `USB`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | V BUS | OUT | 5 V | Red/Gray | USB V BUS |
| 2 | OTG_DP1 | IN/OUT | 3.3 V | Green/Black | USB Data Positive (D+) |
| 3 | OTG_DM1 | IN/OUT | 3.3 V | Red/Black | USB Data Minus (D-) |
| 4 | GND |  | GND | Black | GND |
| 5 | BUZZER_OUT | OUT | Battery Voltage | Gray/Black | VBAT (8.4 - 42 V) |
| 6 | FMU_LED_AMBER | OUT |  | Black | Boot / Error LED (FW updates) |

--- chunk_id: chunk-0112
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 565
content_hash: 0d044ccc457e6e55
prev_chunk_id: chunk-0111
next_chunk_id: chunk-0113
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### **Buzzer / USB / LED | Port: `USB`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | V BUS | OUT | 5 V | Red/Gray | USB V BUS |
| 2 | OTG_DP1 | IN/OUT | 3.3 V | Green/Black | USB Data Positive (D+) |
| 3 | OTG_DM1 | IN/OUT | 3.3 V | Red/Black | USB Data Minus (D-) |
| 4 | GND |  | GND | Black | GND |
| 5 | BUZZER_OUT | OUT | Battery Voltage | Gray/Black | VBAT (8.4 - 42 V) |
| 6 | FMU_LED_AMBER | OUT |  | Black | Boot / Error LED (FW updates) | ### **I2C 2 | Port: `I2C 2`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC Power Supply |
| 2 | I2C_2_SCL | IN/OUT | 3.3 V (PULLUPS) | Blue/Black | I2C 2 Clock Signal, Pull-up on AP |
| 3 | I2C_2_SDA | IN/OUT | 3.3 V (PULLUPS) | Green/Black | I2C 2 Serial Data, Pull-up on AP |
| 4 | GND |  | GND | Black | GND | ### **CAN 1 | Port: `CAN1`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC Power Supply |
| 2 | CAN_H_1 | IN/OUT | 12 V | Orange/Black | CAN High |
| 3 | CAN_L_1 | IN/OUT | 12 V | Green/Black | CAN Low |
| 4 | GND |  | GND | Black | GND | ### **CAN 2 | Port: `CAN2`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC Power Supply |
| 2 | CAN_H_2 | IN/OUT | 12 V | Orange/Black | CAN High |
| 3 | CAN_L_2 | IN/OUT | 12 V | Green/Black | CAN Low |
| 4 | GND |  | GND | Black | GND |

--- chunk_id: chunk-0113
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 652
content_hash: d504b2d944844a11
prev_chunk_id: chunk-0112
next_chunk_id: chunk-0114
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### **CAN 2 | Port: `CAN2`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC Power Supply |
| 2 | CAN_H_2 | IN/OUT | 12 V | Orange/Black | CAN High |
| 3 | CAN_L_2 | IN/OUT | 12 V | Green/Black | CAN Low |
| 4 | GND |  | GND | Black | GND | ### **ADC | Port: `ADC`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VDD_5V_PRES | OUT | 5 V | Red | Power Supply |
| 2 | PRESSURE_SENS_IN | IN |  | Black |  |
| 3 | GND |  | GND | Black | GND | ### **IO USART 1 / DSM | Port: `SPKT`** | Pin Number | Name | I/O | Voltage | Definition |
| --- | --- | --- | --- | --- |
| 1 | IO_USART1_RX_SPECTRUM_DSM | IN |  | IO USART 1 RX, DSM INPUT |
| 2 | GND |  | GND | GND |
| 3 | VDD_3V3_Spektrum | OUT | 3.3 V | Independent Power Supply | ### **SERIAL 8/ UART 8  / S.Bus OUT | Port: `CONS`** **`SBUSo`** | Pin Number | Name | I/O | Voltage | Definition |
| --- | --- | --- | --- | --- |
| 1 SBUSo | S.Bus_Out | OUT |  | S.Bus Signal Output |
| 2 CONS | SERIAL_8_TX | OUT | 3.3 V - 5.0 V TTL | IO UART 8 TX (Transmit Data) |
| 3 SBUSo | VDD_SERVO | OUT | Servo Voltage |  |
| 4 CONS | SERIAL_8_RX | IN | 3.3 V - 5.0 V TTL | IO UART 8 RX (Receive Data) |
| 5 SBUSo | GND |  | GND | GND |
| 6 CONS | GND |  | GND | GND | ### **Main Power POWER 1 | Port: `POWER1`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VDD_5V_BRICK | IN | 5 V | Red/Gray | Supply to AP from Power Brick |
| 2 | VDD_5V_BRICK | IN | 5 V | Red/Gray | Supply to AP from Power Brick |
| 3 | BATT_CURRENT_SENS_PROT |  | 3.3 V | Black | Battery Current Connecter |
| 4 | BATT_CURRENT_VOLTAGE_PROT | IN | 3.3 V | Black | Battery Voltage Connecter |
| 5 | GND |  | GND | Black | GND |
| 6 | GND |  | GND | Black | GND |

--- chunk_id: chunk-0114
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 808
content_hash: 37efb7bac512cddb
prev_chunk_id: chunk-0113
next_chunk_id: chunk-0115
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### **Main Power POWER 1 | Port: `POWER1`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VDD_5V_BRICK | IN | 5 V | Red/Gray | Supply to AP from Power Brick |
| 2 | VDD_5V_BRICK | IN | 5 V | Red/Gray | Supply to AP from Power Brick |
| 3 | BATT_CURRENT_SENS_PROT |  | 3.3 V | Black | Battery Current Connecter |
| 4 | BATT_CURRENT_VOLTAGE_PROT | IN | 3.3 V | Black | Battery Voltage Connecter |
| 5 | GND |  | GND | Black | GND |
| 6 | GND |  | GND | Black | GND | ### **Backup Power POWER 2 | Port: `POWER2`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VDD_5V_BRICK | IN | 5 V | Red/Gray | Supply to AP from Power Brick |
| 2 | VDD_5V_BRICK | IN | 5 V | Red/Gray | Supply to AP from Power Brick |
| 3 | AUX_BATT_CURRENT_SENS |  | 3.3 V | Black | Aux Battery Current Connecter |
| 4 | AUX_BATT_VOLTAGE_SENS | IN | 3.3 V | Black | Aux Battery Voltage Connecter |
| 5 | GND |  | GND | Black | GND Connection |
| 6 | GND |  | GND | Black | GND | ### **CPPM / S.BUS / SERVO SYSTEM | Port: `RCIN`** **`MAIN OUT`** **`AUX OUT`** | Pin Number | Name | I/O | Voltage | Definition |
| --- | --- | --- | --- | --- |
| S - 1 | Secondary_FMU_CH1_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 2 | Secondary_FMU_CH2_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 3 | Secondary_FMU_CH3_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 4 | Secondary_FMU_CH4_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 5 | Secondary_FMU_CH5_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 6 | Secondary_FMU_CH6_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 7 | Primary_FMU_CH1_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 8 | Primary_FMU_CH2_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 9 | Primary_FMU_CH3_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 10 | Primary_FMU_CH4_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 11 | Primary_FMU_CH5_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 12 | Primary_FMU_CH6_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 13 | Primary_FMU_CH7_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 14 | Primary_FMU_CH8_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 15 | PPM_SBUS_PROT | IN/OUT | 3.3 V / 4.5 V Powered | PPM / S.Bus Signal, goes to both Primary and Secondary FMU |

--- chunk_id: chunk-0115
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 666
content_hash: 909c838bd4c4a24f
prev_chunk_id: chunk-0114
next_chunk_id: chunk-0116
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### **CPPM / S.BUS / SERVO SYSTEM | Port: `RCIN`** **`MAIN OUT`** **`AUX OUT`** | Pin Number | Name | I/O | Voltage | Definition |
| --- | --- | --- | --- | --- |
| S - 1 | Secondary_FMU_CH1_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 2 | Secondary_FMU_CH2_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 3 | Secondary_FMU_CH3_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 4 | Secondary_FMU_CH4_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 5 | Secondary_FMU_CH5_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 6 | Secondary_FMU_CH6_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 7 | Primary_FMU_CH1_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 8 | Primary_FMU_CH2_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 9 | Primary_FMU_CH3_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 10 | Primary_FMU_CH4_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 11 | Primary_FMU_CH5_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 12 | Primary_FMU_CH6_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 13 | Primary_FMU_CH7_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 14 | Primary_FMU_CH8_PROT | OUT | 3.3 V Servo Signal, Servo Rail Power | PWM Signal |
| S - 15 | PPM_SBUS_PROT | IN/OUT | 3.3 V / 4.5 V Powered | PPM / S.Bus Signal, goes to both Primary and Secondary FMU | ### **SERIAL 2 / UART 2 | Port: `TELEM2`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC |
| 2 | SERIAL_2_TX | OUT | 3.3 V - 5.0 V TTL | Orange/Black | UART 2 TX (Transmit Data) |
| 3 | SERIAL_2_RX | IN | 3.3 V - 5.0 V TTL | Green/Black | UART 2 RX (Receive Data) |
| 4 | SERIAL_2_CTS (TX) | OUT | 3.3 V - 5.0 V TTL | Gray/Black | UART 2 CTS (Clear To Send) |
| 5 | SERIAL_2_RTS (RX) | IN | 3.3 V - 5.0 V TTL | Gray/Black | UART 2 RTS (Request To Send) |
| 6 | GND |  | GND | Black | GND |

--- chunk_id: chunk-0116
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 537
content_hash: cb030821b33f9faf
prev_chunk_id: chunk-0115
next_chunk_id: chunk-0117
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### **SERIAL 2 / UART 2 | Port: `TELEM2`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC |
| 2 | SERIAL_2_TX | OUT | 3.3 V - 5.0 V TTL | Orange/Black | UART 2 TX (Transmit Data) |
| 3 | SERIAL_2_RX | IN | 3.3 V - 5.0 V TTL | Green/Black | UART 2 RX (Receive Data) |
| 4 | SERIAL_2_CTS (TX) | OUT | 3.3 V - 5.0 V TTL | Gray/Black | UART 2 CTS (Clear To Send) |
| 5 | SERIAL_2_RTS (RX) | IN | 3.3 V - 5.0 V TTL | Gray/Black | UART 2 RTS (Request To Send) |
| 6 | GND |  | GND | Black | GND | ### **SERIAL 4 / UART 4 / I2C 2 | Port: `GPS2`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC Power Supply To GPS From AP |
| 2 | SERIAL_4_TX | OUT | 3.3 V - 5.0 V TTL | Orange/Black | UART 4 TX (Transmit Data) |
| 3 | SERIAL_4_RX | IN | 3.3 V - 5.0 V TTL | Green/Black | UART 4 RX (Receive Data) |
| 4 | I2C_2_SCL | OUT | 3.3 V - 5.0 V | Gray/Black | I2C 2 Clock Signal |
| 5 | I2C_2_SDA | IN | 3.3 V - 5.0 V | Gray/Black | I2C 2 Serial Data |
| 6 | GND |  | GND | Black | GND | ### **CAN 3 | Port: `CAN3`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC Power Supply |
| 2 | CAN_H_2 | IN/OUT | 12 V | Orange/Black | CAN High |
| 3 | CAN_L_2 | IN/OUT | 12 V | Green/Black | CAN Low |
| 4 | GND |  | GND | Black | GND |

--- chunk_id: chunk-0117
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 520
content_hash: 372d8473de687057
prev_chunk_id: chunk-0116
next_chunk_id: chunk-0118
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### **CAN 3 | Port: `CAN3`** | Pin Number | Name | I/O | Voltage | Cable Color | Definition |
| --- | --- | --- | --- | --- | --- |
| 1 | VCC_5V | OUT | 5 V | Red/Gray | VCC Power Supply |
| 2 | CAN_H_2 | IN/OUT | 12 V | Orange/Black | CAN High |
| 3 | CAN_L_2 | IN/OUT | 12 V | Green/Black | CAN Low |
| 4 | GND |  | GND | Black | GND | ### **Ethernet: `ETH1`** | Pin Number | Name | I/O | Desciption |
| --- | --- | --- | --- |
| 1 | TXP/RXP | IN/OUT | Ethernet TXP/RXP Auto-MDIX support |
| 2 | TXN/RXN | IN/OUT | Ethernet TXN/RXN Auto-MDIX support |
| 3 | RXP/TXP | IN/OUT | Ethernet RXP/TXP Auto-MDIX support |
| 4 | NC |  | No connect |
| 5 | NC |  | No connect |
| 6 | RXN/TXN | IN/OUT | Ethernet RXN/TXN Auto-MDIX support |
| 7 | NC |  | No connect |
| 8 | NC |  | No connect | ### **DSI / Timestamp / Boot| Port: `DSI`** | Pin Number | Name | I/O | Definition |
| --- | --- | --- | --- |
| 1 | IO_BOOT_0 | OUT | IO Boot |
| 2 | FMU_BOOT_0 | OUT | FMU Boot |
| 3 | TIMESTAMP_RTC | OUT | Timestamp |
| 4 | GND |  | GND |
| 5 | DSI_CKP | OUT | MIPI DSI Host Clock Positive |
| 6 | DSI_CKN | OUT | MIPI DSI Host Clock Negative |
| 7 | GND |  | GND |
| 8 | DSI_D0P | OUT | MIPI DSI Host DATA 0 Positive |
| 9 | DSI_D0N | OUT | MIPI DSI Host DATA 0 Negative |
| 10 | GND |  | GND |
| 11 | DSI_D1P | OUT | MIPI DSI Host DATA 1 Positive |
| 12 | DSI_D1N | OUT | MIPI DSI Host DATA 1 Negative |
| 13 | GND |  | GND |
| 14 | IO_DAC | OUT | IO analog output |
| 15 | FMU_DAC | OUT | FMU analog output |

--- chunk_id: chunk-0118
source_document: cube-red-standard-carrier-board-pinout.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 281
content_hash: 6c751f80be9247e7
prev_chunk_id: chunk-0117
next_chunk_id: chunk-0119
section_heading: Cube Red 80-Pin DF17 Connector
document_type: technical_reference

### **DSI / Timestamp / Boot| Port: `DSI`** | Pin Number | Name | I/O | Definition |
| --- | --- | --- | --- |
| 1 | IO_BOOT_0 | OUT | IO Boot |
| 2 | FMU_BOOT_0 | OUT | FMU Boot |
| 3 | TIMESTAMP_RTC | OUT | Timestamp |
| 4 | GND |  | GND |
| 5 | DSI_CKP | OUT | MIPI DSI Host Clock Positive |
| 6 | DSI_CKN | OUT | MIPI DSI Host Clock Negative |
| 7 | GND |  | GND |
| 8 | DSI_D0P | OUT | MIPI DSI Host DATA 0 Positive |
| 9 | DSI_D0N | OUT | MIPI DSI Host DATA 0 Negative |
| 10 | GND |  | GND |
| 11 | DSI_D1P | OUT | MIPI DSI Host DATA 1 Positive |
| 12 | DSI_D1N | OUT | MIPI DSI Host DATA 1 Negative |
| 13 | GND |  | GND |
| 14 | IO_DAC | OUT | IO analog output |
| 15 | FMU_DAC | OUT | FMU analog output | The following Github link can be used to revise and update the Cube Red Standard Carrier Board Pinout information**:**

--- chunk_id: chunk-0119
source_document: edu450-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 156
content_hash: 42889958d590de8a
prev_chunk_id: chunk-0118
next_chunk_id: chunk-0120
section_heading: **Introduction**
document_type: technical_reference

## **Introduction**

*EDU450 Carrier Board*


The EDU-450 carrier board is a highly integrated component designed to fit seamlessly into the EDU-450 drone frame. Its primary purpose is to minimize the common wire and module entanglement issues that are often experienced during multi-rotor assembly. The board offers a range of features, such as built-in power distribution, redundant power supplies for the autopilot, fail-over power selection built-in as a backup, a dedicated payload power regulator, etc. It is primarily designed with geometric optimization for quadcopters, X8 configurations, and octocopters. It also provides connections for all the functions supported by The Cube. As a result, it can be easily integrated into any vehicle type that is compatible with The Cube.

--- chunk_id: chunk-0120
source_document: edu450-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 481
content_hash: 5253f7f5a0f00051
prev_chunk_id: chunk-0119
next_chunk_id: chunk-0121
section_heading: Features
document_type: technical_reference

## Features

* Up to 8-cell Lithium battery (36V)
* 100A continuous current
* Power and signal for ESCs
* 5V navigation light port
* Built-in power distribution unit (PDU)
* Built-in Hall effect voltage and current sensor
* Redundant power supplies for flight critical components
* Built-in 5V/10A, 7V/1.5A BEC
* Main power failure indicator lights
* Connectors for all functions of The Cube
* RS485 and SPI ports

### Power
The carrier board incorporates a built-in voltage and Hall current sensor. The main battery can be connected to the XT60 "MAIN PWR" port on the board, removing the need for an external power brick. The power distribution system is rated to distribute 100A in total to the ESCs when under stagnant, room-temperature air conditions. If the EDU450 carrier board is installed within an enclosure or used in challenging conditions, such as high temperatures, the current capacity rating needs to be reduced. For vehicles operating consistently at high currents, conduct a ground test first by using a temperature gun to assess the thermal performance. The carrier board incorporates a built-in voltage and Hall current sensor. The main battery can be connected to the XT60 "MAIN PWR" port on the board, removing the need for an external power brick. The power distribution system is rated to distribute 100A in total to the ESCs when under stagnant, room-temperature air conditions. If the EDU450 carrier board is installed within an enclosure or used in challenging conditions, such as high temperatures, the current capacity rating needs to be reduced. For vehicles operating consistently at high currents, conduct a ground test first by using a temperature gun to assess the thermal performance. To ensure the built-in sensors on the EDU-450 board accurately read the voltage and current numbers, complete the following steps:

1. Go to Mission Planner. 2. Go to **Config/Tuning** -> **Full Parameter List**. 3. Configure the following parameters to the values shown below. | Parameter          | Value |
| ------------------ | ----- |
| BATT_AMP_OFFSET  | 0.25  |
| BATT_AMP_PERVOLT | 50    |
| BATT_CURR_PIN    | 3     |
| BATT_MONITOR      | 4     |
| BATT_VOLT_MULT   | 12.05 |
| BATT_VOLT_PIN    | 2     |

--- chunk_id: chunk-0121
source_document: edu450-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 308
content_hash: 970b1bbdd33b3dde
prev_chunk_id: chunk-0120
next_chunk_id: chunk-0122
section_heading: Specification
document_type: technical_reference

## Specification

**Size**: 170 mm x 145 mm

**Weight**: 185g (with carbon fiber plate)

### **Port Interface**
### RS485 and SPI

The carrier board introduces enhancements such as anti-interference capabilities, high-sensitivity RS485, and a full-duplex, high-speed, synchronous serial communication SPI interface. This interface can be used to connect with Profi-LED or various industrial equipment, thereby offering increased communication support for the extended hardware and a wider range of applications. ### Customized Port for HerePro

The carrier board features a dedicated HerePro interface designed for data streamlining, debugging, and power supply functions. This single connection point enhances the overall integration and minimizes excess wiring. ### ADS-B External Antenna

The integrated ADS-B system is used to receive air traffic information. You can connect an external antenna to the standard SMA interface to extend the data reception range. ### HereLink Airunit Installation

> Connect the receiver to the PPM port, as shown in the figure below. The two SBUS ports are configured for output. ### 5V BEC

The board can supply 5V to the Main and AUX rails by bridging the following pad with solder. ### ProfiLed

The board has four built-in ProfiLed interfaces for connecting and controlling navigation lights. ### ESC Port

The ESCs use the Amass-MR30 connector to power the motor and transmit the PWM signals. The eight ESC ports are for multi-rotor UAVs with either four rotors or eight coaxial rotors.

--- chunk_id: chunk-0122
source_document: edu450-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 521
content_hash: 83e7ede124e3213b
prev_chunk_id: chunk-0121
next_chunk_id: chunk-0123
section_heading: Pin Identification
document_type: technical_reference

## Pin Identification
### ProfiLED | Pin Number | Name    |
| ---------- | ------- |
| 1          | 5V_LED |
| 2          | CI      |
| 3          | DI      |
| 4          | CO      |
| 5          | DO      |
| 6          | GND     |
| 7          | GND     | ### SPI | Pin Number | Name |
| ---------- | ---- |
| 1          | 5V   |
| 2          | MOSI |
| 3          | MISO |
| 4          | SCK  |
| 5          | CS   |
| 6          | GND  | ### 485 | Pin Number | Name |
| ---------- | ---- |
| 1          | Y    |
| 2          | Z    |
| 3          | B    |
| 4          | A    | ### I2C | Pin Number | Name        |
| ---------- | ----------- |
| 1          | VCC_5V     |
| 2          | I2C_2_SCL |
| 3          | I2C_2_SDA |
| 4          | GND         | ### BUZZER | Pin Number | Name   |
| ---------- | ------ |
| 1          | BUZZER |
| 2          | GND    | ### SBUS | Pin Number | Name        |
| ---------- | ----------- |
| 1          | S.bus out 1 |
| 2          | S.bus out 2 |
| 3          | GND         | ### 5V (BEC POWER) | Pin Number | Name |
| ---------- | ---- |
| 1          | 5V   |
| 2          | 5V   |
| 3          | 5V   |
| 4          | GND  |
| 5          | GND  |
| 6          | GND  | ### CAN | Pin Number | Name    |
| ---------- | ------- |
| 1          | VCC_5V |
| 2          | CAN_H  |
| 3          | CAN_L  |
| 4          | GND     | ### Serial (Uart)

**SERIAL 1 | Telem 1** | Pin Number | Name                |
| ---------- | ------------------- |
| 1          | VCC_5V             |
| 2          | SERIAL_1_TX       |
| 3          | SERIAL_1_RX       |
| 4          | SERIAL_1_CTS (TX) |
| 5          | SERIAL_1_RTS (RX) |
| 6          | GND                 | **SERIAL 2 |Telem 2** | Pin Number | Name                |
| ---------- | ------------------- |
| 1          | VCC_5V             |
| 2          | SERIAL_2_TX       |
| 3          | SERIAL_2_RX       |
| 4          | SERIAL_2_CTS (TX) |
| 5          | SERIAL_2_RTS (RX) |
| 6          | GND                 |

--- chunk_id: chunk-0123
source_document: edu450-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 337
content_hash: 92f674624f1f1672
prev_chunk_id: chunk-0122
next_chunk_id: chunk-0124
section_heading: Pin Identification
document_type: technical_reference

**SERIAL 2 |Telem 2** | Pin Number | Name                |
| ---------- | ------------------- |
| 1          | VCC_5V             |
| 2          | SERIAL_2_TX       |
| 3          | SERIAL_2_RX       |
| 4          | SERIAL_2_CTS (TX) |
| 5          | SERIAL_2_RTS (RX) |
| 6          | GND                 | **SERIAL 3** | Pin Number | Name                |
| ---------- | ------------------- |
| 1          | VCC_5V             |
| 2          | SERIAL_3_TX       |
| 3          | SERIAL_3_RX       |
| 4          | SERIAL_3_CTS (TX) |
| 5          | SERIAL_3_RTS (RX) |
| 6          | GND                 | **SERIAL 4** | Pin Number | Name                |
| ---------- | ------------------- |
| 1          | VCC_5V             |
| 2          | SERIAL_4_TX       |
| 3          | SERIAL_4_RX       |
| 4          | SERIAL_4_CTS (TX) |
| 5          | SERIAL_4_RTS (RX) |
| 6          | GND                 | ### ADC | Pin Number | Name              |
| ---------- | ----------------- |
| 1          | VDD_5V_Periph   |
| 2          | Pressure sense in |
| 3          | GND               | ### Debug

**IO_DEBUG** | Pin Number | Name  |
| ---------- | ----- |
| 1          | GND   |
| 2          | SWCLK |
| 3          | SWDIO |
| 4          | NC    |
| 5          | NC    |
| 6          | 5V    | **FMU_DEBUG** | Pin Number | Name  |
| ---------- | ----- |
| 1          | GND   |
| 2          | SWCLK |
| 3          | SWDIO |
| 4          | NC    |
| 5          | NC    |
| 6          | 5V    |

--- chunk_id: chunk-0124
source_document: edu450-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 38
content_hash: ea3b7ec85d66d67b
prev_chunk_id: chunk-0123
next_chunk_id: chunk-0125
section_heading: Indication LED
document_type: technical_reference

## Indication LED
### **Main Power Failure if LED is ON**

The following Github link can be used to revise and update the EDU450 carrier board information**:** \
[**https://github.com/CubePilot/cubepilot-docs/blob/master/carrier-boards/edu450-carrier-board.md**](https://github.com/CubePilot/cubepilot-docs/blob/master/carrier-boards/edu450-carrier-board.md)

--- chunk_id: chunk-0125
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 301
content_hash: eb948f06b764145c
prev_chunk_id: chunk-0124
next_chunk_id: chunk-0126
section_heading: Introduction
document_type: technical_reference

## Introduction

*Kore Carrier Board*


The primary purpose of the Kore Multi-Rotor Carrier Board is to minimize the entangled wiring and modules typically associated with a multi-rotor assembly. It provides many features, such as built-in power distribution, redundant power supplies for the autopilot, built-in fail-over power selection, and a separate payload power regulator. Although this carrier board is geometrically optimized for quadcopters, X8 configurations, and octocopters, it provides connections that can support the various functions supported by The CUBE. Thus, it can be integrated into any vehicle type supported by The Cube, which includes various multi-rotor frame types, planes, rovers, submarines, and antenna trackers. ![](/files/-LlL-fF38oCrh6A7n91l)

### Features
* Up to 12-cell Lithium battery (50.4V)
* 140A continuous current with 280A surges
* Power and signal for ESCs located at the corners
* 12V navigation light power available at each corner
* Built-in power distribution
* Built-in voltage and current sense
* Redundant power supplies for flight critical components
* Payload connectors with resettable fuses for 5V, 12V, and direct battery power
* Power Good and Power Error indicator lights
* Built-in buzzer with volume control
* Connectors for every function of The Cube
* Easily accessible PWM voltage level selector (3.3V or 5V)
* Resistant to ground bounce on PWM signal
* Connector-compatible with Standard carrier board
* Connector ports for debugging I/O and FMU processors

--- chunk_id: chunk-0126
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 226
content_hash: f2e98c2adc3f5075
prev_chunk_id: chunk-0125
next_chunk_id: chunk-0127
section_heading: Power
document_type: technical_reference

## Power

The system battery should be connected directly to the large pads labeled “MAIN PWR”. These Pads are located at the top and bottom of the board. No external power brick is necessary, as voltage and current sense is done directly on the board. Pay special attention to the polarity symbols, as there is no reverse protection. Batteries up to 12S or 50.4V can be used. The power distribution system is rated to supply 140A to the ESCs when exposed to stagnant room-temperature air, with current surges reaching up to 280A. If the board encounters continuous airflow (exposed to prop wash during flight), significantly higher currents can be supported. Alternatively, if the board is mounted within an enclosure or if flown on a very hot day, it may be necessary to de-rate the current capacity. For users that expect to operate the vehicle continuously at high currents (over 100A), conduct ground testing with a temperature gun prior to flight. The surface of the carrier board should never exceed 100°C.

--- chunk_id: chunk-0127
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 522
content_hash: ea557d1d41f6a26c
prev_chunk_id: chunk-0126
next_chunk_id: chunk-0128
section_heading: Ensuring the Built-In Sensors Accurately Read the Voltage and Current
document_type: technical_reference

## Ensuring the Built-In Sensors Accurately Read the Voltage and Current

Some parameters need to be configured to ensure the built-in sensors on the board accurately read the voltage and current. See below for the steps:

### **Method 1**

1. Open Mission Planner. 2. Connect The Cube to Mission Planner. 3. If Mission Planner was just installed, click **Config** -> **Planner** and select **"*****Advanced*****"** for the **Layout.**
4. Click **Config** -> **Full Parameter List.**
5. Download this [parameter file](http://docs.spektreworks.com/assets/params/Multirotor_PCB_Power.param). 6. Click **Load from file** to upload the file to Mission Planner. 7. Click **Write Params**. 8. Reboot The Cube. ### **Method 2**

1. Open Mission Planner. 2. Connect The Cube to Mission Planner. 3. If Mission Planner was just installed, click **Config** -> **Planner** and select **"*****Advanced*****"** for the **Layout.**
4. Click **Config** -> **Full Parameter List.**
5. Configure the BATT_Monitor value to "4". 6. Click **Write Params**. 7. Reboot The Cube. 8. Click **Config** -> **Full Parameter List.**
9. Set the following parameters to the values shown in the table. | Parameter          | Value |
| ------------------ | ----- |
| BATT_AMP_OFFSET  | 0.45  |
| BATT_AMP_PERVOLT | 50    |
| BATT_CURR_PIN    | 3     |
| BATT_VOLT_MULT   | 15.3  |
| BATT_VOLT_PIN    | 2     | 10. Click **Write Params**. ### General Use Payload Power Connectors

Three general-purpose power connectors, labeled J1, J14, and J19, are provided to supply power to external devices and payloads. Molex Clik-Mate power connectors are used. | Reference | Voltage         | Max Current | Pinout                 | Mating Part Number |
| --------- | --------------- | ----------- | ---------------------- | ------------------ |
| J1        | Battery Voltage | 3A          | 1-3: Battery, 4-6: GND | Molex 5023800600   |
| J14       | 5.3V            | 1.5A        | 1-2: 5.3V, 3-4: GND    | Molex 5023800400   |
| J19       | 12.2V           | 2A          | 1-2: 12.2V, 3-5: GND   | Molex 5023800500   | The battery voltage and 5.3V power connectors are independently fused with resettable fuses. If a short circuit occurs, the fuse will cut power to the affected connector. When this happens, complete the following steps:

1. Remove the power source that is providing the excessive current. 2. Wait for a couple of minutes for the fuse to reset. > If the external device uses too much current and the fuse does not immediately cut power, it may damage the carrier board.

--- chunk_id: chunk-0128
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: e916280922e9d656
prev_chunk_id: chunk-0127
next_chunk_id: chunk-0129
section_heading: Ensuring the Built-In Sensors Accurately Read the Voltage and Current
document_type: technical_reference

Wait for a couple of minutes for the fuse to reset. > If the external device uses too much current and the fuse does not immediately cut power, it may damage the carrier board. Cubepilot is not responsible for any damage caused by external devices. ### ESC Connections

Solder pads for ESC power are located at each corner of the board. The power wires from the ESCs can be soldered to the pads on either the top or bottom of the board. Next to the ESC power pads are 3x3 0.1” header pins. The bottom row of these pins provides power for navigation lights. * **Right pin**: Ground
* **Center pin**: Supplies 12V
* **Left pin**: Unused and should be removed. > Do not plug an ESC cable into the bottom row of this connector. The top two rows of pins are for the ESC PWM signal. These pins correspond to two of the **Main Out** connections of The Cube. * S: PWM signal
* +: Power
* \-: Ground

All eight Main Out connections are available at the four corners of the board. Check the header pins from the side to determine which row corresponds to which label. ![PWMPins_v1_3_1](/files/-LlL3L7tZqFg_Gz1uemT)

By default, the board does not supply power to the ESC PWM connections. However, if no BEC is available to power the ESCs, bridge JP1 with solder to provide 5.3V from the board to the ESCs. > Do not plug a BEC into the ESC connections when JP1 is bridged with solder. ![](/files/-LlLpqu8Oz_yWESZL-VO)

Most commercially available ESCs expect 3.3V PWM signals from the autopilot to control the motor. This is the default setting of The CUBE. To change to 5V PWM signals, use a pen or a pointed tool to move the switch, which is located on the right side of the board and labeled as **3V PWM** / **5V PWM**. ![](/files/-LlLq15sx6_uO6GQz4rz)

### Aux Pins

There are six “Aux Out” connections located within a 3x8 group of headers on the right side of the board. The pins are labeled for easy identification. By default, the board does not supply power to the center pins of the Aux channels. An external power supply connected to these pins will supply power to all the Aux pins, but it will be isolated from the rest of the board.

--- chunk_id: chunk-0129
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 162
content_hash: febf1de6f76b9a0e
prev_chunk_id: chunk-0128
next_chunk_id: chunk-0130
section_heading: Ensuring the Built-In Sensors Accurately Read the Voltage and Current
document_type: technical_reference

By default, the board does not supply power to the center pins of the Aux channels. An external power supply connected to these pins will supply power to all the Aux pins, but it will be isolated from the rest of the board. Alternatively, by bridging the pads of JP2 with solder, the board can provide 5.3V to the Aux rail. > * Use on-board power only for low-noise and low-power devices. * Do not use servo motors with on-board power. * Do not connect an external power supply to the Aux pins if JP2 is bridged with solder. ![](/files/-LlLqKIT3jiRvjqltsO9) | Pin Label | Description |
| --------- | ----------- |
| SBUS      | SBUS Out    |
| PPM       | Rcin        |

--- chunk_id: chunk-0130
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 561
content_hash: 0e519fe410a5fd5a
prev_chunk_id: chunk-0129
next_chunk_id: chunk-0131
section_heading: Motor Pin Assignments
document_type: technical_reference

## Motor Pin Assignments

By default, the Motor PWM pins on the carrier board are arranged for easy integration with a standard quadcopter. For other vehicle or frame types (including X8, Hex, Octo, etc.), it is necessary to re-map the motor outputs to the correct corners on the board. This can be done using ArduCopter Firmware v3.5.0 or above. When re-mapping PWM outputs with Ardupilot, it is important to distinguish the motor number from the output number. **Motor number**: Refers to the physical location of the motor and does not change. The following graphic shows the motor numbers used by the ArduCopter firmware. ![](/files/-LlLqVnl7ePIRXat9ZLt)

**Output number**: Refers to the physical pin on the board to which each motor is assigned. These pins are labeled "MAIN1" to "MAIN8" and are located on the board's corners. Any motor number can be re-mapped to any output. This is done by setting the SERVOX_FUNCTION (where x is the output number) to the appropriate value shown in the table below. | Required Motor Number | SERVORX_FUNCTION Value |
| --------------------- | ----------------------- |
| 1                     | 33                      |
| 2                     | 34                      |
| 3                     | 35                      |
| 4                     | 36                      |
| 5                     | 37                      |
| 6                     | 38                      |
| 7                     | 39                      |
| 8                     | 40                      | For example, to plug Motor 3 into the MAIN5 connector on the board, set the SERVO5_FUNCTION parameter to 35. ### Hexa Setup

To configure the carrier board for a hexacopter, complete the following steps:

1. Mount The Cube to the carrier board. 2. Open Mission Planner. 3. Connect The Cube to Mission Planner. 4. If Mission Planner was just installed, click **Config** -> **Planner** and select **"*****Advanced*****"** for the **Layout.**
5. Flash The Cube with ArduCopter 3.5.0 or above. 6. Click **Setup** -> **Mandatory Hardware -> Frame Type**. 7. Select the frame picture with six motors arranged in a radial pattern for the **Frame Class** and choose a **Frame Type**. 8. Reboot The CUBE
9. Click **Config** -> **Full Parameter List**. 10. Set the following parameters to the values shown in the table below. This can be done in two ways:

    * Enter the values manually. * Download this [parameter file ](http://docs.spektreworks.com/assets/params/Multirotor_PCB_HEX.param)and then click **Load from file** to upload it to Mission Planner. | Parameter        | Value |
| ---------------- | ----- |
| SERVO1_FUNCTION | 37    |
| SERVO2_FUNCTION | 38    |
| SERVO3_FUNCTION | 35    |
| SERVO4_FUNCTION | 36    |
| SERVO5_FUNCTION | 34    |
| SERVO6_FUNCTION | 33    |

--- chunk_id: chunk-0131
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: 48050d2d60ce4533
prev_chunk_id: chunk-0130
next_chunk_id: chunk-0132
section_heading: Motor Pin Assignments
document_type: technical_reference

* Download this [parameter file ](http://docs.spektreworks.com/assets/params/Multirotor_PCB_HEX.param)and then click **Load from file** to upload it to Mission Planner. | Parameter        | Value |
| ---------------- | ----- |
| SERVO1_FUNCTION | 37    |
| SERVO2_FUNCTION | 38    |
| SERVO3_FUNCTION | 35    |
| SERVO4_FUNCTION | 36    |
| SERVO5_FUNCTION | 34    |
| SERVO6_FUNCTION | 33    | 11. Click **Write Params**. 12. Reboot The Cube. 13. Connect the ESCs, as shown in the table below. | Motor Number | Output |
| ------------ | ------ |
| 1            | MAIN6  |
| 2            | MAIN5  |
| 3            | MAIN3  |
| 4            | MAIN4  |
| 5            | MAIN1  |
| 6            | MAIN2  | ### Octa Setup

To configure the carrier board for a flat octacopter, complete the following steps:

1. Mount The Cube to the carrier board. 2. Open Mission Planner. 3. Connect The Cube to Mission Planner. 4. If Mission Planner was just installed, click **Config** -> **Planner** and select **"*****Advanced*****"** for the **Layout.**
5. Flash The Cube with ArduCopter 3.5.0 or above. 6. Click **Setup** -> **Mandatory Hardware -> Frame Type**. 7. Select the frame picture with eight motors arranged in a radial pattern for the **Frame Class** and choose a **Frame Type**. 8. Reboot The CUBE. 9. Click **Config** -> **Full Parameter List**. 10. Set the following parameters to the values shown in the table below. This can be done in two ways:

    * Enter the values manually. * Download this [parameter file ](http://docs.spektreworks.com/assets/params/Multirotor_PCB_OCTA.param)and then click **Load from file** to upload it to Mission Planner. | Parameter        | Value |
| ---------------- | ----- |
| SERVO1_FUNCTION | 33    |
| SERVO2_FUNCTION | 34    |
| SERVO3_FUNCTION | 39    |
| SERV04_FUNCTION | 36    |
| SERVO5_FUNCTION | 37    |
| SERVO6_FUNCTION | 35    |
| SERVO7_FUNCTION | 40    |
| SERVO8_FUNCTION | 38    | 11. Click **Write Params**. 12. Reboot The Cube. 13. Connect the ESCs, as shown in the table below. | Motor Number | Output |
| ------------ | ------ |
| 1            | MAIN1  |
| 2            | MAIN2  |
| 3            | MAIN6  |
| 4            | MAIN4  |
| 5            | MAIN5  |
| 6            | MAIN8  |
| 7            | MAIN3  |
| 8            | MAIN7  |

--- chunk_id: chunk-0132
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 401
content_hash: 55d5b0caed0e1631
prev_chunk_id: chunk-0131
next_chunk_id: chunk-0133
section_heading: Motor Pin Assignments
document_type: technical_reference

Connect the ESCs, as shown in the table below. | Motor Number | Output |
| ------------ | ------ |
| 1            | MAIN1  |
| 2            | MAIN2  |
| 3            | MAIN6  |
| 4            | MAIN4  |
| 5            | MAIN5  |
| 6            | MAIN8  |
| 7            | MAIN3  |
| 8            | MAIN7  | ### X-8 Setup

To configure the carrier board for an X-8 (OctaQuad), complete the following steps:

1. Mount The Cube to the carrier board. 2. Open Mission Planner. 3. Connect The Cube to Mission Planner. 4. If Mission Planner was just installed, click **Config** -> **Planner** and select **"*****Advanced*****"** for the **Layout.**
5. Flash The Cube with ArduCopter 3.5.0 or above. 6. Click **Setup** -> **Mandatory Hardware** -> **Frame Type**. 7. Select the frame picture with eight motors arranged in a square pattern, with one motor stacked on top of another at each corner. Then, choose a **Frame Type**. 8. Reboot The CUBE. 9. Click **Config** -> **Full Parameter List**. 10. Set the following parameters to the values shown in the table below. This can be done in two ways:

    * Enter the values manually. * Download this [parameter file](http://docs.spektreworks.com/assets/params/Multirotor_PCB_X8.param)[ ](http://docs.spektreworks.com/assets/params/Multirotor_PCB_OCTA.param)and then click **Load from file** to upload it to Mission Planner. | Parameter        | Value |
| ---------------- | ----- |
| SERVO2_FUNCTION | 35    |
| SERVO3_FUNCTION | 34    | 11. Click **Write Params**. 12. Reboot The Cube. 13. Connect the ESCs, as shown in the table below. | Motor Number | Output |
| ------------ | ------ |
| 1            | MAIN1  |
| 2            | MAIN3  |
| 3            | MAIN2  |
| 4            | MAIN4  |
| 5            | MAIN5  |
| 6            | MAIN6  |
| 7            | MAIN7  |
| 8            | MAIN8  |

--- chunk_id: chunk-0133
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 558
content_hash: 8092434156d310da
prev_chunk_id: chunk-0132
next_chunk_id: chunk-0134
section_heading: Digital and Analog Connectors
document_type: technical_reference

## Digital and Analog Connectors

The Kore carrier board has the same JST-brand receptacles as the standard carrier board, with a few exceptions. The tables below show the pin-out of each JST connector. ### Telemetry 1 | Name | Label | Pins            |
| ---- | ----- | --------------- |
| TLM1 | J4    | 1. 5V           |
|      |       | 2. Serial 1 TX  |
|      |       | 3. Serial 1 RX  |
|      |       | 4. Serial 1 CTS |
|      |       | 5. Serial 1 RTS |
|      |       | 6. GND          | ### Telemetry 2 | Name | Label | Pins            |
| ---- | ----- | --------------- |
| TLM2 | J8    | 1. 5V           |
|      |       | 2. Serial 2 TX  |
|      |       | 3. Serial 2 RX  |
|      |       | 4. Serial 2 CTS |
|      |       | 5. Serial 2 RTS |
|      |       | 6. GND          | ### GPS1 (SER3/I2C1) | Name      | Label | Pins             |
| --------- | ----- | ---------------- |
| SER3/I2C1 | J2    | 1. 5V            |
|           |       | 2. Serial 3 TX   |
|           |       | 3. Serial 3 RX   |
|           |       | 4. SCL1          |
|           |       | 5. SDA1          |
|           |       | 6. Safety Button |
|           |       | 7. Safety LED    |
|           |       | 8. GND           | ### GPS2 (SER4/I2C2) | Name       | Label | Pins           |
| ---------- | ----- | -------------- |
| SER4/ I2C2 | J18   | 1. 5V          |
|            |       | 2. Serial 4 TX |
|            |       | 3. Serial 4 RX |
|            |       | 4. SCL2        |
|            |       | 5. SDA2        |
|            |       | 6. GND         | ### I2C1 | Name | Label | Pins    |
| ---- | ----- | ------- |
| I2C1 | J3    | 1. 5V   |
|      |       | 2. SCL1 |
|      |       | 3. SDA1 |
|      |       | 4. GND  | ### I2C2 | Name | Label | Pins    |
| ---- | ----- | ------- |
| I2C2 | J7    | 1. 5V   |
|      | J15   | 2. SCL1 |
|      |       | 3. SDA1 |
|      |       | 4. GND  | ### CAN1 | Name | Label | Pins       |
| ---- | ----- | ---------- |
| CAN1 | J16   | 1. 5V      |
|      |       | 2. CAN1_H |
|      |       | 3. CAN1_L |
|      |       | 4. GND     |

--- chunk_id: chunk-0134
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: eae98aaa03153419
prev_chunk_id: chunk-0133
next_chunk_id: chunk-0135
section_heading: Digital and Analog Connectors
document_type: technical_reference

### CAN1 | Name | Label | Pins       |
| ---- | ----- | ---------- |
| CAN1 | J16   | 1. 5V      |
|      |       | 2. CAN1_H |
|      |       | 3. CAN1_L |
|      |       | 4. GND     | ### CAN2 | Name | Label | Pins       |
| ---- | ----- | ---------- |
| CAN2 | J6    | 1. 5V      |
|      |       | 2. CAN2_H |
|      |       | 3. CAN2_L |
|      |       | 4. GND     | ### SPI | Name | Label | Pins     |
| ---- | ----- | -------- |
| SPI  | J5    | 1. 5V    |
|      |       | 2. SCK   |
|      |       | 3. MISO  |
|      |       | 4. MOSI  |
|      |       | 5. \~NSS |
|      |       | 6. DRDY  |
|      |       | 7. GND   | > The SPI port is expected to be removed in future versions of this carrier board. ### ADC | Name | Label | Pins       |
| ---- | ----- | ---------- |
| ADC  | J13   | 1. 5V      |
|      |       | 2. ADC_IN |
|      |       | 3. NC      |
|      |       | 4. GND     | > The ADC_IN input voltage is divided by two using a symmetric 10kΩ voltage divider on the board. Do not exceed analog voltages above 6.6V on this pin. ### BATT2 Sense | Name        | Label | Pins                     |
| ----------- | ----- | ------------------------ |
| BATT2 SENSE | J17   | 1. 5V                    |
|             |       | 2. BATT2_Volt_Sense    |
|             |       | 3. BATT2_Current_Sense |
|             |       | 4. GND                   | In order to use the BATT2_Volt_Sense pin, a user-selected resistor must be soldered to the board. Use the following equation to determine the resistor value:

[![](https://latex.codecogs.com/gif.latex?R\&space;=\&space;3030\&space;*\&space;V_{max}-10000)](https://www.codecogs.com/eqnedit.php?latex=R\&space;=\&space;3030\&space;*\&space;V_{max}-10000)

* **Vmax**: Maximum voltage expected on this pin. * **R**: Resistance (Ohms)

When the value is calculated, a common through-hole style resistor should be soldered to the space labeled R46 underneath the board. ![](/files/-LlLv0aLVrbHcmblG0QP)

For The CUBE to accurately read the secondary voltage, the BATT2_VOLT_MULT parameter must be set. Use the following equation to calculate the value. [![](https://latex.codecogs.com/gif.latex?BATT2_VOLT_MULT=\frac{V_{max}}{3.3})](https://www.codecogs.com/eqnedit.php?latex=BATT2_VOLT_MULT=\frac{V_{max}}{3.3})

### Debug

Two debug connectors are provided for developer use. One debug header is provided for each processer on The CUBE.

--- chunk_id: chunk-0135
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 193
content_hash: d008c301b4551410
prev_chunk_id: chunk-0134
next_chunk_id: chunk-0136
section_heading: Digital and Analog Connectors
document_type: technical_reference

[![](https://latex.codecogs.com/gif.latex?BATT2_VOLT_MULT=\frac{V_{max}}{3.3})](https://www.codecogs.com/eqnedit.php?latex=BATT2_VOLT_MULT=\frac{V_{max}}{3.3})

### Debug

Two debug connectors are provided for developer use. One debug header is provided for each processer on The CUBE. The connector is from the JST brand and mates with SHR-06V-S-B or SHR-06V-S. | Name         | Label | Pins           |
| ------------ | ----- | -------------- |
| SER5/FMU DBG | J20   | 1. 3.3V        |
|              |       | 2. Serial 5 TX |
|              |       | 3. Serial 5 RX |
|              |       | 4. FMU-SWDIO   |
|              |       | 5. FMU-SWCLK   |
|              |       | 6. GND         | | Name   | Label | Pins                  |
| ------ | ----- | --------------------- |
| IO DBG | J21   | 1. 3.3V               |
|        |       | 2. IO-SERIAL1_TX     |
|        |       | 3. DSM/IO-SERIAL1_RX |
|        |       | 4. IO-SWDIO           |
|        |       | 5. IO-SWCLK           |
|        |       | 6. GND                |

--- chunk_id: chunk-0136
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 232
content_hash: 60e314b1905d5c80
prev_chunk_id: chunk-0135
next_chunk_id: chunk-0137
section_heading: Indicator Lights
document_type: technical_reference

## Indicator Lights

The carrier board has two indicator lights on the top surface labeled “Pwr” and “Err”. **Pwr Light:** Two independent 5V regulators provide power to The Cube and other peripherals. A constant blue light indicates both regulators are working. **Err Light:** A constant red light indicates one of the two regulators has failed. > * Do not fly the vehicle if the blue Pwr Light is not lit. * Do not fly the vehicle if the Err Light is lit. ![](http://docs.spektreworks.com/assets/images/light_truth_table.PNG)

### Buzzer and Volume Control
The carrier board includes a piezoelectric buzzer mounted on its underside. Thus, no external buzzer is needed. > Do not mount the board onto the vehicle in a way that muffles the buzzer sound. The carrier board has a volume control switch located at the front edge. * **Switch moved to the right**: Buzzer volume is at maximum volume. * **Switch moved to the left**: Buzzer volume is at a reduced level. > Never fly the vehicle with the buzzer volume set to a reduced level.

--- chunk_id: chunk-0137
source_document: kore-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 189
content_hash: 02c6268d36f32457
prev_chunk_id: chunk-0136
next_chunk_id: chunk-0138
section_heading: Mechanical Information
document_type: technical_reference

## Mechanical Information
### Mass

* **Without The Cube**: 79g
* **With The Cube**: 108g

### Outer Dimensions

![](http://docs.spektreworks.com/assets/images/carrier_board_dimensions.png)

### Mounting Hole Locations

![](http://docs.spektreworks.com/assets/images/carrier_board_holes.png)

### Errata
The pins on connector J3 should be labeled “SCL1” and “SDA1”, not “SCL2” and “SDA2”. The label “I2C1” next to the connector is correct. The l"SBUS" label refers to SBUS out, and the "PPM" label denotes Rcin. ### Disclaimer
Due to the complex nature of any drone vehicle, there are many causes of failure that may result in damaged components. SpektreWorks does not warranty the carrier board against damage caused by external devices (ESCs, motors, peripherals, etc.) or due to a crash. SpektreWorks will replace a carrier board that has a manufacturer defect within 30 days of purchase. The following Github link can be used to revise and update the Kore carrier board information**:** \
[**https://github.com/CubePilot/cubepilot-docs/blob/master/carrier-boards/kore-carrier-board.md**](https://github.com/CubePilot/cubepilot-docs/blob/master/carrier-boards/kore-carrier-board.md)

--- chunk_id: chunk-0138
source_document: airbot-mini-carrier-board-set-user-guide.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 74
content_hash: b25b94bb732aa9fe
prev_chunk_id: chunk-0137
next_chunk_id: chunk-0139
section_heading: Airbot Systems Mini Carrier Board
document_type: technical_reference

# Airbot Systems Mini Carrier Board

The Airbot Systems Mini carrier board integrates all the wiring into a 50.5 x 57.5mm board to save both space and weight. It comes with a mini power distribution board (PDB) that can deliver up to 180A. The ultra-compact setup ensures easy and clean mounting on various types of chassis.​

--- chunk_id: chunk-0139
source_document: airbot-mini-carrier-board-set-user-guide.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: 7f9fb01b085bee06
prev_chunk_id: chunk-0138
next_chunk_id: chunk-0140
section_heading: Dimensions
document_type: technical_reference

## Dimensions
### Features
* **Dual power inputs**: Provides redundancy; automatically switching to the second power source if the first one fails. * **Power distribution and voltage protection**: Provides current to each connector. * **Motor PWM signal distribution**: Supports up to eight motors. * **RC input**: Features a standard 2.54mm servo PPM/S.BUS/Spectrum RC input, with +5v/+3.3v selectable power from the carrier board. * **AUX VCC pins**: These pins are connected together, allowing the AUX rail to be powered externally. ### Interfaces | Port                         | Connector on the Board      | Mating Connector |
| ---------------------------- | --------------------------- | ---------------- |
| I2C_2 - CAN1 - CAN2         | JST GH: BM04B-GHS-TBT       | GHR-04V-S        |
| USB - TELEM1 - TELEM2 - GPS2 | JST GH: BM06B-GHS-TBT       | GHR-06V-S        |
| GPS1                         | JST GH: BM08B-GHS-TBT       | GHR-08V-S        |
| POWER1 - POWER2              | Molex CLIKMATE: 502443-0670 | 502439-0600      | > The Airbot Systems carrier board connectors are the same as those on the standard carrier board

--- chunk_id: chunk-0140
source_document: airbot-mini-carrier-board-set-user-guide.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 226
content_hash: b555651205d4d519
prev_chunk_id: chunk-0139
next_chunk_id: chunk-0141
section_heading: Pinout
document_type: technical_reference

## Pinout
### RC Signal and Power Selection
### Airbot Systems Power Distribution Board (optional)
The Airbot Systems PDB can be installed directly below the Airbot Systems Mini carrier board. It allows up to 180A through the ESC interface and provides four pairs of low-power pads (two on the top and two on the bottom). The mounting holes are aligned with those on the carrier board, allowing the boards to be stacked together, but separated by small nylon spacers.The PDB can not be in contact with any conductive materials. Ensure there is sufficient distance between the PDB and any conductive components to prevent short circuits.The following Github links can be used to revise and update the Airbot Systems Mini carrier board information:

> The PDB can not be in contact with any conductive materials. Ensure there is sufficient distance between the PDB and any conductive components to prevent short circuits. The following Github links can be used to revise and update the Airbot Systems Mini carrier board information**:**

*
*

--- chunk_id: chunk-0141
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 321
content_hash: 031e973cf79d1439
prev_chunk_id: chunk-0140
next_chunk_id: chunk-0142
section_heading: Working Conditions and Performance
document_type: technical_reference

## Working Conditions and Performance

*Mini Carrier Board* | Parameter                                    | Description                                                      |
| -------------------------------------------- | ---------------------------------------------------------------- |
| POWER Input Voltage / Rated Input Current    | 4-5.7V / 2.5A; 0-20V is safe for the system but it will not work |
| POWER rated output / input power             | 14 W                                                             |
| USB port input voltage / rated input current | 4-5.7V / 250mA                                                   |
| Servo rail input voltage                     | 4-10.5V                                                          |
| Waterproof performance                       | Not waterproof. External waterproof protection is needed         |
| Working temperature                          | -10°C / 55°C                                                     | ### Size and Specifications | Type                                       | Description                       |
| ------------------------------------------ | --------------------------------- |
| Mini Carrier Board Size / Chassis Material | 47.5x38.5x17.8 (mm) / ABS Molding |
|                                            |                                   | ### Interfaces and Definitions
### Pinout

![](/files/-LosSBEVaF5rTJ_-5hFY)

The red dot on the plug side denotes Pin 1. ![](/files/-LosSSqCoPy1xXkvEW-g)

![](/files/-LosSZ21UmaPgZpG-Gde)

![](/files/-LosSbzPWU16UPz1TaG6)

![](/files/-LosSfw2tMifTJCfbUs2)

![](/files/-LosSjgBFSWJ2dzbkB6U)

### Mini Carrier Board Interface Model | Ports  | Corresponding Connecter Model |
| ------ | ----------------------------- |
| GPS1   | JST-GH 1.25 mm (8-pin)        |
| GPS2   | JST-GH 1.25 mm (6-pin)        |
| TELEM1 | JST-GH 1.25 mm (6-pin)        |
| TELEM2 | JST-GH 1.25 mm (6-pin)        |
| I2C    | JST-GH 1.25 mm (4-pin)        |
| CAN2   | JST-GH 1.25 mm (4-pin)        |
| POWER1 | Molex CLIK-Mate 2 mm (6-pin)  |
| POWER2 | Molex CLIK-Mate 2 mm (6-pin)  |
| BUZZER | DF13 1.25 mm (2-pin)          |

--- chunk_id: chunk-0142
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 328
content_hash: aef3719cf6280188
prev_chunk_id: chunk-0141
next_chunk_id: chunk-0143
section_heading: Mini Cube 80-pin DF17 Connector Assignments (same as the Cube Black)
document_type: technical_reference

**Table — Part 1 of 5 (continued)**
| Pin Number | Name | Direction | Description |
| --- | --- | --- | --- |
| 1 | FMU_SWDIO | I/O | FMU serial wire debug I/O |
| 2 | FMU_LED_AMBER | O | Boot error LED (drive only, controlled by FET) |
| 3 | FMU_SWCLK | O | FMU serial wire debug clock |
| 4 | I2C_2_SDA | I/O | I2C data I/O |
| 5 | EXTERN_CS | O | Chip select for external SPI (NC, only for debugging) |
| 6 | I2C_2_SCL | O | I2C clock |
| 7 | FMU_!RESET | I | Reset pin for the FMU |
| 8 | PROT_SPARE_1 |  | Spare |
| 9 | VDD_SERVO_IN | I | Power for last resort I/O failsafe |
| 10 | PROT_SPARE_2 |  | Spare |
| 11 | EXTERN_DRDY | I | Interrupt pin for external SPI (NC, just for debugging) |
| 12 | SERIAL_5_RX | I | UART 5 RX (Receive Data) |
| 13 | GND |  | System GND |
| 14 | SERIAL_5_TX | O | UART 5 TX (Transmit Data) |
| 15 | GND |  | System GND |
| 16 | SERIAL_4_RX | I | UART 4 RX (Receive Data) |
| 17 | SAFETY |  | Safety button input |
| 18 | SERIAL_4_TX | O | UART 4 TX (Transmit Data) |

--- chunk_id: chunk-0143
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: bd37f0b03d90f83c
prev_chunk_id: chunk-0142
next_chunk_id: chunk-0144
section_heading: Mini Cube 80-pin DF17 Connector Assignments (same as the Cube Black)
document_type: technical_reference

**Table — Part 2 of 5 (continued)**
| Pin Number | Name | Direction | Description |
| --- | --- | --- | --- |
| 19 | VDD_3V3_SPEKTRUM_EN | O | Enable for the spectrum voltage supply |
| 20 | SERIAL_3_RX | I | UART 3 RX (Receive Data) |
| 21 | PRESSURE_SENS_IN | AI | Analogue port, for pressure sensor, or Laser range finder, or Sonar |
| 22 | SERIAL_3_TX | O | UART 3 TX (Transmit Data) |
| 23 | AUX_BATT_VOLTAGE_SENS | AI | Voltage sense for Aux battery input |
| 24 | ALARM | O | Buzzer PWM signal |
| 25 | AUX_BATT_CURRENT_SENS | AI | Current sense for Aux battery input |
| 26 | IO_VDD_3V3 | I | IO chip power, pinned through for debugging |
| 27 | VDD_5V_PERIPH_EN | O | Enable voltage supply for Peripherals |
| 28 | IO_LED_SAFET_PROT | O | IO-LED_SAFETY(safety LED) pinned out for IRIS |
| 29 | VBUS | I | USB VBus (VDD) |
| 30 | SERIAL_2_RTS |  | UART 2 RTS (Request To Send) |
| 31 | OTG_DP1 | I/O | USB Data+ |
| 32 | SERIAL_2_CTS |  | UART 2 CTS (Clear To Send) |
| 33 | OTG_DM1 | I/O | USB Data- |
| 34 | SERIAL_2_RX | I | UART 2 RX (Receive Data) |
| 35 | I2C_1_SDA | I/O | I2C data I/O |
| 36 | SERIAL_2_TX | O | UART 2 TX (Transmit Data) |

--- chunk_id: chunk-0144
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 350
content_hash: 0e7a6722a4709872
prev_chunk_id: chunk-0143
next_chunk_id: chunk-0145
section_heading: Mini Cube 80-pin DF17 Connector Assignments (same as the Cube Black)
document_type: technical_reference

**Table — Part 3 of 5 (continued)**
| Pin Number | Name | Direction | Description |
| --- | --- | --- | --- |
| 37 | I2C_1_SCL | O | I2C clock |
| 38 | SERIAL_1_RX | I | UART 1 RX (Receive Data) |
| 39 | CAN_L_2 | I/O | FMU CAN bus Low signal driver |
| 40 | SERIAL_1_TX | O | UART 1 TX (Transmit Data) |
| 41 | CAN_H_2 | I/O | FMU CAN bus High signal driver |
| 42 | SERIAL_1_RTS |  | UART 1 RTS (Request To Send) |
| 43 | VDD_5V_PERIPH_OC | I | Error state message from peripheral power supply |
| 44 | SERIAL_1_CTS |  | UART 1 CTS (Clear To Send) |
| 45 | VDD_5V_HIPOWER_OC | I | Error state message from High power peripheral power supply |
| 46 | IO_USART_1_TX | O | I/O USART 1 TX |
| 47 | BATT_VOLTAGE_SENS_PROT | AI | Voltage sense from main battery |
| 48 | IO_USART1_RX_SPECTRUM_DSM | O | Signal from Spectrum receiver |
| 49 | BATT_CURRENT_SENS_PROT | AI | Current sense from main battery |
| 50 | FMU_CH1_PROT | O | FMU PWM output channel 1 |
| 51 | SPI_EXT_MOSI | O | External SPI, for debug only |
| 52 | FMU_CH2_PROT | O | FMU PWM output channel 2 |
| 53 | VDD_SERVO | I | VDD_Servo, for monitoring servo bus |
| 54 | FMU_CH3_PROT | O | FMU PWM output channel 3 |

--- chunk_id: chunk-0145
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 345
content_hash: 96a7aa552cea3b6f
prev_chunk_id: chunk-0144
next_chunk_id: chunk-0146
section_heading: Mini Cube 80-pin DF17 Connector Assignments (same as the Cube Black)
document_type: technical_reference

**Table — Part 4 of 5 (continued)**
| Pin Number | Name | Direction | Description |
| --- | --- | --- | --- |
| 55 | VDD_BRICK_VALID | I | Main power valid signal |
| 56 | FMU_CH4_PROT | O | FMU PWM output channel 4 |
| 57 | VDD_BACKUP_VALID | I | Backup power valid signal |
| 58 | FMU_CH5_PROT | O | FMU PWM output channel 5 |
| 59 | VBUS_VALID | I | USB bus valid signal |
| 60 | FMU_CH6_PROT | O | FMU PWM output channel 6 |
| 61 | VDD_5V_IN_PROT | I | Main power (5V) into FMU from power selection |
| 62 | PPM_SBUS_PROT | I | PPM / S.Bus signal input |
| 63 | VDD_5V_IN_PROT | I | Main power (5V) into FMU from power selection |
| 64 | S.BUS_OUT | O | S.Bus signal output |
| 65 | IO_VDD_5V5 | O | IO VDD 5.5 V |
| 66 | IO_CH8_PROT | O | I/O PWM output channel 8 |
| 67 | SPI_EXT_MISO | I | External SPI, for debug only |
| 68 | IO_CH7_PROT | O | I/O PWM output channel 7 |
| 69 | IO_SWDIO | I/O | I/O serial wire debug |
| 70 | IO_CH6_PROT | O | I/O PWM output channel 6 |
| 71 | IO_SWCLK | O | I/O serial wire debug clock |
| 72 | IO_CH5_PROT | O | I/O PWM output channel 5 |

--- chunk_id: chunk-0146
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: fc850a17b5049feb
prev_chunk_id: chunk-0145
next_chunk_id: chunk-0147
section_heading: Mini Cube 80-pin DF17 Connector Assignments (same as the Cube Black)
document_type: technical_reference

**Table — Part 5 of 5 (continued)**
| Pin Number | Name | Direction | Description |
| --- | --- | --- | --- |
| 73 | SPI_EXT_SCK | O | External SPI, for debug only |
| 74 | IO_CH4_PROT | O | I/O PWM output channel 4 |
| 75 | IO_!RESET | I | I/O reset pin |
| 76 | IO_CH3_PROT | O | I/O PWM output channel 3 |
| 77 | CAN_L_1 | I/O | FMU CAN bus Low signal driver |
| 78 | IO_CH2_PROT | O | I/O PWM output channel 2 |
| 79 | CAN_H_1 | I/O | FMU CAN bus High signal driver |
| 80 | IO_CH1_PROT | O | I/O PWM output channel 1 |

--- chunk_id: chunk-0147
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 16
content_hash: 13a9d8db8b5f17f2
prev_chunk_id: chunk-0146
next_chunk_id: chunk-0148
section_heading: Mini Cube 80-pin DF17 Connector Assignments (same as the Cube Black)
document_type: technical_reference

## Mini Cube 80-pin DF17 Connector Assignments (same as the Cube Black)

--- chunk_id: chunk-0148
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 669
content_hash: 212d291f0604bedc
prev_chunk_id: chunk-0147
next_chunk_id: chunk-0149
section_heading: Serial Ports Parameter and Power Distribution
document_type: technical_reference

## Serial Ports Parameter and Power Distribution
### SERIAL 1 / UART 1 | Connector： TELEM1 | Pin Number | Name                | Direction | Voltage           | Wire Color   | Caption                      |
| ---------- | ------------------- | --------- | ----------------- | ------------ | ---------------------------- |
| 1          | VCC_5V             | OUT       | 5 V               | RED/GRAY     | VCC                          |
| 2          | SERIAL_1_TX       | OUT       | 3.3 V - 5.0 V TTL | YELLOW/BLACK | UART 1 TX (Transmit Data)    |
| 3          | SERIAL_1_RX       | IN        | 3.3 V - 5.0 V TTL | GREEN/BLACK  | UART 1 RX (Receive Data)     |
| 4          | SERIAL_1_CTS (TX) | OUT       | 3.3 V - 5.0 V TTL | GRAY/BLACK   | UART 1 CTS (Clear To Send)   |
| 5          | SERIAL_1_RTS (RX) | IN        | 3.3 V - 5.0 V TTL | GRAY/BLACK   | UART 1 RTS (Request To Send) |
| 6          | GND                 |           | GND               | BLACK        | GND                          | ### SERIAL 2 / UART 2 | Connector： TELEM2 | Pin Number | Name                | Direction | Voltage           | Wire Color   | Caption                      |
| ---------- | ------------------- | --------- | ----------------- | ------------ | ---------------------------- |
| 1          | VCC_5V             | OUT       | 5 V               | RED/GRAY     | VCC                          |
| 2          | SERIAL_2_TX       | OUT       | 3.3 V - 5.0 V TTL | YELLOW/BLACK | UART 2 TX (Transmit Data)    |
| 3          | SERIAL_2_RX       | IN        | 3.3 V - 5.0 V TTL | GREEN/BLACK  | UART 2 RX (Receive Data)     |
| 4          | SERIAL_2_CTS (TX) | OUT       | 3.3 V - 5.0 V TTL | GRAY/BLACK   | UART 2 CTS (Clear To Send)   |
| 5          | SERIAL_2_RTS (RX) | IN        | 3.3 V - 5.0 V TTL | GRAY/BLACK   | UART 2 RTS (Request To Send) |
| 6          | GND                 |           | GND               | BLACK        | GND                          | ### SERIAL 3 / UART 3 (GPS) / I2C 1 | Connector： GPS1 | Pin Number | Name                 | Direction | Voltage           | Wire Color | Caption                         |
| ---------- | -------------------- | --------- | ----------------- | ---------- | ------------------------------- |
| 1          | VCC_5V              | IN        | 5 V               | RED        | VCC Power Supply To GPS From AP |
| 3          | SERIAL_3_TX        | OUT       | 3.3 V - 5.0 V TTL | BLACK      | UART 3 TX (Transmit Data)       |
| 2          | SERIAL_3_RX        | IN        | 3.3 V - 5.0 V TTL | BLACK      | UART 3 RX (Receive Data)        |
| 4          | I2C_1_SCL          | IN        | 3.3 V             | BLACK      | I2C 1 Clock Signal              |
| 5          | I2C_1_SDA          | IN/OUT    | 3.3 V             | BLACK      | I2C 1 Serial Data               |
| 6          | BUTTON               |           | GND               | BLACK      | Signal shorted to GND on press  |
| 7          | IO_LED_SAFET_PROT |           | GND               | BLACK      | LED Driver For Safety Button    |
| 8          | GND                  |           | GND               | BLACK      | GND Connection                  |

--- chunk_id: chunk-0149
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 540
content_hash: 3bd18c6c307188c1
prev_chunk_id: chunk-0148
next_chunk_id: chunk-0150
section_heading: Serial Ports Parameter and Power Distribution
document_type: technical_reference

### SERIAL 3 / UART 3 (GPS) / I2C 1 | Connector： GPS1 | Pin Number | Name                 | Direction | Voltage           | Wire Color | Caption                         |
| ---------- | -------------------- | --------- | ----------------- | ---------- | ------------------------------- |
| 1          | VCC_5V              | IN        | 5 V               | RED        | VCC Power Supply To GPS From AP |
| 3          | SERIAL_3_TX        | OUT       | 3.3 V - 5.0 V TTL | BLACK      | UART 3 TX (Transmit Data)       |
| 2          | SERIAL_3_RX        | IN        | 3.3 V - 5.0 V TTL | BLACK      | UART 3 RX (Receive Data)        |
| 4          | I2C_1_SCL          | IN        | 3.3 V             | BLACK      | I2C 1 Clock Signal              |
| 5          | I2C_1_SDA          | IN/OUT    | 3.3 V             | BLACK      | I2C 1 Serial Data               |
| 6          | BUTTON               |           | GND               | BLACK      | Signal shorted to GND on press  |
| 7          | IO_LED_SAFET_PROT |           | GND               | BLACK      | LED Driver For Safety Button    |
| 8          | GND                  |           | GND               | BLACK      | GND Connection                  | ### SERIAL 4 / UART 4 / I2C 2 | Connector： GPS2 | Pin NUmber | Name          | Direction | Voltage           | Wire Color   | Caption                         |
| ---------- | ------------- | --------- | ----------------- | ------------ | ------------------------------- |
| 1          | VCC_5V       | OUT       | 5 V               | RED/GRAY     | VCC Power Supply To GPS From AP |
| 2          | SERIAL_4_TX | OUT       | 3.3 V - 5.0 V TTL | YELLOW/BLACK | UART 4 TX (Transmit Data)       |
| 3          | SERIAL_4_RX | IN        | 3.3 V - 5.0 V TTL | GREEN/BLACK  | UART 4 RX (Receive Data)        |
| 4          | I2C_2_SCL   | OUT       | 3.3 V - 5.0 V     | GRAY/BLACK   | I2C 2 Clock Signal              |
| 5          | I2C_2_SDA   | IN        | 3.3 V - 5.0 V     | GRAY/BLACK   | I2C 2 Serial Data               |
| 6          | GND           |           | GND               | BLACK        | GND                             | ### Buzzer | Connector： BUZZER | Pin Number | Name   | Direction | Voltage         | Wire Color | Caption           |
| ---------- | ------ | --------- | --------------- | ---------- | ----------------- |
| 1          | BUZZER | OUT       | Battery voltage | GRAY/BLACK | VBAT (8.4 - 42 V) |
| 2          | GND    |           | GND             | BLACK      | GND Connection    |

--- chunk_id: chunk-0150
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 576
content_hash: 5348a005efe98ac8
prev_chunk_id: chunk-0149
next_chunk_id: chunk-0151
section_heading: Serial Ports Parameter and Power Distribution
document_type: technical_reference

### Buzzer | Connector： BUZZER | Pin Number | Name   | Direction | Voltage         | Wire Color | Caption           |
| ---------- | ------ | --------- | --------------- | ---------- | ----------------- |
| 1          | BUZZER | OUT       | Battery voltage | GRAY/BLACK | VBAT (8.4 - 42 V) |
| 2          | GND    |           | GND             | BLACK      | GND Connection    | ### I2C 2 | Connector： I2C 2 | Pin Number | Name    | Direction | Voltage          | Wire Color  | Caption                       |
| ---------- | ------- | --------- | ---------------- | ----------- | ----------------------------- |
| 1          | VCC_5V | OUT       | +5 V             | RED/GRAY    | Power supply                  |
| 2          | SCL     | IN/OUT    | +3.3 V (PULLUPS) | BLUE/BLACK  | SCL, 5 V level, pull-up on AP |
| 3          | SDA     | IN/OUT    | +3.3 V (PULLUPS) | GREEN/BLACK | SDA, 5 V level, pull-up on AP |
| 4          | GND     |           | GND              | BLACK       | GND Connection                | ### Main Power POWER 1 | Connector： POWER1 | Pin Number | Name                      | Direction | Voltage | Wire Color | Caption                       |
| ---------- | ------------------------- | --------- | ------- | ---------- | ----------------------------- |
| 1          | VDD_5V_BRICK            | IN        | 5 V     | RED/GRAY   | Supply To AP from Power Brick |
| 2          | VDD_5V_BRICK            | IN        | 5 V     | RED/GRAY   | Supply To AP from Power Brick |
| 3          | BATT_CURRENT_SENS_PROT | IN        | 3.3 V   | BLACK      | Battery Current Connecter     |
| 4          | BATT_VOLTAGE_SENS_PROT | IN        | 3.3 V   | BLACK      | Battery Voltage Connecter     |
| 5          | GND                       |           | GND     | BLACK      | GND                           |
| 6          | GND                       |           | GND     | BLACK      | GND                           | ### Backup Power POWER 2 | Connector： POWER2 | Pin Number | Name                     | Direction | Voltage | Wire Color | Caption                       |
| ---------- | ------------------------ | --------- | ------- | ---------- | ----------------------------- |
| 1          | VDD_5V_BRICK           | IN        | 5 V     | RED/GRAY   | Supply To AP from Power Brick |
| 2          | VDD_5V_BRICK           | IN        | 5 V     | RED/GRAY   | Supply To AP from Power Brick |
| 3          | AUX_BATT_CURRENT_SENS | IN        | 3.3 V   | BLACK      | Aux Battery Current Connecter |
| 4          | AUX_BATT_VOLTAGE_SENS | IN        | 3.3 V   | BLACK      | Aux Battery Voltage Connecter |
| 5          | GND                      |           | GND     | BLACK      | GND Connection                |
| 6          | GND                      |           | GND     | BLACK      | GND                           |

--- chunk_id: chunk-0151
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 649
content_hash: 251e8476135563fa
prev_chunk_id: chunk-0150
next_chunk_id: chunk-0152
section_heading: Serial Ports Parameter and Power Distribution
document_type: technical_reference

### Backup Power POWER 2 | Connector： POWER2 | Pin Number | Name                     | Direction | Voltage | Wire Color | Caption                       |
| ---------- | ------------------------ | --------- | ------- | ---------- | ----------------------------- |
| 1          | VDD_5V_BRICK           | IN        | 5 V     | RED/GRAY   | Supply To AP from Power Brick |
| 2          | VDD_5V_BRICK           | IN        | 5 V     | RED/GRAY   | Supply To AP from Power Brick |
| 3          | AUX_BATT_CURRENT_SENS | IN        | 3.3 V   | BLACK      | Aux Battery Current Connecter |
| 4          | AUX_BATT_VOLTAGE_SENS | IN        | 3.3 V   | BLACK      | Aux Battery Voltage Connecter |
| 5          | GND                      |           | GND     | BLACK      | GND Connection                |
| 6          | GND                      |           | GND     | BLACK      | GND                           | ### CAN | Connector： CAN2 | Pin Number | Name      | Direction | Voltage | Wire Color   | Caption          |
| ---------- | --------- | --------- | ------- | ------------ | ---------------- |
| 1          | VCC_5V   | OUT       | 5 V     | RED/GRAY     | VCC Power Supply |
| 2          | CAN_H_2 | IN/OUT    | 12 V    | YELLOW/BLACK | CAN High         |
| 3          | CAN_L_2 | IN/OUT    | 12 V    | GREEN/BLACK  | CAN Low          |
| 4          | GND       |           | GND     | BLACK        | GND              | ### IO USART 1 / DSM | Connector： SPKT | 1 | IO_USART1_RX_SPECTRUM_DSM | IN  |       | IO USART 1 RX, DSM INPUT |
| - | ----------------------------- | --- | ----- | ------------------------ |
| 2 | GND                           |     | GND   | GND                      |
| 3 | VDD_3V3_Spektrum            | OUT | 3.3 V | Independent Power Supply | ### CPPM / S.BUS / SERVO SYSTEM | Connector： RCIN MAIN OUT | S - 1 | IO_CH1_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power | PWM Signal         |
| ----- | --------------- | ------ | ------------------------------------ | ------------------ |
| S - 2 | IO_CH2_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power | PWM Signal         |
| S - 3 | IO_CH3_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power | PWM Signal         |
| S - 4 | IO_CH4_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power | PWM Signal         |
| S - 5 | IO_CH5_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power | PWM Signal         |
| S - 6 | IO_CH6_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power | PWM Signal         |
| S - 7 | IO_CH7_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power | PWM Signal         |
| S - 8 | IO_CH8_PROT   | OUT    | 3.3 V Servo Signal, Servo Rail Power | PWM Signal         |
| S - 9 | PPM_SBUS_PROT | IN/OUT | 3.3 V / 4.5 V Powered                | PPM / S.Bus Signal |

--- chunk_id: chunk-0152
source_document: mini-carrier-board.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: 84991b8afa59df25
prev_chunk_id: chunk-0151
next_chunk_id: chunk-0153
section_heading: PPM S.bus Signal and SPKT Signal Switching
document_type: technical_reference

## PPM S.bus Signal and SPKT Signal Switching

By default, the Mini carrier board uses PPM and S.bus (PPM/S.B) for the RC IN input. Specifically,

* Left center pad is connected to the 5V pad (provides power). * Right center pad is connected to the PPM/S.B pad (receives the signal). To modify the PCB to receive SPKT signals, complete the following steps:

1. Cut the existing connections:
   * Disconnect the left center pad from the 5V pad. * Disconnect the right center pad from the PPM/S.B pad. 2. Solder the new connections:
   * Connect the 3V3 pad to the left center pad. * Connect the SPKT pad to the right center pad. ![](/files/-LotKxetKtidjFbKvvDF)

The following Github link can be used to revise and update the Mini carrier board information**:** \

--- chunk_id: chunk-0153
source_document: overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 77
content_hash: 59f4d00d6250e1d4
prev_chunk_id: chunk-0152
next_chunk_id: chunk-0154
section_heading: Overview
document_type: technical_reference

# Overview

The Cube is typically installed on a carrier board, which offers various types of external connections to enhance its peripheral connectivity. The carrier board also reduces the wiring, improves reliability, and eases the assembly. Depending on the size and connection requirements, several types of carrier boards are available. The following sections describe each carrier board type.

--- chunk_id: chunk-0154
source_document: standard-carrier-board-footprint-and-dimensions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 92
content_hash: ff49a20b2e85621d
prev_chunk_id: chunk-0153
next_chunk_id: chunk-0155
section_heading: Standard Carrier Board Footprint & Dimensions
document_type: technical_reference

# Standard Carrier Board Footprint & Dimensions

The following shows the footprint and dimensions of the standard carrier board and its various versions used by The Cube. While these versions share the same dimensions, their respective functions may differ. * Standard Carrier board
* Intel Edision Carrier Board
* ADSB-In Carrier Board

![](/files/-Lw0xP9qzq7pp2I54eyx)

The following Github link can be used to revise and update the standard carrier board information:\

--- chunk_id: chunk-0155
source_document: 2023-cubepilot-ecosystem-autopilot-wiring-diagram.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 9
content_hash: a51f45bd2a4d246f
prev_chunk_id: chunk-0154
next_chunk_id: chunk-0156
section_heading: 2023 CubePilot Ecosystem Autopilot Wiring Diagram
document_type: technical_reference

# 2023 CubePilot Ecosystem Autopilot Wiring Diagram

--- chunk_id: chunk-0156
source_document: 2025-cubepilot-ecosystem-autopilot-wiring-diagram.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 9
content_hash: 729191b8886a35be
prev_chunk_id: chunk-0155
next_chunk_id: chunk-0157
section_heading: 2025 CubePilot Ecosystem Autopilot Wiring Diagram
document_type: technical_reference

# 2025 CubePilot Ecosystem Autopilot Wiring Diagram

--- chunk_id: chunk-0157
source_document: cubepilot-ecosystem-autopilot-wiring-diagram.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 117
content_hash: 9c337b14c5443386
prev_chunk_id: chunk-0156
next_chunk_id: chunk-0158
section_heading: CubePilot Ecosystem Autopilot Wiring Diagram - English
document_type: technical_reference

## CubePilot Ecosystem Autopilot Wiring Diagram - English

*CubePilot Ecosystem Autopilot Wiring Diagram (Multilingual)*

### CubePilot 시스템 다이어그램 - Korean
### CubePilot生態系自動操縦配線図 - Japanese
### Diagrama de cableado del piloto automático del ecosistema CubePilot - Spanish
### Oekosystem-Autopilot-Schaltplan - Germany
### Schéma de câblage d’un pilote automatique dans l’écosystème CubePilot - French
### CubePilot Ecosystem ऑटोपायलट वायरिंग आरेख-Hindi
### Схема подключения автопилота в экосистеме CubePilot-Russian
### CubePilot生態系無人機飛控系統配線圖-繁體字
### Cubepilot-ekosystem cubepilot-Polski
### CubePilot-CubePilot Ecosystem Autopilot Wiring Diagram-Turkish
### CubePilot Diagram-Portuguese Version_Tradução
### CubePilot Ecosystem Autopilot Wiring Diagram-Finnish
### 多旋翼开源飞控硬件接线图(汉语版)

--- chunk_id: chunk-0158
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 240
content_hash: d37ad3aae9e506c0
prev_chunk_id: chunk-0157
next_chunk_id: chunk-0159
section_heading: Overview
document_type: maintenance_procedure

## Overview

*Here+V2 User Manual*


HERE+/HERE+ V2 RTK kit developed by CubePilot and Ardupilot Team is compatible with Mission Planner, a ground control station for ArduPilot, as well as PX4 and QGroundControl. The kit is the first Differential Global Positioning System (DGPS) module for open source flight controller users. RTK technology provides much more accurate position estimates than regular GNSS systems. Its ideal accuracy can reach up to centimeters, which greatly improve the precision of flight. Being the first RTK positioning system developed for open source community, HERE+ is easy to use. The Here+ GPS kit comes with a base and a rover. The base can work with Mission Planner with minimum setup required. The data communication between rover and base modules is through a pair of telemetry module(not provided in the standard Here+ package). HERE+/HERE+ V2 has a full set of Inertial navigation system (gyroscope, accelerometer, compass and barometer) and GNSS data to acquire more accurate navigation. In the Ardupilot and PX4 firmware, RTK positioning data is fused with build-in Extended Kalman filter (EKF) algorithm for optimized positioning result.

--- chunk_id: chunk-0159
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 310
content_hash: 674a4de5d8846321
prev_chunk_id: chunk-0158
next_chunk_id: chunk-0160
section_heading: High Precision Positioning:
document_type: maintenance_procedure

## High Precision Positioning:

Many applications of UAV need better precision than what regular GNSS can provide. For example: UAV surveying and mapping; agriculture measuring; high precision take-off and landing; UAV swarming; etc. RTK Differential GPS that is compatible with open source The Cube flight controllers. -Support 1 Base to Multiple Rovers\
-Light and Power Efficient RTK Real-time DGPS Solution\
-Centimeters Level Positioning and Navigation

By Real-time kinematic technology, HERE+ provides real-time 3D coordinate of the observing point. Transmitting carrier phase measurement of the base to rover for correction. Comparing carrier phase from GPS and base respectively, the module calculate the phase difference to obtain centimeters level positioning in real-time. ### The Standard Here+ Kit Includes:
### HERE+ V1 | Item                             | Number |
| -------------------------------- | ------ |
| here+ RTK Rover                  | x1     |
| here+ RTK Rover Connecting Cable | x1     |
| here+ RTK Base Base              | x1     |
| here+ RTK Base Base USB Cable    | x1     | ### HERE+ V2 | Item                                            | Number |
| ----------------------------------------------- | ------ |
| here+ v2 RTK Rover                              | x1     |
| here+ RTK Rover Connecting Cable (serial + I2C) | x1     |
| here+ RTK Rover Connecting Cable (CAN)          | x1     |
| UART-USB Converter for Upgrading Rover          | x1     |
| here+ RTK Base Base                             | x1     |
| here+ RTK Base Base USB Cable                   | x1     |

--- chunk_id: chunk-0160
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 181
content_hash: 1d27f854ce083c2c
prev_chunk_id: chunk-0159
next_chunk_id: chunk-0161
section_heading: Antenna Placing
document_type: maintenance_procedure

## Antenna Placing
### Placing the RTK Antenna is very important for getting precise RTK positioning

For the working condition of RTK, there are some special requirements that are more demanding than regular GPS. The best environment requires the base and rover antenna to have clear view of the sky that is 30 degrees above horizon. RTK antenna can be elevated but make sure that there are no obstacles around, such as buildings, trees, cars, and etc. **Example of bad environment**: indoors, urban area, forest, near the ground. **Example of good environment**: Open spaces, peak of the mountains, roof of the buildings. Do not place the antenna near electronic devices, as high power electronic devices nearby may affect the radio frequency noise of GPS signal. Examples are mobile phone base stations, high voltage transformers, and etc.

--- chunk_id: chunk-0161
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 408
content_hash: 2e2bb7aaa3a65c61
prev_chunk_id: chunk-0160
next_chunk_id: chunk-0162
section_heading: Hardware Specification
document_type: maintenance_procedure

## Hardware Specification
### HERE+ Rover Hardware Parameters | GNSS module      | Connector                                                                |
| ---------------- | ------------------------------------------------------------------------ |
| u-blox NEO-M8P-0 | HERE+ V1: USB, UART (JST-GH connector, HERE+ V2: UART (JST-GH connector) | ### HERE+ Base Hardware Parameters | GNSS module      | Ceramic antenna | Connector      |
| ---------------- | --------------- | -------------- |
| u-blox NEO-M8P-2 | CGGBP.25.4.A.02 | USB, UART, SMA | | GNSS Signals Supported              | Working Environment          | Working Voltage | Working Temperature |
| ----------------------------------- | ---------------------------- | --------------- | ------------------- |
| GPS L1 C/A，GLONASS L10F， BeiDou B11 | Height 5000m，Velocity 500m/s | 5V              | -40℃ to 85℃         | ### Time-To-First-Fix |              | GPS & GLONASS | GPS & BeiDou | GPS |
| ------------ | ------------- | ------------ | --- |
| Cold Start   | 26S           | 28S          | 29S |
| Hot Start    | 1S            | 1S           | 1S  |
| Aided Starts | 2S            | 3S           | 2S  | ### Sensitivity |                       | GPS & GLONASS | GPS & BeiDou | GPS     |
| --------------------- | ------------- | ------------ | ------- |
| Tracking & Navigation | -160dBm       | -160dBm      | -160dBm |
| Reacquisition         | -160dBm       | -160dBm      | -160dBm |
| Cold Start            | -140dBm       | -148dBm      | -148dBm |
| Hot Start             | -157dBm       | -157dBm      | -157dBm | ### Maximum Navigation update rate for RTK | GPS & GLONASS | GPS& BeiDou | GPS |
| ------------- | ----------- | --- |
| 5Hz           | 5Hz         | 8Hz | | Antenna Supported          | Horizontal position accuracy |
| -------------------------- | ---------------------------- |
| Active and Passive Antenna | RTK 0.025m+1ppm CEP          | |             | Size           | Weight |
| ----------- | -------------- | ------ |
| HERE+ Rover | 49mmx49mmx17mm | 49g    |
| HERE+ Base  | 40mmx41mmx11mm | 18.6g  |

--- chunk_id: chunk-0162
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 152
content_hash: 877f0b5fa590d7d7
prev_chunk_id: chunk-0161
next_chunk_id: chunk-0163
section_heading: Hardware Specification
document_type: maintenance_procedure

| Antenna Supported          | Horizontal position accuracy |
| -------------------------- | ---------------------------- |
| Active and Passive Antenna | RTK 0.025m+1ppm CEP          | |             | Size           | Weight |
| ----------- | -------------- | ------ |
| HERE+ Rover | 49mmx49mmx17mm | 49g    |
| HERE+ Base  | 40mmx41mmx11mm | 18.6g  | ### Safety Switch

Enable/disable motors and servos output Long press safety switch for 3 seconds until LED turns solid. Motors and servos can then be turned on. LED meanings：\
Continuously Flashing - System Initializing Intermittent Flashing – System ready. Press to enable motor output

Enable/Disable safety switch：\
Connect flight controller to Mission Planner and go to "Full Parameter List" under "Configuration

![](/files/-Lp2MwH0HV10r7YlJeXJ)

--- chunk_id: chunk-0163
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 280
content_hash: bb0eb5df7b01f7bd
prev_chunk_id: chunk-0162
next_chunk_id: chunk-0164
section_heading: Here+ /Here+ v2 LED Meaning
document_type: maintenance_procedure

## Here+ /Here+ v2 LED Meaning

**Flashing red and blue**：Initializing sensors. Place the vehicle still and level while it initializes the sensors.\
**Flashing blue**：Disarmed, no GPS lock. Auto-mission, loiter and return-to-launch flight modes require GPS lock\
**Solid blue**：Armed with no GPS lock\
**Flashing green**：Disarmed (ready to arm), GPS lock acquired. Quick double tone when disarming from the armed state.\
**Fast Flashing green**: Same as above but GPS is using SBAS (so should have better position estimate)\
**Solid green**: with single long tone at time of arming: Armed, GPS lock acquired. Ready to fly!\
**Double flashing yellow**: Failing pre-arm checks (system refuses to arm)\
**Single Flashing yellow**: Radio failsafe activated

**Flashing yellow - with quick beeping tone**: Battery failsafe activated\
**Flashing yellow and blue- with high-high-high-low tone sequence (dah-dah-dah-doh)**: GPS glitch or GPS failsafe activated\
**Flashing red and yellow**：EKF or Inertial Nav failure\
**Flashing purple and yellow**: Barometer glitch Solid Red: Error，usually due to the SD card（re-plug or place the SD card to solve）,MTD or IMU，you may check the SD card and have a look at BOOT.txt for boot message analysis\
**Solid red with SOS tone sequence**：SD card missing or SD card bad format\
**No light when power on** : No firmware，firmware lost，SD card missing or bad format（ac3.4 or higher version）

--- chunk_id: chunk-0164
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 200
content_hash: 3e4a7e4f9264a59f
prev_chunk_id: chunk-0163
next_chunk_id: chunk-0165
section_heading: Firmware Update
document_type: maintenance_procedure

## Firmware Update

Check your current firmware version before update Check Current Base/Rover Firmware Version

The default firmware version of the HERE + modules is ublox-1.10 firmware. The new version of 1.30 firmware includes new feature of fusing other satellite systems (Glonass / Beidou) with GPS for RTK operations, effectively increasing the RTK positioning accuracy. Therefore, it is recommended that all users upgrade to 1.30 firmware before using HERE+. During the preparation of this guide, ublox-1.40 version of the firmware has also been released. 1.40 version firmware introduced a new feature called the mobile base station, that is, the base station need not be fixed in a location. For example, a base station may be placed on a moving vehicle or boat. Upgrading to Ublox-1.40 version is similar to upgrading to 1.30. For users who do not need to use the mobile baseline feature, upgrading to version 1.30 is sufficient.

--- chunk_id: chunk-0165
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: 7c31c2aeaacf172f
prev_chunk_id: chunk-0164
next_chunk_id: chunk-0166
section_heading: Downloading U-centre UI and 1.30 Firmware
document_type: maintenance_procedure

## Downloading U-centre UI and 1.30 Firmware

Upgrading firmware requires the use of Ublox’s Windows software U-center. To download U-center, please go to the [official website](https://www.u-blox.com/en/product/u-center)

Then follow the prompts to install U-cent software. During the installation process, you will be prompted to install the device Driver, please ensure that only the Standard Driver For Windows is checked, as shown below.（at the newer updates, there will be only 1 selectable driver）

### **Get Firmware**

You will also need to download firmware here Click the choice: u-blox M8 Flash Firmware 3.01 HPG 1.30

* ONLY for High Precision GNSS products. ### Connect your HERE+ Base and Rover to Computer

When upgrading the **base** station module, use the USB cable to connect the base station module to the computer USB interface, as shown in the following photo:

When upgrading a **Here+ V1 rover** module (for **Here+ V2** upgrade, please refer to the later section), use a hexagonal screwdriver to open the case. The rover module has a USB interface connector identical to the base module, you can use the base module USB cable to connect rover to computer. In addition, during the firmware upgrading process, the rover module needs to be powered by connecting to flight controller, as shown in the following photo:

### Upgrading Process

Open the U-center software, click the connection button (as shown in the red circle), select the com port that corresponds to your base/ rover module. Please be reminded that the port should not be connected to other software otherwise the port will be occupied and unavailable.

--- chunk_id: chunk-0166
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 352
content_hash: 8a8563e3877b9e06
prev_chunk_id: chunk-0165
next_chunk_id: chunk-0167
section_heading: Downloading U-centre UI and 1.30 Firmware
document_type: maintenance_procedure

In addition, during the firmware upgrading process, the rover module needs to be powered by connecting to flight controller, as shown in the following photo:

### Upgrading Process

Open the U-center software, click the connection button (as shown in the red circle), select the com port that corresponds to your base/ rover module. Please be reminded that the port should not be connected to other software otherwise the port will be occupied and unavailable. Click "tools →u-blox 5 – 8 Flash Firmware Update and click the settings as shown below:\
In the higher versions, "u-blox 5 – 8 Flash Firmware Update" has been changed to "legacy firmware update", please operate according to the software version. In Firmware image, unzip and select the downloaded 1.30 Firmware. **For base module, chose the firmware with title:** UBX_M8_301_HPG_130_REFERENCE_NEOM8P2.59a07babb501ba6a89ff87cac2f 2765f.bin

**For rover module, choose the firmware:** UBX_M8_301_HPG_130_ROVER_NEOM8P0.3ee86a9e4775e3335e742b53527fa5 d0.bin

In Flash Information Structure(FIS) File, select Flash.xml，which is located in the installation address of Ucentre software (U-center_v8.25→flash.xml). Click "OK" and wait for the firmware uploading to complete. For Here+ V1, uploading usually takes only a minute or less. Here+ V2 will take longer time. If the uploading is successful, the upgrade interface is displayed in green; if the upgrade is aborted, the interface is displayed in red. If the process is interrupted, or if it is not responding for a long time, the modules will need to be power cycled and uploading needs to be done again. ### Check Current Rover/Base Firmware Version

When base/rover is already connected to U-center, click View, go to "View→Message View→ UBX → MON → VER".

--- chunk_id: chunk-0167
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 378
content_hash: d90947ab8cc3c5ce
prev_chunk_id: chunk-0166
next_chunk_id: chunk-0168
section_heading: Downloading U-centre UI and 1.30 Firmware
document_type: maintenance_procedure

If the process is interrupted, or if it is not responding for a long time, the modules will need to be power cycled and uploading needs to be done again. ### Check Current Rover/Base Firmware Version

When base/rover is already connected to U-center, click View, go to "View→Message View→ UBX → MON → VER". You will see the interface below:

As shown in the figure, the current firmware version is FWVER = HPG 1.30 REF, indicating that the current firmware version is 1.30 for base module. ### Here+ V2 Firmware Update

**Preparation** | Tools                  |   |
| ---------------------- | - |
| UART-USB converter     |   |
| Cables                 |   |
| Hexagonal screw driver |   | Connect the cable with UART-USB converter. Connect the red wire to 5V pin and black wire to GND pin. Remove the cover of Here+ v2 with hexagonal screw driver (You have to press and hold to remove the buckle). Then replace the cable. Plug the connector to the computer USB port. Check if all drivers are ready in device manager. If not, drivers can be downloaded here: [link to download connector driver ](http://winchiphead.com/download/CH341/CH341SER.ZIP)

The correct driver should be "USB-SERIAL CH340(COM#)"\
"#" is the corresponding port number. ![](/files/-Lp6s-Nn55GYxCKvZ1nG)

Open u-center and select the COM port for connector. Set the baud rate to 9600 then connect. After connection, select "Tools>legacy firmware update" to enter firmware update UI. Check the option "USB alternative update method" and select the firmware to be updated. (firmware for here+ and here2+ are the same, please look for detailed procedures from the here+ update procedure). Click OK to begin update. ![](/files/-Lp6v4zEMvoJiafEcbIo)

Wait for the progress bar to finish. If the window turns green, update is successful.

--- chunk_id: chunk-0168
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 65
content_hash: c4b32bb47f2266c9
prev_chunk_id: chunk-0167
next_chunk_id: chunk-0169
section_heading: Downloading U-centre UI and 1.30 Firmware
document_type: maintenance_procedure

![](/files/-Lp6v4zEMvoJiafEcbIo)

Wait for the progress bar to finish. If the window turns green, update is successful. If connection failed after the update window shows up, please change the baud rate to 115200 then update it twice (it maybe still failed at the first retry so please retry it twice).

--- chunk_id: chunk-0169
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 376
content_hash: a876a1379b40756d
prev_chunk_id: chunk-0168
next_chunk_id: chunk-0170
section_heading: Basic Operating Manual
document_type: maintenance_procedure

## Basic Operating Manual

These instructions focus on the setup using Mission Planner on Windows, but HERE+ is also supported by QGroundControl. ### Base/Rover Survey by Mission Planner

This part of the tutorial uses Mission Planner ground control software and Arducopter-3.5 flight control firmware for operating instructions. If you are using QGroundControl and PX4 firmware, please read:https\:// docs.px4.io/en/advanced_features/rtk-gps.html

### Preparation before operation

To use HERE+ on a UAV, you need the following hardware： Computer, telemetry modules, here+ rover module, here+ Base Antenna, here+ Base, Tripod(Stand)

Before using, make sure the hardware are connected correctly：\
**Ground side:** The base station module is connected to the computer port through USB port; a telemetry module is connected to another USB port of the same computer.\
**UAV side:** HERE + rover module is connected to the flight controller GPS connector; telemetry module is connected to the TELEM interface. ![](/files/-Lp6wWFhQxXa_D_Mh_lr)

Please place the base station in an outdoor environment with sufficient sky coverage to obtain a good satellite signal. Place the base station on a stable and elevated platform, such as a tripod. ![](/files/-Lp6wkd1KeeKmyblgLEk)

**Base Module Setting using Mission Planner**

Start with base module setup first. During the base station setup, the rover and the UAV do not need to be turned on. Open the Mission Planner ground station software on your computer and go to the "initial setup → Optional Hardware → RTK/GPS Inject". You will see the following page:

Select the correct base module com port in the top left corner and click connect. In the SurveyIn Acc section, enter the absolute geographic accuracy that you expect your HERE + base station to achieve. In the Time column, enter the minimum survey time you expect.

--- chunk_id: chunk-0170
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 369
content_hash: 4a1119d5640b8a65
prev_chunk_id: chunk-0169
next_chunk_id: chunk-0171
section_heading: Basic Operating Manual
document_type: maintenance_procedure

In the SurveyIn Acc section, enter the absolute geographic accuracy that you expect your HERE + base station to achieve. In the Time column, enter the minimum survey time you expect. Click on Restart, the ground station will transfer the data you have entered to the HERE + base module, the base module will start a new round of surveying. You will see the following page:

During the survey process, the right box will show the current survey status: **Position is invalid:** base station has not yet reached a valid location;\
**In Progress:** survey is still in progress；\
**Duration:** The number of seconds that the current surveying task has been executed;\
**Observation:** the number of observations acquired;\
**Current Acc:** Absolute geographic accuracy that the current base station can achieve;\
**Green bar** at the lower part of the Mission Planner page shows the satellites being detected and the signal strength related to each satellite. The base station needs a certain amount of time to meet the accuracy requirements of your input. Testing shows that, in an open area without shelter, to achieve the absolute accuracy of 2m takes a few minutes; to reach the absolute accuracy of less than 30cm takes around an hour; to reach the accuracy of 10cm takes a few hours. It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover. If your application does not require UAV with high absolute geographic accuracy, you do not need to set the base station’s precision too high, resulting in long survey time.

--- chunk_id: chunk-0171
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 354
content_hash: 3c1e19d430197973
prev_chunk_id: chunk-0170
next_chunk_id: chunk-0172
section_heading: Basic Operating Manual
document_type: maintenance_procedure

It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover. If your application does not require UAV with high absolute geographic accuracy, you do not need to set the base station’s precision too high, resulting in long survey time. Even if the accuracy of the base station is 1.5 to 2 m, the position accuracy of the rover module relative to the base station can still reach centimeter level. After the survey is complete, Mission Planner will display the following page:

![](/files/-Lp6xe_ktgKOdsn5OB78)

In the RTCM box it shows that the base status indicator is green and both the GPS and Glonass satellite systems are green (if you want to change the satellite system, refer to the following section). The box on the right says "Position is valid". To store the current location in the Mission Planner: Click "Save Current Pos", enter a name in the dialog box, and click "OK". As shown below, you can see your saved location in the list. Click the "Use" button for the location you saved. The base station will enter the fixed mode and the status will show "Using FixedLLA". In the future, if you set the base station in the same location, you do not need to conduct survey again, just click the "Use" button that corresponds to the location you have saved. ![](/files/-Lp79ALsMfoqUyeWb5pd)

### Rover Module and Flight Controller Setup

After the base station is set up, you can turn on the UAV.

--- chunk_id: chunk-0172
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 381
content_hash: df84026fff555f03
prev_chunk_id: chunk-0171
next_chunk_id: chunk-0173
section_heading: Basic Operating Manual
document_type: maintenance_procedure

In the future, if you set the base station in the same location, you do not need to conduct survey again, just click the "Use" button that corresponds to the location you have saved. ![](/files/-Lp79ALsMfoqUyeWb5pd)

### Rover Module and Flight Controller Setup

After the base station is set up, you can turn on the UAV. Using the same Mission Planner to connect the telemetry module, the base station data will be transmitted through telemetry module to the HERE + rover module on the UAV. In the Mission Planner main page, you can see the current GPS status displayed as RTK Float / RTK Fixed / 3D RTK, indicating that the positioning of the UAV has entered the RTK mode. RTK Float is a floating-point solution; RTK Fixed is a fixed solution. RTK Fixed mode has a higher accuracy and requires better signal strength. 3D RTK is unified saying of RTK Float / RTK in the Mission Planner Chinese version. ![](/files/-Lp79R1RE7BFSCQdjwNK)

### Single Base to Multiple Rovers

There are 2 methods to do this:\
1\) Use 1 telemetry to multiple telemetry broadcasting ;or\
2\) Use multiple 1 to 1 telemetry modules with USB hub

Ground station configuration: connect all telemetry modules to the computer via USB hub. Open Mission Planner to locate the base then connect it with flight controllers. Select AUTO connecting as shown below. All recognized flight controllers on the ports will be connected. You may select the UAV form the dropdown list below:

![](/files/-Lp7ACBPmoC3sTGd4znK)

If you connected the UAVs with 1 telemetry module, they should share the same COM port:

### Use U-centre for Live Data Recording/Replaying

One function of the U-center is to record the base / rover module data for later analysis.

--- chunk_id: chunk-0173
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 366
content_hash: e7603e3fd53879f0
prev_chunk_id: chunk-0172
next_chunk_id: chunk-0174
section_heading: Basic Operating Manual
document_type: maintenance_procedure

All recognized flight controllers on the ports will be connected. You may select the UAV form the dropdown list below:

![](/files/-Lp7ACBPmoC3sTGd4znK)

If you connected the UAVs with 1 telemetry module, they should share the same COM port:

### Use U-centre for Live Data Recording/Replaying

One function of the U-center is to record the base / rover module data for later analysis. Firstly, when the base or rover module is already connected to U-center (in the same way it is connected when updating firmware), click the following bug icon to turn on the "debug message":

![](/files/-Lp7AT26lCnmq1VA2l0x)

Then, click into "View → message view → UBX → RXM → RTCM(RTCM input status)", right click to "enable message". Finally, click on the red recording icon on the upper left corner of the interface (shown below), select an address to save the recording, click OK, the recording will begin. When recording is stopped, the recording will appear in the previously saved address. ![](/files/-Lp7CNx2dtsoH-w9Mnfw)

To play the recorded data, click the green play icon, select a playback speed, select the specified address of your stored data file, then the data will be played. ![](/files/-Lp7Dxr4XJcYPl6w48Lc)

### Use U-Centre for Debugging/Advanced Configuration
### Check Status of Base Station

Connect the base module to U-center software, check the display box in the upper right corner of the interface, Fix Mode section is displayed as TIME. If Fix Mode does not enter TIME, the current state of the base station is not sufficient to allow the rover module to enter RTK mode. As shown in the figure below, Fix Mode is displayed in 3D mode, hence the RTK standard has not yet been reached.

--- chunk_id: chunk-0174
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 350
content_hash: 643d0c3aa88a9980
prev_chunk_id: chunk-0173
next_chunk_id: chunk-0175
section_heading: Basic Operating Manual
document_type: maintenance_procedure

If Fix Mode does not enter TIME, the current state of the base station is not sufficient to allow the rover module to enter RTK mode. As shown in the figure below, Fix Mode is displayed in 3D mode, hence the RTK standard has not yet been reached. ![](/files/-Lp7EAR_FSNCnZTHTlvD)

Possible reason for base station not entering TIME Mode:

1\) Signals received by base station is not strong enough. To check the satellite strength received by base station, see the bottom right corner of the software interface. The vertical bars in the box indicate satellites strength received by the current base station. A vertical bar represents a satellite (GPS or Beidou / GLONASS, depending on the choice of satellite systems). TIME Mode of base station requires a) 5 GPS satellites + 2 GLONASS satellites, with strength > 40; b) 5 GPS satellites + 3 Beidou satellites, with strength > 40;

As shown in the figure below, only one satellite strength is higher than 40. Therefore, the signal condition does not meet the RTK standard. ![](/files/-Lp7ESZqsTYL4eCvctuR)

2\) The user input of survey-in accuracy requirement is too strict to achieve, or the base station has not yet completed the surveying process. Using U-centre for survey-in setup, please refer to later section in this chapter. ### Check whether Rover receives base correction data (Timeout)

After the base station enters the TIME Mode, it is necessary to transmit the RTCM data to the rover, for rover to enter RTK modes. Therefore, a real-time and efficient communication between rover and base station is necessary for good RTK positioning performance.

--- chunk_id: chunk-0175
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 388
content_hash: a47d9eb3c737a9cc
prev_chunk_id: chunk-0174
next_chunk_id: chunk-0176
section_heading: Basic Operating Manual
document_type: maintenance_procedure

### Check whether Rover receives base correction data (Timeout)

After the base station enters the TIME Mode, it is necessary to transmit the RTCM data to the rover, for rover to enter RTK modes. Therefore, a real-time and efficient communication between rover and base station is necessary for good RTK positioning performance. Check whether there is a delay in the data transmission between the mobile station and the base station, connect the rover module to U-center (or replay the data log to inspect a previous operation). Go to "View→Messages view→NMEA→GxGGA" directory to see Age of DGNSS Corr parameters. This parameter represents the time at which the rover did not receive the base station data. In the case of the default base station message frequency 1HZ, if this parameter exceeds 1s, there is a certain delay in the data transmission. ### Set Survey-in/Fixed Mode for Base Station

Similar to Mission Planner RTK Inject page, U-center can also be used to set the base station survey-in time and accuracy. Enter "View→Messages view →UBX→CGF→TMODE3". Select 1.Survey-in under the Mode drop-down option, and set the survey time (and the minimum time required for the base station to survey). The survey-in current status can be viewed in the "View→Message View→NAV→SVIN" page. ![](/files/-Lp7MHXUs0dCfpwjzLOd)

The base station can also be set to Fixed Mode. When the base station’s current precise geographic coordinates are known, the coordinates can be entered directly into the base station, which saves the time required for surveying. In the TMODE3 page, select Fixed mode in the drop-down list, and then enter the precise known base station coordinates. After setting the survey or fixed mode, click the Send button at the bottom left of the page to transfer the modified data to the base station.

--- chunk_id: chunk-0176
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 341
content_hash: f47bb4f9718a50ec
prev_chunk_id: chunk-0175
next_chunk_id: chunk-0177
section_heading: Basic Operating Manual
document_type: maintenance_procedure

In the TMODE3 page, select Fixed mode in the drop-down list, and then enter the precise known base station coordinates. After setting the survey or fixed mode, click the Send button at the bottom left of the page to transfer the modified data to the base station. ### Use Beidou/GLonass

The uBlox 1.30 firmware uses the GPS + GLONASS navigation system for location services by default. If you want to change to GPS + Beidou navigation system, you need to enter "View→Messages view→UBX→CGF→GNSS directory, cancel the tick on GLONASS Enable option, and then check the Beidou Enable option. After the selection, click "Send" to complete the change. ![](/files/-Lp7NuTvNdsioujAVeH4)

To save the current settings, go to "View→Messages view→UBX→CFG (Configuration)" page and click the Save current configuration option, then click Send (as shown below). **Note:** Base station and rover should use the same navigation system configuration, or rover will not be able to enter RTK modes. ### Base Module I/O Port and Protocol Setup

u-blox M8P chip supports a variety of input and output protocols, including USB, UART, I2C and so on. The HERE + base station module uses the USB port for data communication and RTK outputs. If you need to confirm the current settings, go to "View→Messages view → UBX → CGF → PRT" and select 3-USB in the Target field. The correct input and output protocols are shown below:

If you want to use more output protocols (such as UART), you can also select the output protocol and a specific message combination on this page.

--- chunk_id: chunk-0177
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 358
content_hash: d6c7fa3c3e7535c3
prev_chunk_id: chunk-0176
next_chunk_id: chunk-0178
section_heading: Basic Operating Manual
document_type: maintenance_procedure

If you need to confirm the current settings, go to "View→Messages view → UBX → CGF → PRT" and select 3-USB in the Target field. The correct input and output protocols are shown below:

If you want to use more output protocols (such as UART), you can also select the output protocol and a specific message combination on this page. If you want to set a string of specific messages to output under a variety of protocols, you can go to "View→Messages view → UBX → CGF → MSG" .Then select a specific message, and then check the type of protocol you want to output. To save the current settings, go to "View→Messages view→UBX→CFG (Configuration)" and click the "Save" current configuration option, then click Send. ### Change Rover Module Output Rate

By default, the output frequency of the position information by the rover module is 1HZ. If you need to speed up the position output frequency, you can enter "View→Messages view→UBX →CGF→RATE" and modify "Measurement Period". For example, adjust "Measurement Period" to 200ms then the "Measurement Frequency" will be increased to 5Hz. To save the current settings, go to "View→Messages view→UBX→CFG (Configuration" and click the Save current configuration option, then click Send. ### Change Base Antenna and Testing

HERE + base module antenna is a Taoglas antenna. Users can select different antennas according to their needs and connect them to base module. We have conducted a test of three different antennas in an outdoor environment, where three antennas at the same time, same location were connected to the HERE + base station, data were logged using Ucentre recording function.

--- chunk_id: chunk-0178
source_document: here+v2-user-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 169
content_hash: 748e7468584d27ef
prev_chunk_id: chunk-0177
next_chunk_id: chunk-0179
section_heading: Basic Operating Manual
document_type: maintenance_procedure

Users can select different antennas according to their needs and connect them to base module. We have conducted a test of three different antennas in an outdoor environment, where three antennas at the same time, same location were connected to the HERE + base station, data were logged using Ucentre recording function. **It should be noted that** the following data are not sufficient to give a comprehensive conclusion about which antenna is better, but the user can use the following methods to test, compare different antennas to find he one more suitable for their application. ![Base status with Antenna A (Survey Antenna) at TIME Mode](/files/-Lp7S7YkDchd98R3GAgM)

![Base status with Antenna B (GNSS Antenna) at TIME Mode](/files/-Lp7SI-irekxQm8wRYmG)

![Satellite signal comparison for each satellite](/files/-Lp7Slw6lmc101yQBPC_)

Last update: 9th Jan 2019

****

--- chunk_id: chunk-0179
source_document: here-2-can-mode-instruction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 78
content_hash: 8c51c70a8a2d5fb5
prev_chunk_id: chunk-0178
next_chunk_id: chunk-0180
section_heading: Here 2 CAN Mode Instruction
document_type: technical_reference

# Here 2 CAN Mode Instruction

Here2 Default factory setting is CAN mode with DroneCAN Protocol. Default Here2 CAN mode has three devices on CAN bus: GPS, magnetic compass, and barometer. The safety switch is not workable under CAN mode and the barometer is disabled in CAN mode by default. The barometer can be enabled by DroneCAN parameters setting.

--- chunk_id: chunk-0180
source_document: here-2-can-mode-instruction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 520
content_hash: e09d642b403a6378
prev_chunk_id: chunk-0179
next_chunk_id: chunk-0181
section_heading: How to use CAN mode:
document_type: technical_reference

## How to use CAN mode:
### Using Ardupilot Firmware:

Current official Ardupilot firmware (Copter3.6.7, Plane3.9.6 as well as previous versions) does not support Dynamic Node Allocator, hence user needs to allocate node ID to Here2 manually. The later released Copter3.7 firmware will support Dynamic Node Allocator, user only needs to set the parameters of their flight controller to use CAN mode. ### Allocating node ID method：

For allocating node ID to Here2, user needs to use Cube as SLCAN (Serial port to CAN) device, and use the latest version of Mission Planner. At first, upgrade the MissionPlanner to 1.3.63 version, please go to the link:  for downloading. Meanwhile the Cube which would be the SLCAN connector needs to be uploaded with copter3.7master firmware, firmware downloading link:  . Connect the 4p CAN cable in Here2 with the CAN2 port in the Cube controller. Connect the cube to MissionPlanner 1.3.63version and select firmware upload, click on ‘upload custom firmware’ to upload the previously downloaded arducopter firmware. ![](/files/-LnAvXe0MsVbVP-JUjIz)

After uploading successfully, click on ‘Connect’. Press Ctrl+L keys to enter into DRONECAN interface. ![](/files/-LnAvoTlXQIaUTFFCXpg)

Click on ‘SLCan Mode CAN1’, then the information of Here2 device will show up. Click on ‘Parameters’ on the right side. ![](/files/-Lrhkhrq4zfB5xMXKoxm)

Pop up the parameters setting interface shown as the screenshot below, set the value of dronecan.node_id between 0 and 125. Click on ‘Writing parameters’, then click on ‘Commit Params’ to save the setting. With the above mentioned steps, manual Node allocation is completed. If the user would like to enable the barometer, it can be done by setting the value of BARO_ENABLE as 1. ![](/files/-LnAwzwpqwS1Qx0iU_uS)

After modifying the Node ID, the firmware and MissionPlanner can be changed into stable version. Boot Cube controller and connect with MissionPlanner, enter into the MissionPlanner to change the parameters with corresponding values as follows:

CAN_D1_PROTOCOL：1\
CAN_D2_PROTOCOL：1\
CAN_P1_DRIVER：1\
CAN_P2_DRIVER：1\
GPS_TYPE：9\
NTF_LED_TYPES：231

Writing the modified parameters, reboot the cube therefore the CAN mode can work properly. CANBUS external compass will show up as the third compass with current Ardupilot firmware. Future firmware update will allow CANBUS external compass to be primary. Safety switch on the Here2 will not work under CAN mode. Modify the parameter BRD_SAFETYENABLE to 0 to disable the safety switch, or connect an external safety switch to GPS1 port. Note: The later released Copter3.7 firmware will support Dynamic Node Allocator.

--- chunk_id: chunk-0181
source_document: here-2-can-mode-instruction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 57
content_hash: c10f9630c4bac70a
prev_chunk_id: chunk-0180
next_chunk_id: chunk-0182
section_heading: How to use CAN mode:
document_type: technical_reference

Modify the parameter BRD_SAFETYENABLE to 0 to disable the safety switch, or connect an external safety switch to GPS1 port. Note: The later released Copter3.7 firmware will support Dynamic Node Allocator. To use the CAN mode user only needs to modify the parameters.

--- chunk_id: chunk-0182
source_document: here-2-can-mode-instruction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 105
content_hash: 6ed211f5576f053c
prev_chunk_id: chunk-0181
next_chunk_id: chunk-0183
section_heading: Using PX4 firmware:
document_type: technical_reference

## Using PX4 firmware:

Connect with CAN1 or CAN2 port. Connect with the controller to set the DRONECAN_ENABLE parameter as Sensors Automatic Config. The sensors should work properly. ### How to use I2C mode:
Here2 also supports the traditional serial port + I2C communication. To use this mode, please disassemble the Here2 housing, Put the lever switch for CAN and Serial+I2C to Serial+I2C position shown as below. ![](/files/-LnAyI82wvCvnWgNVO0d)

Connect the here2 with GPS1 port of the Cube flight controller.

--- chunk_id: chunk-0183
source_document: here-2-firmware-update-troubleshooting.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 112
content_hash: 9642c36174807ae2
prev_chunk_id: chunk-0182
next_chunk_id: chunk-0184
section_heading: Here 2 Firmware Update Troubleshooting
document_type: technical_reference

# Here 2 Firmware Update Troubleshooting

Most issues updating the HERE 2 are related to not following the update process exsactly or not leaving enough time before rebooting after updaing the bootloader, some issues that have been see are

* Here 2 not showing in SLCAN
* Here 2 No showing in SLCAN after updating bootloader step
* LED's stuck solid green

If you are having trouble updating you Here 2 firmware or your Here 2 is not showing in SLCAN check the following

--- chunk_id: chunk-0184
source_document: here-2-firmware-update-troubleshooting.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 250
content_hash: 0c4d88dc42a3b6bb
prev_chunk_id: chunk-0183
next_chunk_id: chunk-0185
section_heading: Check CAN Port
document_type: technical_reference

## Check CAN Port

On some early standard carrier board models including the Intel Edision verison the CAN ports were incorrectly labled and swapped around, this could result in CAN 1 and CAN 2 showing reversed in SLCAN. ### Latest Mission Planner
Make sure you are using the latest release of mission planner, you can download this from

If you are still having issues with SLCAN now showing the Here 2 try using the Beta verions of Mission Planner, you can download this from the help page. ### Ardupilot
You should have the latest verions of Ardupilot on your Cube when trying to update your Here 2 GPS, if your having prblems getitng the Here 2 to show in SLCAN make sure you have updated your Cube. If your still having issues try flashing your cube to the latest version of a diferent vehicle such as Plane or Rover if your using Copter. ### Boot Delay

If the above does not help try increasing the boot delay pram in ardupilot as follows

BRD_BOOT_DELAY = 7000

**Note**: You should return this to the default value after updating is complete

--- chunk_id: chunk-0185
source_document: here-2-firmware-update-troubleshooting.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 57
content_hash: 27240e6f98987bf7
prev_chunk_id: chunk-0184
next_chunk_id: chunk-0186
section_heading: Solid Green LED's
document_type: technical_reference

## Solid Green LED's

If your Here 2 has solid green led after updating its likely the full process has not competed, you must update both the bootloader and then the application, the update must be completed in full as per the instructions.

--- chunk_id: chunk-0186
source_document: updating-here-2-firmware.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 208
content_hash: dc32f689d72bdb79
prev_chunk_id: chunk-0185
next_chunk_id: chunk-0187
section_heading: **Step 1: Switching the Here 2 to CAN mode**
document_type: technical_reference

## **Step 1: Switching the Here 2 to CAN mode**

*Updating Here 2 Firmware*


![Step 1: Switching the Here 2 to CAN mode](/files/-Lh36ol9MfWy7gEvy2K0)

Remove the case from the Here 2. Unplug the 8-wire cable and replace it with the included 4-wire CAN cable. Move the switch from the I2C position to the CAN position. Note: This step is only required if your Here 2 has the 8-wire Serial/I2C cable which plugs in to the GPS 2 connector on the carrier board. If your Here 2 already has the 4-wire CAN cable attached, you can skip this step. ### Step 2: Connect to the Cube
![Step 2: Connect to the Cube](/files/-Lh37QtBcgNrEXSc7FY4)

Connect the CAN cable to the CAN 1 connector on the carrier board, as shown in the image to the left. Note: On standard carrier boards manufactured before June 2019, this connector is mislabeled as CAN 2. Connect as shown in the image to the left.

--- chunk_id: chunk-0187
source_document: updating-here-2-firmware.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 204
content_hash: 6cbb6b9323d82616
prev_chunk_id: chunk-0186
next_chunk_id: chunk-0188
section_heading: Step 3: Connect USB
document_type: technical_reference

## Step 3: Connect USB

Using the supplied USB cable, connect the Cube to your computer. ### Step 4: Install or update Mission Planner
The required version of mission planner is 1.3.66 or later. Mission planner can be retrieved from

### Step 5: Download ArduCopter master
Released versions of ArduCopter do not have support for SLCAN as of this writing. Download the latest master from firmware.ardupilot.org. The file that you need is called arducopter.apj Direct link:

### Step 6: Flash ArduCopter master
![Step 6: Flash ArduCopter master](/files/-Lh37yHDH_AeWoXKqr4o)

Launch Mission Planner. Click “Initial Setup,” then “Load custom firmware.” Navigate to the arducopter.apj file that you downloaded and select it. ### Step 7: Enable CAN
![Step 7: Enable CAN](/files/-Lh388vlVbVYWQuJE9RZ)

Click **Config/Tuning** then **Full Parameter List** then search for **CAN_**, change **CAN_P1_DRIVER** to **1** and click **Write Params**. ### Step 8: Reboot the cube
Unplug the USB cable, plug it back in and reconnect Mission Planner.

--- chunk_id: chunk-0188
source_document: updating-here-2-firmware.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 178
content_hash: dfeec94420ab0c68
prev_chunk_id: chunk-0187
next_chunk_id: chunk-0189
section_heading: Step 9: Using the Mission Planner SLCAN interface
document_type: technical_reference

## Step 9: Using the Mission Planner SLCAN interface

![Step 9: Using the Mission Planner SLCAN interface](/files/-Lh38O_kDK8pmhxWlMNY)

Click **Initial Setup**, then **Optional Hardware**, then DroneCAN, then **SLCan Mode CAN1**. Connected CAN devices (in this case, a Here 2) will be listed. ### Step 10: Flash the bootloader updater
![](/files/-Lh38ZLUIcJjhJLlBRPx)

The bootloader updater performs the procedure listed above, which will start immediately after the firmware update completes. On the Here 2 entry in the list, select **Update**, navigate to the **bootloader_updater** file and open it. After this point, **DO NOT DISCONNECT POWER UNTIL THE LEDS ARE EITHER GREEN OR YELLOW, OR 3 MINUTES HAVE ELAPSED.**

{% file src="/files/-Lh38oLVBzDWLzUSw3kI" %}

### Step 11: Flash the application
Select **Update** again, navigate to the **Here2_com.here_2.1-crc.bin** file and open it to flash the latest firmware. {% file src="/files/WwiRhaFM55dhO0QQDcCl" %}

--- chunk_id: chunk-0189
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: a20d31095f5d8fd6
prev_chunk_id: chunk-0188
next_chunk_id: chunk-0190
section_heading: Here 3 Manual
document_type: maintenance_procedure

# Here 3 Manual

![](/files/SCmHnfiFHzdwRnpVwKMV)

### Overview

Here 3/3+ GPS is a Cost-efficient GNSS system that supports RTK mode. Positioning accuracy down to centimetre-level in an ideal environment. Improved dust and water resistance over the Here+ (Not guaranteed to be water-proof).High data rate, upgradeability, noise immunity, and real-time features from the DroneCAN protocol, with Here3+ now moving to DroneCAN 8Mbit bus speed. Here 3 is Equipped with the STM32F302 processor while the Here3+ jumps to the Dual core STM32H757 running at 400MHz with 2MByte Flash, and 1MByte RAM. Supports future firmware updates. Support from ground control software. Future updates will be available from Mission Planner. Built-in Inertial Measurement Unit (compass, gyroscope, and accelerometer), for advanced navigation needs. ***

### Here 3 / Here 3+ :
#### Hardware Specification | **Model**                   |                     Here 3                     |                     Here3+                     |
| --------------------------- | :--------------------------------------------: | :--------------------------------------------: |
| **Receiver Type**           | u-blox **high precision GNSS modules** (M8P-2) | u-blox **high precision GNSS modules** (M8P-2) |
| **Satellite Constellation** |       GPS L1C/A, GLONASS L1OF, BeiDou B1I      |       GPS L1C/A, GLONASS L1OF, BeiDou B1I      |
| **Positioning accuracy**    |          3D FIX: 2.5 m / RTK: 0.025 m          |          3D FIX: 2.5 m / RTK: 0.025 m          |
| **Processor**               |                    STM32F302                   |                    STM32H757                   |
| **IMU sensor**              |                    ICM20948                    |                 ICM42688,RM3100                |
| **Navigation Update Rate**  |                      8 hz                      |                      8 hz                      |
| **Communication Protocol**  |                DroneCAN 1Mbit/s                |                DroneCAN 8Mbit/s                |
| **Operating Temperature**   |                   -40℃ to 85℃                  |                   -40℃ to 85℃                  |
| **Dimension**               |                 68mmx68mmx16mm                 |                 68mmx68mmx16mm                 |
| **Weight**                  |                      48.8g                     |                      51.8g                     | #### Pinout

![](/files/nqvm1XsqYom32MiJ0jCG) | Pin | Definition | Cable color |
| :-: | :--------: | :---------: |
|  1  |   VCC_5V  |     red     |
|  2  |   CAN_H   |    brown    |
|  3  |   CAN_L   |    orange   |
|  4  |     GND    |    black    |

--- chunk_id: chunk-0190
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: 8334a148fddd523f
prev_chunk_id: chunk-0189
next_chunk_id: chunk-0191
section_heading: Here 3 Manual
document_type: maintenance_procedure

#### Pinout

![](/files/nqvm1XsqYom32MiJ0jCG) | Pin | Definition | Cable color |
| :-: | :--------: | :---------: |
|  1  |   VCC_5V  |     red     |
|  2  |   CAN_H   |    brown    |
|  3  |   CAN_L   |    orange   |
|  4  |     GND    |    black    | ![](/files/iBcloY33j61K5k2xtsmO) | Pin | Definition | Cable color |
| :-: | :--------: | :---------: |
|  1  |   VCC_5V  |     grey    |
|  2  |   CAN_H   |     blue    |
|  3  |   CAN_L   |    white    |
|  4  |     GND    |    green    | **Note: Current firmware only support CAN 1 ,CAN 2 is not supported. Dual CAN will be enabled in a future firmware update.**

### Operation instruction
#### 1. Using Ardupilot Firmware：

**Using one Here 3 / Here 3+：**

Connect the 4 pin CAN cable connector to CAN1 or CAN2 port on the flight controller. Power the flight controller and connect it to Mission Planner. Go to "Config/Tuning > Full Parameter List" and modify the following parameters:

**CAN_D1_PROTOCOL: 1** set virtual driver of CAN1 to DRONECAN

**CAN_D2_PROTOCOL: 1** set virtual driver of CAN 2 to DRONECAN

**CAN_P1_DRIVER: 1** set this parameter to enable CAN 1 bus

**CAN_P2_DRIVER: 1** set this parameter to enable CAN 2 bus

**GPS_TYPE: 9** set the communication protal type of GPS 1 to DRONECAN

**NTF_LED_TYPES: 231** Set to DRONECAN for LED type

There is no external safety switch. Set BRD_SAFETYENABLE as 0 to disable safety switch, or connect an physical external safety switch

Click "Write Params" when done. CAN functions will be available after rebooting the flight controller.

--- chunk_id: chunk-0191
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 333
content_hash: 43ec2524ff1d5de0
prev_chunk_id: chunk-0190
next_chunk_id: chunk-0192
section_heading: Here 3 Manual
document_type: maintenance_procedure

Set BRD_SAFETYENABLE as 0 to disable safety switch, or connect an physical external safety switch

Click "Write Params" when done. CAN functions will be available after rebooting the flight controller. **Using two Here 3 / Here 3+：**

As the document is written，The firmware used for flight control is ArduCopter 4.1.5, which automatically allocate 2 node ID for Here 3 / Here 3+，you can perform following operation directly. > Old firmware might not be able to automatically allocate 2 node ID . Need to use latest firmware and perform following operation to manually assigning node ID. Connect two Here 3 / Here 3+ CAN cable to the CAN1 and CAN 2 port of the flight controller

Power up flight controller and connect to Mission Planner. Go to "Config/Tuning > Full Parameter List" and modify the following parameters:

**CAN_D1_PROTOCOL: 1** set virtual driver of CAN1 to DRONECAN

**CAN_D2_PROTOCOL: 1** set virtual driver of CAN 2 to DRONECAN

**CAN_P1_DRIVER: 1** set this parameter to enable CAN 1 bus

**CAN_P2_DRIVER: 1** set this parameter to enable CAN 2 bus

**GPS_TYPE: 9** set the communication protocol type of GPS 1 to DRONECAN

**GPS_TYPE2：9** set the communication protocol type of GPS 2 to DRONECAN

**NTF_LED_TYPES: 231** Set to DRONECAN for LED type

There is no external safety switch on Here 3 / Here 3+. You can set BRD_SAFETYENABLE to 0 to disable safety switch, or connect an physical external safety switch

Click "Write Params" when done. CAN functions will be available after rebooting the flight controller.

--- chunk_id: chunk-0192
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 378
content_hash: ef120ec776e772f5
prev_chunk_id: chunk-0191
next_chunk_id: chunk-0193
section_heading: Here 3 Manual
document_type: maintenance_procedure

You can set BRD_SAFETYENABLE to 0 to disable safety switch, or connect an physical external safety switch

Click "Write Params" when done. CAN functions will be available after rebooting the flight controller. **Compass Setting(Using the latest version of firmware)：**

> As the document is written，The firmware used for flight control is ArduCopter 4.1.5

When using Cube Black , from top to bottom are compass 1 ,2 and 3 .When using Cube Orange ，from top to bottom are compass 1 and 2. The external compass will be displayed in BusType list as UAVCAN. Usually need to set the external compass to NO 1 compass , if the external compass is not NO 1 compass, please do the following operation. ![](/files/wNRHo9ly4fJgpgBa8cXX)

If you want to use CAN external compass as the NO 1 compass ,please move the UAVCAN compass to the top. ![](/files/l65Rp0qHQaFPvbUagk6k)

Select the compass you want to use (the default is normally ok).Then click "Start" to begin calibrate the compass,follow the process until the calibration is done . ![](/files/cw4Hz6p1OmbjihkoiEPn)

#### 2. Using PX4 firmware：

As the document is written，The firmware used for flight control is PX4 V1.12.3, which automatically allocate 2 node ID ，you can perform following operation directly. > Old firmware might not be able to automatically allocate CAN node ID . Need to manually assigning node ID Here 3 / Here 3+ with latest firmware and perform following operation

![](/files/fDmIdmfKXyxfgmL5TcJs)

Load PX4 firmware into the autopilot. Connect the 4pin CAN connector from Here3 to CAN1 or CAN2 port on flight control. Connect to the flight control and set the parameter "UAVCAN_ENABLE" to "Sensor Automatic Config". The Here3 will now work. #### 3. LED defination(with ardupilot firmware)：

Flashing red and blue: Initializing gyroscopes.

--- chunk_id: chunk-0193
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 357
content_hash: df2eb73434884312
prev_chunk_id: chunk-0192
next_chunk_id: chunk-0194
section_heading: Here 3 Manual
document_type: maintenance_procedure

#### 3. LED defination(with ardupilot firmware)：

Flashing red and blue: Initializing gyroscopes. Hold the vehicle still and level while it initializes the sensors. Flashing blue: Disarmed, no GPS lock found. Solid blue: Armed with no GPS lock. Flashing green: Disarmed (ready to arm), GPS lock acquired. Fast Flashing green: Same as above but GPS is using SBAS. Solid green - with single long tone at the time of arming: Armed, GPS lock acquired. Ready to fly. Double flashing yellow: Failing pre-arm checks (system refuses to arm). Please check the pre-arm error message. Single Flashing yellow: Radio failsafe activated. Flashing yellow - with quick beeping tone: Battery failsafe activated. Flashing yellow and blue - with high-high-high-low tone sequence (dah-dah-dah-doh): GPS glitch or GPS failsafe activated. Flashing red and yellow - with rising tone: EKF or Inertial Nav failure

Flashing purple and yellow: Barometer glitched

Solid Red: Error. Usually due to cannot detect SD card (please try to re-plug or replace SD card), MTD device, or IMU sensors. Analysis can be found in BOOT.txt in SD card. Solid Red with SOS tone sequence : SD Card missing (or other SD error like bad format etc.)

Not lighting up: No firmware detected or firmware corrupted. ### RTK Use Operation
#### 1. Base/Rover Survey by Mission Planner

> This part of the tutorial uses Mission Planner ground software and Arducopter-4.1.5 flight firmware for operating instructions. RTK mode requires a base station. The following tutorial Use "Here+" base stations as an example. Users can also use other uBlox M8P/F9P base stations (such as HerePro, etc.), or use the local wireless RTK correction service.

--- chunk_id: chunk-0194
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 385
content_hash: 3e85b9f00a4728e9
prev_chunk_id: chunk-0193
next_chunk_id: chunk-0195
section_heading: Here 3 Manual
document_type: maintenance_procedure

The following tutorial Use "Here+" base stations as an example. Users can also use other uBlox M8P/F9P base stations (such as HerePro, etc.), or use the local wireless RTK correction service. **Prepare Before use：**

To use Here 3 / Here 3+ on a UAV, you need the following hardware： Computer, telemetry modules, **Here 3 / Here 3+* , Base Antenna, Base, Tripod(Stand). ![](/files/H5FaywgDlvrdZw679Uw7)

**Before starting to use, please make sure that the hardware connection is correct:**

**Ground side:** Connect base antenna to base station, then connect the base station module to computer through USB port; Telemetry module is connected to another USB port of the same computer. **UAV side**: Connect Here 3 / Here 3+ to CAN interface , telemetry module to the TELEM interface on flight control. ![](/files/mLAMWkldWMxtOrzqinRP)

**Antenna Placing**

**Placing the RTK Antenna is very important for getting precise RTK positioning**

Normal GPS positioning,you only have to places the device near a window in your room and it would provide you a GPS location over a period of time. But that's not enough for RTK. For the working environment of RTK, there are special requirements on antenna placement, which are much stricter than GPS. The best environment forthe base and rover antenna is a clear view of the sky that is 30 degrees above the horizon. RTK antenna can be elevated but make sure that there are no obstacles around, such as buildings, trees, cars, and etc

**Example of a bad environment:** indoors, urban area, forest, near the ground. **Example of a good environment:** Open spaces, peak of the mountains, roof of the buildings. Do not place the antenna near electronic devices, as high power electronic devices nearby may affect the radio frequency noise of GPS signal.

--- chunk_id: chunk-0195
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 286
content_hash: 44d02bb053d6ad5d
prev_chunk_id: chunk-0194
next_chunk_id: chunk-0196
section_heading: Here 3 Manual
document_type: maintenance_procedure

**Example of a good environment:** Open spaces, peak of the mountains, roof of the buildings. Do not place the antenna near electronic devices, as high power electronic devices nearby may affect the radio frequency noise of GPS signal. Examples are mobile phone base stations, high voltage transformers, and etc. Please place the base station in an outdoor environment with sufficient sky coverage to obtain a good satellite signal. Place the base station on a stable and elevated platform, such as a tripod. ![](/files/9pyeZgl6CPeWE6RAfJia)

**Base Module Setting using Mission Planner**

Start with a base module setup first. During the base station setup, the rover and the UAV do not need to be turned on. Open the Mission Planner ground station software on your computer and go to the "initial setup → Optional Hardware → RTK/GPS Inject". You will see the following page:

![](/files/oQshKaoLv324ZFhSn3WG)

Select the correct base module com port in the top left corner and click connect. In the SurveyIn Acc section, enter the absolute geographic accuracy that you expect your Here+ base station to achieve. In the Time column, enter the minimum survey time you expect. Click on Restart, the ground station will transfer the data you have entered to the Here3 base module, the base module will start a new round of surveying.

--- chunk_id: chunk-0196
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 353
content_hash: 9f8275139b7df8d8
prev_chunk_id: chunk-0195
next_chunk_id: chunk-0197
section_heading: Here 3 Manual
document_type: maintenance_procedure

In the Time column, enter the minimum survey time you expect. Click on Restart, the ground station will transfer the data you have entered to the Here3 base module, the base module will start a new round of surveying. You will see the following page:

![](/files/8GPFuNSlRIi9oITZO85C)

During the survey process, the right box will show the current survey status:

**The Position is invalid:** The base station has not yet reached a valid location;

**In Progress:** The survey is still in progress；

**Duration:** The number of seconds that the current surveying task has been executed;

**Observation:** the number of observations acquired;

**Current Acc:** Absolute geographic accuracy that the current base station can achieve;

**The Green bar** at the lower part of the Mission Planner page shows the current satellites being detected and the signal strength related to each satellite. At least eight or more satellite signals need to be guaranteed to exceed the red line ( Only when the satellite signal exceeds the red line is the effective number of satellites). The base station needs a certain amount of time to meet the accuracy requirements of your input. Testing shows that in an open area without shelter, to achieve the absolute accuracy of 2m takes a few minutes; to reach the absolute accuracy of less than 30cm takes around an hour; to reach the accuracy of 10cm takes a few hours. It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover.

--- chunk_id: chunk-0197
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 388
content_hash: 35edd5635f653c22
prev_chunk_id: chunk-0196
next_chunk_id: chunk-0198
section_heading: Here 3 Manual
document_type: maintenance_procedure

Testing shows that in an open area without shelter, to achieve the absolute accuracy of 2m takes a few minutes; to reach the absolute accuracy of less than 30cm takes around an hour; to reach the accuracy of 10cm takes a few hours. It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover. If your application does not require UAV with high absolute geographic accuracy, you do not need to set the base station's precision too high,which resulting in long survey time. Even if the accuracy of the base station is 1.5 to 2 m, the position accuracy of the rover module relative to the base station can still reach the centimeter level. After the survey is complete, the Mission Planner will display the following page:

![](/files/YHcHZWcb5f8ttOur5h5A)

In the RTCM box it shows that the base status indicator is green and both the GPS and Glonass satellite systems are green (if you want to change the satellite system, refer to the following section). The box on the right says "Position is valid". To store the current location in the Mission Planner: Click "Save Current Pos", enter a name in the dialogue box, and click "OK". As shown below, you can see your saved location in the list. Click the "Use" button for the location you saved. The base station will enter the fixed mode and the status will show "Using FixedLLA". In the future, if you set the base station in the same location, you do not need to conduct the survey again, just click the "Use" button that corresponds to the location you have saved.

--- chunk_id: chunk-0198
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 332
content_hash: 29c99eabe89c3dd7
prev_chunk_id: chunk-0197
next_chunk_id: chunk-0199
section_heading: Here 3 Manual
document_type: maintenance_procedure

The base station will enter the fixed mode and the status will show "Using FixedLLA". In the future, if you set the base station in the same location, you do not need to conduct the survey again, just click the "Use" button that corresponds to the location you have saved. ![](/files/YQNk2jSGvS1Rs2x34CmO)

**Rover Module and Flight Controller Setup**

After the base station is set up, you can turn on the UAV. Using the same telemetry module to connect Mission Planner, the base station data will be transmitted through the telemetry module to the Here3 rover module on the UAV. In the Mission Planner main page, you can see the current GPS status displayed as RTK Float / RTK Fixed / 3D RTK, indicating that the positioning of the UAV has entered the RTK mode. RTK Float is a floating-point solution; RTK Fixed is a fixed solution. RTK Fixed mode has higher accuracy and requires better signal strength. 3D RTK is unified saying of RTK Float / RTK in the Mission Planner Chinese version

![](/files/DEGLPGi3lfONgvLer1wo)

**2. Single Base to Multiple Rovers ****

There are 2 methods to do this: 1) Use 1 telemetry to multiple telemetry broadcasting ;or 2) Use multiple 1 to 1 telemetry modules with USB hub

Ground station configuration: connect all telemetry modules to the computer via USB hub. Open Mission Planner to locate the base then connect it with flight controllers. Select AUTO connecting as shown below. All recognized flight controllers on the ports will be connected.

--- chunk_id: chunk-0199
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 349
content_hash: 915816e7f862ede0
prev_chunk_id: chunk-0198
next_chunk_id: chunk-0200
section_heading: Here 3 Manual
document_type: maintenance_procedure

Select AUTO connecting as shown below. All recognized flight controllers on the ports will be connected. You may select the UAV form the dropdown list below:

![](/files/7we6bi0KqUGufJJhnUen)

If you connected the UAVs with 1 telemetry module, they should share the same COM port:

![](/files/4nIRxG5ovopp1vmZqlul)

### Software Configuration
#### 1.CAN ID change

**Use Cube Black to change ID ：**

Connect each Here 3 / Here 3+ 4 Pin CAN cable to the CAN 1 port of the flight controller(one at a time), and conduct the following procedure. Select "install firmware" from Mission Planner and load the latest copter and plane firmware. ![](/files/3PuvAKttRMhSfs2TCQn7)

After successful installed firmware, change baud to 115200, and click connect. Then go to "Config/Tuning > Full Parameter List" and modify the following parameters:

CAN_D1_PROTOCOL：1 set virtual driver of CAN 1 to DRONECAN

CAN_D2_PROTOCOL：1 set virtual driver of CAN 2 to DRONECAN

After successful loading, select the autopilot SLCAN COM port with 115200 baud rate and Connect and then Go to "Initial Setup - Optional Hardware - DRONECAN", click "SLCan Mode CAN1". ![](/files/yNAPRQyRJKMPcerBDYJY)

When the device settings of Here3 pop-up, click "Parameters" from the right. ![](/files/jWEnwoDPxlY7pxhEJq9J)

In parameter setting page, change uavcan.node_id to 0-125. Click before entering a value. Then, click "Commit Params" to save the changes and completed manual CAN id allocation. ![](/files/EHAYq9Mo6OmD5XHbn376)

**Use Cube Orange to change ID:**

Connect each Here 3 / Here 3+ 4Pin CAN cable to the CAN 1 port of the flight controller(one at a time), and conduct the following procedure. Select "install firmware" from Mission Planner and load the latest copter or plane firmware.

--- chunk_id: chunk-0200
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: fc5ac0a1015687f8
prev_chunk_id: chunk-0199
next_chunk_id: chunk-0201
section_heading: Here 3 Manual
document_type: maintenance_procedure

![](/files/EHAYq9Mo6OmD5XHbn376)

**Use Cube Orange to change ID:**

Connect each Here 3 / Here 3+ 4Pin CAN cable to the CAN 1 port of the flight controller(one at a time), and conduct the following procedure. Select "install firmware" from Mission Planner and load the latest copter or plane firmware. ![](/files/2uJo9jlTB95soAFvQWlG)

After successful loading, select the autopilot SLCAN COM port with 115200 baud rate and Connect and then go to "Config/Tuning > Full Parameter List" and modify the following parameters:

CAN_D1_PROTOCOL：1 set virtual driver of CAN 1 to DRONECAN

CAN_D2_PROTOCOL：1 set virtual driver of CAN 2 to DRONECAN

After successful loading, select the autopilot SLCAN COM port with 115200 baud rate. **Do not click connect . **

Then Go to "Initial Setup - Optional Hardware - UAVCAN", click "SLCan Mode CAN1". ![](/files/LW9P94Bo9DjWgWI8gQTj)

When the device settings of Here 3 / Here 3+ pop-up, click "Parameters" from the right. ![](/files/sdfsN1dJ4JLMbccNM0W2)

In parameter setting page, change uavcan.node_id to 0-125. Click before entering a value. Then, click "Commit Params" to save the changes and completed manual CAN id allocation. ![](/files/qu6N4qYqHVA0BJkDPI4T)

#### 2. Here 3 / Here 3+ firmware upgrade

Please update Mission Planner to the version indicated below(1.3.74) or higher:

![](/files/nxwD2nno97YmrXMCZYL1)

Be aware that the following steps should be done when there is only 1 GPS module connected to autopilot. Connect the HERE3 CAN connector to CAN 1 port on autopilot. Connect to Mission Planner and go to “UAVCAN” tab. Click “SLCan Mode CAN 1” to load CAN GPS status. Click “Menu>Update” to check available updates. Update the HERE3 firmware. (The following procedure is using Here 3 firmware upgrade as an example. The other Here series GPS can also refer to this procedure.)

![](/files/wWWjPe316pl9Ltv2JIPD)

After clicking “Update”it will ask whether to search update from the Internet. Click “Yes”.

--- chunk_id: chunk-0201
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 389
content_hash: 0ea811367f910f73
prev_chunk_id: chunk-0200
next_chunk_id: chunk-0202
section_heading: Here 3 Manual
document_type: maintenance_procedure

The other Here series GPS can also refer to this procedure.)

![](/files/wWWjPe316pl9Ltv2JIPD)

After clicking “Update”it will ask whether to search update from the Internet. Click “Yes”. (Automatically searches for upgraded to the latest stable version firmware)

![](/files/hXiilXaUKTtVPbKsnsCO)

Check firmware version after upgrade.After the upgrade, check whether the version is successfully upgraded. ![](/files/FXxvbKlynyGkcsTHDOjk)

If “no available updates” appears when searching updates. Please turn off your firewall in the system setting and try again. ![](/files/CtIPUL4WHIpOlnkUYum4)

#### 3. Modify Here 3 GNSS constellations

Through the following steps, GNSS constellations being used by HERE 3 can be selected. It requires HERE 3 to be v1.6 or later. Updating instructions are mentioned in “HERE 3 Firmware Update” section above. Be aware that the following steps should be done when there is only 1 GPS module connected to autopilot. Connect the HERE 3 CAN connector to CAN 1 on autopilot. Connect to Mission Planner and go to “UAVCAN” tab. Click “SLCan Mode CAN 1” to load CAN GPS status. After verifying the firmware has already updated to latest, click “Menu – Parameters to enter the setting:

gnssConfig = 8 for BeiDou

gnssConfig = 9 for GPS+BeiDou

gnssConfig = 97 for GPS+GLONASS+QZSS

When done, click “Write Params” and “Commit Params” at the righthand side. ![](/files/EJSqZv7crrQ4WkAKLyYd)

#### 4. HERE3 u-blox Chip Firmware Update

> Here is 3 + U-Blox firmware update method will be released when a new firmware comes out for the M8P-2, the here3+ has the latest firmware at launch, and we will update here if a newer version comes out. The u-blox chip firmware update can be completed only when HERE 3 is updated to latest version. Please follow the instructions in section “HERE 3 Firmware Update” to update your HERE 3 firmware to the latest version.

--- chunk_id: chunk-0202
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: f86930ff0489c06b
prev_chunk_id: chunk-0201
next_chunk_id: chunk-0203
section_heading: Here 3 Manual
document_type: maintenance_procedure

The u-blox chip firmware update can be completed only when HERE 3 is updated to latest version. Please follow the instructions in section “HERE 3 Firmware Update” to update your HERE 3 firmware to the latest version. This instruction uses u-center GUI from u-blox, the correct version should be v20.10 or later:

![](/files/hrmzEIhUZ6ADyNZSOhgB)

Download the u-blox chip firmware. (The latest firmware for u-blox M8P chip is v1.4 when this guide is written):

u-blox M8P chip firmware: :

> Parameter definition:
>
> passThrough = 0 Standard mode
>
> passThrough = 1 Connect to u-center for parameter review
>
> passThrough = 2 Connect to u-center for firmware update on u-blox chip

After downloading the firmware, connect to Mission Planner. Go to UAVCAN tab and modify the parameter “passthrough” to “2”. When done, click “Write Params” and “Commit Params” at the righthand side. ![](/files/KOXHyn5GKjRIwyTet0aX)

Click “Menu > Restart”. After that, uptime should be reset to “00:00:00”. ![](/files/1QkXPvHIlEoxIA6lfQIH)

Click “Menu > CANPassThrough”. Set TCP port to “500” then click “OK”. ![](/files/VjjZMlVBPlbs5lrVuH3b)

Open u-center and connect it (Receiver > Connection > Network connection > New.). ![](/files/zpgoOxc0xNoS41BeRlmr)

Open “Firmware Update Utility” (Tools > Firmware Update.) and set the following:

![](/files/IeqmPCqUcZkiyXOxn6Eo)

Click “GO” at the bottom-left corner to start firmware flashing. Wait until it is finished. ![](/files/Ys69XwBmkb573If4uFfO)

After update completed, connect to Mission Planner. Go to “UAVCAN” tab. Modify the parameter “passThrough” to “0” then write and commit. HERE 3 will now work normally. ![](/files/NI9Ksol8gfywAja7YwWV)

#### 5. Connect HERE 3 to u-center for GNSS-related Parameter Checking

> Here is 3 + details to follow as this feature gets expanded

The u-blox chip Parameter Checking can be completed only when Here 3 / Here 3+ is updated to latest version.

--- chunk_id: chunk-0203
source_document: here-3-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 184
content_hash: ca4490c3d55c3510
prev_chunk_id: chunk-0202
next_chunk_id: chunk-0204
section_heading: Here 3 Manual
document_type: maintenance_procedure

![](/files/NI9Ksol8gfywAja7YwWV)

#### 5. Connect HERE 3 to u-center for GNSS-related Parameter Checking

> Here is 3 + details to follow as this feature gets expanded

The u-blox chip Parameter Checking can be completed only when Here 3 / Here 3+ is updated to latest version. Please follow the instructions in section “HERE 3 Firmware Update” to update your HERE 3 firmware to the latest version. The u-center must be on v20.10 or later:

![](/files/j9R1DrbBnMoJPrv8YdZ9)

Connect to Mission Planner and go to “UAVCAN” tab. Modify “passThrough” to “1”. ![](/files/MM6hEGOtUHPuN9sLSlaz)

Click “Menu > CANPassThrough”. Set TCP port to 500 and click “OK”. ![](/files/WKtJgBU32i9qAtvlWCDh)

Open u-center and connect it (Connect > Network Connection > new). ![](/files/wPXYlsHtuu6Qd9ZaJ64W)

When connected, parameters and messages can be viewed in u-center. When finished reviewing, go back to Mission Planner and set “passThrough” to “0”. ![](/files/a5nQEBwc2wwU4flFsw6B)

2022.06.27

--- chunk_id: chunk-0204
source_document: here-4-base.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 621
content_hash: 237fa24c0d1aed0c
prev_chunk_id: chunk-0203
next_chunk_id: chunk-0205
section_heading: Overview
document_type: technical_reference

## Overview

*Here 4 Base*


The Here 4 Base, a product of CubePilot, compatibile with both Ardupilot and PX4 systems. It also seamlessly interfaces with ground control stations, including Mission Planner and QGroundControl. Employing RTK (Real-Time Kinematic) technology offers more precise position estimation compared to standard GNSS systems. Its potential for centimeter-level accuracy greatly enhances flight precision. Furthermore, the Here 4 Base is designed for user-friendliness. Setting it up to work with Mission Planner is a straightforward process, requiring minimal configuration. For data communication between rover and base modules, a pair of telemetry modules is required (please note that these modules are not included in the standard package). ### Specification | GNSS                      | BeiDou, Galileo, GLONASS, GPS / QZSS                                           |
| ------------------------- | ------------------------------------------------------------------------------ |
| Number of concurrent GNSS | 4 Constellations                                                               |
| GNSS bands                | B1I, B2a, E1B/C, E5a, L1C/A, L1OF, L5                                          |
| Size                      | 40mm x 41mm x 11mm                                                             |
| Weight                    | 43g（With cable）/ 18g（Without cable）                                            |
| Operation temperature     | -40 ℃ to 80 ℃                                                                  |
| Antenna                   | **L1 & L5** SMA connector Antenna ( item does not come with external antenna ) | | **Parameter**                  | **Specification**                       |                                 |
| ------------------------------ | --------------------------------------- | ------------------------------- |
| Receiver type                  | Multi-band GNSS high precision receiver |                                 |
| Accuracy of time pulse signal  | RMS                                     | 30 ns                           |
|                                | 99%                                     | 60 ns                           |
| Frequency of time pulse signal |                                         | 0.25 Hz to 10 MHz(configurable) |
| Operational limits             | Dynamics                                | ≤ 4 g                           |
|                                | Altitude                                | 80,000 m                        |
|                                | Velocity                                | 500 m/s                         |
| Velocity accuracy              |                                         | 0.05 m/s                        |
| Dynamic heading accuracy       |                                         | 0.3 deg                         | ### Acquisition |             | GPS+GLO+GAL+BDS | GPS+BDS+GAL | GPS+GAL | GPS+GLO | GPS+BDS | GPS |
| ----------- | --------------- | ----------- | ------- | ------- | ------- | --- |
| Cold start  | 27s             | 28s         | 29s     | 30s     | 27s     | 37s |
| Hot start   | 3s              | 3s          | 3s      | 3s      | 3s      | 3s  |
| Aided start | 4s              | 4s          | 4s      | 4s      | 4s      | 5s  | ### Max Navigation update rate

| | GPS+GLO+GAL+BDS | GPS+BDS+GAL | GPS+GAL | GPS+GLO | GPS+BDS | GPS   |
| ----------- | --------------- | ----------- | ------- | ------- | ------- | ----- |
| RTK         | 7 Hz            | 8 Hz        | 14 Hz   | 15 Hz   | 10 Hz   | 25 Hz |
| PVT         | 7 Hz            | 8 Hz        | 14 Hz   | 20 Hz   | 11 Hz   | 25 Hz |
| RAW         | 10 Hz           | 10 Hz       | 20 Hz   | 25 Hz   | 20 Hz   | 25 Hz |

--- chunk_id: chunk-0205
source_document: here-4-base.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 760
content_hash: 405f404dfda549d2
prev_chunk_id: chunk-0204
next_chunk_id: chunk-0206
section_heading: Overview
document_type: technical_reference

### Max Navigation update rate

| | GPS+GLO+GAL+BDS | GPS+BDS+GAL | GPS+GAL | GPS+GLO | GPS+BDS | GPS   |
| ----------- | --------------- | ----------- | ------- | ------- | ------- | ----- |
| RTK         | 7 Hz            | 8 Hz        | 14 Hz   | 15 Hz   | 10 Hz   | 25 Hz |
| PVT         | 7 Hz            | 8 Hz        | 14 Hz   | 20 Hz   | 11 Hz   | 25 Hz |
| RAW         | 10 Hz           | 10 Hz       | 20 Hz   | 25 Hz   | 20 Hz   | 25 Hz | ### Convergence Time

| | GPS+GLO+GAL+BDS | GPS+BDS+GAL | GPS+GAL | GPS+GLO | GPS+BDS | GPS    |
| ----------- | --------------- | ----------- | ------- | ------- | ------- | ------ |
| RTK         | < 12 s          | < 12 s      | < 12 s  | < 12 s  | < 12 s  | < 30 s | ### Horizontal pos. accuracy |      | GPS+GLO+GAL+BDS    | GPS+BDS+GAL        | GPS+GAL            | GPS+GLO            | GPS+BDS            | GPS                |
| ---- | ------------------ | ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| PVT  | 1.5 m CEP          | 1.5 m CEP          | 1.5 m CEP          | 1.5 m CEP          | 1.5 m CEP          | 1.5 m CEP          |
| SBAS | 1.0 m CEP          | 1.0 m CEP          | 1.0 m CEP          | 1.0 m CEP          | 1.0 m CEP          | 1.0 m CEP          |
| RTK  | 0.01 m + 1 ppm CEP | 0.01 m + 1 ppm CEP | 0.01 m + 1 ppm CEP | 0.01 m + 1 ppm CEP | 0.01 m + 1 ppm CEP | 0.01 m + 1 ppm CEP | ### Vertical pos. accuracy |      | GPS+GLO+GAL+BDS | GPS+BDS+GAL        | GPS+GAL            | GPS+GLO            | GPS+BDS            | GPS                |
| ---- | -------------------------- | ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| PVT  | 2.0 m R50                  | 2.0 m R50          | 2.0 m R50          | 2.0 m R50          | 2.0 m R50          | 2.0 m R50          |
| SBAS | 1.5 m R50                  | 1.5 m R50          | 1.5 m R50          | 1.5 m R50          | 1.5 m R50          | 1.5 m R50          |
| RTK  | 0.01 m + 1 ppm R50         | 0.01 m + 1 ppm R50 | 0.01 m + 1 ppm R50 | 0.01 m + 1 ppm R50 | 0.01 m + 1 ppm R50 | 0.01 m + 1 ppm R50 | | GNSS                     |        | **GPS+GLO+GAL+BDS** | **GPS+BDS+GAL** |
| ------------------------ | ------ | ------------------- | --------------- |
| Horizontal pos. accuracy | SPARTN | < 0.10 m CEP        | < 0.10 m CEP    |
|                          | CLAS   | 0.04 m CEP          | 0.04 m CEP      |
| Vertical pos. accuracy   | SPARTN | < 0.20 m R50        | < 0.20 m R50    |
|                          | CLAS   | 0.08 m R50          | 0.08 m R50      |
| Convergence time         | SPARTN | < 65 s              | < 65 s          |
|                          | CLAS   | < 90 s              | < 90 s          | | GNSS        |                  | GPS+GLO+GAL+BDS |
| ----------- | ---------------- | --------------- |
| Sensitivity | Tracking and nav | -167 dBm        |
| Sensitivity | Reacquisition    | -160 dBm        |
| Sensitivity | Cold start       | -148 dBm        |
| Sensitivity | Hot start        | -157 dBm        |

--- chunk_id: chunk-0206
source_document: here-4-base.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 449
content_hash: a47bcc017bceee6a
prev_chunk_id: chunk-0205
next_chunk_id: chunk-0207
section_heading: Overview
document_type: technical_reference

| GNSS                     |        | **GPS+GLO+GAL+BDS** | **GPS+BDS+GAL** |
| ------------------------ | ------ | ------------------- | --------------- |
| Horizontal pos. accuracy | SPARTN | < 0.10 m CEP        | < 0.10 m CEP    |
|                          | CLAS   | 0.04 m CEP          | 0.04 m CEP      |
| Vertical pos. accuracy   | SPARTN | < 0.20 m R50        | < 0.20 m R50    |
|                          | CLAS   | 0.08 m R50          | 0.08 m R50      |
| Convergence time         | SPARTN | < 65 s              | < 65 s          |
|                          | CLAS   | < 90 s              | < 90 s          | | GNSS        |                  | GPS+GLO+GAL+BDS |
| ----------- | ---------------- | --------------- |
| Sensitivity | Tracking and nav | -167 dBm        |
| Sensitivity | Reacquisition    | -160 dBm        |
| Sensitivity | Cold start       | -148 dBm        |
| Sensitivity | Hot start        | -157 dBm        | ### Pinout | Pin | Definition |
| :-: | :--------: |
|  1  |   VCC_5V  |
|  2  |   usb-dp   |
|  3  |   usb-dn   |
|  4  |     GND    |
|  5  |     GND    | ### U-blox Firmware Update

To upgrade the base station module, connect it to your computer's USB interface using a USB cable. #### Upgrading Process

To initiate the U-center software, click on the connection button (refer to red frame indicated below). Then, choose the COM port that corresponds to your base module. Please remember not to have this port connected to any other software, as it will occupy the port and render it unavailable for use. **Click Tools>Firmware upgrade.**

**Download firmware from U-blox official website. **

()

**Please made sure baud rate is 230400**. Wait for programing. Done

**(If the upload process is successful, you will see the upgrade interface displayed in green. However, if the upgrade fails, the interface will appear in red. If the process gets interrupted or becomes unresponsive for an extended period, you will need to power cycle the modules and then attempt the uploading process again.)**

--- chunk_id: chunk-0207
source_document: here-4-base.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: 98e87b0c61c10c52
prev_chunk_id: chunk-0206
next_chunk_id: chunk-0208
section_heading: Operation instruction
document_type: technical_reference

## Operation instruction
### 1. Base/Rover Survey by Mission Planner

> This part of the tutorial uses Mission Planner ground software and Arducopter-4.3.5 flight firmware for operating instructions. To use Here 4 Base on a UXV, you need the following hardware： Computer, telemetry modules, Here4 Base , Base Antenna, Tripod. **Before starting to use, please make sure that the hardware connection is correct:**

**Ground side:** Connect base antenna to base station, then connect the base station module to computer through USB port; Telemetry module is connected to another USB port of the same computer. **UXV side**: Connect Here 4 Base to CAN interface , telemetry module to the TELEM interface on flight control. #### **Antenna Placing**

**Placing the RTK Antenna is very important for getting precise RTK positioning**

Normal GPS positioning, only requires you to place the device near a window and it will provide you a GPS location over a period of time. But that's not enough for RTK. For the working environment of RTK, there are special requirements on antenna placement, which are much stricter than GPS. The best environment for the base and rover antenna is a clear view of the sky that is 30 degrees above the horizon. RTK antenna can be elevated but ensure that there are no obstacles around, such as buildings, trees, cars, and etc

**Example of a bad environment:** indoors, urban areas, forests, or near the ground. **Example of a good environment:** Open spaces, peak of a mountain, roof of a building. Do not place the antenna near electronic devices, as high power electronic devices in close proximity may affect the radio frequency noise of the GPS signal. Examples are mobile phone base stations, high voltage transformers, etc. Please place the base station in an outdoor environment with sufficient sky coverage to obtain a good satellite signal. Place the base station on a stable and elevated platform, such as a tripod. #### **Base Module Setting using Mission Planner**

Start with a base module setup first. During the base station setup, the rover and the UXV do not need to be turned on. Open the Mission Planner ground station software on your computer and go to the "initial setup → Optional Hardware → RTK/GPS Inject".

--- chunk_id: chunk-0208
source_document: here-4-base.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 9ce7916ca39f45cf
prev_chunk_id: chunk-0207
next_chunk_id: chunk-0209
section_heading: Operation instruction
document_type: technical_reference

During the base station setup, the rover and the UXV do not need to be turned on. Open the Mission Planner ground station software on your computer and go to the "initial setup → Optional Hardware → RTK/GPS Inject". You will see the following page:

Select the correct base module com port in the top left corner and click connect. In the SurveyIn Acc section, enter the absolute geographic accuracy that you expect your Here 4 Base station to achieve. In the Time column, enter the minimum survey time you expect. Click on Restart, the ground station will transfer the data you have entered to the Here 4 base module, the base module will start a new round of surveying. You will see the following page:

During the survey process, the right box will show the current survey status:

**The Position is invalid:** The base station has not yet reached a valid location;

**In Progress:** The survey is still in progress；

**Duration:** The number of seconds that the current surveying task has been executed;

**Observation:** the number of observations acquired;

**Current Acc:** Absolute geographic accuracy that the current base station can achieve;

**The Green bar** at the lower part of the Mission Planner page shows the current satellites being detected and the signal strength related to each satellite. At least eight or more satellite signals need to be guaranteed to exceed the red line ( Only when the satellite signal exceeds the red line is the effective number of satellites). The base station needs a certain amount of time to meet the accuracy requirements of your input. Testing shows that in an open area without shelter, to achieve the absolute accuracy of 2m takes a few minutes; to reach the absolute accuracy of less than 30cm takes around an hour; to reach the accuracy of 10cm takes a few hours. It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover. If your application does not require UXV with high absolute geographic accuracy, you do not need to set the base station's precision too high, which resulting in long survey time.

--- chunk_id: chunk-0209
source_document: here-4-base.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: 1d4a95ebf40dd11e
prev_chunk_id: chunk-0208
next_chunk_id: chunk-0210
section_heading: Operation instruction
document_type: technical_reference

It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover. If your application does not require UXV with high absolute geographic accuracy, you do not need to set the base station's precision too high, which resulting in long survey time. Even if the accuracy of the base station is 1.5 to 2 m, the position accuracy of the rover module relative to the base station can still reach the centimeter level. After the survey is complete, the Mission Planner will display the following page:

In the RTCM box it shows that the base status indicator is green and both the GPS and Glonass satellite systems are green (if you want to change the satellite system, refer to the following section). The box on the right says "Position is valid". To store the current location in the Mission Planner: Click "Save Current Pos", enter a name in the dialogue box, and click "OK". As shown below, you can see your saved location in the list. Click the "Use" button for the location you saved. The base station will enter the fixed mode and the status will show "Using FixedLLA". In the future, if you set the base station in the same location, you do not need to conduct the survey again, just click the "Use" button that corresponds to the location you have saved. ### **Rover Module and Flight Controller Setup**

After the base station is set up, you can turn on the UXV. Using the same telemetry module to connect Mission Planner, the base station data will be transmitted through the telemetry module to the Here 4 rover module on the UXV. In the Mission Planner main page, you can see the current GPS status displayed as RTK Float / RTK Fixed / 3D RTK, indicating that the positioning of the UXV has entered the RTK mode. RTK Float is a floating-point solution; RTK Fixed is a fixed solution. RTK Fixed mode has higher accuracy and requires better signal strength. 3D RTK is unified saying of RTK Float / RTK in the Mission Planner version. ### **2. Single Base to Multiple Rovers**

There are 2 methods to do this:

1.

--- chunk_id: chunk-0210
source_document: here-4-base.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 137
content_hash: 38e9b4f6dec12944
prev_chunk_id: chunk-0209
next_chunk_id: chunk-0211
section_heading: Operation instruction
document_type: technical_reference

### **2. Single Base to Multiple Rovers**

There are 2 methods to do this:

1. Use 1 telemetry to multiple telemetry broadcasting ;

   or

   Use multiple 1 to 1 telemetry modules with USB hub

Ground station configuration: connect all telemetry modules to the computer via USB hub. Open Mission Planner to locate the base then connect it with flight controllers. Select AUTO connecting as shown below. All recognized flight controllers on the ports will be connected. You may select the UXV form the dropdown list below:

If you connected the UXVs with 1 telemetry module, they should share the same COM port:

2023/09/28

--- chunk_id: chunk-0211
source_document: here-4-blue.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 301
content_hash: 1c64d00f289f0094
prev_chunk_id: chunk-0210
next_chunk_id: chunk-0212
section_heading: Here 4 Blue
document_type: technical_reference

# Here 4 Blue

**Functional Overview**

The Here4 Blue is a professional-grade GNSS navigation module featuring integrated Remote ID broadcasting capability (CubeID™)**.** It provides accurate positioning data to the flight controller while simultaneously broadcasting identification and telemetry data via Bluetooth to meet regulatory requirements. **Core Capabilities**

* Precision Navigation: Supports multi-band GNSS for reliable flight control and autonomous positioning. * Integrated Remote ID (CubeID™): Provides real-time broadcast of identification and telemetry data to comply with FAA and international tracking requirements
* Secure & Compliant: Designed to meet NDAA requirements, making it authorized for use in government-restricted and defense-related applications. **Here4 Blue vs. Here4**

The Here4 Blue retains the industry-leading GNSS performance of the standard Here4 but is differentiated by its focus on regulatory transparency and manufacturing security:

* Bluetooth 5.2 and CubeID™: Features a dedicated 2.4 GHz nRF module for high-reliability Remote ID broadcasting, enabling FAA compliance without external hardware. * Secure Supply Chain: To meet NDAA standards, the Here4 Blue is manufactured in the United States or allied countries (typically the USA or Taiwan), ensuring suitability for government and enterprise projects. **Testing and Compliance**

The Here4 Blue has undergone extensive third-party laboratory testing to ensure it meets international safety and radio standards, including:

* Radio Interference: FCC (USA), CE (EU), UKCA (UK), RCM (Australia/NZ)
* Material Safety: RoHS (Hazardous Substances), California Proposition 65 (Chemical Disclosure)

--- chunk_id: chunk-0212
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 149
content_hash: 0e48c929e04595e0
prev_chunk_id: chunk-0211
next_chunk_id: chunk-0213
section_heading: Here 4 **High Precision Dual-band RTK Navigation**
document_type: maintenance_procedure

## Here 4 **High Precision Dual-band RTK Navigation**

*Here 4 Manual*

### Overview
Here 4 is a professional High Precision Dual-band RTK Navigation module. It supports multiple GNSS options such as BeiDou, Galileo, GLONASS, GPS, QZSS. The Here 4 utilizes advanced algorithms and multi-frequency DGNSS signals to quickly achieve an RTK Fix within seconds. This results in highly reliable positioning at an accuracy within centimeters. The Here 4 goes beyond being a simple GNSS module. It combines flight control and navigation functionalities into a single device. With 8 PWM or BDSHOT outputs, an RCIN, Hotshoe, and camera trigger, it offers a self-contained solution for accurate mapping and precise control capabilities. ### Features

--- chunk_id: chunk-0213
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: 09a62e6f7d6e841b
prev_chunk_id: chunk-0212
next_chunk_id: chunk-0214
section_heading: 1. Equipped with u-blox F9P, a professional high precision Dual-band RTK navigation module.
document_type: maintenance_procedure

1. Equipped with u-blox F9P, a professional high precision Dual-band RTK navigation module.

--- chunk_id: chunk-0214
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 30
content_hash: 9112b054003f73c0
prev_chunk_id: chunk-0213
next_chunk_id: chunk-0215
section_heading: 2. Powerful processing performance provided by a built-in STM32H7 chip. It offers real-time processing and data optimiza
document_type: maintenance_procedure

2. Powerful processing performance provided by a built-in STM32H7 chip. It offers real-time processing and data optimization, and Unmanned Industry standard AP_Periph Firmware.

--- chunk_id: chunk-0215
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 26
content_hash: 11f7f552292d2947
prev_chunk_id: chunk-0214
next_chunk_id: chunk-0216
section_heading: 3. The tailor-made Dual-band antenna from Taoglas supports L1and L5 frequencies. It features high gain, high sensitivity
document_type: maintenance_procedure

3. The tailor-made Dual-band antenna from Taoglas supports L1and L5 frequencies. It features high gain, high sensitivity, and high stability.

--- chunk_id: chunk-0216
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: 2d878b72b12c5d51
prev_chunk_id: chunk-0215
next_chunk_id: chunk-0217
section_heading: 4. Here 4 provides built-in Drone-ID feature.\
document_type: maintenance_procedure

4. Here 4 provides built-in Drone-ID feature.\
   ***Blue version supports Drone-ID**

--- chunk_id: chunk-0217
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: 3184c1d371b51c3a
prev_chunk_id: chunk-0216
next_chunk_id: chunk-0218
section_heading: 5. Here 4 uses multi-frequency DGNSS signals with advanced algorithms. This allows fast convergence to an RTK Fix, achie
document_type: maintenance_procedure

5. Here 4 uses multi-frequency DGNSS signals with advanced algorithms. This allows fast convergence to an RTK Fix, achieving more reliable and stable centimeter level positioning.

--- chunk_id: chunk-0218
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: 965f46de1a6d2a8f
prev_chunk_id: chunk-0217
next_chunk_id: chunk-0219
section_heading: 6. The Here 4 module is 16 x 68mm and 60g.
document_type: maintenance_procedure

6. The Here 4 module is 16 x 68mm and 60g.

--- chunk_id: chunk-0219
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 38
content_hash: d26fc39ff6ab96f6
prev_chunk_id: chunk-0218
next_chunk_id: chunk-0220
section_heading: 7. LED embedded with ProfiLEDs. Built-in multiple display modes for notification or navigation signals. Display modes ca
document_type: maintenance_procedure

7. LED embedded with ProfiLEDs. Built-in multiple display modes for notification or navigation signals. Display modes can be selected according to specific scenarios via parameters or onboard Lua Scripting.

--- chunk_id: chunk-0220
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 12
content_hash: 4a633bf448c68873
prev_chunk_id: chunk-0219
next_chunk_id: chunk-0221
section_heading: 8. CAN FD, real time, and high transmission rate.
document_type: maintenance_procedure

8. CAN FD, real time, and high transmission rate.

--- chunk_id: chunk-0221
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 20
content_hash: 9735f3b77834fd80
prev_chunk_id: chunk-0220
next_chunk_id: chunk-0222
section_heading: 9. Built-in IMU. Through future firmware updates, Here 4 can achieve tightly coupled DGNSS-INS-fusing solutions.
document_type: maintenance_procedure

9. Built-in IMU. Through future firmware updates, Here 4 can achieve tightly coupled DGNSS-INS-fusing solutions.

--- chunk_id: chunk-0222
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 230
content_hash: 32f65b701c05ad3c
prev_chunk_id: chunk-0221
next_chunk_id: chunk-0223
section_heading: Specifications
document_type: maintenance_procedure

## Specifications | Features                    |                                                                                                                       |
| --------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| GNSS module                 | NEO-F9P                                                                                                               |
| Processor                   | STM32H757                                                                                                             |
| IMU sensor                  | ICM42688+RM3100                                                                                                       |
| Barometer                   | MS5611                                                                                                                |
| Communication Protocol      | DroneCAN 8Mbit/s                                                                                                      |
| Receiver type               | Dual-band GNSS high precision receiver                                                                                |
| GNSS systems                | GPS, GLONASS, Galileo and BeiDou + SBAS and QZSS                                                                      |
| Satellite bands             | B1I, B2a, E1B/C, E5a, L1C/A, L1OF, L5                                                                                 |
| Maximum GNSS systems        | 4                                                                                                                     |
| Navigation update rate（RTK） | up to 20 Hz                                                                                                           |
| Positioning accuracy        | 0.01 m + 1 ppm CEP                                                                                                    |
| Maximum speed               | 500 m/s                                                                                                               |
| Convergence time（RTK）       | < 10 sec                                                                                                              |
| Acquisition                 | Cold starts 25s
Aided start 2s
Hot start 2s                                                              | | Sensitivity                 | Tracking & Navigation: –167 dBm
Cold starts: –148 dBm
Hot starts: –157 dBmReacquisition: –160 dBm | | Antenna                     | Dual band antenna                                                                                                     |
| Protocols                   | NMEA、UBX binary、RTCM 3.3、SPARTN 2.0.1                                                                                 |
| Anti-spoofing               | Advanced anti-spoofing algorithms                                                                                     |

--- chunk_id: chunk-0223
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 385
content_hash: 7958298f4de7528c
prev_chunk_id: chunk-0222
next_chunk_id: chunk-0224
section_heading: Pinout with Case
document_type: maintenance_procedure

## Pinout with Case | Parameter | Description |
| --- | --- |
| CAN | Two (current firmware only supports one CAN port where the cable color is green, blue, white, and grey) |
| Working Temperature | -40 °C to +85 °C |
| Size | 16 x 68 mm |
| Weight | 60g (with cable) | Here 4 can enable the flight controller function when connected to a breakout board. For details on how to set up the flight controller, refer to the following link:

### **Power** | PIN | Name |
| --- | ---- |
| 1   | 5V   |
| 2   | 5V   |
| 3   | NC   |
| 4   | NC   |
| 5   | GND  |
| 6   | GND  | ### **CPPM / S.BUS / SERVO SYSTEM** | PIN | Name    |
| --- | ------- |
| 1   | RC_IN  |
| 2   | PWM 8   |
| 3   | PWM 7   |
| 4   | PWM 6   |
| 5   | PWM 5   |
| 6   | PWM 4   |
| 7   | PWM 3   |
| 8   | PWM 2   |
| 9   | PWM 1   |
| 10  | PPS     |
| 11  | HOTSHOE | ### **11 Pin in** | PIN | Name    |
| --- | ------- |
| 1   | PWM 8   |
| 2   | PWM 7   |
| 3   | PWM 6   |
| 4   | PWM 5   |
| 5   | PWM 4   |
| 6   | PWM 3   |
| 7   | PWM 2   |
| 8   | PWM 1   |
| 9   | RC_IN  |
| 10  | HOTSHOE |
| 11  | PPS     |

--- chunk_id: chunk-0224
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 381
content_hash: b0f07905329977f3
prev_chunk_id: chunk-0223
next_chunk_id: chunk-0225
section_heading: Pinout with Case
document_type: maintenance_procedure

### **11 Pin in** | PIN | Name    |
| --- | ------- |
| 1   | PWM 8   |
| 2   | PWM 7   |
| 3   | PWM 6   |
| 4   | PWM 5   |
| 5   | PWM 4   |
| 6   | PWM 3   |
| 7   | PWM 2   |
| 8   | PWM 1   |
| 9   | RC_IN  |
| 10  | HOTSHOE |
| 11  | PPS     | ### **10 Pin in** | PIN | Name     |
| --- | -------- |
| 1   | 5V       |
| 2   | CAN1_H  |
| 3   | CAN1_L  |
| 4   | CAN2_H  |
| 5   | CAN2_L  |
| 6   | GPS_TX  |
| 7   | GPS_RX  |
| 8   | I2C_SCL |
| 9   | I2C_SDA |
| 10  | GND      | ### **CAN** | PIN | Name   |
| --- | ------ |
| 1   | 5V     |
| 2   | CAN_H |
| 3   | CAN_L |
| 4   | GND    | ### **UART** | PIN | Name     |
| --- | -------- |
| 1   | 5V       |
| 2   | GPS_TX  |
| 3   | GPS_RX  |
| 4   | I2C_SCL |
| 5   | I2C_SDA |
| 6   | GND      | > The UART pinout shown above applies when using Here 4 as a GPS unit, with the pin labels indicating connections to a flight controller. When using Here 4 as a flight controller, the pinout changes: GPS_TX becomes UART_RX, and GPS_RX becomes UART_TX. Ensure that you make the necessary adjustments, which will most likely involve crossing the RX and TX wires when connecting peripherals to Here 4 as a flight controller.

--- chunk_id: chunk-0225
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 369
content_hash: 66cd33f21b3d42cb
prev_chunk_id: chunk-0224
next_chunk_id: chunk-0226
section_heading: Pinout without Case
document_type: maintenance_procedure

## Pinout without Case
### Connector 1 | Pin Number | Definition |
| ---------- | ---------- |
| 1          | 5V_IN     |
| 2          | CAN1_H    |
| 3          | CAN1_L    |
| 4          | CAN2_H    |
| 5          | CAN2_L    |
| 6          | SERIAL_RX |
| 7          | SERIAL_TX |
| 8          | I2C_SCL   |
| 9          | I2C_SDA   |
| 10         | GND        | ### Connector 2 | Pin Number | Definition        |
| ---------- | ----------------- |
| 1          | PWM8 Input/Output |
| 2          | PWM7 Input/Output |
| 3          | PWM6 Input/Output |
| 4          | PWM5 Input/Output |
| 5          | PWM4 Input/Output |
| 6          | PWM3 Input/Output |
| 7          | PWM2 Input/Output |
| 8          | PWM1 Input/Output |
| 9          | RC input          |
| 10         | Hotshoe signal    |
| 11         | PPS signal        | ### Dimensions
### User Manual
### 1. For use with Ardupilot:

Connect the 4pin CAN cable from Here 4 to CAN1 or CAN2 on flight control. **（Note: Current firmware only supports CAN1-green、blue、white、grey）**

Power the flight control and connect it to Mission Planner. Go to **Config - Full Parameter** List page and modify the following parameters:

**CAN_D1_PROTOCOL: 1**

**CAN_D2_PROTOCOL: 1**

**CAN_P1_DRIVER: 1**

**CAN_P2_DRIVER: 1**

**GPS_TYPE: 9**

**NTF_LED_TYPES: 231**

Once completed, click **Write Params**. CAN function should be enabled after rebooting the autopilot. ### **Compass Setting**

**There is no safety switch. Safety switch can be disabled by modifying BRD_SAFETYENABLE to 0. Another option is to connect to an external safety switch to GPS1 port.**

When using Cube orange+, compasses are ordered on the bottom. External CAN compass is selected by default.

--- chunk_id: chunk-0226
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 381
content_hash: 7935b485780d6b1a
prev_chunk_id: chunk-0225
next_chunk_id: chunk-0227
section_heading: Pinout without Case
document_type: maintenance_procedure

Another option is to connect to an external safety switch to GPS1 port.**

When using Cube orange+, compasses are ordered on the bottom. External CAN compass is selected by default. Select the compasses by using the default setting (generally default setting is fine) and click "Start" to calibrate compasses. ### 2. Using with PX4:

By the time of this writing, PX4 v1.13 is being used. \
***Please make sure that you are using the most recent stable release of PX4 firmware.**

Install PX4 firmware. Connect the 4pin CAN cable to CAN1 or CAN2 port

Connect to autopilot through GCS. Modify the parameter ***UAVCAN_ENABLE*** to ***Sensors Automatic*** Conﬁg and reboot the autopilot. ### 3. Firmware update

> Latest firmware releases along with notes are available here  . Ensure that your units are running latest firmware for safe operation. Update procedures are shown as the following when there are any future firmware updates. Mission Planner must be updated to the following or later version to have the new feature available:

Connect the 4pin CAN cable from CAN port on Here 4 to CAN1 on the autopilot. Connect the autopilot to Mission Planner and go to the UAVCAN screen. Click SLCan Mode CAN1 to load CAN GPS status. Click Menu > Update to check if there are any firmware updates for Here 4

Click the Update button. A window will pop up and ask if you want to search the internet for updates. Click ***Yes***. Wait for the firmware update to complete. Confirm the change in ***SW*** Version. If the update was successful, reboot the Here 4. **If update gets stuck at SOFTWARE UPDATE:** When updating from version [1.15.6 and earlier](https://github.com/CubePilot/GNSSPeriph-release/releases), restarting the Here4 may be required before updating.

--- chunk_id: chunk-0227
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 386
content_hash: adfd2c7a415401e0
prev_chunk_id: chunk-0226
next_chunk_id: chunk-0228
section_heading: Pinout without Case
document_type: maintenance_procedure

If the update was successful, reboot the Here 4. **If update gets stuck at SOFTWARE UPDATE:** When updating from version [1.15.6 and earlier](https://github.com/CubePilot/GNSSPeriph-release/releases), restarting the Here4 may be required before updating. If the Update message box is stuck at SOFTWARE UPDATE with no progress change:

* Cancel the update
* Restart the Here4
* After restarting, confirm the unit is in mode MAINTENANCE then attempt the update again

This is resolved in version 1.15.7 and above. ### 4.Cube_ID setting

For the set up procedure, please check\
. ### 5.RTK Use Operation
### 1. Base/Rover Survey by Mission Planner

This part of the tutorial uses Mission Planner ground software and Arducopter-4.3.5 flight firmware for operating instructions. RTK mode requires a base station. The following tutorial Uses "Here+" base stations as an example. Users can also use other u-blox M8P/F9P base stations (such as HerePro, etc.), or use the local wireless RTK correction service. **Prepare Before use：**

To use Here 4 on a UXV, you need the following hardware： Computer, telemetry modules, Here 4 , Here+Base Antenna, Here+Base, Tripod(Stand). **Before use, please make sure that the hardware connection is correct:**

**Ground side:** Connect the base antenna to the base station, then connect the base station module to the computer through the USB port; The Telemetry module should be connected to another USB port of the same computer. **UXV side:** Connect Here 4 to CAN interface, and telemetry module to the TELEM interface on flight control. #### **Antenna Placing**

**Placing the RTK Antenna is very important for getting precise RTK positioning**

Normal GPS positioning, only requires you to place the device near a window and it will provide you a GPS location over a period of time. But that's not enough for RTK.

--- chunk_id: chunk-0228
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 370
content_hash: 269b96a25cc51ebc
prev_chunk_id: chunk-0227
next_chunk_id: chunk-0229
section_heading: Pinout without Case
document_type: maintenance_procedure

#### **Antenna Placing**

**Placing the RTK Antenna is very important for getting precise RTK positioning**

Normal GPS positioning, only requires you to place the device near a window and it will provide you a GPS location over a period of time. But that's not enough for RTK. For the working environment of RTK, there are special requirements on antenna placement, which are much more stricter than GPS. The best environment for the base and rover antenna is a clear view of the sky that is 30 degrees above the horizon. RTK antenna can be elevated but ensure that there are no obstacles around, such as buildings, trees, cars, and etc

**Examples of bad environments:** indoors, urban areas, forests, or near the ground. **Examples of good environments:** Open spaces, peak of a mountain, roof of a building. Do not place the antenna near electronic devices, as high power electronic devices in close proximity may affect the radio frequency noise of the GPS signal. Examples are mobile phone base stations, high voltage transformers, etc. Please place the base station in an outdoor environment with sufficient sky coverage to obtain a good satellite signal. Place the base station on a stable and elevated platform, such as a tripod. **Base Module Setting using Mission Planner**

Start with a base module setup first. During the base station setup, the rover and the UXV do not need to be turned on. Open the Mission Planner ground station software on your computer and go to the "initial setup → Optional Hardware → RTK/GPS Inject". You will see the following page:

Select the correct base module com port in the top left corner and click ‘connect’.

--- chunk_id: chunk-0229
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 330
content_hash: 4ae1b5b715c1010c
prev_chunk_id: chunk-0228
next_chunk_id: chunk-0230
section_heading: Pinout without Case
document_type: maintenance_procedure

Open the Mission Planner ground station software on your computer and go to the "initial setup → Optional Hardware → RTK/GPS Inject". You will see the following page:

Select the correct base module com port in the top left corner and click ‘connect’. In the SurveyIn Acc section, enter the absolute geographic accuracy that you expect your Here+ base station to achieve. In the Time column, enter the minimum survey time you expect. Click on Restart, the ground station will transfer the data you have entered to the base module, the base module will start a new round of surveying. You will see the following page:

During the survey process, the right box will show the current survey status:

**The Position is invalid:** The base station has not yet reached a valid location;

**In Progress:** The survey is still in progress;

**Duration:** The number of seconds that the current surveying task has been executed;

**Observation:** the number of observations acquired;

**Current Acc:** Absolute geographic accuracy that the current base station can achieve;

**The Green bar** at the lower part of the Mission Planner page shows the current satellites being detected and the signal strength related to each satellite. At least eight or more satellite signals need to be guaranteed to exceed the red line (Only when the satellite signal exceeds the red line,  the effective number of satellites have been connected). The base station needs a certain amount of time to meet the accuracy requirements of your input.

--- chunk_id: chunk-0230
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: 8d494728f4c46349
prev_chunk_id: chunk-0229
next_chunk_id: chunk-0231
section_heading: Pinout without Case
document_type: maintenance_procedure

At least eight or more satellite signals need to be guaranteed to exceed the red line (Only when the satellite signal exceeds the red line,  the effective number of satellites have been connected). The base station needs a certain amount of time to meet the accuracy requirements of your input. Testing shows that in an open area without sky coverage, the base station will achieve the absolute accuracy of 2m within a few minutes; to reach the absolute accuracy of less than 30cm takes about an hour; to reach the absolute accuracy of 10cm takes a few hours. It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover. If your application does not require UXV with high absolute geographic accuracy, you do not need to set the base station's precision too high, which helps to avoid a longer survey time. Even if the accuracy of the base station is 1.5 to 2 m, the position accuracy of the rover module relative to the base station can still reach the centimeter level. After the survey is complete, the Mission Planner will display the following page:

In the RTCM box it shows that the base status indicator is green and both GPS and Glonass satellite systems are green (if you want to change the satellite system, refer to the following section). The box on the right says "Position is valid". To store the current location in Mission Planner: Click "Save Current Pos", enter a name in the dialogue box, and click "OK". As shown below, you can see your saved location in the list.

--- chunk_id: chunk-0231
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 381
content_hash: d101715edcb07df9
prev_chunk_id: chunk-0230
next_chunk_id: chunk-0232
section_heading: Pinout without Case
document_type: maintenance_procedure

To store the current location in Mission Planner: Click "Save Current Pos", enter a name in the dialogue box, and click "OK". As shown below, you can see your saved location in the list. Click the "Use" button for the location you saved. The base station will enter the fixed mode and the status will show "Using FixedLLA". In the future, if you set the base station in the same location, you do not need to conduct the survey again, just click the "Use" button that corresponds to the location you have saved. **Rover Module and Flight Controller Setup**

Once the base station is established, you can activate the UXV. By utilizing the same telemetry module to connect with Mission Planner, the base station data will be transmitted through the telemetry module to the Here4 rover module on the UXV. On the main page of Mission Planner, you will be able to observe the current GPS status, which will be indicated as either RTK Float, RTK Fixed, or 3D RTK. These indications signify that the UXV's positioning has entered the RTK mode. RTK Float represents a floating-point solution, while RTK Fixed represents a fixed solution. RTK Fixed mode offers higher accuracy but requires a stronger signal strength. The term "3D RTK" is a comprehensive reference to both RTK Float and RTK Fixed in the Mission Planner interface. ### **2. Single Base to Multiple Rovers**

There are 2 methods to do this:

1.)Use 1 telemetry to multiple telemetry broadcasting ;

or

2.)Use multiple 1 to 1 telemetry modules with USB hub

Ground station configuration: connect all telemetry modules to the computer via USB hub. Open Mission Planner to locate the base then connect it with flight controllers.

--- chunk_id: chunk-0232
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 294
content_hash: ac99fcb35d58f1f9
prev_chunk_id: chunk-0231
next_chunk_id: chunk-0233
section_heading: Pinout without Case
document_type: maintenance_procedure

Single Base to Multiple Rovers**

There are 2 methods to do this:

1.)Use 1 telemetry to multiple telemetry broadcasting ;

or

2.)Use multiple 1 to 1 telemetry modules with USB hub

Ground station configuration: connect all telemetry modules to the computer via USB hub. Open Mission Planner to locate the base then connect it with flight controllers. Select AUTO connecting as shown below. All recognized flight controllers on the ports will be connected. You may select the UXV from the dropdown list below:

If you connected the UXVs with 1 telemetry module, they should share the same COM port:

### 6. U-Center Firmware Update

> Please do not update your Here4 Ublox firmware if you purchased your unit after 7th December 2023 before consulting your reseller. The firmware on new Here4s have our customised firmware which adds support for Moving Baseline, firmware from ublox website do not support that feature. Updating the firmware will drop Moving Baseline support from your units and you will not be able to revert back to production firmware with Moving Baseline support. To verify version please follow the steps here: [#steps-to-verify-ublox-firmware-version](#steps-to-verify-ublox-firmware-version "mention")

> Ensure that you have the latest firmware on Here4 before this process. Please follow [#3.-firmware-update](#3.-firmware-update "mention") to update the firmware. Latest NEO F9P L1L5 firmware can be found here under Firmware Update section.

--- chunk_id: chunk-0233
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 44
content_hash: baddde2f67dee98c
prev_chunk_id: chunk-0232
next_chunk_id: chunk-0234
section_heading: 1. Inside DroneCAN/UAVCAN config page of Mission Planner. Select Menu and Check
document_type: maintenance_procedure

1. Inside DroneCAN/UAVCAN config page of Mission Planner. Select Menu and Check

> If the following option is not visible in Mission Planner, then update Mission Planner to latest Beta from Help menu.

--- chunk_id: chunk-0234
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 10
content_hash: 3c05d5ce4290bd4f
prev_chunk_id: chunk-0233
next_chunk_id: chunk-0235
section_heading: 2. Select port for u-Center to connect on.
document_type: maintenance_procedure

2. Select port for u-Center to connect on.

--- chunk_id: chunk-0235
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 10
content_hash: 3f8b6bb3b35741a8
prev_chunk_id: chunk-0234
next_chunk_id: chunk-0236
section_heading: 3. Select baudrate to set for ublox communication.
document_type: maintenance_procedure

3. Select baudrate to set for ublox communication.

--- chunk_id: chunk-0236
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 20
content_hash: 1b44ec9c1fb0cc51
prev_chunk_id: chunk-0235
next_chunk_id: chunk-0237
section_heading: 4. Open u-center (Ensure that its version 22.07+). Under connections select Network connections > New.
document_type: maintenance_procedure

4. Open u-center (Ensure that its version 22.07+). Under connections select Network connections > New.

--- chunk_id: chunk-0237
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 6
content_hash: 8a7e02a941f203e8
prev_chunk_id: chunk-0236
next_chunk_id: chunk-0238
section_heading: 5. Set url to tcp\://127.0.0.1:500.
document_type: maintenance_procedure

5. Set url to tcp\://127.0.0.1:500.

--- chunk_id: chunk-0238
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 377
content_hash: f1d10ded2dbcef85
prev_chunk_id: chunk-0237
next_chunk_id: chunk-0239
section_heading: 6. Select Tools>Firmware Update Utility. Select the downloaded firmware from ublox website in the tool. Ensure that baud
document_type: maintenance_procedure

6. Select Tools>Firmware Update Utility. Select the downloaded firmware from ublox website in the tool. Ensure that baudrate is same as set in Mission Planner. And Options are correctly selected as shown below. And then click GO. ### 7. Moving baseline

> Please note that early Here4 units (Pre December 2023 Production Here4 Black and Alpha Here4 Blue Units) do not support Moving Baseline. If you have such units and require this feature you will need to contact your reseller. To check if your unit has Moving Baseline support please follow the steps below. #### Steps to verify Ublox Firmware version

* Connect Here4 Units as shown above and ensure the firmware running on them is atleast v1.13. * Connect CubeOrange to the Mission Planner and Open DroneCAN/UAVCAN window. * Reboot the Here4 units, and wait for few seconds until the message as shown below appears. * The firmware supporting Moving Baseline has firmware hash: u-blox 1 HW: 00190000 SW: EXT CORE 1.00 **(49f616)**

Once all settings and versions are confirmed, set following parameters for Moving Baseline on Ardupilot:

* [GPS_TYPE](https://ardupilot.org/copter/docs/parameters.html#gps-type) = 22 (“DroneCAN moving baseline base”)
* [GPS_TYPE2](https://ardupilot.org/copter/docs/parameters.html#gps-type2) = 23 (“DroneCAN moving baseline rover”)
* [GPS_AUTO_CONFIG](https://ardupilot.org/copter/docs/parameters.html#gps-auto-config) = 2 (AutoConfig DroneCAN)
* [GPS_AUTO_SWITCH](https://ardupilot.org/copter/docs/parameters.html#gps-auto-switch) = 1
* Set the [GPS_POS1_X](https://ardupilot.org/copter/docs/parameters.html#gps-pos1-x)/Y/Z and [GPS_POS2_X](https://ardupilot.org/copter/docs/parameters.html#gps-pos2-x)/Y/Z parameters for the GPS antennas (see [Sensor Position Offset are here](https://ardupilot.org/copter/docs/common-sensor-offset-compensation.html#common-sensor-offset-compensation)). You must establish the relative positions of each GPS location on the vehicle with respect the vehicle’s motion. * [GPS1_CAN_OVRIDE](https://ardupilot.org/copter/docs/parameters.html#gps1-can-ovride) (Base NODEID) and [GPS2_CAN_OVRIDE](https://ardupilot.org/copter/docs/parameters.html#gps2-can-ovride) (Rover NODEID) determine which physical DroneCAN GPS is used for GPS1 and GPS2. These are automatically populated at boot from the detected addresses, which are also shown in [GPS_CAN_NODEID1](https://ardupilot.org/copter/docs/parameters.html#gps-can-nodeid1) and [GPS_CAN_NODEID2](https://ardupilot.org/copter/docs/parameters.html#gps-can-nodeid2), but can be overriden, if needed.

--- chunk_id: chunk-0239
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 378
content_hash: 53a5d92a0b80c814
prev_chunk_id: chunk-0238
next_chunk_id: chunk-0240
section_heading: 6. Select Tools>Firmware Update Utility. Select the downloaded firmware from ublox website in the tool. Ensure that baud
document_type: maintenance_procedure

* [GPS1_CAN_OVRIDE](https://ardupilot.org/copter/docs/parameters.html#gps1-can-ovride) (Base NODEID) and [GPS2_CAN_OVRIDE](https://ardupilot.org/copter/docs/parameters.html#gps2-can-ovride) (Rover NODEID) determine which physical DroneCAN GPS is used for GPS1 and GPS2. These are automatically populated at boot from the detected addresses, which are also shown in [GPS_CAN_NODEID1](https://ardupilot.org/copter/docs/parameters.html#gps-can-nodeid1) and [GPS_CAN_NODEID2](https://ardupilot.org/copter/docs/parameters.html#gps-can-nodeid2), but can be overriden, if needed. You will need to determine which physical CAN GPS is assigned as GPS1 and GPS2 in order to setup the position offsets (see [Sensor Position Offset are here](https://ardupilot.org/copter/docs/common-sensor-offset-compensation.html#common-sensor-offset-compensation))

### 8. Installing Ardupilot on Here4

* You will require following components to upgrade Here4 to be Flight Controller

  * Cube : For updating the bootloader on Here4 unit. * Serial to USB connection: For talking to Here4 module over telemetry and updating firmware. * Here4 Splitter board: For wiring IO pins in usable form

* ### Step 1: Updating Here4 Bootloader:
  * Connect Here4 to a Cube configured to operate over CAN bus. * Follow the steps here to update Here4 to latest release [Firmware Update](#id-3.-firmware-update). * After update, open parameters pane for Here4 Unit. * Search parameter `FLASH_BOOTLOADER` , set the parameter to 1
  * Then click `Refresh Params`, check if the parameter auto resetted to 0, confirming successful update. * ### Step2: Updating to Here4 FC firmware

  * Connect GPS_TX and GPS_RX pins, Vcc and Gnd to Serial to USB converter, which after update will be swapped in reference and become SERIAL0_RX and SERIAL0_TX , refer to the note below [Uart Pinout ](#uart)for description on why. * Disconnect all connected flight controller like Cube from the system. * Open Setup > Install Firmware page on Mission Planner. * Plug in Here4 vis Serial to USB converter, and wait for Mission Planner to detect board type **1043** , as shown bellow.

--- chunk_id: chunk-0240
source_document: here-4-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 97
content_hash: 7201ff25eff02926
prev_chunk_id: chunk-0239
next_chunk_id: chunk-0241
section_heading: 6. Select Tools>Firmware Update Utility. Select the downloaded firmware from ublox website in the tool. Ensure that baud
document_type: maintenance_procedure

* Open Setup > Install Firmware page on Mission Planner. * Plug in Here4 vis Serial to USB converter, and wait for Mission Planner to detect board type **1043** , as shown bellow. If not detected make sure you have Here4 powered and RX/TX correctly connected. * After detection you can move to select the Ardupilot version to update and wait for firmare flash to finish. Refer [Pinout](#pinout) for splitter board for connections.

--- chunk_id: chunk-0241
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 5
content_hash: d9ca1dd37a1a94e1
prev_chunk_id: chunk-0240
next_chunk_id: chunk-0242
section_heading: HerePro Manual
document_type: maintenance_procedure

# HerePro Manual

![](/files/-M_UmdLe5cSdtPVgYOrP)

--- chunk_id: chunk-0242
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 381
content_hash: 3f96ba45cea61096
prev_chunk_id: chunk-0241
next_chunk_id: chunk-0243
section_heading: HerePro High Precision Multi-band RTK Navigation
document_type: maintenance_procedure

## HerePro High Precision Multi-band RTK Navigation
### Overview

HerePro is a professional High Precision Multi-band RTK Navigation module. It supports various GNSS options such as BeiDou, Galileo, GLONASS, GPS, QZSS. To establish a precise Multi-band Multi-GNSS RTK system, follow these steps to connect two HerePro modules, one serving as the base and the other as the rover. It's important to note that both the HerePro rover and base have identical software and hardware, with the only variation being in the parameter settings. HerePro utilizes multi-frequency DGNSS signals with advanced algorithms to converge on an RTK Fix in seconds, achieving more reliable centimeter level positioning. ### Features

**1.**  Equipped with u-blox F9P, a professional high precision Multi-band RTK navigation module. **2.** Powerful processing performance provided by a built-in STM32H7 chip. It offers real-time processing and data optimization, and Unmanned Industry standard AP_Periph Firmware. **3.** The tailor-made multi-band antenna from Taoglas supports L1, L2, and E5 frequencies. It features high gain, high sensitivity, and high stability. **4.** HerePro base supports both fixed and moving base mode, selectable for different scenarios to maximize performance. **5.** The HerePro module functions as both a base and a rover. Switching between these two functionalities is a straightforward process that can be achieved through parameter settings

**6.** HerePro uses multi-frequency DGNSS signals with advanced algorithms. This allow fast convergence to an RTK Fix, achieving more reliable and stable centimeter level positioning. **7.** HerePro module is 15 x 78mm and 101g. **8.** The HerePro supports voltages from 6V to 40V. This allows for compatibility with different voltage levels. To enhance safety, it supports redundant power input system. **9.** The HerePro module is designed with a circular ProfiLEDs. It offers multiple built-in display modes.

--- chunk_id: chunk-0243
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 113
content_hash: 0bb1641c1abb9708
prev_chunk_id: chunk-0242
next_chunk_id: chunk-0244
section_heading: HerePro High Precision Multi-band RTK Navigation
document_type: maintenance_procedure

**9.** The HerePro module is designed with a circular ProfiLEDs. It offers multiple built-in display modes. These modes can be easily selected based on specific needs, either through parameter settings or by utilizing the onboard Lua Scripting feature. This flexibility enables the module to effectively convey notifications or serve as a navigation signal, enhancing its usability and adaptability in different applications. **10.** CAN FD, real time, and high transmission rate. **11.** Built-in 9-axis IMU. Through future firmware updates, HerePro can achieve tightly coupled DGNSS-INS-fusing solutions.

--- chunk_id: chunk-0244
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 736dd4e9ac48c298
prev_chunk_id: chunk-0243
next_chunk_id: chunk-0245
section_heading: Specifications
document_type: maintenance_procedure

## Specifications | Features |  |  |
| --- | --- | --- |
| Features |  |  |
| Receiver type | 184-channel u-blox F9P |  |
| GNSS systems | BeiDou, Galileo, GLONASS, GPS, QZSS |  |
| Satellite bands | BDS B1I B2I, GPS L1C/A L2C, GLONASS L1OF L2OF, GALILEO E1B/C E5b, QZSS L1C/A L2C |  |
| Number of concurrent GNSS | 4 |  |
| Navigation update rate | Up to 20 Hz for RTK |  |
| Horizontal and vertical accuracy | RTK 0.01m +1ppm CEP |  |
| Heading accuracy | 0.4 degrees |  |
| PVT horizontal positioning accuracy | 1.5m CEP |  |
| Maximum altitude | 50,000 m |  |
| Maximum speed | 500 m/s |  |
| Convergence time | RTK < 10s |  |
| Acquisition | Cold starts 24s |  |
|  | Aided starts 2s |  |
|  | Reacquisition 2s |  |
| Sensitivity | Tracking & Navigation: –167 dBm |  |
|  | Cold starts: –148 dBm |  |
|  | Hot starts: –157 dBm |  |
|  | Reacquisition: –160 dBm |  |
| Antenna | Multi-band dual antenna |  |
| Timepulse | Configurable from 0.25hz to 10mhz |  |
| Protocols | NMEA、UBX binary、RTCM 3.3 |  |
| Anti-jamming | Active CW detection and removal |  |
|  | Onboard band pass filter |  |
| Anti-spoofing | Advanced anti-spoofing algorithms |  |
| Pinout |  |  |
| Power (XT30) | x2 |  |
| Debug | x1 |  |
| CAN | x2 |  |
| USB / GPIO | x1 |  |
| Others |  |  |
| EMMC | 2G |  |
| Flash | 2M |  |
| RAM | 1M |  |
| Input voltage | 6 V - 40 V (maximum 60V) |  |
| Working Temperature | -40 °C to +85 °C |  |
| Size | 17 x 78 mm |  |
| Weight | 110g（without cable，with pogo pin board） |  |

--- chunk_id: chunk-0245
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 392
content_hash: 4c47911df626b3f8
prev_chunk_id: chunk-0244
next_chunk_id: chunk-0246
section_heading: User Manual
document_type: maintenance_procedure

## User Manual
### 1. Install connector

HerePro does not come with connector installed. Before first time using, install the port connector as shown below:

Align the mount holes on port connect and HerePro. Then lock them tightly with 3 M3*8 screws. \

![](/files/624s8lxgXwkQFc3n0NU1)

### 2. Using with Ardupilot:

Connect the 4pin CAN cable from left-hand-side CAN port on HerePro to CAN1 or CAN2 on autopilot. Then, supply 6V - 40V to HerePro. (or connect HerePro with type-c to PC directly for power supply)

Turn on the autopilot and connect it to Mission Planner. Go to Config - Full Parameter List page and modify the following parameters:

**CAN_D1_PROTOCOL: 1**

**CAN_D2_PROTOCOL: 1**

**CAN_P1_DRIVER: 1**

**CAN_P2_DRIVER: 1**

**GPS_TYPE: 9**

**NTF_LED_TYPES: 231**

Once completed, click "Write Params". CAN function should be enabled after rebooting the autopilot. **Compass Setting (Using the current firmware):**

> **There is no safety switch. Safety switch can be disabled by modifying BRD_SAFETYENABLE to 0. Connecting external safety switch to GPS1 port is also an option.**

When using Cube Black, compasses are ordered from top to bottom as 1,2, and 3; When using Cube Orange+, compasses are ordered from top to bottom as 1 and 2. External CAN compass is selected as the last one by default. ![](/files/-M_UqBaFzKdcjffM__YL)

To set external CAN compass as compass 1, move the UAVCAN compass to the top. ![](/files/-M_Uq_INHZFhphhFSPvN)

Select the compasses using (generally default setting is fine) and click "Start" to calibrate compasses. ![](/files/-M_UrHfXPHVFVMe5vmEe)

### 3. Using with PX4:

> By the time of writing, PX4 v1.13.1 is being used. >
> ***Please make sure that you are using the most recent stable release of PX4 firmware.**

Install PX4 firmware. Connect the 4pin CAN cable to CAN1 or CAN2 port. Then, supply 6V - 40V power to HerePro.

--- chunk_id: chunk-0246
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 372
content_hash: 1cca009c7275f016
prev_chunk_id: chunk-0245
next_chunk_id: chunk-0247
section_heading: User Manual
document_type: maintenance_procedure

Connect the 4pin CAN cable to CAN1 or CAN2 port. Then, supply 6V - 40V power to HerePro. Connect to autopilot through GCS. Modify the parameter UAVCAN_ENABLE to Sensors Automatic Conﬁg and reboot the autopilot. ![](/files/-M_Ut-3hrwRuh2ZTKNR4)

### 4.GPS for Yaw
#### （For Ardupilot Firmware）

Two u-blox F9 GPS modules can be used to estimate yaw which removes the need for a compass which may suffer from magnetic interference from the ground or the vehicle’s motors and ESCs. This works even if the GPSs do not have RTK fix (RTCM data from a fixed RTK station or NTRIP server). When DroneCAN GPS are used ,make sure that no SERIAL ports are setup with GPS protocol . Also be sure that the two DroneCAN GPS are on the same physical CAN bus from the autopilot（CAN port on the same flight control）. This might requires that a CAN bus splitter be used. Then set these parameters:

GPS_TYPE = 22 (“DroneCAN moving baseline base”)

GPS_TYPE2 = 23 (“DroneCAN moving baseline rover”)

GPS_AUTO_CONFIG = 2 (AutoConfig DroneCAN)

GPS1_CAN_OVRIDE (Base NODEID) and GPS2_CAN_OVRIDE (Rover NODEID) determine which physical DroneCAN GPS is used for GPS1 and GPS2. These are automatically populated at boot from the detected addresses, which are also shown in GPS_CAN_NODEID1 and GPS_CAN_NODEID2, but can be overridden if needed. You will need to determine which physical CAN GPS is assigned as GPS1 and GSP2 in order to setup the position offsets (see Sensor Position Offset are here)

For either Serial or DroneCAN GPS also set:

Set the GPS_POS1_X/Y/Z and GPS_POS2_X/Y/Z parameters for the GPSs . You must establish the relative positions of each GPS location on the vehicle with respect to the vehicle’s motion.

--- chunk_id: chunk-0247
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 378
content_hash: 73977315157ed4e0
prev_chunk_id: chunk-0246
next_chunk_id: chunk-0248
section_heading: User Manual
document_type: maintenance_procedure

You will need to determine which physical CAN GPS is assigned as GPS1 and GSP2 in order to setup the position offsets (see Sensor Position Offset are here)

For either Serial or DroneCAN GPS also set:

Set the GPS_POS1_X/Y/Z and GPS_POS2_X/Y/Z parameters for the GPSs . You must establish the relative positions of each GPS location on the vehicle with respect to the vehicle’s motion. GPS_AUTO_SWITCH = 1

AHRS_EKF_TYPE = 3 (to use EKF3)

EK2_ENABLE = 0 (to disable EKF2)

EK3_ENABLE = 1 (to enable EKF3)

EK3_MAG_CAL is not used for this feature so it can be left at its default value (“0” for Plane, “3” for Copter, “2” for Rover)

EK3_SRC1_YAW = 2 (“GPS”) or 3 (“GPS with Compass Fallback”) if a compass(es) is also in the system

The above configuration assumes that you want the RTCMv3 data between the two GPS modules to go via the autopilot board. ### 5.LED Control

LED arrays on HerePro supports Lua script. The script can be saved into the EMMC on HerePro. > There is an official Lua script for default setting. Put it into the EMMC if needed. >
> Prerequisites: Set HerePro to Rover mode. Then connect it to Mission Planner via USB and upload the script to HerePro. Connect the 4pin CAN cable from left-hand-side CAN port on HerePro to CAN1 or CAN2 on autopilot. Then, supply 6V - 40V to HerePro. Connect the autopilot to Mission Planner via USB. Go to Initial Settings > Optional Hardware > UAVCAN page and click SLCan Mode CAN1. CAN device status will show up. Click Menu > parameters at the right-hand-side to modify the following parameters:

![](/files/hTl7H2PICkhJCrxqfJvU)

Modify parameters “GPS_TYPE” = 1，**“GPS_RTCMSOURCE” = 0**，**“GPS_RTCMSOURCE” = 0**.

--- chunk_id: chunk-0248
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 8b64cf0ec4899863
prev_chunk_id: chunk-0247
next_chunk_id: chunk-0249
section_heading: User Manual
document_type: maintenance_procedure

CAN device status will show up. Click Menu > parameters at the right-hand-side to modify the following parameters:

![](/files/hTl7H2PICkhJCrxqfJvU)

Modify parameters “GPS_TYPE” = 1，**“GPS_RTCMSOURCE” = 0**，**“GPS_RTCMSOURCE” = 0**. After that, click write params then Commit Params and reboot the HerePro. ![](/files/eckWnaJaSWHJKqvxptAL)

After power cycle the HerePro, connect it to the computer through its USB port. Select the lower COM port as there are 2 for HerePro. ![](/files/-M_UuZwceY9c60_qiuGI)

After connecting, go to Config > MAVFtp > APM > scripts screen and right click. Click Upload to import the new Lua script. Then reboot the HerePro. ![("Right click here")](/files/-M_V3L-CiGdQongR2gX9)

Or connect HerePro to PC with USB-Type c directly. Connect the HerePro to Mission Planner via USB. Go to Config > Full Parameter page to modify the relative parameters:

### 6. Firmware update

> Update procedures are as shown as following if there are any future firmware update

**Mission Planner must be later or at the following version to have the new feature available:**

![](/files/-M_V3cwuW_UZ4eYGlkhr)

Connect the 4pin CAN cable from left-hand-side CAN port on HerePro to CAN1 or CAN2 on autopilot. Then, supply 6V - 40V to HerePro. Connect the autopilot to Mission Planner and go to UAVCAN screen. Click SLCan Mode CAN1 to load CAN GPS status. Click Menu > Update to check if there are any firmware updates for HerePro. ![](/files/cr5P3rqHmlfsIKZCvLa7)

Click the Update button. A window will pop up and ask if you want to search the internet for updates. Click Yes. ![](/files/GRQZr6pEPYG20bIMXkIe)

Wait for the firmware update to complete. Confirm the change in SW Version. If the update was successful, reboot the HerePro. ![](/files/ZThHAYQ9LSVPlhes7Axp)

### 7. RTK manual

This part of the tutorial uses Mission Planner ground software and Arducopter-4.3.5 flight firmware for operating instructions. RTK mode requires a base station.

--- chunk_id: chunk-0249
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 3675f1e88895f54c
prev_chunk_id: chunk-0248
next_chunk_id: chunk-0250
section_heading: User Manual
document_type: maintenance_procedure

RTK manual

This part of the tutorial uses Mission Planner ground software and Arducopter-4.3.5 flight firmware for operating instructions. RTK mode requires a base station. The following tutorial Uses HerePro as an example. Users can also use other u-blox M8P/F9P base stations (such as Here+ RTK Base, etc.), or use the local wireless RTK correction service. **Setup:**

To use HerePro RTK, you will need the following hardware : autopilot, computer, telemetry, HerePro, Tripod(Stand), and 6V-40V power supply or USB Type-C cable. To use HerePro on a UXV, you need the following hardware : Computer, telemetry modules, HerePro, Tripod(Stand). ![](/files/IepGcl7lcflasnb6lgK8)

The following operations use 2 HerePro modules, with one as base and one as rover respectively. Connecting them 1 by 1 to setup their parameters. **HerePro RTK rover parameter settings:**

Connect the 4pin CAN cable from CAN port on HerePro to CAN1 or CAN2 on autopilot. Then, supply 6V - 40V to HerePro. Connect the autopilot to Mission Planner via USB. Go to Initial Settings > Optional Hardware > UAVCAN page and click SLCan Mode CAN1. CAN device status will show up. Click Menu > parameters at the right-hand-side to modify the following parameters:

![](/files/mBrv3Gqxq5UFVVPY32k3)

Modify parameters **“GPS_TYPE = 1“**，**“SERIAL_PASS1 = 0“**. After that, click write params then Commit Params and disconnect the HerePro. ![](/files/YIJaZa118WXhobIfYpaV)

Connect another HerePro and continue. **HerePro Base parameter settings(Ground side):**

Connect the 4pin CAN cable from left-hand-side CAN port on HerePro to CAN1 or CAN2 on autopilot. supply 6V - 40V to HerePro. Connect the autopilot to Mission Planner via USB. Go to Initial Settings > Optional Hardware > UAVCAN page and click SLCan Mode CAN1. CAN device status will show up. Click Menu > parameters at the right-hand-side to modify the following parameters:

Modify parameters **“SERIAL_PASS1 = 1”**.

--- chunk_id: chunk-0250
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: 2823b33eea21e2c5
prev_chunk_id: chunk-0249
next_chunk_id: chunk-0251
section_heading: User Manual
document_type: maintenance_procedure

CAN device status will show up. Click Menu > parameters at the right-hand-side to modify the following parameters:

Modify parameters **“SERIAL_PASS1 = 1”**. After that, click write params then Commit Params and disconnect the HerePro. **Before using, please ensure that everything are correctly connected.:**

**Base:** \
Power the HerePro base with 6V-40V. \
Connect its USB port to the computer USB port. (Or connect HerePro with type-c cable to PC)\
Connect a telemetry to another port on the computer. **Rover:** \
Power the HerePro with 6V-40V. Connect it to CAN1 port on autopilot. Connect a telemetry to TELEM1 port on autopilot. **Antenna Placement:** \
**RTK Antenna placement is very important for getting precise RTK positioning**\
RTK requires a much better environment to work. There are special requirements on placement of its antenna. The best environment requires the base and rover antenna to have a clear view of the sky that is 20 degrees above the horizon. RTK antenna can be elevated but make sure that there are no obstacles around, such as buildings, trees, cars, and etc. **Examples of a bad environment:** indoors, crowded urban area, forest, near the ground. **Examples of a good environment**: Open spaces, peak of the mountains, roof of buildings. Do not place the antenna near electronic devices, as high power electronic devices in close proximity may affect the radio frequency noise of the GPS signal. Examples are mobile phone base stations, high voltage transformers, and etc. Please place the base station in an outdoor environment with sufficient sky coverage to obtain good satellite signal. Place the base station on a stable and elevated platform such as a tripod. ### **Base Module Setting using Mission Planner:**

Start with base module setup.

--- chunk_id: chunk-0251
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 378
content_hash: 2b48f542f414fdfd
prev_chunk_id: chunk-0250
next_chunk_id: chunk-0252
section_heading: User Manual
document_type: maintenance_procedure

Place the base station on a stable and elevated platform such as a tripod. ### **Base Module Setting using Mission Planner:**

Start with base module setup. During the base station setup, the rover and the UXV do not need to be turned on. * Connect HerePro module to Mission Planner for Parameter setting

* Go to Parameters and set B_ENABLE  1

* Disconnect HerePro and Connect it again, then go to the "initial setup → Optional Hardware → RTK/GPS Inject". You will see the following page:

Select the correct base module COM port at the top-left corner. Uncheck **Send GGA**. Check “**M8P/F9P autoconfig**” and “**M8P fw 130+/F9P**”. Then click connect. In the SurveyIn Acc section, enter the expected absolute geographic accuracy. In the Time column, enter the expected minimum survey time. Click Restart. The ground station will now transfer the data you have entered to the HerePro base, the base module will start surveying. You will see the following screen:

During the survey process, the right box will show the current survey status:

**Position is invalid:** The base station has not yet reached a valid location;

**In Progress:** The survey is still in progress;

**Duration:** The number of seconds that the current surveying task has been executed;

**Observation:** The number of observations acquired;

**Current Acc:** Absolute geographic accuracy that the current base station can achieve;

**The Green bar** at the lower part of the Mission Planner page shows the current satellites being detected and the signal strength related to each satellite. At least eight or more satellite signals need to be guaranteed to exceed the red line (Only when the satellite signal exceeds the red line, the effective number of satellites have been connected).

--- chunk_id: chunk-0252
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 349
content_hash: 9c7c9ce8b9ea5923
prev_chunk_id: chunk-0251
next_chunk_id: chunk-0253
section_heading: User Manual
document_type: maintenance_procedure

You will see the following screen:

During the survey process, the right box will show the current survey status:

**Position is invalid:** The base station has not yet reached a valid location;

**In Progress:** The survey is still in progress;

**Duration:** The number of seconds that the current surveying task has been executed;

**Observation:** The number of observations acquired;

**Current Acc:** Absolute geographic accuracy that the current base station can achieve;

**The Green bar** at the lower part of the Mission Planner page shows the current satellites being detected and the signal strength related to each satellite. At least eight or more satellite signals need to be guaranteed to exceed the red line (Only when the satellite signal exceeds the red line, the effective number of satellites have been connected). The base station needs a certain amount of time to meet the accuracy requirements of your input. Testing shows that in an open area without sky coverage, the base station will achieve the absolute accuracy of 2m within a few minutes; to reach the absolute accuracy of less than 30cm takes about an hour; to reach the absolute accuracy of 10cm takes a few hours. It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover. If your application does not require UXV with high absolute geographic accuracy, you do not need to set the base station's precision too high, which helps to avoid a longer survey time.

--- chunk_id: chunk-0253
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 353
content_hash: af90041522589363
prev_chunk_id: chunk-0252
next_chunk_id: chunk-0254
section_heading: User Manual
document_type: maintenance_procedure

It should be noted that the absolute geographic accuracy of the base station here will affect the absolute geographic accuracy of the rover module without affecting the relative accuracy between the base station and rover. If your application does not require UXV with high absolute geographic accuracy, you do not need to set the base station's precision too high, which helps to avoid a longer survey time. Even if the accuracy of the base station is 1.5 to 2 m, the position accuracy of the rover module relative to the base station can still reach the centimeter level. After the survey is complete, the Mission Planner will display the following page:

In the RTCM box, the base status indicator is green and indicators for different GNSS systems are also green. The box on the right shows Position is valid. To store the current location in Mission Planner : Click Save Current Pos, enter a name in the dialogue box, and click OK. As shown below, you can see your saved location in the list. Click the Use button for the location you saved, the status will show Using FixedLLA. If you set the base station in the same location later, you do not need to survey again. You may click the Use button that corresponds to the location you have saved. ### **Rover Module and Flight Controller Setup**

After the base station is set up, you can turn on the UXV. Using the same Mission Planner to connect the telemetry, the base station data will be transmitted through telemetry to the HerePro rover on UXV.

--- chunk_id: chunk-0254
source_document: herepro-manual.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 297
content_hash: 6bf7ce411b9bc6a7
prev_chunk_id: chunk-0253
next_chunk_id: chunk-0255
section_heading: User Manual
document_type: maintenance_procedure

### **Rover Module and Flight Controller Setup**

After the base station is set up, you can turn on the UXV. Using the same Mission Planner to connect the telemetry, the base station data will be transmitted through telemetry to the HerePro rover on UXV. In the Mission Planner main page, you will see the current GPS status showing as RTK Float / RTK Fixed / 3D RTK, indicating UXVUAV positioning has entered RTK mode. RTK Float is a floating-point solution; RTK Fixed is a fixed solution. RTK Fixed mode has higher accuracy and requires better signal strength. 3D RTK is unified saying of RTK Float / RTK in the Mission Planner. ![](/files/-M_WCngOTIEUJHqZXCq1)

### **Single Base to Multiple Rovers:**

There are 2 methods to do this:

* Using 1 telemetry to multiple telemetry broadcasting; or
* Using multiple 1 to 1 telemetry modules with the USB hub

Ground station configuration: connect all telemetry modules to the computer via USB hub. Open Mission Planner to locate the base then connect it with flight controllers. Select AUTO connecting as shown below. All recognized flight controllers on the ports will be connected. You may select the UAV from the dropdown list below:

![](/files/mgAs878BaqbJoSYTtDS9)

If you connected the UXVs with 1 telemetry module, they should share the same COM port:

![](/files/2wi5gsS45CMMJmobfK6Q)

### 8. Moving baseline setup reference

2023/07/12

--- chunk_id: chunk-0255
source_document: readme.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 145
content_hash: 660d27b2aa525165
prev_chunk_id: chunk-0254
next_chunk_id: chunk-0256
section_heading: What is CubePilot?
document_type: technical_reference

## What is CubePilot? *CubePilot*


CubePilot provides Hardware and embedded software ecosystem for the ever-evolving Civilian Unmanned Systems Industry. The CubePilot team understands the diversity of problems that can be solved using Unmanned Systems. And that, having ability to tailor the system for the application makes it possible to get the best out of this cutting-edge technology. With Open Source and Community as the soul, Reliability and Quality as the character, CubePilot has been continually bringing premium hardware to the market. CubePilot Ecosystem currently consists of Cube Autopilot range serving as the core with variety of Accessories and Carrier Boards developed with massive support from the Community and Industry.

--- chunk_id: chunk-0256
source_document: powering-telemetry-radios-externally.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 18
content_hash: ee8ff5ae76750b72
prev_chunk_id: chunk-0255
next_chunk_id: chunk-0257
section_heading: Powering Telemetry Radios Externally
document_type: technical_reference

# Powering Telemetry Radios Externally

"NEVER power radio devices off the Carrier board connectors"

--- chunk_id: chunk-0257
source_document: critical-notices.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 10
content_hash: 6260a756490dd9c0
prev_chunk_id: chunk-0256
next_chunk_id: chunk-0258
section_heading: Critical Notices
document_type: technical_reference

# Critical Notices

- [Powering Telemetry Radios Externally](https://docs.cubepilot.org/user-guides/service-bulletins-and-critical-notices/critical-notices/powering-telemetry-radios-externally.md)

--- chunk_id: chunk-0258
source_document: sb_0000001-critical-service-bulletin-for-beta-cube-2.1-2016.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 353
content_hash: 626fc85164f7beb0
prev_chunk_id: chunk-0257
next_chunk_id: chunk-0259
section_heading: SB_0000001 Critical Service Bulletin for Beta Cube 2.1 (2016)
document_type: technical_reference

# SB_0000001 Critical Service Bulletin for Beta Cube 2.1 (2016)

**Latest update please refer to:**\
[SB_0000001 Critical service bulletin for Beta Cube 2.1 (2016)](https://discuss.cubepilot.org/t/sb-0000001-critical-service-bulletin-for-beta-cube-2-1-2016/405)

### If you have a Beta Cube 2.1 **Delivered** **in 2016**, follow these instructions before further flight. **

This does NOT affect the Alpha boards, it does not affect 2.0 boards (SOLO) and does not affect made in 2017 boards

I/O channel 1 can be affected by over torquing the mounting screws holding the cube to the carrier board.\
There is no preflight check that can be done to stop the aircraft arming if this is the case. There are two solutions to this issue. 1. As short term, software fix to keep you in the air…

Move channel 1 to channel 5 by setting the following parameters:

* Firmware 3.4 set RC5_FUNCTION=33
* Firmware 3.5 set SERVO5_FUNCTION=33

![](/files/-Ma6RWDXPJZVBu4k-Unl)

After you have made these changes, leave I/O channel 1 disconnected… plug Aileron / ESC1 to I/O5

2. We will be sending all affected users a mod kit. This will involve an insulating sticker that will fit in the corner of the board. ![SB_0000001 Photo-02 PH2 ch 1-4](/files/-Ma6RkwCOD91vHe206hD)

![SB_0000001 Photo-03 PH2 short](/files/-Ma6RwAB0_Rn-MvQ8bBR)

![SB_0000001 Photo-04 PWM CH1 Fix](/files/-Ma6S54qDfd5GQJbpwN2)

As a third thing, I am working with Michael Oborne to make a service bulletin section in mission planner. this will identify your board, and list any known issues, and give you any information you need to maintain safe flight. Keep mission planner up to date to take advantage of this service. The modification is a user mod, and instructions will be posted for these.

--- chunk_id: chunk-0259
source_document: sb_0000002-critical-service-bulletin-for-cubes-purchased-between-jan-2019-to-jul-2019.-do-not-fly.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: bf7f1e2a376d3cdf
prev_chunk_id: chunk-0258
next_chunk_id: chunk-0260
section_heading: SB_0000002 Critical Service Bulletin for Cubes Purchased between JAN 2019 to JUL 2019. DO NOT FLY
document_type: technical_reference

# SB_0000002 Critical Service Bulletin for Cubes Purchased between JAN 2019 to JUL 2019. DO NOT FLY

**For the latest updates, refer to the following link:**\
[SB_0000002 Critical service bulletin for Cubes Purchased between January 2019 to July 2019. DO NOT FLY](https://discuss.cubepilot.org/t/sb-0000002-critical-service-bulletin-for-cubes-purchased-between-january-2019-to-july-2019-do-not-fly/406)

[Cube Blue (USA) is not affected by safety Bulletin 2
](https://discuss.cubepilot.org/t/cube-blue-is-not-affected-by-safety-bulletin-2/631)\
*Cube Blue manufactured in USA with US and allied components

**Edit 3 April 2020\
This issue is fully resolved by 3.6.12 but many updates have come since. Please keep up to date as this SB only relates to the IMU matter.\
Please see Ardupilot release notes for other Ardupilot matters covered in each release

**EDIT 11th December 2019**\
Due to SB_0000005 I’m updating this to ensure that you use 3.6.11 as a minimum\
No other changes

**Edit 28th July 2019**\
Please ensure you are using at least Arducopter 3.6.10\
SB_0000002 Critical service bulletin for Cubes Purchased between January 2019 to present.\
**flight is possible under the following conditions** :

1. You MUST run Latest Ardupilot RELEASE **CUBE BLACK** code. 2. You must use latest Mission Planner or Latest QGC
3. Set the following parameters\
   [CUBE_BLACK.param 32](https://discuss.cubepilot.org/uploads/default/original/1X/d4ace0149f9bfbabac84c30cdff2d53ec98879de.param) (98 Bytes)

> BRD_TYPE == 3 \
> EK2_IMU_MASK == 7 \
> (or EK3_IMU_MASK == 7 if using EKF3) \
> INS_USE == 1 \
> INS_USE2 == 1 \
> INS_USE3 == 1

4. Save the parameters and reboot the cube. 5. Reconnect mission planner

6.If Mission planner flags your code, contact your local re-seller, and log the issue. DO NOT FLY TILL I HAVE PERSONALLY CHECKED YOUR LOGS, and either given the go ahead, or, organised what we will do next in your case. 7.Further flight is only to be conducted where you have carried out a full risk assessment on the implications of a failure occurring, the new code is good… but it should not be relied upon as your only means of protection. You must not fly over people, you must not fly over critical infrastructure, you must also take responsibility for your payload and vehicle. **Failure to comply with these requirements may lead to serious damage, injury, or death.**

**EDIT: 02nd of May 2019:**\
In addition to following the instructions on the 27th of April, ensure that the following parameters are set.

--- chunk_id: chunk-0260
source_document: sb_0000002-critical-service-bulletin-for-cubes-purchased-between-jan-2019-to-jul-2019.-do-not-fly.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: 37e68e7b22881270
prev_chunk_id: chunk-0259
next_chunk_id: chunk-0261
section_heading: SB_0000002 Critical Service Bulletin for Cubes Purchased between JAN 2019 to JUL 2019. DO NOT FLY
document_type: technical_reference

You must not fly over people, you must not fly over critical infrastructure, you must also take responsibility for your payload and vehicle. **Failure to comply with these requirements may lead to serious damage, injury, or death.**

**EDIT: 02nd of May 2019:**\
In addition to following the instructions on the 27th of April, ensure that the following parameters are set. > EK2_IMU_MASK == 7 (or EK3 if using EKF3) \
> INS_USE == 1 \
> INS_USE2 == 1 \
> INS_USE3 == 1

**EDIT: 27th of April 2019**: Ardupilot has now added detection, prearm checking, and inflight checking and failover to the redundant sensors. This is now in Release Copter and Release Plane.\
Detection of the fault has also been added to Mission Planner, and QGC latest. Mission planner now collects information on this fault if you are willing to send it to us. As such, we are reducing this service bulletin to **flight is possible under the following conditions**:\
1\. You MUST run Latest Ardupilot RELEASE **CUBE BLACK** code.\
2\. You must use latest Mission Planner or Latest QGC\
3\. If QGC or Mission planner flags your code, contact your local re-seller, and log the issue. DO NOT FLY TILL I HAVE PERSONALLY CHECKED YOUR LOGS, and either given the go ahead, or, organised what we will do next in your case.\
4.Further flight is only to be conducted where you have carried out a full risk assessment on the implications of a failure occurring, the new code is good… but it should not be relied upon as your only means of protection. You must not fly over people, you must not fly over critical infrastructure, you must also take responsibility for your payload and vehicle. **Failure to comply with these requirements may lead to serious damage, injury, or death.**

Original notice:

It has come to our attention, that there is an anomaly with sensor readings on some recent cubes. This notification will be modified multiple times a day!!! Please check often. This is an unfolding investigation, more details will be added as they come to light. **If your vehicle is fitted with a CUBE BLACK, DO NOT FLY. Wait for further instructions.**

Your Cube is fitted with Three Gyros, Three Accelerometers, two Barometers, two internal Compasses.

--- chunk_id: chunk-0261
source_document: sb_0000002-critical-service-bulletin-for-cubes-purchased-between-jan-2019-to-jul-2019.-do-not-fly.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 242
content_hash: 1c2b8b074ae232ef
prev_chunk_id: chunk-0260
next_chunk_id: chunk-0262
section_heading: SB_0000002 Critical Service Bulletin for Cubes Purchased between JAN 2019 to JUL 2019. DO NOT FLY
document_type: technical_reference

**If your vehicle is fitted with a CUBE BLACK, DO NOT FLY. Wait for further instructions.**

Your Cube is fitted with Three Gyros, Three Accelerometers, two Barometers, two internal Compasses. to tell what is fitted…

Open mission planner and connect to your cube.\
go to the full parameter list. Please keep an eye on this notice for further instructions. There will be an update to mission planner, and to Ardupilot coming to assist in determining if your Cube is affected by this fault. We are sorry about this situation, and will endeavour to follow up with solutions as soon as possible\
Thank you

**NEW MISSION PLANNER BETA RELEASED TODAY! PLEASE UPDATE MISSION PLANNER TO ADD a test of AUTO DETECTION OF THIS ISSUE** . please let us know if you get the following error…

“Your board has a Critical service bulletin please see \[link;[https://discuss.cubepilot.org/t/sb-0000002-critical-service-bulletin-for-cubes-purchased-between-january-2019-to-present;Click 728](https://discuss.cubepilot.org/t/sb-0000002-critical-service-bulletin-for-cubes-purchased-between-january-2019-to-present;Click) here]”

Failure to get the mission planner notification is NOT an indication that it is safe to fly. All advice given will assume your device is running MASTER ARDUPILOT FOR CUBE BLACK, unless otherwise stated. Philip Rowse

--- chunk_id: chunk-0262
source_document: sb_0000003-flight-with-arming-checks-set-anything-other-than-1-prohibited.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 224
content_hash: d6da55bbc6a0c301
prev_chunk_id: chunk-0261
next_chunk_id: chunk-0263
section_heading: SB_0000003 Flight with Arming Checks Set Anything other than 1 prohibited
document_type: technical_reference

# SB_0000003 Flight with Arming Checks Set Anything other than 1 prohibited

**For the latest updates, refer to the following link:**\
[SB_0000003 Flight with arming checks set to anything other than 1 prohibited](https://discuss.cubepilot.org/t/sb-0000003-flight-with-arming-checks-set-to-anything-other-than-1-prohibited/857)

We are seeing too many logs where arming checks are set at either 0, or at a value other than 1. If your vehicle will not arm, you need to investigate why! do not take off until you have solved the issue that is causing the arming checks to fail. The arming checks are there for your safety, and the safety of those around you. the following parameters are NOT OPTIONAL on Cube Black, Green, Blue, Yellow, Orange\
\#NOTE: CUBE_BLACK\
BRD_TYPE,3 #sets the board type to the three IMU board\
EK2_IMU_MASK,7 # makes sure that 3 EKF’s run\
INS_USE,1 #the following three parameters enable the IMUs\
INS_USE2,1\
INS_USE3,1\
LOG_DISARMED,1 #ensures you can get a log that includes pre-arm information\
ARMING_CHECK,1 #Ensures that you run all the arming checks. Your safety comes first

[CUBE_BLACK.param](https://discuss.cubepilot.org/uploads/default/original/1X/a70e1ea4cd6ad8cf37436a06cb709a3308c8894a.param) (114 Bytes)

--- chunk_id: chunk-0263
source_document: sb_0000004-limited-power-capacity-of-the-rcin-power-rail-on-pixhawk-autopilots.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 166
content_hash: 211f597f9b760c4f
prev_chunk_id: chunk-0262
next_chunk_id: chunk-0264
section_heading: SB_0000004 Limited Power Capacity of the RCIN Power Rail on The Cube Autopilots
document_type: technical_reference

# SB_0000004 Limited Power Capacity of the RCIN Power Rail on The Cube Autopilots

**For the latest updates, refer to the following link:**\
[SB_0000004 Limited power capacity of the RCIN power rail on The Cube Autopilots](https://discuss.cubepilot.org/t/sb-0000004limited-power-capacity-of-the-rcin-power-rail-on-pixhawk-autopilots/1853)

This bulletin applies to all The Cube hardware. DO NOT POWER anything off the RCIN power pin other than a traditional RC Receiver, and do not connect any servos to the RCIN pin, nor to the Receiver itself. Companion Computers like HereLink, Raspberry Pi, Nvidia Jetson etc (and any others) should not be powered from this pin. They should be powered separately from the Autopilot. Failure to follow this safety Bulletin could cause loss of control of your vehicle. This applies to ALL Autopilots that run PX4 or Ardupilot.

--- chunk_id: chunk-0264
source_document: sb_0000005-i2c-storm-can-cause-inflight-reboots-chibios-only-not-nuttx-all-cube-and-pixhawk-hardw.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: b6fc3f565cd0748a
prev_chunk_id: chunk-0263
next_chunk_id: chunk-0265
section_heading: SB_0000005 I2C Storm can cause Inflight Reboots, Chibios ONLY, not Nuttx (all The Cube hardware)
document_type: technical_reference

# SB_0000005 I2C Storm can cause Inflight Reboots, Chibios ONLY, not Nuttx (all The Cube hardware)

**For the latest updates, refer to the following link:**\
[SB_0000005 I2C Storm can cause inflight reboots, Chibios ONLY, not Nuttx (all The Cube hardware)](https://discuss.cubepilot.org/t/sb-0000005-i2c-storm-can-cause-inflight-reboots-chibios-only-not-nuttx-all-cube-and-pixhawk-hardware-including-clones-and-derivatives/2419)

**CRITICAL**

**Update ALL CHIBIOS Copter USERS MUST USE 3.6.12 or cease flight**. Critical Safety Update is in Copter 3.6.12\
Update Friday, 13th December. This is a Chibios only issue. Old hardware running old custom or stock Nuttx firmware is not affected by this SB. Due to an issue with a bug in the I2C system for ArduCopter for 3.6.10 version and earlier and Arduplane before 4.0. Ground any vehicles that have not BEEN updated to Arduplane 4.0 or 3.6.11 for Arducopter or later. This issue has lead to aircraft failing mid flight, and the details can be found in the Ardupilot release notes for 3.6.11. A rare case can still occur in 3.6.11, 3.6.12 will be released shortly, and as soon as it is, this notice will be updated.

--- chunk_id: chunk-0265
source_document: sb_0000006-time-to-go-orange.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 349
content_hash: 2cb82511cfbf5d53
prev_chunk_id: chunk-0264
next_chunk_id: chunk-0266
section_heading: SB_0000006 Time to Go Orange
document_type: technical_reference

# SB_0000006 Time to Go Orange

**For the latest updates, refer to the following link:**\
[SB_0000006 time to Go Orange](https://discuss.cubepilot.org/t/sb-0000006-time-to-go-orange/4124)

Reminder to plan for upgrade to cube Orange soon, Orange is the new Long Term Stable (LTS) option. This is not a safety notice, but is critical for people to know. The cube Black sensors are all End Of Life from suppliers. We have multiple options for people needing cubes moving forward. Pick an option to suite your needs. 1. Switch to cube Orange, cube Orange and the upcoming Cube Orange Pro are the best autopilots in the Unmanned industry. 2. If you absolutely MUST have current design CubeBlack, contact your reseller and order in advance for the total number you will need. 3. Switch to cube Black +

Cube black plus is the latest version of cube black, it has newer sensors, but the same F4 FMU as the cube black. this is only for users that cannot use the Orange cube, if you can use the orange cube, please do. Cube black\
IMU1 MPU9250\
IMU2 LSM303D/ L3gd20\
IMU3 MPU9250

Cube black+\
IMU1 ICM20948\
IMU2 ICM20602\
IMU3 MPU9250

Ardupilot supports CubeBlack plus

4. For PX4 users. There are some developers working on Cube Orange support. Once that work is proven, you will be able to switch to orange. Meanwhile, yellow is in PX4 master, and Black+ shouldn’t be a difficult path forward. Remember that as soon as orange is released in Stable, I recommend PX4 users go with orange as well. Thanks Daniel Agar for the great news of PX4 support!

--- chunk_id: chunk-0266
source_document: sb_0000007-ethernet-on-herelink-one-a-siyi-camera.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 134
content_hash: 421d31be5f885b56
prev_chunk_id: chunk-0265
next_chunk_id: chunk-0267
section_heading: SB_0000007 Ethernet on Herelink One a SIYI Camera
document_type: technical_reference

# SB_0000007 Ethernet on Herelink One a SIYI Camera

**For the latest updates, refer to the following link:**\
[SB_0000007 Ethernet on Herelink one a SIYI camera](https://discuss.cubepilot.org/t/sb-0000007-ethernet-on-herelink-one-a-siyi-camera/13112)

Attention all SIYI camera users, please DO NOT connect a SIYI camera to HereLink ethernet directly, you MUST use magnetics or capacitors to isolate or put a switch or hub in line. We are unsure as to why, but it appears that the SIYI is destroying the HereLink ethernet port. We are not blaming SIYI, it is simply that some hardware’s do not play well together, and sometimes need something in the middle to help…

--- chunk_id: chunk-0267
source_document: sb_0000008-here4-magnetometer-flight-status-restored.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: 0f2a975cb1858836
prev_chunk_id: chunk-0266
next_chunk_id: chunk-0268
section_heading: SB_0000008 Here4 Magnetometer (Flight Status Restored)
document_type: technical_reference

# SB_0000008 Here4 Magnetometer (Flight Status Restored)

**For the latest updates, refer to the following link:**\
[SB_0000008 Here4 magnetometer (Flight status Restored)](https://discuss.cubepilot.org/t/sb-0000008-here4-magnetometer-flight-status-restored/13378)

Edit 9th of July, 2024: All should please update your Here4 unit using Mission planner DroneCAN/UAVCAN panel, select download from the internet. Software Version should be 1.14.FE92DFEF or later. DO NOT UPDATE UBLOX FIRMWARE

This fixes an issue that can cause momentary loss of gps after 1 hour of use

Edit: 3rd of July: Flight status RESTORED. After much testing, it is confirmed that the failure mode is 100% predictable, and if it happens in flight, Ardupilot has no issues handling this. Testing with the here4 as a flight controller with no other assistance is underway, and we will update on the tests asap

Thanks to [@sidbh](https://discuss.cubepilot.org/u/sidbh) and Paul Riseborough for their efforts in devising the tests to verify return to flight status. This doesn’t mean your mag will not fail, but it does mean that if it happens in flight, it by itself will not be the cause of an accident. This has occured to less than 0.1% of units. Edit: 15th June 2024: we have 3 confirmed customers with this situation, all returned units labelled as faulty exhibit this failure mode. Break is not visible on 3D X-ray. Firmware update has been issued for Here4, this will ensure the module behaves correctly in this failure mode. Flight with Dual Here4 is acceptable (or any other backup magnetometer

————————

Here4 magnetometer issue under investigation. Reports of magnetometer losses in Here4 have been reported to Cubepilot staff by a few customers now. We are unsure as to how widespread this issue is, as such we have put a hold on sales of Here4 GPS’s as of the 20th of May 2024. We are investigating this matter at the moment to get a root cause and will add information to this bulletin as information comes to light. In the meantime, please verify your magnetometer fallback on your vehicle, ensure you have effective redundancy to this sensor. In the reported cases, once the error occurs, the mag never comes back. Thus preflight checks will prevent further flight. We will obviously replace any affected units, but replacements will only happen once we have a proper solution. We appreciate your patience on this matter and apologize for the inconvenience this brings.

--- chunk_id: chunk-0268
source_document: sb_0000008-here4-magnetometer-flight-status-restored.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 50
content_hash: 339ce9fea0952f7f
prev_chunk_id: chunk-0267
next_chunk_id: chunk-0269
section_heading: SB_0000008 Here4 Magnetometer (Flight Status Restored)
document_type: technical_reference

We will obviously replace any affected units, but replacements will only happen once we have a proper solution. We appreciate your patience on this matter and apologize for the inconvenience this brings. Thanks\
Philip and the Cubepilot team

--- chunk_id: chunk-0269
source_document: sb_0000009-cube-red-free-upgrade-for-beta-hardware.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 256
content_hash: 0c83fd879cf4eb77
prev_chunk_id: chunk-0268
next_chunk_id: chunk-0270
section_heading: SB_0000009 Cube Red Free Upgrade for Beta Hardware
document_type: technical_reference

# SB_0000009 Cube Red Free Upgrade for Beta Hardware

**For the latest updates, refer to the following link:**\
[SB_0000009 cube Red Free upgrade for Beta hardware](https://discuss.cubepilot.org/t/sb-09-cube-red-free-upgrade-for-beta-hardware/15317)

Cube Red Beta hardware update. Do not Fly

To all that purchased a cube Red.. We will be doing a free upgrade to improve the hardware performance based on learning from users. We will not require you to return your existing hardware, but rather, we ask that you assign it to desk duties, development, and other non moving vehicle related responsibilities. We know that it was supposed to be “non beta” but we feel these improvements are worthwhile and don’t want “two” versions of cube red in the market at this time. This will roll out over the next couple of months, we appreciate all of you that take the jump on new hardware, and as such, we plan on adding a special feature to commemorate moving to Stable hardware. New hardware will be distinguishable by a feature that we will announce in this chat soon. Your reseller will contact you when your upgraded cube is ready. There is nothing that you need to do yet.

--- chunk_id: chunk-0270
source_document: sb_0000010-mandatory-here4-bootloader-update-before-further-flight.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: 93914e1f3d349c0a
prev_chunk_id: chunk-0269
next_chunk_id: chunk-0271
section_heading: SB_0000010 Mandatory Here4 Bootloader Update before Further Flight
document_type: technical_reference

# SB_0000010 Mandatory Here4 Bootloader Update before Further Flight

**For the latest updates, refer to the following link:**\
[SB_0000010 Mandatory Here4 bootloader update before further flight](https://discuss.cubepilot.org/t/sb-0000010-mandatory-here4-bootloader-update-before-further-flight/15630)

--- chunk_id: chunk-0271
source_document: sb_0000010-mandatory-here4-bootloader-update-before-further-flight.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 354
content_hash: 8bbfb3ec2d8c2c4c
prev_chunk_id: chunk-0270
next_chunk_id: chunk-0272
section_heading: BEFORE FURTHER FLIGHT
document_type: technical_reference

## BEFORE FURTHER FLIGHT
### Urgent Bootloader Update needed on Here4 If your Here4 doesn’t breath blue on boot, then you MUST do this bootloader update

All Here4 users need to update the bootloader on their Here4 units BEFORE FURTHER FLIGHT. #### For units NOT showing blue breathing at boot

The process for doing this update is as follows:

* Follow the steps here to update the firmware
* Once the Update is done, set parameter on Here4 FLASH_BOOTLOADER to 1 wait for either Bootloader Flash OK or Bootloader Unchanged message
* An updated bootloader boots with Blue Breathing at boot. It will breathe purple if CAN1 on here4(blue/white cable) is not connected or Cube is still booting, so to check best to unplug and plug Here4 without power cycling the Cube itself. * Use the Blue/white Can cable on the here 4 to CAN 1 or 2 on the Cube carrier board

#### For units already showing solid White LED (NOT breathing)

If you have appropriate SWD connector (6pin JST SUR) to Here4 available, and are capable of doing a bootloader update. Follow the following steps:

**For STLink:**

* Use this [bootloader file](https://github.com/CubePilot/GNSSPeriph-release/raw/refs/heads/release/bootloaders/Here4_bl.bin) and flash at address 0x08000000

**For JLink:**

* Use this [bootloader file](https://github.com/CubePilot/GNSSPeriph-release/raw/refs/heads/release/bootloaders/Here4_bl.hex) use JFlashLite to flash. **Important: For users that are not capable of opening Here4 unit and updating using JST SUR and Debug probe to fix solid white LED, please contact your Reseller for further support. For units that are still healthy make sure to follow primary bootloader update method.**

Additional Resources:

* [Batch Update Tool](https://github.com/CubePilot/DroneCAN-Batch-Updater/blob/v0.0.1/Here4%20Batch%20Update%20User%20Manual.md)
* [Here4 FW Release 1.15.0](https://github.com/CubePilot/GNSSPeriph-release/releases/tag/v1.15.0)

--- chunk_id: chunk-0272
source_document: safety-service-bulletins.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 357
content_hash: 6699855135b411cf
prev_chunk_id: chunk-0271
next_chunk_id: null
section_heading: Safety/Service Bulletins
document_type: technical_reference

# Safety/Service Bulletins

**Any Mandatory Safety Bulletins for any Cube, Here, or accessory will be listed here.**

**FAILURE TO COMPLY WITH ANY DIRECTIONS GIVEN IN THESE BULLETINS MAY LEAD TO SERIOUS CONSEQUENCES, OR DEATH**

**Each Bulletin will contain the brief issue, any actions you must take, any planned remedies, and whether the issue is solved, and how to apply the solution to your hardware.**

**It is YOUR responsibility NOT to fly until the issue has been resolved for your vehicle.**

> **Safety bulletin updates in this online documentation may occasionally be delayed. For the latest information, go to** [**https://discuss.cubepilot.org/c/msb/16**](https://discuss.cubepilot.org/c/msb/16)**.**

{% content-ref url="/pages/-Ma6Ma6comw2PgMsVTd3" %}
[SB_0000001 Critical Service Bulletin for Beta Cube 2.1 (2016)](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000001-critical-service-bulletin-for-beta-cube-2.1-2016.md)
{% endcontent-ref %}

{% content-ref url="/pages/-Ma6Serbohfok5gfRu8s" %}
[SB_0000002 Critical Service Bulletin for Cubes Purchased between JAN 2019 to JUL 2019. DO NOT FLY](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000002-critical-service-bulletin-for-cubes-purchased-between-jan-2019-to-jul-2019.-do-not-fly.md)
{% endcontent-ref %}

{% content-ref url="/pages/-Ma6Wpivfvz7LLT_BLAU" %}
[SB_0000003 Flight with Arming Checks Set Anything other than 1 prohibited](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000003-flight-with-arming-checks-set-anything-other-than-1-prohibited.md)
{% endcontent-ref %}

{% content-ref url="/pages/-Ma6pYKdAczl4qs5F7IK" %}
[SB_0000004 Limited Power Capacity of the RCIN Power Rail on The Cube Autopilots](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000004-limited-power-capacity-of-the-rcin-power-rail-on-pixhawk-autopilots.md)
{% endcontent-ref %}

{% content-ref url="/pages/-Ma6pyWvWxpIXF38zrGk" %}
[SB_0000005 I2C Storm can cause Inflight Reboots, Chibios ONLY, not Nuttx (all The Cube hardware)](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000005-i2c-storm-can-cause-inflight-reboots-chibios-only-not-nuttx-all-cube-and-pixhawk-hardw.md)
{% endcontent-ref %}

{% content-ref url="/pages/-Ma6qrlxLe7fa0LsRjz_" %}
[SB_0000006 Time to Go Orange](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000006-time-to-go-orange.md)
{% endcontent-ref %}

{% content-ref url="/pages/O8WtEaRCYQdGD7673AAD" %}
[SB_0000007 Ethernet on Herelink One a SIYI Camera](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000007-ethernet-on-herelink-one-a-siyi-camera.md)
{% endcontent-ref %}

{% content-ref url="/pages/S12CwiADoIvp5XfzdovX" %}
[SB_0000008 Here4 Magnetometer (Flight Status Restored)](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000008-here4-magnetometer-flight-status-restored.md)
{% endcontent-ref %}

{% content-ref url="/pages/U34r3eQYDy3BJJVuUHDZ" %}
[SB_0000009 Cube Red Free Upgrade for Beta Hardware](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000009-cube-red-free-upgrade-for-beta-hardware.md)
{% endcontent-ref %}

{% content-ref url="/pages/N4mPXKy8J0sfJBoPbwUN" %}
[SB_0000010 Mandatory Here4 Bootloader Update before Further Flight](/user-guides/service-bulletins-and-critical-notices/safety-service-bulletins/sb_0000010-mandatory-here4-bootloader-update-before-further-flight.md)
{% endcontent-ref %}
