# CubePilot FC corpus

- Raw: `docs/corpus/cubepilot_fc/docs_snapshot/md/` (llms.txt .md)
- **Ingested:** `docs_snapshot/md_clean/` (GitBook sanitize: llms preamble, `<mark>`, figures, `{%hint%}`/`{%embed%}`, HTML tables → markdown)
- ArduPilot: common-thecubeorange-overview, common-pixhawk-overview
- Framing: Orange/Red peer lizard-brain sensor suites; Red = latest gen
