---
kb_id: ardupilot-mavlink-protocol-commands
title: ArduPilot MAVLink — Protocol & Commands
author: ArduPilot Dev Team
created_date: 2026-07-18
classification: Internal
confidence_level: High
domain_tags: ["ardupilot", "mavlink", "protocol", "mission"]
entity_mentions: ["System ID", "system id"]
document_type: Technical Reference
primary_subject: MAVLink messages, MAV_CMD mission commands, ArduPilot routing/basics
intended_audience: Operators, companion-computer integrators, GCS developers
sources: [{"filename": "doctrine_mavlink-basics.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/doctrine_mavlink-basics.md", "page_count": 1}, {"filename": "doctrine_mavlink-commands.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/doctrine_mavlink-commands.md", "page_count": 1}, {"filename": "doctrine_mavlink-routing-in-ardupilot.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/doctrine_mavlink-routing-in-ardupilot.md", "page_count": 1}, {"filename": "doctrine_common-mavlink-mission-command-messages-mav_cmd.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/doctrine_common-mavlink-mission-command-messages-mav_cmd.md", "page_count": 1}, {"filename": "messages_batch_01.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_01.md", "page_count": 1}, {"filename": "messages_batch_02.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_02.md", "page_count": 1}, {"filename": "messages_batch_03.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_03.md", "page_count": 1}, {"filename": "messages_batch_04.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_04.md", "page_count": 1}, {"filename": "messages_batch_05.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_05.md", "page_count": 1}, {"filename": "messages_batch_06.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_06.md", "page_count": 1}, {"filename": "messages_batch_07.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_07.md", "page_count": 1}, {"filename": "messages_batch_08.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_08.md", "page_count": 1}, {"filename": "messages_batch_09.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_09.md", "page_count": 1}, {"filename": "messages_batch_10.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_10.md", "page_count": 1}, {"filename": "messages_batch_11.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_11.md", "page_count": 1}, {"filename": "messages_batch_12.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_12.md", "page_count": 1}, {"filename": "messages_batch_13.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/messages_batch_13.md", "page_count": 1}, {"filename": "mav_cmd_batch_01.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/mav_cmd_batch_01.md", "page_count": 1}, {"filename": "mav_cmd_batch_02.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/mav_cmd_batch_02.md", "page_count": 1}, {"filename": "mav_cmd_batch_03.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/mav_cmd_batch_03.md", "page_count": 1}, {"filename": "mav_cmd_batch_04.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/mav_cmd_batch_04.md", "page_count": 1}, {"filename": "mav_cmd_batch_05.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/mav_cmd_batch_05.md", "page_count": 1}, {"filename": "mav_cmd_batch_06.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/mav_cmd_batch_06.md", "page_count": 1}, {"filename": "mav_cmd_batch_07.md", "path": "docs/corpus/ardupilot_mavlink/structured_md/mav_cmd_batch_07.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-07-18T13:22:49.725722", "page_count": 24, "extraction_methods": {"txt": 24}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "confidence_level", "created_date", "entity_mentions", "ingest_provenance", "kb_id", "sources"]
brick_role: mavlink_protocol
out_of_scope: ["live MAVLink send/receive or vehicle control", "Plane mode/failsafe doctrine (see ArduPilot_Plane)", "parameter defaults (see ArduPilot_Plane_Params)", "full firmware source / custom message implementation guides as primary use"]
usage_notes: Docs-only MAVLink reference for ArduPilot-related co-pilot. No live link stack. Prefer message/command name retrieval.
routing_policy: For flight modes, failsafes, TECS procedure → ArduPilot_Plane. For param numbers → ArduPilot_Plane_Params. Do not invent message field meanings not in retrieved definitions.
adjacent_bricks: [{"brick_id": "ArduPilot_Plane", "role": "ops_doctrine", "when_to_use": ["modes", "failsafes", "setup procedures"], "when_not_to_use": ["MAVLink field definitions"], "status": "built"}, {"brick_id": "ArduPilot_Plane_Params", "role": "params_reference", "when_to_use": ["parameter defaults and ranges"], "when_not_to_use": ["MAVLink message catalogs"], "status": "built"}]
kb_name: ArduPilot_MAVLink
created: 2026-07-18T13:22:49.727626
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 310
template: technical_reference
domain: general
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-18T13:23:00.590530
  chunk_count: 310
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: doctrine_mavlink-basics.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 305
content_hash: 8cb0ae1e826e2faa
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: MAVLink basics (ArduPilot)
document_type: technical_reference

# MAVLink basics (ArduPilot)

MAVLink Basics &mdash; Dev documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Dev

Getting Started 

Downloading the code / Using Git 

Building the code 

Editors &amp; IDEs 

Learning the code 

Simulation &amp; Testing 

Debugging 

License (GPLv3) 

Contributing 

Contributing Code 

How The Team Works 

Wiki Editing Guide 

GSoC 

Hardware &amp; Peripherals 

Porting to a new Flight Controller 

Advanced Hardware Info 

AP_Peripheral Devices 

Companion Computers 

Linux Support 

OEM Customization 

RTF Vehicle Developer Information 

USB IDs 

Protocols &amp; Interfaces 

MAVLink Interface 
MAVLink Basics 

Request Data From The AutoPilot 

Get and Set Parameters 

Copter Commands (Guided Mode) 

Plane Commands (Guided Mode) 

Rover Commands (Guided Mode) 

Get and Set Home and/or EKF origin 

Arm and Disarm 

Get and Set FlightMode 

Camera Commands 

Gimbal / Camera Mount 

MAVFTP 

Mission Upload/Download 

Move a Servo 

Non-GPS Position Estimation 

Precision Landing 

RC Input (aka Pilot Input) 

Winch Commands 

MAVLink Routing 

Other Commands 

Mission Command List 

Mission Command Package Format 

MAVProxy Developer GCS 

GCS Developer Resources 

CAN and DroneCAN/UAVCAN 

Lua Scripts 

ROS1 

ROS2 

RemoteID 

Security &amp; Reference 

Security 

Support Proxy 

User Alerts

--- chunk_id: chunk-0001
source_document: doctrine_mavlink-basics.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 153
content_hash: 2eced4b869b8b00b
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
document_type: technical_reference

Appendix 

Community &amp; Events 

Developers Conference 

Events 

Training Centers 

Academic Works Involving ArduPilot 

Individual 
Partners 
SWAG Shop 

Dev 

MAVLink Interface 

MAVLink Basics

Edit on GitHub 

# MAVLink Basics 
MAVLink is a serial protocol most commonly used to send data and commands between vehicles and ground stations

The protocol defines a large set of messages which can be found in common.xml and ardupilot.xml 

MAVLink messages can be sent over almost any serial connection and does not depend upon the underlying technology (wifi, 900mhz radio, etc)

The messages are not guaranteed to be delivered which means ground stations or companion computers must often check the state of the vehicle to determine if a command has been executed

--- chunk_id: chunk-0002
source_document: doctrine_mavlink-basics.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 236
content_hash: 0097a68f0a3905c6
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: Message Format
document_type: technical_reference

## Message Format 

Messages are no more than 263 bytes (Mavlink version1.0) or 280 bytes (Mavlink version 2.0). The sender always fills in the System ID and Component ID fields so that the receiver knows where the packet came from. The System ID is a unique ID for each vehicle or ground station. Ground stations normally use a high system id like “255” and vehicles default to use “1” (this can be changed by setting the MAV_SYSID parameter, see also MAV_GCS_SYSID and MAV_GCS_SYSID_HI ). The Component ID for the ground station or flight controller is normally “1”. Other MAVLink capable device on the vehicle (i.e. companion computer, gimbal) should use the same System ID as the flight controller but use a different Component ID 

The Message ID field can be seen in the common.xml and ardupilot.xml next to the message name. For example the HEARTBEAT message Id is “0”

The Data portion of the message holds the individual field values being sent

See this page for advice on how to add support for a new MAVLink message

--- chunk_id: chunk-0003
source_document: doctrine_mavlink-basics.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 194e3093b1cf52d6
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: High Level Message Flow
document_type: technical_reference

## High Level Message Flow 

Once a connection is opened each device (aka “System”) sends the HEARTBEAT message at 1hz

The ground station or companion computer requests the data it wants (and the rate) by sending messages of the following types

REQUEST_DATA_STREAM supports setting the rate of groups of messages

COMMAND_LONG containing a SET_MESSAGE_INTERVAL command provides precise control of which messages are sent (and their rate) but is only supported on ArduPilot 4.0 and higher

Ground station or companion computer send commands to the vehicle. Details of the supported commands are here for copter and plane

### MAVLink1(v1) vs MAVLink2(v2) 
In this document, MAVLink protocol versions v1 and v2 are referred to as MAVLink1 and MAVLink2 respectively. - MAVLink2 messages have a maximum of 280 bytes of length, as they implement compatibility flags and support for signature. - MAVLink2 extends MAVLink1 by allowing new fields to be added to existing MAVLink1 messages, supports new messages with Message ID over “255” and adds support for signing messages
- MAVLink2 is backwards compatible with MAVLink1 meaning that if a device understands MAVLink2 messages it certainly understands MAVLink1 messages
- If a device only capable of understanding MAVLink1 receives a message that includes additional fields (added under MAVLink2) the device will only see the original fields. I.e. the device will be able to read the message but will not “see” the additional fields
- A flight controller’s serial port (presumably connected to a telemetry radio) can be set to use MAVLink2 by setting the SERIALx_PROTOCOL parameter to “2” (where “x” is the serial port number on the flight controller)
- See Mavlink2 Documentation for more information (especially on message extensions)

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0004
source_document: doctrine_mavlink-commands.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 306
content_hash: 3cb8efea384c3e5c
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: MAVLink commands interface (ArduPilot)
document_type: technical_reference

# MAVLink commands interface (ArduPilot)

MAVLink Interface &mdash; Dev documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Dev

Getting Started 

Downloading the code / Using Git 

Building the code 

Editors &amp; IDEs 

Learning the code 

Simulation &amp; Testing 

Debugging 

License (GPLv3) 

Contributing 

Contributing Code 

How The Team Works 

Wiki Editing Guide 

GSoC 

Hardware &amp; Peripherals 

Porting to a new Flight Controller 

Advanced Hardware Info 

AP_Peripheral Devices 

Companion Computers 

Linux Support 

OEM Customization 

RTF Vehicle Developer Information 

USB IDs 

Protocols &amp; Interfaces 

MAVLink Interface 
MAVLink Basics 

Request Data From The AutoPilot 

Get and Set Parameters 

Copter Commands (Guided Mode) 

Plane Commands (Guided Mode) 

Rover Commands (Guided Mode) 

Get and Set Home and/or EKF origin 

Arm and Disarm 

Get and Set FlightMode 

Camera Commands 

Gimbal / Camera Mount 

MAVFTP 

Mission Upload/Download 

Move a Servo 

Non-GPS Position Estimation 

Precision Landing 

RC Input (aka Pilot Input) 

Winch Commands 

MAVLink Routing 

Other Commands 

Mission Command List 

Mission Command Package Format 

MAVProxy Developer GCS 

GCS Developer Resources 

CAN and DroneCAN/UAVCAN 

Lua Scripts 

ROS1 

ROS2 

RemoteID 

Security &amp; Reference 

Security 

Support Proxy 

User Alerts

--- chunk_id: chunk-0005
source_document: doctrine_mavlink-commands.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 156
content_hash: 3f118c8ab11997ad
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
document_type: technical_reference

Appendix 

Community &amp; Events 

Developers Conference 

Events 

Training Centers 

Academic Works Involving ArduPilot 

Individual 
Partners 
SWAG Shop 

Dev 

MAVLink Interface

Edit on GitHub 

# MAVLink Interface 
ArduPilot supports the MAVLink protocol for communication with Ground Stations and Companion Computers . These pages explain the details of this interface and commonly used commands:

MAVLink Basics 

Request Data From The AutoPilot 

Get and Set Parameters 

Copter Commands (Guided Mode) 

Plane Commands (Guided Mode) 

Rover Commands (Guided Mode) 

Get and Set Home and/or EKF origin 

Arm and Disarm 

Get and Set FlightMode 

Camera Commands 

Gimbal / Camera Mount 

MAVFTP 

Mission Upload/Download 

Move a Servo 

Non-GPS Position Estimation 

Precision Landing 

RC Input (aka Pilot Input) 

Winch Commands 

MAVLink Routing 

Other Commands

--- chunk_id: chunk-0006
source_document: doctrine_mavlink-commands.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 178
content_hash: f9f52d12c8d04fe2
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: Complete lists of Messages
document_type: technical_reference

## Complete lists of Messages 

MAVLink not only has command messages but also incoming messages. A complete list of all MAVLink messages in ArduPilot by vehicle type, as of November 2024, are shown below:

Plane Copter Rover Sub 
MAVLink Messages 

MAVLink Messages 

MAVLink Messages 

MAVLink Messages

### External References 
MAVLink Common Message Set (HTML) and XML (Protocol Definition)

MAVLink ArduPilot Message Set (HTML) and XML 

MAVLink Tutorial for Absolute Dummies (Part–1) by Shyam Balasubramanian

### Autonomous Mission Commands 
Mission commands are stored on the flight controller in eeprom and executed one-by-one when the vehicle is switched into Auto mode. Although not directly related to the real-time MAVLink interface linked above, the available commands are a subset of the MAVLink MAV_CMD list 

Mission Command List 

Mission Command Package Format 

See also: Copter Mission Command List

--- chunk_id: chunk-0007
source_document: doctrine_mavlink-commands.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 76
content_hash: 142d7fb4900d0799
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Vehicle Parameter References
document_type: technical_reference

## Vehicle Parameter References 

Copter Parameters 

Plane Parameters 

Rover Parameters 

Sub Parameters

### Software Integration Tools 
MAVSDK 

Pymavlink python script 

Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0008
source_document: doctrine_mavlink-routing-in-ardupilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 309
content_hash: 0310f8961807bc20
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: MAVLink routing in ArduPilot
document_type: technical_reference

# MAVLink routing in ArduPilot

MAVLink Routing in ArduPilot &mdash; Dev documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Dev

Getting Started 

Downloading the code / Using Git 

Building the code 

Editors &amp; IDEs 

Learning the code 

Simulation &amp; Testing 

Debugging 

License (GPLv3) 

Contributing 

Contributing Code 

How The Team Works 

Wiki Editing Guide 

GSoC 

Hardware &amp; Peripherals 

Porting to a new Flight Controller 

Advanced Hardware Info 

AP_Peripheral Devices 

Companion Computers 

Linux Support 

OEM Customization 

RTF Vehicle Developer Information 

USB IDs 

Protocols &amp; Interfaces 

MAVLink Interface 
MAVLink Basics 

Request Data From The AutoPilot 

Get and Set Parameters 

Copter Commands (Guided Mode) 

Plane Commands (Guided Mode) 

Rover Commands (Guided Mode) 

Get and Set Home and/or EKF origin 

Arm and Disarm 

Get and Set FlightMode 

Camera Commands 

Gimbal / Camera Mount 

MAVFTP 

Mission Upload/Download 

Move a Servo 

Non-GPS Position Estimation 

Precision Landing 

RC Input (aka Pilot Input) 

Winch Commands 

MAVLink Routing 

Other Commands 

Mission Command List 

Mission Command Package Format 

MAVProxy Developer GCS 

GCS Developer Resources 

CAN and DroneCAN/UAVCAN 

Lua Scripts 

ROS1 

ROS2 

RemoteID 

Security &amp; Reference 

Security 

Support Proxy 

User Alerts

--- chunk_id: chunk-0009
source_document: doctrine_mavlink-routing-in-ardupilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 38c686f6d06adcde
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
document_type: technical_reference

Appendix 

Community &amp; Events 

Developers Conference 

Events 

Training Centers 

Academic Works Involving ArduPilot 

Individual 
Partners 
SWAG Shop 

Dev 

MAVLink Interface 

MAVLink Routing in ArduPilot

Edit on GitHub 

# MAVLink Routing in ArduPilot 
ArduPilot (which runs on the flight controller) can route MAVLink messages received on one telemetry port to all other telemetry ports. This is important in cases where there are multiple MAVLink enabled components on the vehicle (i.e. a flight controller and a companion computer) but only a single telemetry connection between the vehicle and the ground station. This page describes how ArduPilot decides which messages should be routed and to which telemetry ports. As described on the MAVLink Basics page a MAVLink network is made up of systems (vehicles, GCS, antenna trackers, etc) which are themselves made up of components (flight controller, camera system, etc). Each message contains a System ID and Component ID field to specify where the message came from. In addition some messages (including SET_POSITION_TARGET_GLOBAL_INT ) include target_system and target_component fields to allow specifying which system/component should execute the command. A value of 0 for the target_system or target_component is
considered a broadcast ID, and will be sent to all systems in the
network/components on the target system. The routing on ArduPilot systems works in the following way:

All received MAVLink messages are checked by the MAVLink_routing class. The class extracts the source system id (aka sysid ) and component id (aka compid ) and builds up a routing array which maps the channel (i.e. USB port, Telem1, Telem2) to the &lt;sysid,compid&gt; pair. The class also extracts the target system id ( target_system ) and component id ( target_component ) and if these don’t match the vehicle’s &lt;sysid,compid&gt; the messages are forwarded to the appropriate channel using the array above. Messages that don’t have a target &lt;sysid,compid&gt; are processed by the vehicle and then forwarded to each known system/component.

--- chunk_id: chunk-0010
source_document: doctrine_mavlink-routing-in-ardupilot.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 473
content_hash: ceb0a3085f53770e
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Detailed theory of MAVLink routing
document_type: technical_reference

## Detailed theory of MAVLink routing 
This information below is reproduced from the routing code in-source
comments
( /libraries/GCS_MAVLink/MAVLink_routing.cpp )

When a flight controller receives a message it should process it
locally if any of these conditions hold:

It has no target_system field

It has a target_system of zero

It has the flight controllers target system and has no
target_component field

It has the flight controllers target system and has the flight
controllers target_component 

It has the flight controllers target system and the flight
controller has not seen any messages on any of its links from a
system that has the messages
target_system / target_component combination

When a flight controller receives a message it should forward it onto
another different link if any of these conditions hold for that link:

It has no target_system field

It has a target_system of zero

It does not have the flight controllers target_system and the
flight controller has seen a message from the messages
target_system on the link

It has the flight controllers target_system and has a
target_component field and the flight controllers has seen a
message from the target_system / target_component 
combination on the link

Note

This proposal assumes that ground stations will not send command
packets to a non-broadcast destination (sysid/compid combination) until
they have received at least one package from that destination over the
link. This is essential to prevent a flight controller from acting on a
message that is not meant for it. For example, a PARAM_SET cannot be
sent to a specific &lt;sysid/compid&gt; combination until the GCS has seen a
packet from that &lt;sysid/compid&gt; combination on the link. The GCS must also reset what &lt;sysid/compid&gt; combinations it has seen
on a link when it sees a SYSTEM_TIME message with a decrease in
time_boot_ms from a particular &lt;sysid/compid&gt; . That is essential to
detect a reset of the flight controller, which implies a reset of its
routing table. Previous 
Next 

Questions, issues, and suggestions about this page can be raised on the forums . Issues and suggestions may be posted on the forums or the Github Issue Tracker . &#169; Copyright 2024, ArduPilot Dev Team.

--- chunk_id: chunk-0011
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 1779fdfa6988bb40
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Mission commands supported by ArduPilot vehicles
document_type: technical_reference

# Mission commands supported by ArduPilot vehicles

Mission Commands &mdash; Plane documentation 

Home 

Copter 

Plane 

Rover 

Blimp 

Sub 

AntennaTracker 

Mission Planner 

APM Planner 2 

MAVProxy 

Companion Computers 

Developer 

Downloads 

Mission Planner 

APM Planner 2 

Advanced User Tools 

Developer Tools 

Firmware 

Community 

Support Forums 

Facebook 

Developer Chat (Discord) 

Developer Voice (Discord) 

Contact us 

Getting involved 

Commercial Support 

Development Team 

UAS Training Centers 

Stores 

About 

News 

History 

License 

Trademark 

Acknowledgments 

Wiki Editing Guide 

Partners Program 

Plane

Introduction to Plane 

Choosing an Autopilot 

Ground Control Stations 
Choosing a Ground Station 

Mission Planning 
Planning a Mission with Waypoints and Events 

Mission Command List 
Overview 

Commands supported by Plane 

Navigation commands 

Conditional commands 

DO commands 

Camera Control in Auto Missions 

Rally Points 

DO_LAND_START 

DO_RETURN_PATH_START 

Geotagging Images with Mission Planner 

Terrain Following 

Rewind-on-resume 

Continue Mission After Landing 

First Time Setup 

First Flight and Tuning 

QuadPlane Setup and Operation 

Mission Planning 
Planning a Mission with Waypoints and Events 

Mission Command List 
Overview 
Types of commands 

Frames of reference 

How accurate is the information? How to interpret the command parameters 

Using this information with a GCS 

Commands supported by Plane 

Navigation commands 
MAV_CMD_NAV_WAYPOINT 

MAV_CMD_NAV_TAKEOFF 

MAV_CMD_NAV_VTOL_TAKEOFF 

MAV_CMD_NAV_LOITER_UNLIM 

MAV_CMD_NAV_LOITER_TURNS 

MAV_CMD_NAV_LOITER_TIME 

MAV_CMD_NAV_RETURN_TO_LAUNCH 

MAV_CMD_NAV_LAND 

MAV_CMD_NAV_VTOL_LAND 

MAV_CMD_NAV_CONTINUE_AND_CHANGE_ALT 

MAV_CMD_NAV_ALTITUDE_WAIT 

MAV_CMD_NAV_LOITER_TO_ALT 

MAV_CMD_NAV_DELAY 

MAV_CMD_NAV_PAYLOAD_PLACE 

MAV_CMD_DO_JUMP 

MAV_CMD_JUMP_TAG 

MAV_CMD_DO_JUMP_TAG 

Conditional commands 
MAV_CMD_CONDITION_DELAY 

MAV_CMD_CONDITION_DISTANCE 

DO commands 
MAV_CMD_DO_CHANGE_SPEED 

MAV_CMD_DO_SET_HOME 

MAV_CMD_DO_SET_RELAY 

MAV_CMD_DO_REPEAT_RELAY 

MAV_CMD_DO_SET_SERVO 

MAV_CMD_DO_REPEAT_SERVO 

MAV_CMD_DO_LAND_START 

MAV_CMD_DO_VTOL_TRANSITION 

MAV_CMD_DO_SET_ROI, MAV_CMD_DOE_SET_ROI_LOOCATION, MAV_CMD_DO_SET_ROI_NONE 

MAV_CMD_DO_DIGICAM_CONFIGURE 

MAV_CMD_DO_DIGICAM_CONTROL 

MAV_CMD_DO_MOUNT_CONTROL 

MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW 

MAV_CMD_DO_SET_CAM_TRIGG_DIST 

MAV_CMD_DO_FENCE_ENABLE 

MAV_CMD_DO_AUX_FUNCTION 

MAV_CMD_DO_INVERTED_FLIGHT 

MAV_CMD_DO_AUTOTUNE_ENABLE 

MAV_CMD_DO_ENGINE_CONTROL 

MAV_CMD_DO_SET_RESUME_REPEAT_DIST 

MAV_CMD_STORAGE_FORMAT 

Camera Control in Auto Missions 

Rally Points 

DO_LAND_START 

DO_RETURN_PATH_START 

Geotagging Images with Mission Planner 

Terrain Following 

Rewind-on-resume 

Continue Mission After Landing 

If A Problem Arises 

Advanced Configuration 

Peripheral Hardware 

Additional Information 

User Alerts 

Individual 
Partners 
SWAG Shop 

Plane 

Ground Control Stations 

Mission Planning 

Mission Commands

Edit on GitHub 

# Mission Commands 
This article describes the mission commands that are supported by Copter, Plane, Sub and Rover when switched into Auto mode. Note

there are many other MAVLink commands that a GCS or other device can send to the autopilot. See the ArduPilot/navlink repository, or the documentation for your GCS.

--- chunk_id: chunk-0012
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 488
content_hash: 4933adec4b9f7bf2
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: Overview
document_type: technical_reference

## Overview 

The MAVLink protocol defines a large number of
MAV_CMD 
waypoint command types (sent in a MAVLink_mission_item_message ). ArduPilot implements handling for the subset of these commands and
command parameters that are most relevant and meaningful for each of
the vehicles. Unsupported commands that are sent to a particular
autopilot will simply be dropped. This article lists and describes the commands and command-parameters
that are supported on each of the vehicle types. Any parameter that is
“grey” is not supported by the autopilot and will be ignored. They are
still documented to make it clear which properties are supported by
the MAV_CMD protocol 
are not implemented by the vehicle. Some commands and command parameters are not implemented because they
are not relevant for particular vehicle types (for example
“MAV_CMD_NAV_TAKEOFF” command makes sense for Plane and Copter but
not Rover and the pitch parameter only makes sense for Plane). There
are also some potentially useful command parameters that are not handled
because there is a limit to the message size, and a decision has been
made to prioritize some parameters over others. Note

There is additional information about the supported commands on
Copter (from a Mission Planner perspective) in the Copter Mission Command List . ### Types of commands 
There are several different types of commands that can be used within
missions:

Navigation commands are used to control the movement of the vehicle,
including takeoff, moving to and around waypoints, changing altitude,
and landing. DO commands are for auxiliary functions and do not affect the
vehicle’s position (for example, setting the camera trigger distance,
or setting a servo value). Condition commands are used to delay DO commands until some condition
is met, for example, the UAV reaches a certain altitude or distance
from the waypoint. During a mission at most one “Navigation” command and one “Do” or
“Condition” command can be running at one time. A typical mission might
set a waypoint (NAV command), add a CONDITION command that doesn’t
complete until a certain distance from the destination
( MAV_CMD_CONDITION_DISTANCE ), and
then add a number of DO commands that are executed sequentially (for
example
MAV_CMD_DO_SET_CAM_TRIGG_DIST 
to take pictures at regular intervals) when the condition completes.

--- chunk_id: chunk-0013
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 9a2c1b46a8a366d5
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: Overview
document_type: technical_reference

During a mission at most one “Navigation” command and one “Do” or
“Condition” command can be running at one time. A typical mission might
set a waypoint (NAV command), add a CONDITION command that doesn’t
complete until a certain distance from the destination
( MAV_CMD_CONDITION_DISTANCE ), and
then add a number of DO commands that are executed sequentially (for
example
MAV_CMD_DO_SET_CAM_TRIGG_DIST 
to take pictures at regular intervals) when the condition completes. Note

CONDITION and DO commands are associated with the preceding NAV
command: if the UAV reaches the next waypoint before these commands are
executed, the next NAV command is loaded and they will be
skipped. ### Frames of reference 
Many of the commands (in particular the NAV_ commands ) include position/location
information. The information is provided relative to a particular “frame
of reference”, which is specified in the message’s Frames of reference field. Copter and Rover Mission use MAV_CMD_DO_SET_HOME command to set the
“home position” in the global coordinate frame (MAV_FRAME_GLOBAL),
WGS84 coordinate system , where
the altitude is relative to mean sea level. All other commands use the
MAV_FRAME_GLOBAL_RELATIVE_ALT frame, which uses the same latitude
and longitude, but sets altitude as relative to the home position 
(home altitude = 0). Plane commands can additionally use MAV_FRAME_GLOBAL_TERRAIN_ALT
frame of reference. This again has the same WGS84 frame of reference for
latitude/longitude, but specifies altitude relative to ground height (as
defined in a terrain database). Note

The other frame types are defined in the MAVLink protocol (see
MAV_FRAME )
are not supported for mission commands. ### How accurate is the information? If a command or parameter is marked as supported then it is likely (but
not guaranteed) that it will behave as indicated. If a command or
parameter is not listed (or marked as not supported) then it is
extremely likely that it is not supported on ArduPilot. The reason for this is that the information was predominantly inferred
by inspecting the command handlers for messages:

The switch statement in AP_Mission::mavlink_to_mission_cmd 
was inspected to determine which commands are handled by all 
vehicle platforms, and which parameters from the message are stored. The command handler switch for each vehicle type
( Plane ,
Copter ,
Rover )
tells us which commands are likely to be supported in each vehicle
and which parameters are passed to the handler.

--- chunk_id: chunk-0014
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 449
content_hash: 387db8b212b27918
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: Overview
document_type: technical_reference

The reason for this is that the information was predominantly inferred
by inspecting the command handlers for messages:

The switch statement in AP_Mission::mavlink_to_mission_cmd 
was inspected to determine which commands are handled by all 
vehicle platforms, and which parameters from the message are stored. The command handler switch for each vehicle type
( Plane ,
Copter ,
Rover )
tells us which commands are likely to be supported in each vehicle
and which parameters are passed to the handler. The above checks give a very accurate picture of what commands and
parameters are not supported. They give a fairly accurate picture of
what commands/parameters are likely to be supported . However, this
indication is not guaranteed to be accurate because a command handler
could just throw away all the information (and we have not fully checked
all of these). In addition to the above checks, we have also merged information from
the Copter Mission Command List . ### How to interpret the command parameters 
The parameters for each command are listed in a table. The parameters
that are “greyed out” are not supported. The command field column (param
name) uses “bold” text to indicate those parameters that are defined in
the protocol (normal text is used for “empty” parameters). This allows users/developers to see both what is supported, and what
protocol fields are not supported in ArduPilot. ### Using this information with a GCS 
Mission Planner (MP) exposes the full subset of commands and
parameters supported by ArduPilot, filtered to display just those
relevant to the currently connected vehicle. Mapping the MP commands to
this documentation is easy, because it simply names commands using a
cut-down version of the full command name (e.g. DO_SET_SERVO rather
than the full command name: MAV_CMD_DO_SET_SERVO ). In addition, this
document conveniently lists the column label used by Mission Planner
alongside each of the parameters. Other GCSs (APM Planner 2, Tower etc.) may support some other subset of
commands/parameters and use alternative names/labels for them. In most
cases, the mapping should be obvious.

--- chunk_id: chunk-0015
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 490
content_hash: 132ff89f681bd44c
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: Commands supported by Plane
document_type: technical_reference

## Commands supported by Plane 

This list of commands was inferred from the command handler in
/ArduPlane/commands_logic.cpp . MAV_CMD_NAV_WAYPOINT 

MAV_CMD_NAV_RETURN_TO_LAUNCH 

MAV_CMD_NAV_TAKEOFF 

MAV_CMD_NAV_LAND 

MAV_CMD_NAV_LOITER_UNLIM 

MAV_CMD_NAV_LOITER_TURNS 

MAV_CMD_NAV_LOITER_TIME 

MAV_CMD_NAV_ALTITUDE_WAIT 

MAV_CMD_NAV_LOITER_TO_ALT 

MAV_CMD_NAV_CONTINUE_AND_CHANGE_ALT 

MAV_CMD_NAV_VTOL_TAKEOFF 

MAV_CMD_NAV_VTOL_LAND 

MAV_CMD_NAV_DELAY 

MAV_CMD_NAV_PAYLOAD_PLACE 

MAV_CMD_CONDITION_DELAY 

MAV_CMD_CONDITION_DISTANCE 

MAV_CMD_DO_AUX_FUNCTION 

MAV_CMD_DO_CHANGE_SPEED 

MAV_CMD_DO_ENGINE_CONTROL 

MAV_CMD_DO_VTOL_TRANSITION 

MAV_CMD_DO_SET_HOME 

MAV_CMD_DO_SET_SERVO 

MAV_CMD_DO_SET_RELAY 

MAV_CMD_DO_REPEAT_SERVO 

MAV_CMD_DO_REPEAT_RELAY 

MAV_CMD_DO_DIGICAM_CONFIGURE (Camera enabled only)

MAV_CMD_DO_DIGICAM_CONTROL (Camera enabled only)

MAV_CMD_DO_SET_CAM_TRIGG_DIST (Camera enabled only)

MAV_CMD_DO_SET_ROI (Gimbal/mount enabled only)

MAV_CMD_DO_SET_ROI_LOCATION (Gimbal/mount enabled only)

MAV_CMD_DO_SET_ROI_NONE (Gimbal/mount enabled only)

MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW (Gimbal/mount enabled only)

MAV_CMD_DO_JUMP 

MAV_CMD_JUMP_TAG 

MAV_CMD_DO_JUMP_TAG 

MAV_CMD_DO_MOUNT_CONTROL 

MAV_CMD_DO_INVERTED_FLIGHT 

MAV_CMD_DO_LAND_START 

MAV_CMD_DO_FENCE_ENABLE 

MAV_CMD_DO_AUTOTUNE_ENABLE 

MAV_CMD_DO_SET_RESUME_REPEAT_DIST 

MAV_CMD_STORAGE_FORMAT

### Navigation commands 
Navigation commands are used to control the movement of the vehicle,
including takeoff, moving to and around waypoints, and landing. NAV commands have the highest priority. Any DO_ and CONDITION_
commands that have not executed when a NAV command is loaded are skipped
(for example, if a waypoint completes and the NAV command for another
waypoint is loaded, and unexecuted DO/CONDITION commands associated with
the first waypoint are dropped. ### MAV_CMD_NAV_WAYPOINT 
Supported by: All vehicles. Navigate to the specified position. The vehicle will fly to the specified latitude, longitude and altitude. The waypoint is considered “complete” when Plane is within the specified
radius of the target location, at which point Plane processes the next
command. The protocol additionally provides for the plane to circle the waypoint
with a specified radius and direction for a specified time (Delay). These parameters are not supported by Copter. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

param2 
Acc radius 
Acceptance radius in meters (waypoint is complete when the plane is this close to the waypoint location 

param3 
Pass by 
0 to pass through the WP, if > 0 radius in meters to pass by WP. Positive value for clockwise orbit, negative value for counter-clockwise
orbit. Allows trajectory control. param4 

param5 
Lat 
Target latitude 

param6 
Lon 
Target longitude 

param7 
Alt 
Target altitude 

### MAV_CMD_NAV_TAKEOFF 
Supported by: Copter, Plane (not Rover). Takeoff (either from the ground or by hand-launch). It should be the first
command of nearly all Plane and Copter missions. The plane climbs to the specified altitude (at the specified pitch/climb
angle) before proceeding to the next waypoint. The plane is only attempting to climb at this point and can be pushed
off its heading by wind.

--- chunk_id: chunk-0016
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: 66b8d661d0feebe9
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: Commands supported by Plane
document_type: technical_reference

The plane climbs to the specified altitude (at the specified pitch/climb
angle) before proceeding to the next waypoint. The plane is only attempting to climb at this point and can be pushed
off its heading by wind. The pitch value is the minimum climb angle
when using an airspeed sensor, and maximum angle when not 
using an airspeed sensor. Command Field 
Mission Planner Field 
Description 

param1 
Pitch Angle 
Pitch/climb angle in degrees 

param2 

Empty 

param3 

Empty 

param4 

Yaw angle (ignored if compass not present). param5 
Lat 
Latitude 

param6 
Lon 
Longitude 

param7 
Alt 
Altitude 

### MAV_CMD_NAV_VTOL_TAKEOFF 
Supported by: Plane (not Copter or Rover). Specifically QuadPlanes. Takeoff while in VTOL mode. The vehicle will climb straight up from it’s current location to the
specified altitude as a delta above its current altitude. However, if Q_OPTIONS bit 3 is set (use altitude reference frames for VTOL takeoff), then the altitude value (in the specified reference frame) will be used for the target altitude, instead of a delta above the current altitude. If the command is begun while the vehicle is already flying, the vehicle will climb straight up to the specified altitude, if
the vehicle is already above the altitude the command will be ignored
and the mission will move on to the next command immediately. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Empty 

param2 

Empty 

param3 

Empty 

param4 

param5 
Lat 
Latitude 

param6 
Lon 
Longitude 

param7 
Alt 
Altitude 

### MAV_CMD_NAV_LOITER_UNLIM 
Supported by: All vehicles. Loiter at the specified location for an unlimited amount of time. Fly to the specified location and then loiter there indefinitely — where
loiter means “circle the waypoint”. If zero is specified for a
latitude/longitude/altitude parameter then the current location value
for the parameter will be used. You can also specify the radius and
direction for the loiter. The mission will not proceed past this command while in AUTO mode. In
order to break out of this command you need to change the mode (i.e. to
MANUAL). If there are subsequent commands then you can continue the
mission at the next command, if the Copter MIS_RESTART parameter is
set to resume, by switching back to AUTO mode (otherwise the mission
will restart). Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Empty 

param2 

Empty 

param3 
Dir 1=CW 
Radius around waypoint, in meters.

--- chunk_id: chunk-0017
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: f7ed4cc9214ca7c9
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: Commands supported by Plane
document_type: technical_reference

If there are subsequent commands then you can continue the
mission at the next command, if the Copter MIS_RESTART parameter is
set to resume, by switching back to AUTO mode (otherwise the mission
will restart). Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Empty 

param2 

Empty 

param3 
Dir 1=CW 
Radius around waypoint, in meters. Specify as a positive value to loiter clockwise, as a negative to move counter-clockwise. param4 

Desired yaw angle. param5 
Lat 
Target latitude. If zero, the vehicle will loiter at the current latitude. param6 
Lon 
Target longitude. If zero, the vehicle will loiter at the current longitude. param7 
Alt 
Target altitude. If zero, the vehicle will loiter at the current altitude. ### MAV_CMD_NAV_LOITER_TURNS 
Supported by: Copter, Plane (not Rover). Loiter (circle) the specified location for at least the specified number of complete turns,
and then proceed to the next command upon intersection of the course to it with the circle’s perimeter. If zero is specified for a latitude/longitude/altitude parameter then the current location value
for the parameter will be used. Fractional turns between 0 and 1 are supported, while turns greater than 1 must be integers. The radius of the circle is controlled by the
command parameter. A radius of 0 will result in WP_LOITER_RAD being used as the radius. Negative radius values result in counter-clockwise turns instead of clockwise turns. Radius values over 255 meters will be rounded down to the nearest 10 meter mark. Once the number of turns is completed, continue to loiter until heading
points to next nav waypoint. If XTrack Tangent param =1, proceed directly to next waypoint, otherwise, track to
the path in a line between the waypoint centers. =1. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Turns 
Number of turns (N x 360°) 

param2 

Empty 

param3 
Radius 
Loiter radius around the waypoint. Units are in meters. Values over 255 will be rounded to units of 10 meters. and values greater than 2550 will be clamped to 2550 m. Negative values indicate counter-clockwise turns. A value of zero will use WP_LOITER_RAD 

param4 
XTrack Tangent 
Determines which line the aircraft will track after exiting the loiter. If 0, track the line from the center of the circle to the next waypoint. If 1, track the line tangent to the circle to the next waypoint. param5 
Lat 
Target latitude.

--- chunk_id: chunk-0018
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 521
content_hash: a4d0935d1a30ba61
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: Commands supported by Plane
document_type: technical_reference

If 1, track the line tangent to the circle to the next waypoint. param5 
Lat 
Target latitude. If zero, the vehicle will loiter at the current latitude. param6 
Lon 
Target longitude. If zero, the vehicle will loiter at the current longitude. param7 
Alt 
Target altitude. If zero, the vehicle will loiter at the current altitude. ### MAV_CMD_NAV_LOITER_TIME 
Supported by: Copter, Plane, Rover. Fly to the specified location and then loiter there for the specified
number of seconds — where loiter means “circle the waypoint”. The timer
starts when the waypoint is reached; when it expires the waypoint is
complete. If zero is specified for a latitude/longitude/altitude
parameter then the current location value for the parameter will be
used. You can also specify the radius and direction for the loiter. Once
time has elapsed, continue to loiter until heading
points to next nav waypoint. If XTrack Tangent param = gb1, proceed directly to next waypoint, otherwise, track to
the path in a line between the waypoint centers. The radius of the loiter is set in the WP_LOITER_RAD parameter. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Time (s) 
Time to loiter at waypoint (seconds - decimal) 

param2 

Empty 

param3 
Dir 1=CW 
Radius around waypoint, in meters. Specify as a positive value to loiter clockwise, as a negative to move counter-clockwise. param4 
XTrack Tangent 
Determines which line the aircraft will track after exiting the loiter. If 0, track the line from the center of the circle to the next waypoint. If 1, track the line tangent to the circle to the next waypoint. param5 
Lat 
Target latitude. If zero, the vehicle will loiter at the current latitude. param6 
Lon 
Target longitude. If zero, the vehicle will loiter at the current longitude. param7 
Alt 
Target altitude. If zero, the vehicle will loiter at the current altitude. ### MAV_CMD_NAV_RETURN_TO_LAUNCH 
Supported by: All vehicles. Return to the home location or the nearest Rally
Point , if closer. The home location is where
the vehicle was last armed (or when it first gets GPS lock after arming
if the vehicle configuration allows this). Return to the home location (or the nearest Rally Point if closer) and then “Loiter” (circle the
point). The home location is where the vehicle was last armed (or when
it first gets GPS lock after arming if the vehicle configuration allows
this).

--- chunk_id: chunk-0019
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: bdfc3f3c7c75aee0
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: Commands supported by Plane
document_type: technical_reference

Return to the home location (or the nearest Rally Point if closer) and then “Loiter” (circle the
point). The home location is where the vehicle was last armed (or when
it first gets GPS lock after arming if the vehicle configuration allows
this). If the return is to a rally point, the plane will loiter at the position
and altitude set in the rally point. If the return is to the home
location, then the parameter
RTL_ALTITUDE 
is used for the loiter height (default 100m). The radius of the loiter
is defined in the parameter
WP_LOITER_RAD . This command takes no parameters and generally should be the last
command in the mission. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Empty 

param2 

Empty 

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

### MAV_CMD_NAV_LAND 
Supported by: Copter, Plane (not Rover). The plane will land at its current location or proceed to the (non-zero)
lat/lon coordinates provided beginning with current altitude. Information on the parameters used to
control the landing is provided in LAND flight mode . Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
Abort Alt 

param2 

Empty 

param3 

Empty 

param4 

Desired yaw angle. param5 
Lat 
Latitude 

param6 
Long 
Longitude 

param7 
Alt 
Altitude to target for the landing. Unless you are landing at a location different than home, this should be zero 

### MAV_CMD_NAV_VTOL_LAND 
Supported by: Plane (not Copter or Rover). Specifically QuadPlanes. Land the vehicle at the current or a specified location. If the Q_OPTIONS bit 4 is not set (default),the vehicle will land at its current location or proceed at the current altitude to the lat/lon
coordinates provided (if non-zero) and land. The ALT parameter is used to determine final landing phase initiation rather than Q_LAND_FINAL_ALT . This is the mission equivalent of the QLAND flight mode . If the Q_OPTIONS bit 4 is set (Use a fixed wind spiral approach), the it will fly in plane mode to the lat/lon coordinates provided (if non-zero), climbing or descending to the altitude set in the NAV_VTOL_LAND waypoint. When it reaches within Q_FW_LND_APR_RAD of the landing location, it will perform a LOITER_TO_ALT to finish the climb or descent to that ALT set in the waypoint, then, turning into the wind, transition to VTOL mode and proceed to the landing location and land.

--- chunk_id: chunk-0020
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 7490e288cf37b5b3
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
section_heading: Commands supported by Plane
document_type: technical_reference

If the Q_OPTIONS bit 4 is set (Use a fixed wind spiral approach), the it will fly in plane mode to the lat/lon coordinates provided (if non-zero), climbing or descending to the altitude set in the NAV_VTOL_LAND waypoint. When it reaches within Q_FW_LND_APR_RAD of the landing location, it will perform a LOITER_TO_ALT to finish the climb or descent to that ALT set in the waypoint, then, turning into the wind, transition to VTOL mode and proceed to the landing location and land. The motors will disarm on their own once landed

Note

param1 of the command acts just like Q_OPTIONS bit 4 above, if that option bit is not set. This allows the use of different approaches for different VTOL_LAND commands within the same mission. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Option:if set to 1,forces FW spiral approach 

param2 

Empty 

param3 

Empty 

param4 

Desired yaw angle. param5 
Lat 
Target latitude. If zero, the QuadPlane will land at the current latitude. param6 
Lon 
Longitude 

param7 
Alt 
additional altitude above Q_LAND_FINAL_ALT to switch to final landing phase 

### MAV_CMD_NAV_CONTINUE_AND_CHANGE_ALT 
Supported by: Plane (not Copter, Rover). Continue on the current course and climb/descend to a specified altitude. Move to the next command when the desired altitude is reached. Note

The param1 value sets how close the
vehicle altitude must be to target altitude for command
completion. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
TBD 
Climb or Descend (0 = Neutral, command completes when within 5m of this
command's altitude, 1 = Climbing, command completes when at or above
this command's altitude, 2 = Descending, command completes when at or
below this command's altitude. param2 

Empty 

param3 

Empty 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 
Alt 
Target altitude 

### MAV_CMD_NAV_ALTITUDE_WAIT 
Supported by: Plane (not Copter or Rover). Mission command to wait for an altitude or downward vertical speed. This is meant for high-altitude balloon launches, allowing the aircraft
to be idle until either an altitude is reached or a negative vertical
speed is reached (indicating early balloon burst). The wiggle time is
how often to wiggle the control surfaces to prevent them from seizing up. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 
? Altitude (m) 

param2 
? Descent speed (m/s) 

param3 
?

--- chunk_id: chunk-0021
source_document: doctrine_common-mavlink-mission-command-messages-mav_cmd.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 288
content_hash: 006c0da436f12489
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: Commands supported by Plane
document_type: technical_reference

Altitude (m) 

param2 
? Descent speed (m/s) 

param3 
? Wiggle Time (s) 

param4 

Empty 

param5 

Empty 

param6 

Empty 

param7 

Empty 

### MAV_CMD_NAV_LOITER_TO_ALT 
Supported by: Plane (not Copter or Rover). Loiter while climbing/descending to an altitude. Begin loitering at the specified Latitude and Longitude. If Lat=Lon=0, then
loiter at the current position. Don’t consider the navigation command
complete (don’t leave loiter) until the altitude has been reached. Continue to loiter until heading
points to next nav waypoint. If XTrack Tangent param =1, proceed directly to next waypoint, otherwise, track to
the path in a line between the waypoint centers. Command parameters 

Command Field 
Mission Planner Field 
Description 

param1 

Empty 

param2 
Radius 
Radius in meters. If positive loiter clockwise, negative counter-clockwise, 0 means no change to standard loiter. param3 

Empty 

param4 
XTrack Tangent 
Determines which line the aircraft will track after exiting the loiter. If 0, track the line from the center of the circle to the next waypoint. If 1, track the line tangent to the circle to the next waypoint. param5 
Lat 
Latitude. param6 
Long 
Longitude 

param7 
Alt 
Altitude 

### MAV_CMD_NAV_DELAY 
Supported by: Copter, Rover, Plane. After reaching this waypoint, if disarmed, delay the execution of the next mission command
until the time in seconds has elapsed. This is used in a mission to al

…(truncated)…

--- chunk_id: chunk-0022
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: d614eb7c420e7d06
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
section_heading: MAVLink messages batch 1
document_type: technical_reference

# MAVLink messages batch 1

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0023
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: 0f31aab200fa219a
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: HEARTBEAT (msg id 0, dialect minimal)
document_type: technical_reference

## HEARTBEAT (msg id 0, dialect minimal)

The heartbeat message shows that a system or component is present and responding. The type and autopilot fields (along with the message component id), allow the receiving system to treat further messages from this system appropriately (e.g. by laying out the user interface based on the autopilot). This microservice is documented at https://mavlink.io/en/services/heartbeat.html

### Fields

- **type** (`uint8_t`): Vehicle or component type. For a flight controller component the vehicle type (quadrotor, helicopter, etc.). For other components the component type (e.g. camera, gimbal, etc.). This should be used in preference to component id for identifying the component type. - **autopilot** (`uint8_t`): Autopilot type / class. Use MAV_AUTOPILOT_INVALID for components that are not flight controllers. - **base_mode** (`uint8_t`): System mode bitmap. - **custom_mode** (`uint32_t`): A bitfield for use for autopilot-specific flags
- **system_status** (`uint8_t`): System status flag. - **mavlink_version** (`uint8_t_mavlink_version`): MAVLink version, not writable by user, gets added by protocol because of magic data type: uint8_t_mavlink_version

--- chunk_id: chunk-0024
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 796fbe723cad05b7
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: SYS_STATUS (msg id 1, dialect common)
document_type: technical_reference

## SYS_STATUS (msg id 1, dialect common)

Sensor and subsystem status information. Provides a compact representation of sensor/subsystem status and a few other basic statistics. ### Fields

- **onboard_control_sensors_present** (`uint32_t`): Bitmap showing which onboard controllers and sensors are present. Value of 0: not present. Value of 1: present. - **onboard_control_sensors_enabled** (`uint32_t`): Bitmap showing which onboard controllers and sensors are enabled:  Value of 0: not enabled. Value of 1: enabled. - **onboard_control_sensors_health** (`uint32_t`): Bitmap showing which onboard controllers and sensors have an error (or are operational). Value of 0: error. Value of 1: healthy. - **load** (`uint16_t`, d%): Maximum usage in percent of the mainloop time. Values: [0-1000] - should always be below 1000
- **voltage_battery** (`uint16_t`, mV): Battery voltage, UINT16_MAX: Voltage not sent by autopilot. Value is ambiguous on multi-battery systems. BATTERY_STATUS is a recommended alternative. - **current_battery** (`int16_t`, cA): Battery current, -1: Current not sent by autopilot. Value may overflow/rollover for very high currents (> 327.67A). Value is ambiguous on multi-battery systems. BATTERY_STATUS is a recommended alternative. - **battery_remaining** (`int8_t`, %): Battery energy remaining, -1: Battery remaining energy not sent by autopilot. Value is ambiguous on multi-battery systems. BATTERY_STATUS is a recommended alternative. - **drop_rate_comm** (`uint16_t`, c%): Communication drop rate, (UART, I2C, SPI, CAN), dropped packets on all links (packets that were corrupted on reception on the MAV)
- **errors_comm** (`uint16_t`): Communication errors (UART, I2C, SPI, CAN), dropped packets on all links (packets that were corrupted on reception on the MAV)
- **errors_count1** (`uint16_t`): Autopilot-specific errors
- **errors_count2** (`uint16_t`): Autopilot-specific errors
- **errors_count3** (`uint16_t`): Autopilot-specific errors
- **errors_count4** (`uint16_t`): Autopilot-specific errors
- **onboard_control_sensors_present_extended** (`uint32_t`): Bitmap showing which onboard controllers and sensors are present. Value of 0: not present. Value of 1: present. - **onboard_control_sensors_enabled_extended** (`uint32_t`): Bitmap showing which onboard controllers and sensors are enabled:  Value of 0: not enabled. Value of 1: enabled. - **onboard_control_sensors_health_extended** (`uint32_t`): Bitmap showing which onboard controllers and sensors have an error (or are operational). Value of 0: error. Value of 1: healthy.

--- chunk_id: chunk-0025
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 329
content_hash: 122a2605b2da05f7
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: SYSTEM_TIME (msg id 2, dialect common)
document_type: technical_reference

## SYSTEM_TIME (msg id 2, dialect common)

The system time is the time of the sender's master clock. This can be emitted by flight controllers, onboard computers, or other components in the MAVLink network. Components that are using a less reliable time source, such as a battery-backed real time clock, can choose to match their system clock to that of a system that indicates a more recent time. This allows more broadly accurate date stamping of logs, and so on. If precise time synchronization is needed then use TIMESYNC instead. ### Fields

- **time_unix_usec** (`uint64_t`, us): Timestamp (UNIX epoch time). - **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). ### PING (msg id 4, dialect common)
A ping message either requesting or responding to a ping. This allows to measure the system latencies, including serial port, radio modem and UDP connections. The ping microservice is documented at https://mavlink.io/en/services/ping.html

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **seq** (`uint32_t`): PING sequence
- **target_system** (`uint8_t`): 0: request ping from all receiving systems. If greater than 0: message is a ping response and number is the system id of the requesting system
- **target_component** (`uint8_t`): 0: request ping from all receiving components. If greater than 0: message is a ping response and number is the component id of the requesting component.

--- chunk_id: chunk-0026
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: 982db3ac39ad477b
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: CHANGE_OPERATOR_CONTROL (msg id 5, dialect common)
document_type: technical_reference

## CHANGE_OPERATOR_CONTROL (msg id 5, dialect common)

Request to control this MAV

### Fields

- **target_system** (`uint8_t`): System the GCS requests control for
- **control_request** (`uint8_t`): 0: request control of this MAV, 1: Release control of this MAV
- **version** (`uint8_t`): 0: key as plaintext, 1-255: future, different hashing/encryption variants. The GCS should in general use the safest mode possible initially and then gradually move down the encryption level if it gets a NACK message indicating an encryption mismatch. - **passkey** (`char[25]`): Password / Key, depending on version plaintext or encrypted. 25 or less characters, NULL terminated. The characters may involve A-Z, a-z, 0-9, and "!?,.-"

### CHANGE_OPERATOR_CONTROL_ACK (msg id 6, dialect common)
Accept / deny control of this MAV

### Fields

- **gcs_system_id** (`uint8_t`): ID of the GCS this message
- **control_request** (`uint8_t`): 0: request control of this MAV, 1: Release control of this MAV
- **ack** (`uint8_t`): 0: ACK, 1: NACK: Wrong passkey, 2: NACK: Unsupported passkey encryption method, 3: NACK: Already under control

--- chunk_id: chunk-0027
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: c170a9df62c13049
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
section_heading: AUTH_KEY (msg id 7, dialect common)
document_type: technical_reference

## AUTH_KEY (msg id 7, dialect common)

Emit an encrypted signature / key identifying this system. PLEASE NOTE: This protocol has been kept simple, so transmitting the key requires an encrypted channel for true safety. ### Fields

- **key** (`char[32]`): key

### LINK_NODE_STATUS (msg id 8, dialect common)
Status generated in each node in the communication chain and injected into MAVLink stream. ### Fields

- **timestamp** (`uint64_t`, ms): Timestamp (time since system boot). - **tx_buf** (`uint8_t`, %): Remaining free transmit buffer space
- **rx_buf** (`uint8_t`, %): Remaining free receive buffer space
- **tx_rate** (`uint32_t`, bytes/s): Transmit rate
- **rx_rate** (`uint32_t`, bytes/s): Receive rate
- **rx_parse_err** (`uint16_t`, bytes): Number of bytes that could not be parsed correctly. - **tx_overflows** (`uint16_t`, bytes): Transmit buffer overflows. This number wraps around as it reaches UINT16_MAX
- **rx_overflows** (`uint16_t`, bytes): Receive buffer overflows. This number wraps around as it reaches UINT16_MAX
- **messages_sent** (`uint32_t`): Messages sent
- **messages_received** (`uint32_t`): Messages received (estimated from counting seq)
- **messages_lost** (`uint32_t`): Messages lost (estimated from counting seq)

--- chunk_id: chunk-0028
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 297
content_hash: 75f4fbb8fc7c3188
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
section_heading: SET_MODE (msg id 11, dialect common)
document_type: technical_reference

## SET_MODE (msg id 11, dialect common)

Set the system mode, as defined by enum MAV_MODE_FLAG. There is no target component id as the mode is by definition for the overall aircraft, not only for one component. ### Fields

- **target_system** (`uint8_t`): The system setting the mode
- **base_mode** (`uint8_t`): The new base mode. - **custom_mode** (`uint32_t`): The new autopilot-specific mode. This field can be ignored by an autopilot. ### PARAM_REQUEST_READ (msg id 20, dialect common)
Request to read the onboard parameter with the param_id string id. Onboard parameters are stored as key[const char*] -> value[float]. This allows to send a parameter to any other component (such as the GCS) without the need of previous knowledge of possible parameter names. Thus the same GCS can store different parameters for different autopilots. See also https://mavlink.io/en/services/parameter.html for a full documentation of QGroundControl and IMU code. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **param_id** (`char[16]`): Onboard parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_index** (`int16_t`): Parameter index. Send -1 to use the param ID field as identifier (else the param id will be ignored)

--- chunk_id: chunk-0029
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: 0abd296c9efd250f
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: PARAM_REQUEST_LIST (msg id 21, dialect common)
document_type: technical_reference

## PARAM_REQUEST_LIST (msg id 21, dialect common)

Request all parameters of this component. After this request, all parameters are emitted. The parameter microservice is documented at https://mavlink.io/en/services/parameter.html

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID

### PARAM_VALUE (msg id 22, dialect common)
Emit the value of a onboard parameter. The inclusion of param_count and param_index in the message allows the recipient to keep track of received parameters and allows him to re-request missing parameters after a loss or timeout. The parameter microservice is documented at https://mavlink.io/en/services/parameter.html

### Fields

- **param_id** (`char[16]`): Onboard parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_value** (`float`): Onboard parameter value
- **param_type** (`uint8_t`): Onboard parameter type. - **param_count** (`uint16_t`): Total number of onboard parameters
- **param_index** (`uint16_t`): Index of this onboard parameter

--- chunk_id: chunk-0030
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 186
content_hash: 3a4b37c27459ccef
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
section_heading: PARAM_SET (msg id 23, dialect common)
document_type: technical_reference

## PARAM_SET (msg id 23, dialect common)

Set a parameter value (write new value to permanent storage). The receiving component should acknowledge the new parameter value by broadcasting a PARAM_VALUE message (broadcasting ensures that multiple GCS all have an up-to-date list of all parameters). If the sending GCS did not receive a PARAM_VALUE within its timeout time, it should re-send the PARAM_SET message. The parameter microservice is documented at https://mavlink.io/en/services/parameter.html. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **param_id** (`char[16]`): Onboard parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_value** (`float`): Onboard parameter value
- **param_type** (`uint8_t`): Onboard parameter type.

--- chunk_id: chunk-0031
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: 9d788f23c2cb7086
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
section_heading: GPS_RAW_INT (msg id 24, dialect common)
document_type: technical_reference

## GPS_RAW_INT (msg id 24, dialect common)

The global position, as returned by the Global Positioning System (GPS). This is
                NOT the global position estimate of the system, but rather a RAW sensor value. See message GLOBAL_POSITION_INT for the global position estimate. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **fix_type** (`uint8_t`): GPS fix type. - **lat** (`int32_t`, degE7): Latitude (WGS84, EGM96 ellipsoid)
- **lon** (`int32_t`, degE7): Longitude (WGS84, EGM96 ellipsoid)
- **alt** (`int32_t`, mm): Altitude (MSL). Positive for up. Note that virtually all GPS modules provide the MSL altitude in addition to the WGS84 altitude. - **eph** (`uint16_t`): GPS HDOP horizontal dilution of position (unitless * 100). If unknown, set to: UINT16_MAX
- **epv** (`uint16_t`): GPS VDOP vertical dilution of position (unitless * 100). If unknown, set to: UINT16_MAX
- **vel** (`uint16_t`, cm/s): GPS ground speed. If unknown, set to: UINT16_MAX
- **cog** (`uint16_t`, cdeg): Course over ground (NOT heading, but direction of movement) in degrees * 100, 0.0..359.99 degrees. If unknown, set to: UINT16_MAX
- **satellites_visible** (`uint8_t`): Number of satellites visible. If unknown, set to UINT8_MAX
- **alt_ellipsoid** (`int32_t`, mm): Altitude (above WGS84, EGM96 ellipsoid). Positive for up. - **h_acc** (`uint32_t`, mm): Position uncertainty. - **v_acc** (`uint32_t`, mm): Altitude uncertainty. - **vel_acc** (`uint32_t`, mm/s): Speed uncertainty. - **hdg_acc** (`uint32_t`, degE5): Heading / track uncertainty
- **yaw** (`uint16_t`, cdeg): Yaw in earth frame from north. Use 0 if this GPS does not provide yaw. Use UINT16_MAX if this GPS is configured to provide yaw and is currently unable to provide it. Use 36000 for north.

--- chunk_id: chunk-0032
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 321
content_hash: b0413e1dd979827d
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
section_heading: GPS_STATUS (msg id 25, dialect common)
document_type: technical_reference

## GPS_STATUS (msg id 25, dialect common)

The positioning status, as reported by GPS. This message is intended to display status information about each satellite visible to the receiver. See message GLOBAL_POSITION_INT for the global position estimate. This message can contain information for up to 20 satellites. ### Fields

- **satellites_visible** (`uint8_t`): Number of satellites visible
- **satellite_prn** (`uint8_t[20]`): Global satellite ID
- **satellite_used** (`uint8_t[20]`): 0: Satellite not used, 1: used for localization
- **satellite_elevation** (`uint8_t[20]`, deg): Elevation (0: right on top of receiver, 90: on the horizon) of satellite
- **satellite_azimuth** (`uint8_t[20]`, deg): Direction of satellite, 0: 0 deg, 255: 360 deg. - **satellite_snr** (`uint8_t[20]`, dB): Signal to noise ratio of satellite

### SCALED_IMU (msg id 26, dialect common)
The RAW IMU readings for the usual 9DOF sensor setup. This message should contain the scaled values to the described units

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **xacc** (`int16_t`, mG): X acceleration
- **yacc** (`int16_t`, mG): Y acceleration
- **zacc** (`int16_t`, mG): Z acceleration
- **xgyro** (`int16_t`, mrad/s): Angular speed around X axis
- **ygyro** (`int16_t`, mrad/s): Angular speed around Y axis
- **zgyro** (`int16_t`, mrad/s): Angular speed around Z axis
- **xmag** (`int16_t`, mgauss): X Magnetic field
- **ymag** (`int16_t`, mgauss): Y Magnetic field
- **zmag** (`int16_t`, mgauss): Z Magnetic field
- **temperature** (`int16_t`, cdegC): Temperature, 0: IMU does not provide temperature values. If the IMU is at 0C it must send 1 (0.01C).

--- chunk_id: chunk-0033
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 254
content_hash: d78d273d15ecb315
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
section_heading: RAW_IMU (msg id 27, dialect common)
document_type: technical_reference

## RAW_IMU (msg id 27, dialect common)

The RAW IMU readings for a 9DOF sensor, which is identified by the id (default IMU1). This message should always contain the true raw values without any scaling to allow data capture and system debugging. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **xacc** (`int16_t`): X acceleration (raw)
- **yacc** (`int16_t`): Y acceleration (raw)
- **zacc** (`int16_t`): Z acceleration (raw)
- **xgyro** (`int16_t`): Angular speed around X axis (raw)
- **ygyro** (`int16_t`): Angular speed around Y axis (raw)
- **zgyro** (`int16_t`): Angular speed around Z axis (raw)
- **xmag** (`int16_t`): X Magnetic field (raw)
- **ymag** (`int16_t`): Y Magnetic field (raw)
- **zmag** (`int16_t`): Z Magnetic field (raw)
- **id** (`uint8_t`): Id. Ids are numbered from 0 and map to IMUs numbered from 1 (e.g. IMU1 will have a message with id=0)
- **temperature** (`int16_t`, cdegC): Temperature, 0: IMU does not provide temperature values. If the IMU is at 0C it must send 1 (0.01C).

--- chunk_id: chunk-0034
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: 1806a20d2264347d
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: RAW_PRESSURE (msg id 28, dialect common)
document_type: technical_reference

## RAW_PRESSURE (msg id 28, dialect common)

The RAW pressure readings for the typical setup of one absolute pressure and one differential pressure sensor. The sensor values should be the raw, UNSCALED ADC values. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **press_abs** (`int16_t`): Absolute pressure (raw)
- **press_diff1** (`int16_t`): Differential pressure 1 (raw, 0 if nonexistent)
- **press_diff2** (`int16_t`): Differential pressure 2 (raw, 0 if nonexistent)
- **temperature** (`int16_t`): Raw Temperature measurement (raw)

### SCALED_PRESSURE (msg id 29, dialect common)
The pressure readings for the typical setup of one absolute and differential pressure sensor. The units are as specified in each field. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **press_abs** (`float`, hPa): Absolute pressure
- **press_diff** (`float`, hPa): Differential pressure 1
- **temperature** (`int16_t`, cdegC): Absolute pressure temperature
- **temperature_press_diff** (`int16_t`, cdegC): Differential pressure temperature (0, if not available). Report values of 0 (or 1) as 1 cdegC.

--- chunk_id: chunk-0035
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 374
content_hash: 4074fea8a4b1b05e
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: ATTITUDE (msg id 30, dialect common)
document_type: technical_reference

## ATTITUDE (msg id 30, dialect common)

The attitude in the aeronautical frame (right-handed, Z-down, Y-right, X-front, ZYX, intrinsic). ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **roll** (`float`, rad): Roll angle (-pi..+pi)
- **pitch** (`float`, rad): Pitch angle (-pi..+pi)
- **yaw** (`float`, rad): Yaw angle (-pi..+pi)
- **rollspeed** (`float`, rad/s): Roll angular speed
- **pitchspeed** (`float`, rad/s): Pitch angular speed
- **yawspeed** (`float`, rad/s): Yaw angular speed

### ATTITUDE_QUATERNION (msg id 31, dialect common)
The attitude in the aeronautical frame (right-handed, Z-down, X-front, Y-right), expressed as quaternion. Quaternion order is w, x, y, z and a zero rotation would be expressed as (1 0 0 0). ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **q1** (`float`): Quaternion component 1, w (1 in null-rotation)
- **q2** (`float`): Quaternion component 2, x (0 in null-rotation)
- **q3** (`float`): Quaternion component 3, y (0 in null-rotation)
- **q4** (`float`): Quaternion component 4, z (0 in null-rotation)
- **rollspeed** (`float`, rad/s): Roll angular speed
- **pitchspeed** (`float`, rad/s): Pitch angular speed
- **yawspeed** (`float`, rad/s): Yaw angular speed
- **repr_offset_q** (`float[4]`): Rotation offset by which the attitude quaternion and angular speed vector should be rotated for user display (quaternion with [w, x, y, z] order, zero-rotation is [1, 0, 0, 0], send [0, 0, 0, 0] if field not supported). This field is intended for systems in which the reference attitude may change during flight. For example, tailsitters VTOLs rotate their reference attitude by 90 degrees between hover mode and fixed wing mode, thus repr_offset_q is equal to [1, 0, 0, 0] in hover mode and equal to [0.7071, 0, 0.7071, 0] in fixed wing mode.

--- chunk_id: chunk-0036
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 294
content_hash: 57eae0fd4a757ee7
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
section_heading: LOCAL_POSITION_NED (msg id 32, dialect common)
document_type: technical_reference

## LOCAL_POSITION_NED (msg id 32, dialect common)

The filtered local position (e.g. fused computer vision and accelerometers). Coordinate frame is right-handed, Z-axis down (aeronautical frame, NED / north-east-down convention)

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **x** (`float`, m): X Position
- **y** (`float`, m): Y Position
- **z** (`float`, m): Z Position
- **vx** (`float`, m/s): X Speed
- **vy** (`float`, m/s): Y Speed
- **vz** (`float`, m/s): Z Speed

### RC_CHANNELS_SCALED (msg id 34, dialect common)
The scaled values of the RC channels received: (-100%) -10000, (0%) 0, (100%) 10000. Channels that are inactive should be set to INT16_MAX. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **port** (`uint8_t`): Servo output port (set of 8 outputs = 1 port). Flight stacks running on Pixhawk should use: 0 = MAIN, 1 = AUX. - **chan1_scaled** (`int16_t`): RC channel 1 value scaled. - **chan2_scaled** (`int16_t`): RC channel 2 value scaled. - **chan3_scaled** (`int16_t`): RC channel 3 value scaled. - **chan4_scaled** (`int16_t`): RC channel 4 value scaled. - **chan5_scaled** (`int16_t`): RC channel 5 value scaled. - **chan6_scaled** (`int16_t`): RC channel 6 value scaled. - **chan7_scaled** (`int16_t`): RC channel 7 value scaled. - **chan8_scaled** (`int16_t`): RC channel 8 value scaled. - **rssi** (`uint8_t`): Receive signal strength indicator in device-dependent units/scale. Values: [0-254], UINT8_MAX: invalid/unknown.

--- chunk_id: chunk-0037
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 210
content_hash: 0a06d0328ff45b26
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
section_heading: RC_CHANNELS_RAW (msg id 35, dialect common)
document_type: technical_reference

## RC_CHANNELS_RAW (msg id 35, dialect common)

The RAW values of the RC channels received. The standard PPM modulation is as follows: 1000 microseconds: 0%, 2000 microseconds: 100%. A value of UINT16_MAX implies the channel is unused. Individual receivers/transmitters might violate this specification. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **port** (`uint8_t`): Servo output port (set of 8 outputs = 1 port). Flight stacks running on Pixhawk should use: 0 = MAIN, 1 = AUX. - **chan1_raw** (`uint16_t`, us): RC channel 1 value. - **chan2_raw** (`uint16_t`, us): RC channel 2 value. - **chan3_raw** (`uint16_t`, us): RC channel 3 value. - **chan4_raw** (`uint16_t`, us): RC channel 4 value. - **chan5_raw** (`uint16_t`, us): RC channel 5 value. - **chan6_raw** (`uint16_t`, us): RC channel 6 value. - **chan7_raw** (`uint16_t`, us): RC channel 7 value. - **chan8_raw** (`uint16_t`, us): RC channel 8 value. - **rssi** (`uint8_t`): Receive signal strength indicator in device-dependent units/scale. Values: [0-254], UINT8_MAX: invalid/unknown.

--- chunk_id: chunk-0038
source_document: messages_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 306
content_hash: fde02e2b2ae07df6
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: SERVO_OUTPUT_RAW (msg id 36, dialect common)
document_type: technical_reference

## SERVO_OUTPUT_RAW (msg id 36, dialect common)

Superseded by ACTUATOR_OUTPUT_STATUS. The RAW values of the servo outputs (for RC input from the remote, use the RC_CHANNELS messages). The standard PPM modulation is as follows: 1000 microseconds: 0%, 2000 microseconds: 100%. ### Fields

- **time_usec** (`uint32_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **port** (`uint8_t`): Servo output port (set of 8 outputs = 1 port). Flight stacks running on Pixhawk should use: 0 = MAIN, 1 = AUX. - **servo1_raw** (`uint16_t`, us): Servo output 1 value
- **servo2_raw** (`uint16_t`, us): Servo output 2 value
- **servo3_raw** (`uint16_t`, us): Servo output 3 value
- **servo4_raw** (`uint16_t`, us): Servo output 4 value
- **servo5_raw** (`uint16_t`, us): Servo output 5 value
- **servo6_raw** (`uint16_t`, us): Servo output 6 value
- **servo7_raw** (`uint16_t`, us): Servo output 7 value
- **servo8_raw** (`uint16_t`, us): Servo output 8 value
- **servo9_raw** (`uint16_t`, us): Servo output 9 value
- **servo10_raw** (`uint16_t`, us): Servo output 10 value
- **servo11_raw** (`uint16_t`, us): Servo output 11 value
- **servo12_raw** (`uint16_t`, us): Servo output 12 value
- **servo13_raw** (`uint16_t`, us): Servo output 13 value
- **servo14_raw** (`uint16_t`, us): Servo output 14 value
- **servo15_raw** (`uint16_t`, us): Servo output 15 value
- **servo16_raw** (`uint16_t`, us): Servo output 16 value

--- chunk_id: chunk-0039
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: a124e2d3f05c0484
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: MAVLink messages batch 2
document_type: technical_reference

# MAVLink messages batch 2

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0040
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 226
content_hash: 6328943d9697e03f
prev_chunk_id: chunk-0039
next_chunk_id: chunk-0041
section_heading: MISSION_REQUEST_PARTIAL_LIST (msg id 37, dialect common)
document_type: technical_reference

## MISSION_REQUEST_PARTIAL_LIST (msg id 37, dialect common)

Request a partial list of mission items from the system/component. https://mavlink.io/en/services/mission.html. If start and end index are the same, just send one waypoint. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **start_index** (`int16_t`): Start index
- **end_index** (`int16_t`): End index, -1 by default (-1: send list to end). Else a valid index of the list
- **mission_type** (`uint8_t`): Mission type. ### MISSION_WRITE_PARTIAL_LIST (msg id 38, dialect common)
This message is sent to the MAV to write a partial list. If start index == end index, only one item will be transmitted / updated. If the start index is NOT 0 and above the current list size, this request should be REJECTED! ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **start_index** (`int16_t`): Start index. Must be smaller / equal to the largest index of the current onboard list. - **end_index** (`int16_t`): End index, equal or greater than start index. - **mission_type** (`uint8_t`): Mission type.

--- chunk_id: chunk-0041
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 290
content_hash: f60457ed4cbc56d1
prev_chunk_id: chunk-0040
next_chunk_id: chunk-0042
section_heading: MISSION_ITEM (msg id 39, dialect common)
document_type: technical_reference

## MISSION_ITEM (msg id 39, dialect common)

Message encoding a mission item. This message is emitted to announce the presence of a mission item and to set a mission item on the system. The mission item can be either in x, y, z meters (type: LOCAL) or x:lat, y:lon, z:altitude. Local frame is Z-down, right handed (NED), global frame is Z-up, right handed (ENU). NaN may be used to indicate an optional/default value (e.g. to use the system's current latitude or yaw rather than a specific value). See also https://mavlink.io/en/services/mission.html. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **seq** (`uint16_t`): Sequence
- **frame** (`uint8_t`): The coordinate system of the waypoint. - **command** (`uint16_t`): The scheduled action for the waypoint. - **current** (`uint8_t`): false:0, true:1
- **autocontinue** (`uint8_t`): Autocontinue to next waypoint. 0: false, 1: true. Set false to pause mission after the item completes. - **param1** (`float`): PARAM1, see MAV_CMD enum
- **param2** (`float`): PARAM2, see MAV_CMD enum
- **param3** (`float`): PARAM3, see MAV_CMD enum
- **param4** (`float`): PARAM4, see MAV_CMD enum
- **x** (`float`): PARAM5 / local: X coordinate, global: latitude
- **y** (`float`): PARAM6 / local: Y coordinate, global: longitude
- **z** (`float`): PARAM7 / local: Z coordinate, global: altitude (relative or absolute, depending on frame). - **mission_type** (`uint8_t`): Mission type.

--- chunk_id: chunk-0042
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 257
content_hash: 8388c077ce7d2fb0
prev_chunk_id: chunk-0041
next_chunk_id: chunk-0043
section_heading: MISSION_REQUEST (msg id 40, dialect common)
document_type: technical_reference

## MISSION_REQUEST (msg id 40, dialect common)

Request the information of the mission item with the sequence number seq. The response of the system to this message should be a MISSION_ITEM message. https://mavlink.io/en/services/mission.html

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **seq** (`uint16_t`): Sequence
- **mission_type** (`uint8_t`): Mission type. ### MISSION_SET_CURRENT (msg id 41, dialect common)
Set the mission item with sequence number seq as the current item and emit MISSION_CURRENT (whether or not the mission number changed). If a mission is currently being executed, the system will continue to this new mission item on the shortest path, skipping any intermediate mission items. Note that mission jump repeat counters are not reset (see MAV_CMD_DO_JUMP param2). This message may trigger a mission state-machine change on some systems: for example from MISSION_STATE_NOT_STARTED or MISSION_STATE_PAUSED to MISSION_STATE_ACTIVE. If the system is in mission mode, on those systems this command might therefore start, restart or resume the mission. If the system is not in mission mode this message must not trigger a switch to mission mode. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **seq** (`uint16_t`): Sequence

--- chunk_id: chunk-0043
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: 3992bff3691d0414
prev_chunk_id: chunk-0042
next_chunk_id: chunk-0044
section_heading: MISSION_CURRENT (msg id 42, dialect common)
document_type: technical_reference

## MISSION_CURRENT (msg id 42, dialect common)

Message that announces the sequence number of the current target mission item (that the system will fly towards/execute when the mission is running). This message should be streamed all the time (nominally at 1Hz). This message should be emitted following a call to MAV_CMD_DO_SET_MISSION_CURRENT or MISSION_SET_CURRENT. ### Fields

- **seq** (`uint16_t`): Sequence
- **total** (`uint16_t`): Total number of mission items on vehicle (on last item, sequence == total). If the autopilot stores its home location as part of the mission this will be excluded from the total. 0: Not supported, UINT16_MAX if no mission is present on the vehicle. - **mission_state** (`uint8_t`): Mission state machine state. MISSION_STATE_UNKNOWN if state reporting not supported. - **mission_mode** (`uint8_t`): Vehicle is in a mode that can execute mission items or suspended. 0: Unknown, 1: In mission mode, 2: Suspended (not in mission mode). - **mission_id** (`uint32_t`): Id of current on-vehicle mission plan, or 0 if IDs are not supported or there is no mission loaded. GCS can use this to track changes to the mission plan type. The same value is returned on mission upload (in the MISSION_ACK). - **fence_id** (`uint32_t`): Id of current on-vehicle fence plan, or 0 if IDs are not supported or there is no fence loaded. GCS can use this to track changes to the fence plan type. The same value is returned on fence upload (in the MISSION_ACK). - **rally_points_id** (`uint32_t`): Id of current on-vehicle rally point plan, or 0 if IDs are not supported or there are no rally points loaded. GCS can use this to track changes to the rally point plan type. The same value is returned on rally point upload (in the MISSION_ACK).

--- chunk_id: chunk-0044
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 278
content_hash: 59fb7a7ec420cfce
prev_chunk_id: chunk-0043
next_chunk_id: chunk-0045
section_heading: MISSION_REQUEST_LIST (msg id 43, dialect common)
document_type: technical_reference

## MISSION_REQUEST_LIST (msg id 43, dialect common)

Request the overall list of mission items from the system/component. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **mission_type** (`uint8_t`): Mission type. ### MISSION_COUNT (msg id 44, dialect common)
This message is emitted as response to MISSION_REQUEST_LIST by the MAV and to initiate a write transaction. The GCS can then request the individual mission item based on the knowledge of the total number of waypoints. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **count** (`uint16_t`): Number of mission items in the sequence
- **mission_type** (`uint8_t`): Mission type. - **opaque_id** (`uint32_t`): Id of current on-vehicle mission, fence, or rally point plan (on download from vehicle). This field is used when downloading a plan from a vehicle to a GCS. 0 on upload to the vehicle from GCS. 0 if plan ids are not supported. The current on-vehicle plan ids are streamed in `MISSION_CURRENT`, allowing a GCS to determine if any part of the plan has changed and needs to be re-uploaded. The ids are recalculated by the vehicle when any part of the on-vehicle plan changes (when a new plan is uploaded, the vehicle returns the new id to the GCS in MISSION_ACK).

--- chunk_id: chunk-0045
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 326
content_hash: 59397be9a48c1655
prev_chunk_id: chunk-0044
next_chunk_id: chunk-0046
section_heading: MISSION_CLEAR_ALL (msg id 45, dialect common)
document_type: technical_reference

## MISSION_CLEAR_ALL (msg id 45, dialect common)

Delete all mission items at once. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **mission_type** (`uint8_t`): Mission type. ### MISSION_ITEM_REACHED (msg id 46, dialect common)
A certain mission item has been reached. The system will either hold this position (or circle on the orbit) or (if the autocontinue on the WP was set) continue to the next waypoint. ### Fields

- **seq** (`uint16_t`): Sequence

### MISSION_ACK (msg id 47, dialect common)
Acknowledgment message during waypoint handling. The type field states if this message is a positive ack (type=0) or if an error happened (type=non-zero). ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **type** (`uint8_t`): Mission result. - **mission_type** (`uint8_t`): Mission type. - **opaque_id** (`uint32_t`): Id of new on-vehicle mission, fence, or rally point plan (on upload to vehicle). The id is calculated and returned by a vehicle when a new plan is uploaded by a GCS. The only requirement on the id is that it must change when there is any change to the on-vehicle plan type (there is no requirement that the id be globally unique). 0 on download from the vehicle to the GCS (on download the ID is set in MISSION_COUNT). 0 if plan ids are not supported. The current on-vehicle plan ids are streamed in `MISSION_CURRENT`, allowing a GCS to determine if any part of the plan has changed and needs to be re-uploaded.

--- chunk_id: chunk-0046
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 290
content_hash: 74fa9c36a606c4d2
prev_chunk_id: chunk-0045
next_chunk_id: chunk-0047
section_heading: SET_GPS_GLOBAL_ORIGIN (msg id 48, dialect common)
document_type: technical_reference

## SET_GPS_GLOBAL_ORIGIN (msg id 48, dialect common)

Sets the GPS coordinates of the vehicle local origin (0,0,0) position. Vehicle should emit GPS_GLOBAL_ORIGIN irrespective of whether the origin is changed. This enables transform between the local coordinate frame and the global (GPS) coordinate frame, which may be necessary when (for example) indoor and outdoor settings are connected and the MAV should move from in- to outdoor. ### Fields

- **target_system** (`uint8_t`): System ID
- **latitude** (`int32_t`, degE7): Latitude (WGS84)
- **longitude** (`int32_t`, degE7): Longitude (WGS84)
- **altitude** (`int32_t`, mm): Altitude (MSL). Positive for up. - **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. ### GPS_GLOBAL_ORIGIN (msg id 49, dialect common)
Publishes the GPS coordinates of the vehicle local origin (0,0,0) position. Emitted whenever a new GPS-Local position mapping is requested or set - e.g. following SET_GPS_GLOBAL_ORIGIN message. ### Fields

- **latitude** (`int32_t`, degE7): Latitude (WGS84)
- **longitude** (`int32_t`, degE7): Longitude (WGS84)
- **altitude** (`int32_t`, mm): Altitude (MSL). Positive for up. - **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.

--- chunk_id: chunk-0047
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 265
content_hash: 96476ba5d4680b4c
prev_chunk_id: chunk-0046
next_chunk_id: chunk-0048
section_heading: PARAM_MAP_RC (msg id 50, dialect common)
document_type: technical_reference

## PARAM_MAP_RC (msg id 50, dialect common)

Bind a RC channel to a parameter. The parameter should change according to the RC channel value. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **param_id** (`char[16]`): Onboard parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_index** (`int16_t`): Parameter index. Send -1 to use the param ID field as identifier (else the param id will be ignored), send -2 to disable any existing map for this rc_channel_index. - **parameter_rc_channel_index** (`uint8_t`): Index of parameter RC channel. Not equal to the RC channel id. Typically corresponds to a potentiometer-knob on the RC. - **param_value0** (`float`): Initial parameter value
- **scale** (`float`): Scale, maps the RC range [-1, 1] to a parameter value
- **param_value_min** (`float`): Minimum param value. The protocol does not define if this overwrites an onboard minimum value. (Depends on implementation)
- **param_value_max** (`float`): Maximum param value. The protocol does not define if this overwrites an onboard maximum value. (Depends on implementation)

--- chunk_id: chunk-0048
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 261
content_hash: ced5720cc3b4a6b8
prev_chunk_id: chunk-0047
next_chunk_id: chunk-0049
section_heading: MISSION_REQUEST_INT (msg id 51, dialect common)
document_type: technical_reference

## MISSION_REQUEST_INT (msg id 51, dialect common)

Request the information of the mission item with the sequence number seq. The response of the system to this message should be a MISSION_ITEM_INT message. https://mavlink.io/en/services/mission.html

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **seq** (`uint16_t`): Sequence
- **mission_type** (`uint8_t`): Mission type. ### SAFETY_SET_ALLOWED_AREA (msg id 54, dialect common)
Set a safety zone (volume), which is defined by two corners of a cube. This message can be used to tell the MAV which setpoints/waypoints to accept and which to reject. Safety areas are often enforced by national or competition regulations. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **frame** (`uint8_t`): Coordinate frame. Can be either global, GPS, right-handed with Z axis up or local, right handed, Z axis down. - **p1x** (`float`, m): x position 1 / Latitude 1
- **p1y** (`float`, m): y position 1 / Longitude 1
- **p1z** (`float`, m): z position 1 / Altitude 1
- **p2x** (`float`, m): x position 2 / Latitude 2
- **p2y** (`float`, m): y position 2 / Longitude 2
- **p2z** (`float`, m): z position 2 / Altitude 2

--- chunk_id: chunk-0049
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 337
content_hash: 48db83d762843063
prev_chunk_id: chunk-0048
next_chunk_id: chunk-0050
section_heading: SAFETY_ALLOWED_AREA (msg id 55, dialect common)
document_type: technical_reference

## SAFETY_ALLOWED_AREA (msg id 55, dialect common)

Read out the safety zone the MAV currently assumes. ### Fields

- **frame** (`uint8_t`): Coordinate frame. Can be either global, GPS, right-handed with Z axis up or local, right handed, Z axis down. - **p1x** (`float`, m): x position 1 / Latitude 1
- **p1y** (`float`, m): y position 1 / Longitude 1
- **p1z** (`float`, m): z position 1 / Altitude 1
- **p2x** (`float`, m): x position 2 / Latitude 2
- **p2y** (`float`, m): y position 2 / Longitude 2
- **p2z** (`float`, m): z position 2 / Altitude 2

### ATTITUDE_QUATERNION_COV (msg id 61, dialect common)
The attitude in the aeronautical frame (right-handed, Z-down, X-front, Y-right), expressed as quaternion. Quaternion order is w, x, y, z and a zero rotation would be expressed as (1 0 0 0). ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **q** (`float[4]`): Quaternion components, w, x, y, z (1 0 0 0 is the null-rotation)
- **rollspeed** (`float`, rad/s): Roll angular speed
- **pitchspeed** (`float`, rad/s): Pitch angular speed
- **yawspeed** (`float`, rad/s): Yaw angular speed
- **covariance** (`float[9]`): Row-major representation of a 3x3 attitude covariance matrix (states: roll, pitch, yaw; first three entries are the first ROW, next three entries are the second row, etc.). If unknown, assign NaN value to first element in the array.

--- chunk_id: chunk-0050
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 386
content_hash: b8990efd22694bfb
prev_chunk_id: chunk-0049
next_chunk_id: chunk-0051
section_heading: NAV_CONTROLLER_OUTPUT (msg id 62, dialect common)
document_type: technical_reference

## NAV_CONTROLLER_OUTPUT (msg id 62, dialect common)

The state of the navigation and position controller. ### Fields

- **nav_roll** (`float`, deg): Current desired roll
- **nav_pitch** (`float`, deg): Current desired pitch
- **nav_bearing** (`int16_t`, deg): Current desired heading
- **target_bearing** (`int16_t`, deg): Bearing to current waypoint/target
- **wp_dist** (`uint16_t`, m): Distance to active waypoint
- **alt_error** (`float`, m): Current altitude error
- **aspd_error** (`float`, m/s): Current airspeed error
- **xtrack_error** (`float`, m): Current crosstrack error on x-y plane

### GLOBAL_POSITION_INT_COV (msg id 63, dialect common)
The filtered global position (e.g. fused GPS and accelerometers). The position is in GPS-frame (right-handed, Z-up). It  is designed as scaled integer message since the resolution of float is not sufficient. NOTE: This message is intended for onboard networks / companion computers and higher-bandwidth links and optimized for accuracy and completeness. Please use the GLOBAL_POSITION_INT message for a minimal subset. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **estimator_type** (`uint8_t`): Class id of the estimator this estimate originated from. - **lat** (`int32_t`, degE7): Latitude
- **lon** (`int32_t`, degE7): Longitude
- **alt** (`int32_t`, mm): Altitude in meters above MSL
- **relative_alt** (`int32_t`, mm): Altitude above ground
- **vx** (`float`, m/s): Ground X Speed (Latitude)
- **vy** (`float`, m/s): Ground Y Speed (Longitude)
- **vz** (`float`, m/s): Ground Z Speed (Altitude)
- **covariance** (`float[36]`): Row-major representation of a 6x6 position and velocity 6x6 cross-covariance matrix (states: lat, lon, alt, vx, vy, vz; first six entries are the first ROW, next six entries are the second row, etc.). If unknown, assign NaN value to first element in the array.

--- chunk_id: chunk-0051
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: 8f2df6675978ad40
prev_chunk_id: chunk-0050
next_chunk_id: chunk-0052
section_heading: LOCAL_POSITION_NED_COV (msg id 64, dialect common)
document_type: technical_reference

## LOCAL_POSITION_NED_COV (msg id 64, dialect common)

The filtered local position (e.g. fused computer vision and accelerometers). Coordinate frame is right-handed, Z-axis down (aeronautical frame, NED / north-east-down convention)

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **estimator_type** (`uint8_t`): Class id of the estimator this estimate originated from. - **x** (`float`, m): X Position
- **y** (`float`, m): Y Position
- **z** (`float`, m): Z Position
- **vx** (`float`, m/s): X Speed
- **vy** (`float`, m/s): Y Speed
- **vz** (`float`, m/s): Z Speed
- **ax** (`float`, m/s/s): X Acceleration
- **ay** (`float`, m/s/s): Y Acceleration
- **az** (`float`, m/s/s): Z Acceleration
- **covariance** (`float[45]`): Row-major representation of position, velocity and acceleration 9x9 cross-covariance matrix upper right triangle (states: x, y, z, vx, vy, vz, ax, ay, az; first nine entries are the first ROW, next eight entries are the second row, etc.). If unknown, assign NaN value to first element in the array.

--- chunk_id: chunk-0052
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 334
content_hash: 3303e2db8e8db72d
prev_chunk_id: chunk-0051
next_chunk_id: chunk-0053
section_heading: RC_CHANNELS (msg id 65, dialect common)
document_type: technical_reference

## RC_CHANNELS (msg id 65, dialect common)

The PPM values of the RC channels received. The standard PPM modulation is as follows: 1000 microseconds: 0%, 2000 microseconds: 100%. A value of UINT16_MAX implies the channel is unused. Individual receivers/transmitters might violate this specification. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **chancount** (`uint8_t`): Total number of RC channels being received. This can be larger than 18, indicating that more channels are available but not given in this message. This value should be 0 when no RC channels are available. - **chan1_raw** (`uint16_t`, us): RC channel 1 value. - **chan2_raw** (`uint16_t`, us): RC channel 2 value. - **chan3_raw** (`uint16_t`, us): RC channel 3 value. - **chan4_raw** (`uint16_t`, us): RC channel 4 value. - **chan5_raw** (`uint16_t`, us): RC channel 5 value. - **chan6_raw** (`uint16_t`, us): RC channel 6 value. - **chan7_raw** (`uint16_t`, us): RC channel 7 value. - **chan8_raw** (`uint16_t`, us): RC channel 8 value. - **chan9_raw** (`uint16_t`, us): RC channel 9 value. - **chan10_raw** (`uint16_t`, us): RC channel 10 value. - **chan11_raw** (`uint16_t`, us): RC channel 11 value. - **chan12_raw** (`uint16_t`, us): RC channel 12 value. - **chan13_raw** (`uint16_t`, us): RC channel 13 value. - **chan14_raw** (`uint16_t`, us): RC channel 14 value. - **chan15_raw** (`uint16_t`, us): RC channel 15 value. - **chan16_raw** (`uint16_t`, us): RC channel 16 value. - **chan17_raw** (`uint16_t`, us): RC channel 17 value. - **chan18_raw** (`uint16_t`, us): RC channel 18 value. - **rssi** (`uint8_t`): Receive signal strength indicator in device-dependent units/scale. Values: [0-254], UINT8_MAX: invalid/unknown.

--- chunk_id: chunk-0053
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: bf4af944075c896d
prev_chunk_id: chunk-0052
next_chunk_id: chunk-0054
section_heading: REQUEST_DATA_STREAM (msg id 66, dialect common)
document_type: technical_reference

## REQUEST_DATA_STREAM (msg id 66, dialect common)

Request a data stream. ### Fields

- **target_system** (`uint8_t`): The target requested to send the message stream. - **target_component** (`uint8_t`): The target requested to send the message stream. - **req_stream_id** (`uint8_t`): The ID of the requested data stream. - **req_message_rate** (`uint16_t`, Hz): The requested message rate
- **start_stop** (`uint8_t`): 1 to start sending, 0 to stop sending. ### DATA_STREAM (msg id 67, dialect common)
Data stream status information. ### Fields

- **stream_id** (`uint8_t`): The ID of the requested data stream. - **message_rate** (`uint16_t`, Hz): The message rate
- **on_off** (`uint8_t`): 1 stream is enabled, 0 stream is stopped. ### MANUAL_CONTROL (msg id 69, dialect common)
Manual (joystick) control message. This message represents movement axes and button using standard joystick axes nomenclature. Unused axes can be disabled and buttons states are transmitted as individual on/off bits of a bitmask. For more information see https://mavlink.io/en/services/manual_control.html

### Fields

- **target** (`uint8_t`): The system to be controlled. - **x** (`int16_t`): X-axis, normalized to the range [-1000,1000]. A value of INT16_MAX indicates that this axis is invalid. Generally corresponds to forward(1000)-backward(-1000) movement on a joystick and the pitch of a vehicle. - **y** (`int16_t`): Y-axis, normalized to the range [-1000,1000]. A value of INT16_MAX indicates that this axis is invalid. Generally corresponds to left(-1000)-right(1000) movement on a joystick and the roll of a vehicle. - **z** (`int16_t`): Z-axis, normalized to the range [-1000,1000]. A value of INT16_MAX indicates that this axis is invalid. Generally corresponds to a separate slider movement with maximum being 1000 and minimum being -1000 on a joystick and the thrust of a vehicle. Positive values are positive thrust, negative values are negative thrust. - **r** (`int16_t`): R-axis, normalized to the range [-1000,1000]. A value of INT16_MAX indicates that this axis is invalid. Generally corresponds to a twisting of the joystick, with clockwise being 1000 and counter-clockwise being -1000, and the yaw of a vehicle. - **buttons** (`uint16_t`): A bitfield corresponding to the joystick buttons' 0-15 current state, 1 for pressed, 0 for released. The lowest bit corresponds to Button 1. - **buttons2** (`uint16_t`): A bitfield corresponding to the joystick buttons' 16-31 current state, 1 for pressed, 0 for released. The lowest bit corresponds to Button 16.

--- chunk_id: chunk-0054
source_document: messages_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 445
content_hash: 6e58e024cd8ad21a
prev_chunk_id: chunk-0053
next_chunk_id: chunk-0055
section_heading: REQUEST_DATA_STREAM (msg id 66, dialect common)
document_type: technical_reference

- **buttons2** (`uint16_t`): A bitfield corresponding to the joystick buttons' 16-31 current state, 1 for pressed, 0 for released. The lowest bit corresponds to Button 16. - **enabled_extensions** (`uint8_t`): Set bits to 1 to indicate which of the following extension fields contain valid data: bit 0: pitch, bit 1: roll, bit 2: aux1, bit 3: aux2, bit 4: aux3, bit 5: aux4, bit 6: aux5, bit 7: aux6
- **s** (`int16_t`): Pitch-only-axis, normalized to the range [-1000,1000]. Generally corresponds to pitch on vehicles with additional degrees of freedom. Valid if bit 0 of enabled_extensions field is set. Set to 0 if invalid. - **t** (`int16_t`): Roll-only-axis, normalized to the range [-1000,1000]. Generally corresponds to roll on vehicles with additional degrees of freedom. Valid if bit 1 of enabled_extensions field is set. Set to 0 if invalid. - **aux1** (`int16_t`): Aux continuous input field 1. Normalized in the range [-1000,1000]. Purpose defined by recipient. Valid data if bit 2 of enabled_extensions field is set. 0 if bit 2 is unset. - **aux2** (`int16_t`): Aux continuous input field 2. Normalized in the range [-1000,1000]. Purpose defined by recipient. Valid data if bit 3 of enabled_extensions field is set. 0 if bit 3 is unset. - **aux3** (`int16_t`): Aux continuous input field 3. Normalized in the range [-1000,1000]. Purpose defined by recipient. Valid data if bit 4 of enabled_extensions field is set. 0 if bit 4 is unset. - **aux4** (`int16_t`): Aux continuous input field 4. Normalized in the range [-1000,1000]. Purpose defined by recipient. Valid data if bit 5 of enabled_extensions field is set. 0 if bit 5 is unset. - **aux5** (`int16_t`): Aux continuous input field 5. Normalized in the range [-1000,1000]. Purpose defined by recipient. Valid data if bit 6 of enabled_extensions field is set. 0 if bit 6 is unset. - **aux6** (`int16_t`): Aux continuous input field 6. Normalized in the range [-1000,1000]. Purpose defined by recipient. Valid data if bit 7 of enabled_extensions field is set. 0 if bit 7 is unset.

--- chunk_id: chunk-0055
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: 772bb1064689faae
prev_chunk_id: chunk-0054
next_chunk_id: chunk-0056
section_heading: MAVLink messages batch 3
document_type: technical_reference

# MAVLink messages batch 3

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0056
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 524
content_hash: 751135caf62115e8
prev_chunk_id: chunk-0055
next_chunk_id: chunk-0057
section_heading: RC_CHANNELS_OVERRIDE (msg id 70, dialect common)
document_type: technical_reference

## RC_CHANNELS_OVERRIDE (msg id 70, dialect common)

The RAW values of the RC channels sent to the MAV to override info received from the RC radio. The standard PPM modulation is as follows: 1000 microseconds: 0%, 2000 microseconds: 100%. Individual receivers/transmitters might violate this specification. Note carefully the semantic differences between the first 8 channels and the subsequent channels

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **chan1_raw** (`uint16_t`, us): RC channel 1 value. A value of UINT16_MAX means to ignore this field. A value of 0 means to release this channel back to the RC radio. - **chan2_raw** (`uint16_t`, us): RC channel 2 value. A value of UINT16_MAX means to ignore this field. A value of 0 means to release this channel back to the RC radio. - **chan3_raw** (`uint16_t`, us): RC channel 3 value. A value of UINT16_MAX means to ignore this field. A value of 0 means to release this channel back to the RC radio. - **chan4_raw** (`uint16_t`, us): RC channel 4 value. A value of UINT16_MAX means to ignore this field. A value of 0 means to release this channel back to the RC radio. - **chan5_raw** (`uint16_t`, us): RC channel 5 value. A value of UINT16_MAX means to ignore this field. A value of 0 means to release this channel back to the RC radio. - **chan6_raw** (`uint16_t`, us): RC channel 6 value. A value of UINT16_MAX means to ignore this field. A value of 0 means to release this channel back to the RC radio. - **chan7_raw** (`uint16_t`, us): RC channel 7 value. A value of UINT16_MAX means to ignore this field. A value of 0 means to release this channel back to the RC radio. - **chan8_raw** (`uint16_t`, us): RC channel 8 value. A value of UINT16_MAX means to ignore this field. A value of 0 means to release this channel back to the RC radio. - **chan9_raw** (`uint16_t`, us): RC channel 9 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan10_raw** (`uint16_t`, us): RC channel 10 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan11_raw** (`uint16_t`, us): RC channel 11 value.

--- chunk_id: chunk-0057
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 370
content_hash: 03f36ce05829082a
prev_chunk_id: chunk-0056
next_chunk_id: chunk-0058
section_heading: RC_CHANNELS_OVERRIDE (msg id 70, dialect common)
document_type: technical_reference

A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan11_raw** (`uint16_t`, us): RC channel 11 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan12_raw** (`uint16_t`, us): RC channel 12 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan13_raw** (`uint16_t`, us): RC channel 13 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan14_raw** (`uint16_t`, us): RC channel 14 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan15_raw** (`uint16_t`, us): RC channel 15 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan16_raw** (`uint16_t`, us): RC channel 16 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan17_raw** (`uint16_t`, us): RC channel 17 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio. - **chan18_raw** (`uint16_t`, us): RC channel 18 value. A value of 0 or UINT16_MAX means to ignore this field. A value of UINT16_MAX-1 means to release this channel back to the RC radio.

--- chunk_id: chunk-0058
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 342
content_hash: 09ed96f905a78410
prev_chunk_id: chunk-0057
next_chunk_id: chunk-0059
section_heading: MISSION_ITEM_INT (msg id 73, dialect common)
document_type: technical_reference

## MISSION_ITEM_INT (msg id 73, dialect common)

Message encoding a mission item. This message is emitted to announce
                the presence of a mission item and to set a mission item on the system. The mission item can be either in x, y, z meters (type: LOCAL) or x:lat, y:lon, z:altitude. Local frame is Z-down, right handed (NED), global frame is Z-up, right handed (ENU). NaN or INT32_MAX may be used in float/integer params (respectively) to indicate optional/default values (e.g. to use the component's current latitude, yaw rather than a specific value). See also https://mavlink.io/en/services/mission.html. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **seq** (`uint16_t`): Waypoint ID (sequence number). Starts at zero. Increases monotonically for each waypoint, no gaps in the sequence (0,1,2,3,4). - **frame** (`uint8_t`): The coordinate system of the waypoint. - **command** (`uint16_t`): The scheduled action for the waypoint. - **current** (`uint8_t`): false:0, true:1
- **autocontinue** (`uint8_t`): Autocontinue to next waypoint. 0: false, 1: true. Set false to pause mission after the item completes. - **param1** (`float`): PARAM1, see MAV_CMD enum
- **param2** (`float`): PARAM2, see MAV_CMD enum
- **param3** (`float`): PARAM3, see MAV_CMD enum
- **param4** (`float`): PARAM4, see MAV_CMD enum
- **x** (`int32_t`): PARAM5 / local: x position in meters * 1e4, global: latitude in degrees * 10^7
- **y** (`int32_t`): PARAM6 / y position: local: x position in meters * 1e4, global: longitude in degrees *10^7
- **z** (`float`): PARAM7 / z position: global: altitude in meters (relative or absolute, depending on frame. - **mission_type** (`uint8_t`): Mission type.

--- chunk_id: chunk-0059
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 465
content_hash: fd5d73ddb59d6c0e
prev_chunk_id: chunk-0058
next_chunk_id: chunk-0060
section_heading: VFR_HUD (msg id 74, dialect common)
document_type: technical_reference

## VFR_HUD (msg id 74, dialect common)

Metrics typically displayed on a HUD for fixed wing aircraft. ### Fields

- **airspeed** (`float`, m/s): Vehicle speed in form appropriate for vehicle type. For standard aircraft this is typically calibrated airspeed (CAS) or indicated airspeed (IAS) - either of which can be used by a pilot to estimate stall speed. - **groundspeed** (`float`, m/s): Current ground speed. - **heading** (`int16_t`, deg): Current heading in compass units (0-360, 0=north). - **throttle** (`uint16_t`, %): Current throttle setting (0 to 100). - **alt** (`float`, m): Current altitude (MSL). - **climb** (`float`, m/s): Current climb rate. ### COMMAND_INT (msg id 75, dialect common)
Send a command with up to seven parameters to the MAV, where params 5 and 6 are integers and the other values are floats. This is preferred over COMMAND_LONG as it allows the MAV_FRAME to be specified for interpreting positional information, such as altitude. COMMAND_INT is also preferred when sending latitude and longitude data in params 5 and 6, as it allows for greater precision. Param 5 and 6 encode positional data as scaled integers, where the scaling depends on the actual command value. NaN or INT32_MAX may be used in float/integer params (respectively) to indicate optional/default values (e.g. to use the component's current latitude, yaw rather than a specific value). The command microservice is documented at https://mavlink.io/en/services/command.html

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **frame** (`uint8_t`): The coordinate system of the COMMAND. - **command** (`uint16_t`): The scheduled action for the mission item. - **current** (`uint8_t`): Not used. - **autocontinue** (`uint8_t`): Not used (set 0). - **param1** (`float`): PARAM1, see MAV_CMD enum
- **param2** (`float`): PARAM2, see MAV_CMD enum
- **param3** (`float`): PARAM3, see MAV_CMD enum
- **param4** (`float`): PARAM4, see MAV_CMD enum
- **x** (`int32_t`): PARAM5 / local: x position in meters * 1e4, global: latitude in degrees * 10^7
- **y** (`int32_t`): PARAM6 / local: y position in meters * 1e4, global: longitude in degrees * 10^7
- **z** (`float`): PARAM7 / z position: global: altitude in meters (relative or absolute, depending on frame).

--- chunk_id: chunk-0060
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 224
content_hash: b459c970df500502
prev_chunk_id: chunk-0059
next_chunk_id: chunk-0061
section_heading: COMMAND_LONG (msg id 76, dialect common)
document_type: technical_reference

## COMMAND_LONG (msg id 76, dialect common)

Send a command with up to seven parameters to the MAV. COMMAND_INT is generally preferred when sending MAV_CMD commands that include positional information; it offers higher precision and allows the MAV_FRAME to be specified (which may otherwise be ambiguous, particularly for altitude). The command microservice is documented at https://mavlink.io/en/services/command.html

### Fields

- **target_system** (`uint8_t`): System which should execute the command
- **target_component** (`uint8_t`): Component which should execute the command, 0 for all components
- **command** (`uint16_t`): Command ID (of command to send). - **confirmation** (`uint8_t`): 0: First transmission of this command. 1-255: Confirmation transmissions (e.g. for kill command)
- **param1** (`float`): Parameter 1 (for the specific command). - **param2** (`float`): Parameter 2 (for the specific command). - **param3** (`float`): Parameter 3 (for the specific command). - **param4** (`float`): Parameter 4 (for the specific command). - **param5** (`float`): Parameter 5 (for the specific command). - **param6** (`float`): Parameter 6 (for the specific command). - **param7** (`float`): Parameter 7 (for the specific command).

--- chunk_id: chunk-0061
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: 11b4037c2deefa47
prev_chunk_id: chunk-0060
next_chunk_id: chunk-0062
section_heading: COMMAND_ACK (msg id 77, dialect common)
document_type: technical_reference

## COMMAND_ACK (msg id 77, dialect common)

Report status of a command. Includes feedback whether the command was executed. The command microservice is documented at https://mavlink.io/en/services/command.html

### Fields

- **command** (`uint16_t`): Command ID (of acknowledged command). - **result** (`uint8_t`): Result of command. - **progress** (`uint8_t`, %): The progress percentage when result is MAV_RESULT_IN_PROGRESS. Values: [0-100], or UINT8_MAX if the progress is unknown. - **result_param2** (`int32_t`): Additional result information. Can be set with a command-specific enum containing command-specific error reasons for why the command might be denied. If used, the associated enum must be documented in the corresponding MAV_CMD (this enum should have a 0 value to indicate "unused" or "unknown"). - **target_system** (`uint8_t`): System ID of the target recipient. This is the ID of the system that sent the command for which this COMMAND_ACK is an acknowledgement. - **target_component** (`uint8_t`): Component ID of the target recipient. This is the ID of the system that sent the command for which this COMMAND_ACK is an acknowledgement.

--- chunk_id: chunk-0062
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 237
content_hash: b3ae01b708be7a63
prev_chunk_id: chunk-0061
next_chunk_id: chunk-0063
section_heading: COMMAND_CANCEL (msg id 80, dialect common)
document_type: technical_reference

## COMMAND_CANCEL (msg id 80, dialect common)

Cancel a long running command. The target system should respond with a COMMAND_ACK to the original command with result=MAV_RESULT_CANCELLED if the long running process was cancelled. If it has already completed, the cancel action can be ignored. The cancel action can be retried until some sort of acknowledgement to the original command has been received. The command microservice is documented at https://mavlink.io/en/services/command.html

### Fields

- **target_system** (`uint8_t`): System executing long running command. Should not be broadcast (0). - **target_component** (`uint8_t`): Component executing long running command. - **command** (`uint16_t`): Command ID (of command to cancel). ### MANUAL_SETPOINT (msg id 81, dialect common)
Setpoint in roll, pitch, yaw and thrust from the operator

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **roll** (`float`, rad/s): Desired roll rate
- **pitch** (`float`, rad/s): Desired pitch rate
- **yaw** (`float`, rad/s): Desired yaw rate
- **thrust** (`float`): Collective thrust, normalized to 0 .. 1
- **mode_switch** (`uint8_t`): Flight mode switch position, 0.. 255
- **manual_override_switch** (`uint8_t`): Override mode switch position, 0.. 255

--- chunk_id: chunk-0063
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 182
content_hash: 5fb554f934e47152
prev_chunk_id: chunk-0062
next_chunk_id: chunk-0064
section_heading: SET_ATTITUDE_TARGET (msg id 82, dialect common)
document_type: technical_reference

## SET_ATTITUDE_TARGET (msg id 82, dialect common)

Sets a desired vehicle attitude. Used by an external controller to command the vehicle (manual controller or other system). ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **type_mask** (`uint8_t`): Bitmap to indicate which dimensions should be ignored by the vehicle. - **q** (`float[4]`): Attitude quaternion (w, x, y, z order, zero-rotation is 1, 0, 0, 0) from MAV_FRAME_LOCAL_NED to MAV_FRAME_BODY_FRD
- **body_roll_rate** (`float`, rad/s): Body roll rate
- **body_pitch_rate** (`float`, rad/s): Body pitch rate
- **body_yaw_rate** (`float`, rad/s): Body yaw rate
- **thrust** (`float`): Collective thrust, normalized to 0 .. 1 (-1 .. 1 for vehicles capable of reverse thrust)
- **thrust_body** (`float[3]`): 3D thrust setpoint in the body NED frame, normalized to -1 .. 1

--- chunk_id: chunk-0064
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 465
content_hash: a312edb551412f20
prev_chunk_id: chunk-0063
next_chunk_id: chunk-0065
section_heading: ATTITUDE_TARGET (msg id 83, dialect common)
document_type: technical_reference

## ATTITUDE_TARGET (msg id 83, dialect common)

Reports the current commanded attitude of the vehicle as specified by the autopilot. This should match the commands sent in a SET_ATTITUDE_TARGET message if the vehicle is being controlled this way. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **type_mask** (`uint8_t`): Bitmap to indicate which dimensions should be ignored by the vehicle. - **q** (`float[4]`): Attitude quaternion (w, x, y, z order, zero-rotation is 1, 0, 0, 0)
- **body_roll_rate** (`float`, rad/s): Body roll rate
- **body_pitch_rate** (`float`, rad/s): Body pitch rate
- **body_yaw_rate** (`float`, rad/s): Body yaw rate
- **thrust** (`float`): Collective thrust, normalized to 0 .. 1 (-1 .. 1 for vehicles capable of reverse thrust)

### SET_POSITION_TARGET_LOCAL_NED (msg id 84, dialect common)
Sets a desired vehicle position in a local north-east-down coordinate frame. Used by an external controller to command the vehicle (manual controller or other system). ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **coordinate_frame** (`uint8_t`): Valid options are: MAV_FRAME_LOCAL_NED = 1, MAV_FRAME_LOCAL_OFFSET_NED = 7, MAV_FRAME_BODY_NED = 8, MAV_FRAME_BODY_OFFSET_NED = 9
- **type_mask** (`uint16_t`): Bitmap to indicate which dimensions should be ignored by the vehicle. - **x** (`float`, m): X Position in NED frame
- **y** (`float`, m): Y Position in NED frame
- **z** (`float`, m): Z Position in NED frame (note, altitude is negative in NED)
- **vx** (`float`, m/s): X velocity in NED frame
- **vy** (`float`, m/s): Y velocity in NED frame
- **vz** (`float`, m/s): Z velocity in NED frame
- **afx** (`float`, m/s/s): X acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **afy** (`float`, m/s/s): Y acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **afz** (`float`, m/s/s): Z acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **yaw** (`float`, rad): yaw setpoint
- **yaw_rate** (`float`, rad/s): yaw rate setpoint

--- chunk_id: chunk-0065
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 300
content_hash: 7cef6f2d911b04af
prev_chunk_id: chunk-0064
next_chunk_id: chunk-0066
section_heading: POSITION_TARGET_LOCAL_NED (msg id 85, dialect common)
document_type: technical_reference

## POSITION_TARGET_LOCAL_NED (msg id 85, dialect common)

Reports the current commanded vehicle position, velocity, and acceleration as specified by the autopilot. This should match the commands sent in SET_POSITION_TARGET_LOCAL_NED if the vehicle is being controlled this way. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **coordinate_frame** (`uint8_t`): Valid options are: MAV_FRAME_LOCAL_NED = 1, MAV_FRAME_LOCAL_OFFSET_NED = 7, MAV_FRAME_BODY_NED = 8, MAV_FRAME_BODY_OFFSET_NED = 9
- **type_mask** (`uint16_t`): Bitmap to indicate which dimensions should be ignored by the vehicle. - **x** (`float`, m): X Position in NED frame
- **y** (`float`, m): Y Position in NED frame
- **z** (`float`, m): Z Position in NED frame (note, altitude is negative in NED)
- **vx** (`float`, m/s): X velocity in NED frame
- **vy** (`float`, m/s): Y velocity in NED frame
- **vz** (`float`, m/s): Z velocity in NED frame
- **afx** (`float`, m/s/s): X acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **afy** (`float`, m/s/s): Y acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **afz** (`float`, m/s/s): Z acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **yaw** (`float`, rad): yaw setpoint
- **yaw_rate** (`float`, rad/s): yaw rate setpoint

--- chunk_id: chunk-0066
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 357
content_hash: bf20d126072ee2d4
prev_chunk_id: chunk-0065
next_chunk_id: chunk-0067
section_heading: SET_POSITION_TARGET_GLOBAL_INT (msg id 86, dialect common)
document_type: technical_reference

## SET_POSITION_TARGET_GLOBAL_INT (msg id 86, dialect common)

Sets a desired vehicle position, velocity, and/or acceleration in a global coordinate system (WGS84). Used by an external controller to command the vehicle (manual controller or other system). ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). The rationale for the timestamp in the setpoint is to allow the system to compensate for the transport delay of the setpoint. This allows the system to compensate processing latency. - **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **coordinate_frame** (`uint8_t`): Valid options are: MAV_FRAME_GLOBAL = 0, MAV_FRAME_GLOBAL_RELATIVE_ALT = 3, MAV_FRAME_GLOBAL_TERRAIN_ALT = 10 (MAV_FRAME_GLOBAL_INT, MAV_FRAME_GLOBAL_RELATIVE_ALT_INT, MAV_FRAME_GLOBAL_TERRAIN_ALT_INT are allowed synonyms, but have been deprecated)
- **type_mask** (`uint16_t`): Bitmap to indicate which dimensions should be ignored by the vehicle. - **lat_int** (`int32_t`, degE7): Latitude in WGS84 frame
- **lon_int** (`int32_t`, degE7): Longitude in WGS84 frame
- **alt** (`float`, m): Altitude (MSL, Relative to home, or AGL - depending on frame)
- **vx** (`float`, m/s): X velocity in NED frame
- **vy** (`float`, m/s): Y velocity in NED frame
- **vz** (`float`, m/s): Z velocity in NED frame
- **afx** (`float`, m/s/s): X acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **afy** (`float`, m/s/s): Y acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **afz** (`float`, m/s/s): Z acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **yaw** (`float`, rad): yaw setpoint
- **yaw_rate** (`float`, rad/s): yaw rate setpoint

--- chunk_id: chunk-0067
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: 06c26cd25328a609
prev_chunk_id: chunk-0066
next_chunk_id: chunk-0068
section_heading: POSITION_TARGET_GLOBAL_INT (msg id 87, dialect common)
document_type: technical_reference

## POSITION_TARGET_GLOBAL_INT (msg id 87, dialect common)

Reports the current commanded vehicle position, velocity, and acceleration as specified by the autopilot. This should match the commands sent in SET_POSITION_TARGET_GLOBAL_INT if the vehicle is being controlled this way. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). The rationale for the timestamp in the setpoint is to allow the system to compensate for the transport delay of the setpoint. This allows the system to compensate processing latency. - **coordinate_frame** (`uint8_t`): Valid options are: MAV_FRAME_GLOBAL = 0, MAV_FRAME_GLOBAL_RELATIVE_ALT = 3, MAV_FRAME_GLOBAL_TERRAIN_ALT = 10 (MAV_FRAME_GLOBAL_INT, MAV_FRAME_GLOBAL_RELATIVE_ALT_INT, MAV_FRAME_GLOBAL_TERRAIN_ALT_INT are allowed synonyms, but have been deprecated)
- **type_mask** (`uint16_t`): Bitmap to indicate which dimensions should be ignored by the vehicle. - **lat_int** (`int32_t`, degE7): Latitude in WGS84 frame
- **lon_int** (`int32_t`, degE7): Longitude in WGS84 frame
- **alt** (`float`, m): Altitude (MSL, AGL or relative to home altitude, depending on frame)
- **vx** (`float`, m/s): X velocity in NED frame
- **vy** (`float`, m/s): Y velocity in NED frame
- **vz** (`float`, m/s): Z velocity in NED frame
- **afx** (`float`, m/s/s): X acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **afy** (`float`, m/s/s): Y acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **afz** (`float`, m/s/s): Z acceleration or force (if bit 10 of type_mask is set) in NED frame in meter / s^2 or N
- **yaw** (`float`, rad): yaw setpoint
- **yaw_rate** (`float`, rad/s): yaw rate setpoint

--- chunk_id: chunk-0068
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 342
content_hash: f5a0f6261497bd03
prev_chunk_id: chunk-0067
next_chunk_id: chunk-0069
section_heading: LOCAL_POSITION_NED_SYSTEM_GLOBAL_OFFSET (msg id 89, dialect common)
document_type: technical_reference

## LOCAL_POSITION_NED_SYSTEM_GLOBAL_OFFSET (msg id 89, dialect common)

The offset in X, Y, Z and yaw between the LOCAL_POSITION_NED messages of MAV X and the global coordinate frame in NED coordinates. Coordinate frame is right-handed, Z-axis down (aeronautical frame, NED / north-east-down convention)

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **x** (`float`, m): X Position
- **y** (`float`, m): Y Position
- **z** (`float`, m): Z Position
- **roll** (`float`, rad): Roll
- **pitch** (`float`, rad): Pitch
- **yaw** (`float`, rad): Yaw

### HIL_STATE (msg id 90, dialect common)
Sent from simulation to autopilot. This packet is useful for high throughput applications such as hardware in the loop simulations. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **roll** (`float`, rad): Roll angle
- **pitch** (`float`, rad): Pitch angle
- **yaw** (`float`, rad): Yaw angle
- **rollspeed** (`float`, rad/s): Body frame roll / phi angular speed
- **pitchspeed** (`float`, rad/s): Body frame pitch / theta angular speed
- **yawspeed** (`float`, rad/s): Body frame yaw / psi angular speed
- **lat** (`int32_t`, degE7): Latitude
- **lon** (`int32_t`, degE7): Longitude
- **alt** (`int32_t`, mm): Altitude
- **vx** (`int16_t`, cm/s): Ground X Speed (Latitude)
- **vy** (`int16_t`, cm/s): Ground Y Speed (Longitude)
- **vz** (`int16_t`, cm/s): Ground Z Speed (Altitude)
- **xacc** (`int16_t`, mG): X acceleration
- **yacc** (`int16_t`, mG): Y acceleration
- **zacc** (`int16_t`, mG): Z acceleration

--- chunk_id: chunk-0069
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 17747e85746c7e6a
prev_chunk_id: chunk-0068
next_chunk_id: chunk-0070
section_heading: HIL_CONTROLS (msg id 91, dialect common)
document_type: technical_reference

## HIL_CONTROLS (msg id 91, dialect common)

Sent from autopilot to simulation. Hardware in the loop control outputs. Alternative to HIL_ACTUATOR_CONTROLS. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **roll_ailerons** (`float`): Control output -1 .. 1
- **pitch_elevator** (`float`): Control output -1 .. 1
- **yaw_rudder** (`float`): Control output -1 .. 1
- **throttle** (`float`): Throttle 0 .. 1
- **aux1** (`float`): Aux 1, -1 .. 1
- **aux2** (`float`): Aux 2, -1 .. 1
- **aux3** (`float`): Aux 3, -1 .. 1
- **aux4** (`float`): Aux 4, -1 .. 1
- **mode** (`uint8_t`): System mode. - **nav_mode** (`uint8_t`): Navigation mode (MAV_NAV_MODE)

### HIL_RC_INPUTS_RAW (msg id 92, dialect common)
Sent from simulation to autopilot. The RAW values of the RC channels received. The standard PPM modulation is as follows: 1000 microseconds: 0%, 2000 microseconds: 100%. Individual receivers/transmitters might violate this specification. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **chan1_raw** (`uint16_t`, us): RC channel 1 value
- **chan2_raw** (`uint16_t`, us): RC channel 2 value
- **chan3_raw** (`uint16_t`, us): RC channel 3 value
- **chan4_raw** (`uint16_t`, us): RC channel 4 value
- **chan5_raw** (`uint16_t`, us): RC channel 5 value
- **chan6_raw** (`uint16_t`, us): RC channel 6 value
- **chan7_raw** (`uint16_t`, us): RC channel 7 value
- **chan8_raw** (`uint16_t`, us): RC channel 8 value
- **chan9_raw** (`uint16_t`, us): RC channel 9 value
- **chan10_raw** (`uint16_t`, us): RC channel 10 value
- **chan11_raw** (`uint16_t`, us): RC channel 11 value
- **chan12_raw** (`uint16_t`, us): RC channel 12 value
- **rssi** (`uint8_t`): Receive signal strength indicator in device-dependent units/scale. Values: [0-254], UINT8_MAX: invalid/unknown.

--- chunk_id: chunk-0070
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 298
content_hash: 321bad864be1b2b9
prev_chunk_id: chunk-0069
next_chunk_id: chunk-0071
section_heading: HIL_ACTUATOR_CONTROLS (msg id 93, dialect common)
document_type: technical_reference

## HIL_ACTUATOR_CONTROLS (msg id 93, dialect common)

Sent from autopilot to simulation. Hardware in the loop control outputs. Alternative to HIL_CONTROLS. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **controls** (`float[16]`): Control outputs -1 .. 1. Channel assignment depends on the simulated hardware. - **mode** (`uint8_t`): System mode. Includes arming state. - **flags** (`uint64_t`): Flags bitmask. ### OPTICAL_FLOW (msg id 100, dialect common)
Optical flow from a flow sensor (e.g. optical mouse sensor)

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **sensor_id** (`uint8_t`): Sensor ID
- **flow_x** (`int16_t`, dpix): Flow in x-sensor direction
- **flow_y** (`int16_t`, dpix): Flow in y-sensor direction
- **flow_comp_m_x** (`float`, m/s): Flow in x-sensor direction, angular-speed compensated
- **flow_comp_m_y** (`float`, m/s): Flow in y-sensor direction, angular-speed compensated
- **quality** (`uint8_t`): Optical flow quality / confidence. 0: bad, 255: maximum quality
- **ground_distance** (`float`, m): Ground distance. Positive value: distance known. Negative value: Unknown distance
- **flow_rate_x** (`float`, rad/s): Flow rate about X axis
- **flow_rate_y** (`float`, rad/s): Flow rate about Y axis

--- chunk_id: chunk-0071
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 206
content_hash: fc2a1ff096cbeab6
prev_chunk_id: chunk-0070
next_chunk_id: chunk-0072
section_heading: GLOBAL_VISION_POSITION_ESTIMATE (msg id 101, dialect common)
document_type: technical_reference

## GLOBAL_VISION_POSITION_ESTIMATE (msg id 101, dialect common)

Global position/attitude estimate from a vision source. ### Fields

- **usec** (`uint64_t`, us): Timestamp (UNIX time or since system boot)
- **x** (`float`, m): Global X position
- **y** (`float`, m): Global Y position
- **z** (`float`, m): Global Z position
- **roll** (`float`, rad): Roll angle
- **pitch** (`float`, rad): Pitch angle
- **yaw** (`float`, rad): Yaw angle
- **covariance** (`float[21]`): Row-major representation of pose 6x6 cross-covariance matrix upper right triangle (states: x_global, y_global, z_global, roll, pitch, yaw; first six entries are the first ROW, next five entries are the second ROW, etc.). If unknown, assign NaN value to first element in the array. - **reset_counter** (`uint8_t`): Estimate reset counter. This should be incremented when the estimate resets in any of the dimensions (position, velocity, attitude, angular speed). This is designed to be used when e.g an external SLAM system detects a loop-closure and the estimate jumps.

--- chunk_id: chunk-0072
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 208
content_hash: d464be9555bfc8ec
prev_chunk_id: chunk-0071
next_chunk_id: chunk-0073
section_heading: VISION_POSITION_ESTIMATE (msg id 102, dialect common)
document_type: technical_reference

## VISION_POSITION_ESTIMATE (msg id 102, dialect common)

Local position/attitude estimate from a vision source. ### Fields

- **usec** (`uint64_t`, us): Timestamp (UNIX time or time since system boot)
- **x** (`float`, m): Local X position
- **y** (`float`, m): Local Y position
- **z** (`float`, m): Local Z position
- **roll** (`float`, rad): Roll angle
- **pitch** (`float`, rad): Pitch angle
- **yaw** (`float`, rad): Yaw angle
- **covariance** (`float[21]`): Row-major representation of pose 6x6 cross-covariance matrix upper right triangle (states: x, y, z, roll, pitch, yaw; first six entries are the first ROW, next five entries are the second ROW, etc.). If unknown, assign NaN value to first element in the array. - **reset_counter** (`uint8_t`): Estimate reset counter. This should be incremented when the estimate resets in any of the dimensions (position, velocity, attitude, angular speed). This is designed to be used when e.g an external SLAM system detects a loop-closure and the estimate jumps.

--- chunk_id: chunk-0073
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 318
content_hash: 19db9ed76ba6e710
prev_chunk_id: chunk-0072
next_chunk_id: chunk-0074
section_heading: VISION_SPEED_ESTIMATE (msg id 103, dialect common)
document_type: technical_reference

## VISION_SPEED_ESTIMATE (msg id 103, dialect common)

Speed estimate from a vision source. ### Fields

- **usec** (`uint64_t`, us): Timestamp (UNIX time or time since system boot)
- **x** (`float`, m/s): Global X speed
- **y** (`float`, m/s): Global Y speed
- **z** (`float`, m/s): Global Z speed
- **covariance** (`float[9]`): Row-major representation of 3x3 linear velocity covariance matrix (states: vx, vy, vz; 1st three entries - 1st row, etc.). If unknown, assign NaN value to first element in the array. - **reset_counter** (`uint8_t`): Estimate reset counter. This should be incremented when the estimate resets in any of the dimensions (position, velocity, attitude, angular speed). This is designed to be used when e.g an external SLAM system detects a loop-closure and the estimate jumps. ### VICON_POSITION_ESTIMATE (msg id 104, dialect common)
Global position estimate from a Vicon motion system source. ### Fields

- **usec** (`uint64_t`, us): Timestamp (UNIX time or time since system boot)
- **x** (`float`, m): Global X position
- **y** (`float`, m): Global Y position
- **z** (`float`, m): Global Z position
- **roll** (`float`, rad): Roll angle
- **pitch** (`float`, rad): Pitch angle
- **yaw** (`float`, rad): Yaw angle
- **covariance** (`float[21]`): Row-major representation of 6x6 pose cross-covariance matrix upper right triangle (states: x, y, z, roll, pitch, yaw; first six entries are the first ROW, next five entries are the second ROW, etc.). If unknown, assign NaN value to first element in the array.

--- chunk_id: chunk-0074
source_document: messages_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 238
content_hash: cdf0e8b24748ee84
prev_chunk_id: chunk-0073
next_chunk_id: chunk-0075
section_heading: HIGHRES_IMU (msg id 105, dialect common)
document_type: technical_reference

## HIGHRES_IMU (msg id 105, dialect common)

The IMU readings in SI units in NED body frame

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **xacc** (`float`, m/s/s): X acceleration
- **yacc** (`float`, m/s/s): Y acceleration
- **zacc** (`float`, m/s/s): Z acceleration
- **xgyro** (`float`, rad/s): Angular speed around X axis
- **ygyro** (`float`, rad/s): Angular speed around Y axis
- **zgyro** (`float`, rad/s): Angular speed around Z axis
- **xmag** (`float`, gauss): X Magnetic field
- **ymag** (`float`, gauss): Y Magnetic field
- **zmag** (`float`, gauss): Z Magnetic field
- **abs_pressure** (`float`, hPa): Absolute pressure
- **diff_pressure** (`float`, hPa): Differential pressure
- **pressure_alt** (`float`): Altitude calculated from pressure
- **temperature** (`float`, degC): Temperature
- **fields_updated** (`uint16_t`): Bitmap for fields that have updated since last message
- **id** (`uint8_t`): Id. Ids are numbered from 0 and map to IMUs numbered from 1 (e.g. IMU1 will have a message with id=0)

--- chunk_id: chunk-0075
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: dd54fcef874d25d7
prev_chunk_id: chunk-0074
next_chunk_id: chunk-0076
section_heading: MAVLink messages batch 4
document_type: technical_reference

# MAVLink messages batch 4

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0076
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 301
content_hash: 216224a13523f795
prev_chunk_id: chunk-0075
next_chunk_id: chunk-0077
section_heading: OPTICAL_FLOW_RAD (msg id 106, dialect common)
document_type: technical_reference

## OPTICAL_FLOW_RAD (msg id 106, dialect common)

Optical flow from an angular rate flow sensor (e.g. PX4FLOW or mouse sensor)

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **sensor_id** (`uint8_t`): Sensor ID
- **integration_time_us** (`uint32_t`, us): Integration time. Divide integrated_x and integrated_y by the integration time to obtain average flow. The integration time also indicates the. - **integrated_x** (`float`, rad): Flow around X axis (Sensor RH rotation about the X axis induces a positive flow. Sensor linear motion along the positive Y axis induces a negative flow.)
- **integrated_y** (`float`, rad): Flow around Y axis (Sensor RH rotation about the Y axis induces a positive flow. Sensor linear motion along the positive X axis induces a positive flow.)
- **integrated_xgyro** (`float`, rad): RH rotation around X axis
- **integrated_ygyro** (`float`, rad): RH rotation around Y axis
- **integrated_zgyro** (`float`, rad): RH rotation around Z axis
- **temperature** (`int16_t`, cdegC): Temperature
- **quality** (`uint8_t`): Optical flow quality / confidence. 0: no valid flow, 255: maximum quality
- **time_delta_distance_us** (`uint32_t`, us): Time since the distance was sampled. - **distance** (`float`, m): Distance to the center of the flow field. Positive value (including zero): distance known. Negative value: Unknown distance.

--- chunk_id: chunk-0077
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 236
content_hash: 6c5d0ec0b67e9ceb
prev_chunk_id: chunk-0076
next_chunk_id: chunk-0078
section_heading: HIL_SENSOR (msg id 107, dialect common)
document_type: technical_reference

## HIL_SENSOR (msg id 107, dialect common)

The IMU readings in SI units in NED body frame

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **xacc** (`float`, m/s/s): X acceleration
- **yacc** (`float`, m/s/s): Y acceleration
- **zacc** (`float`, m/s/s): Z acceleration
- **xgyro** (`float`, rad/s): Angular speed around X axis in body frame
- **ygyro** (`float`, rad/s): Angular speed around Y axis in body frame
- **zgyro** (`float`, rad/s): Angular speed around Z axis in body frame
- **xmag** (`float`, gauss): X Magnetic field
- **ymag** (`float`, gauss): Y Magnetic field
- **zmag** (`float`, gauss): Z Magnetic field
- **abs_pressure** (`float`, hPa): Absolute pressure
- **diff_pressure** (`float`, hPa): Differential pressure (airspeed)
- **pressure_alt** (`float`): Altitude calculated from pressure
- **temperature** (`float`, degC): Temperature
- **fields_updated** (`uint32_t`): Bitmap for fields that have updated since last message
- **id** (`uint8_t`): Sensor ID (zero indexed). Used for multiple sensor inputs

--- chunk_id: chunk-0078
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 384
content_hash: 3312d35821cbbd9d
prev_chunk_id: chunk-0077
next_chunk_id: chunk-0079
section_heading: SIM_STATE (msg id 108, dialect common)
document_type: technical_reference

## SIM_STATE (msg id 108, dialect common)

Status of simulation environment, if used

### Fields

- **q1** (`float`): True attitude quaternion component 1, w (1 in null-rotation)
- **q2** (`float`): True attitude quaternion component 2, x (0 in null-rotation)
- **q3** (`float`): True attitude quaternion component 3, y (0 in null-rotation)
- **q4** (`float`): True attitude quaternion component 4, z (0 in null-rotation)
- **roll** (`float`, rad): Attitude roll expressed as Euler angles, not recommended except for human-readable outputs
- **pitch** (`float`, rad): Attitude pitch expressed as Euler angles, not recommended except for human-readable outputs
- **yaw** (`float`, rad): Attitude yaw expressed as Euler angles, not recommended except for human-readable outputs
- **xacc** (`float`, m/s/s): X acceleration
- **yacc** (`float`, m/s/s): Y acceleration
- **zacc** (`float`, m/s/s): Z acceleration
- **xgyro** (`float`, rad/s): Angular speed around X axis
- **ygyro** (`float`, rad/s): Angular speed around Y axis
- **zgyro** (`float`, rad/s): Angular speed around Z axis
- **lat** (`float`, deg): Latitude (lower precision). Both this and the lat_int field should be set. - **lon** (`float`, deg): Longitude (lower precision). Both this and the lon_int field should be set. - **alt** (`float`, m): Altitude
- **std_dev_horz** (`float`): Horizontal position standard deviation
- **std_dev_vert** (`float`): Vertical position standard deviation
- **vn** (`float`, m/s): True velocity in north direction in earth-fixed NED frame
- **ve** (`float`, m/s): True velocity in east direction in earth-fixed NED frame
- **vd** (`float`, m/s): True velocity in down direction in earth-fixed NED frame
- **lat_int** (`int32_t`, degE7): Latitude (higher precision). If 0, recipients should use the lat field value (otherwise this field is preferred). - **lon_int** (`int32_t`, degE7): Longitude (higher precision). If 0, recipients should use the lon field value (otherwise this field is preferred).

--- chunk_id: chunk-0079
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: e040f57ac4942446
prev_chunk_id: chunk-0078
next_chunk_id: chunk-0080
section_heading: RADIO_STATUS (msg id 109, dialect common)
document_type: technical_reference

## RADIO_STATUS (msg id 109, dialect common)

Status generated by radio and injected into MAVLink stream. ### Fields

- **rssi** (`uint8_t`): Local (message sender) received signal strength indication in device-dependent units/scale. Values: [0-254], UINT8_MAX: invalid/unknown. - **remrssi** (`uint8_t`): Remote (message receiver) signal strength indication in device-dependent units/scale. Values: [0-254], UINT8_MAX: invalid/unknown. - **txbuf** (`uint8_t`, %): Remaining free transmitter buffer space. - **noise** (`uint8_t`): Local background noise level. These are device dependent RSSI values (scale as approx 2x dB on SiK radios). Values: [0-254], UINT8_MAX: invalid/unknown. - **remnoise** (`uint8_t`): Remote background noise level. These are device dependent RSSI values (scale as approx 2x dB on SiK radios). Values: [0-254], UINT8_MAX: invalid/unknown. - **rxerrors** (`uint16_t`): Count of radio packet receive errors (since boot). - **fixed** (`uint16_t`): Count of error corrected radio packets (since boot).

--- chunk_id: chunk-0080
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: 7c7da62481cb9068
prev_chunk_id: chunk-0079
next_chunk_id: chunk-0081
section_heading: FILE_TRANSFER_PROTOCOL (msg id 110, dialect common)
document_type: technical_reference

## FILE_TRANSFER_PROTOCOL (msg id 110, dialect common)

File transfer protocol message: https://mavlink.io/en/services/ftp.html. ### Fields

- **target_network** (`uint8_t`): Network ID (0 for broadcast)
- **target_system** (`uint8_t`): System ID (0 for broadcast)
- **target_component** (`uint8_t`): Component ID (0 for broadcast)
- **payload** (`uint8_t[251]`): Variable length payload. The content/format of this block is defined in https://mavlink.io/en/services/ftp.html. The length is defined by the remaining message length when subtracting the header and other fields. See also MAV_FTP_OPCODE and MAV_FTP_ERR. ### TIMESYNC (msg id 111, dialect common)
Time synchronization message. The message is used for both timesync requests and responses. The request is sent with `ts1=syncing component timestamp` and `tc1=0`, and may be broadcast or targeted to a specific system/component. The response is sent with `ts1=syncing component timestamp` (mirror back unchanged), and `tc1=responding component timestamp`, with the `target_system` and `target_component` set to ids of the original request. Systems can determine if they are receiving a request or response based on the value of `tc`. If the response has `target_system==target_component==0` the remote system has not been updated to use the component IDs and cannot reliably timesync; the requester may report an error. Timestamps are UNIX Epoch time or time since system boot in nanoseconds (the timestamp format can be inferred by checking for the magnitude of the number; generally it doesn't matter as only the offset is used). The message sequence is repeated numerous times with results being filtered/averaged to estimate the offset. See also: https://mavlink.io/en/services/timesync.html. ### Fields

- **tc1** (`int64_t`, ns): Time sync timestamp 1. Syncing: 0. Responding: Timestamp of responding component. - **ts1** (`int64_t`, ns): Time sync timestamp 2. Timestamp of syncing component (mirrored in response). - **target_system** (`uint8_t`): Target system id. Request: 0 (broadcast) or id of specific system. Response must contain system id of the requesting component. - **target_component** (`uint8_t`): Target component id. Request: 0 (broadcast) or id of specific component. Response must contain component id of the requesting component.

--- chunk_id: chunk-0081
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 452
content_hash: a0b642b572be9fc5
prev_chunk_id: chunk-0080
next_chunk_id: chunk-0082
section_heading: CAMERA_TRIGGER (msg id 112, dialect common)
document_type: technical_reference

## CAMERA_TRIGGER (msg id 112, dialect common)

Camera-IMU triggering and synchronisation message. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp for image frame (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **seq** (`uint32_t`): Image frame sequence

### HIL_GPS (msg id 113, dialect common)
The global position, as returned by the Global Positioning System (GPS). This is
                 NOT the global position estimate of the system, but rather a RAW sensor value. See message GLOBAL_POSITION_INT for the global position estimate. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **fix_type** (`uint8_t`): 0-1: no fix, 2: 2D fix, 3: 3D fix. Some applications will not use the value of this field unless it is at least two, so always correctly fill in the fix. - **lat** (`int32_t`, degE7): Latitude (WGS84)
- **lon** (`int32_t`, degE7): Longitude (WGS84)
- **alt** (`int32_t`, mm): Altitude (MSL). Positive for up. - **eph** (`uint16_t`): GPS HDOP horizontal dilution of position (unitless * 100). If unknown, set to: UINT16_MAX
- **epv** (`uint16_t`): GPS VDOP vertical dilution of position (unitless * 100). If unknown, set to: UINT16_MAX
- **vel** (`uint16_t`, cm/s): GPS ground speed. If unknown, set to: UINT16_MAX
- **vn** (`int16_t`, cm/s): GPS velocity in north direction in earth-fixed NED frame
- **ve** (`int16_t`, cm/s): GPS velocity in east direction in earth-fixed NED frame
- **vd** (`int16_t`, cm/s): GPS velocity in down direction in earth-fixed NED frame
- **cog** (`uint16_t`, cdeg): Course over ground (NOT heading, but direction of movement), 0.0..359.99 degrees. If unknown, set to: UINT16_MAX
- **satellites_visible** (`uint8_t`): Number of satellites visible. If unknown, set to UINT8_MAX
- **id** (`uint8_t`): GPS ID (zero indexed). Used for multiple GPS inputs
- **yaw** (`uint16_t`, cdeg): Yaw of vehicle relative to Earth's North, zero means not available, use 36000 for north

--- chunk_id: chunk-0082
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 306
content_hash: 4394f8c4d1f5e72c
prev_chunk_id: chunk-0081
next_chunk_id: chunk-0083
section_heading: HIL_OPTICAL_FLOW (msg id 114, dialect common)
document_type: technical_reference

## HIL_OPTICAL_FLOW (msg id 114, dialect common)

Simulated optical flow from a flow sensor (e.g. PX4FLOW or optical mouse sensor)

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **sensor_id** (`uint8_t`): Sensor ID
- **integration_time_us** (`uint32_t`, us): Integration time. Divide integrated_x and integrated_y by the integration time to obtain average flow. The integration time also indicates the. - **integrated_x** (`float`, rad): Flow in radians around X axis (Sensor RH rotation about the X axis induces a positive flow. Sensor linear motion along the positive Y axis induces a negative flow.)
- **integrated_y** (`float`, rad): Flow in radians around Y axis (Sensor RH rotation about the Y axis induces a positive flow. Sensor linear motion along the positive X axis induces a positive flow.)
- **integrated_xgyro** (`float`, rad): RH rotation around X axis
- **integrated_ygyro** (`float`, rad): RH rotation around Y axis
- **integrated_zgyro** (`float`, rad): RH rotation around Z axis
- **temperature** (`int16_t`, cdegC): Temperature
- **quality** (`uint8_t`): Optical flow quality / confidence. 0: no valid flow, 255: maximum quality
- **time_delta_distance_us** (`uint32_t`, us): Time since the distance was sampled. - **distance** (`float`, m): Distance to the center of the flow field. Positive value (including zero): distance known. Negative value: Unknown distance.

--- chunk_id: chunk-0083
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 258
content_hash: 4c0c85f85c9a5357
prev_chunk_id: chunk-0082
next_chunk_id: chunk-0084
section_heading: HIL_STATE_QUATERNION (msg id 115, dialect common)
document_type: technical_reference

## HIL_STATE_QUATERNION (msg id 115, dialect common)

Sent from simulation to autopilot, avoids in contrast to HIL_STATE singularities. This packet is useful for high throughput applications such as hardware in the loop simulations. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **attitude_quaternion** (`float[4]`): Vehicle attitude expressed as normalized quaternion in w, x, y, z order (with 1 0 0 0 being the null-rotation)
- **rollspeed** (`float`, rad/s): Body frame roll / phi angular speed
- **pitchspeed** (`float`, rad/s): Body frame pitch / theta angular speed
- **yawspeed** (`float`, rad/s): Body frame yaw / psi angular speed
- **lat** (`int32_t`, degE7): Latitude
- **lon** (`int32_t`, degE7): Longitude
- **alt** (`int32_t`, mm): Altitude
- **vx** (`int16_t`, cm/s): Ground X Speed (Latitude)
- **vy** (`int16_t`, cm/s): Ground Y Speed (Longitude)
- **vz** (`int16_t`, cm/s): Ground Z Speed (Altitude)
- **ind_airspeed** (`uint16_t`, cm/s): Indicated airspeed
- **true_airspeed** (`uint16_t`, cm/s): True airspeed
- **xacc** (`int16_t`, mG): X acceleration
- **yacc** (`int16_t`, mG): Y acceleration
- **zacc** (`int16_t`, mG): Z acceleration

--- chunk_id: chunk-0084
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 304
content_hash: 77d19b567a5f464f
prev_chunk_id: chunk-0083
next_chunk_id: chunk-0085
section_heading: SCALED_IMU2 (msg id 116, dialect common)
document_type: technical_reference

## SCALED_IMU2 (msg id 116, dialect common)

The RAW IMU readings for secondary 9DOF sensor setup. This message should contain the scaled values to the described units

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **xacc** (`int16_t`, mG): X acceleration
- **yacc** (`int16_t`, mG): Y acceleration
- **zacc** (`int16_t`, mG): Z acceleration
- **xgyro** (`int16_t`, mrad/s): Angular speed around X axis
- **ygyro** (`int16_t`, mrad/s): Angular speed around Y axis
- **zgyro** (`int16_t`, mrad/s): Angular speed around Z axis
- **xmag** (`int16_t`, mgauss): X Magnetic field
- **ymag** (`int16_t`, mgauss): Y Magnetic field
- **zmag** (`int16_t`, mgauss): Z Magnetic field
- **temperature** (`int16_t`, cdegC): Temperature, 0: IMU does not provide temperature values. If the IMU is at 0C it must send 1 (0.01C). ### LOG_REQUEST_LIST (msg id 117, dialect common)
Request a list of available logs. On some systems calling this may stop on-board logging until LOG_REQUEST_END is called. If there are no log files available this request shall be answered with one LOG_ENTRY message with id = 0 and num_logs = 0. LOG_ENTRY messages can start with id 1 or 0. The ground station needs to be able to process either. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **start** (`uint16_t`): First log id (0 for first available)
- **end** (`uint16_t`): Last log id (0xffff for last available)

--- chunk_id: chunk-0085
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: 8663d6f10a559721
prev_chunk_id: chunk-0084
next_chunk_id: chunk-0086
section_heading: LOG_ENTRY (msg id 118, dialect common)
document_type: technical_reference

## LOG_ENTRY (msg id 118, dialect common)

Reply to LOG_REQUEST_LIST

### Fields

- **id** (`uint16_t`): Log id
- **num_logs** (`uint16_t`): Total number of logs
- **last_log_num** (`uint16_t`): High log number
- **time_utc** (`uint32_t`, s): UTC timestamp of log since 1970, or 0 if not available
- **size** (`uint32_t`, bytes): Size of the log (may be approximate)

### LOG_REQUEST_DATA (msg id 119, dialect common)
Request a chunk of a log

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **id** (`uint16_t`): Log id (from LOG_ENTRY reply)
- **ofs** (`uint32_t`): Offset into the log
- **count** (`uint32_t`, bytes): Number of bytes

### LOG_DATA (msg id 120, dialect common)
Reply to LOG_REQUEST_DATA

### Fields

- **id** (`uint16_t`): Log id (from LOG_ENTRY reply)
- **ofs** (`uint32_t`): Offset into the log
- **count** (`uint8_t`, bytes): Number of bytes (zero for end of log)
- **data** (`uint8_t[90]`): log data

### LOG_ERASE (msg id 121, dialect common)
Erase all logs

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID

--- chunk_id: chunk-0086
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: 4ae227b84da5faad
prev_chunk_id: chunk-0085
next_chunk_id: chunk-0087
section_heading: LOG_REQUEST_END (msg id 122, dialect common)
document_type: technical_reference

## LOG_REQUEST_END (msg id 122, dialect common)

Stop log transfer and resume normal logging

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID

### GPS_INJECT_DATA (msg id 123, dialect common)
Data for injecting into the onboard GPS (used for DGPS)

### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **len** (`uint8_t`, bytes): Data length
- **data** (`uint8_t[110]`): Raw data (110 is enough for 12 satellites of RTCMv2)

### GPS2_RAW (msg id 124, dialect common)
Second GPS data. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **fix_type** (`uint8_t`): GPS fix type. - **lat** (`int32_t`, degE7): Latitude (WGS84)
- **lon** (`int32_t`, degE7): Longitude (WGS84)
- **alt** (`int32_t`, mm): Altitude (MSL). Positive for up. - **eph** (`uint16_t`): GPS HDOP horizontal dilution of position (unitless * 100). If unknown, set to: UINT16_MAX
- **epv** (`uint16_t`): GPS VDOP vertical dilution of position (unitless * 100). If unknown, set to: UINT16_MAX
- **vel** (`uint16_t`, cm/s): GPS ground speed. If unknown, set to: UINT16_MAX
- **cog** (`uint16_t`, cdeg): Course over ground (NOT heading, but direction of movement): 0.0..359.99 degrees. If unknown, set to: UINT16_MAX
- **satellites_visible** (`uint8_t`): Number of satellites visible. If unknown, set to UINT8_MAX
- **dgps_numch** (`uint8_t`): Number of DGPS satellites
- **dgps_age** (`uint32_t`, ms): Age of DGPS info
- **yaw** (`uint16_t`, cdeg): Yaw in earth frame from north. Use 0 if this GPS does not provide yaw. Use UINT16_MAX if this GPS is configured to provide yaw and is currently unable to provide it. Use 36000 for north. - **alt_ellipsoid** (`int32_t`, mm): Altitude (above WGS84, EGM96 ellipsoid). Positive for up. - **h_acc** (`uint32_t`, mm): Position uncertainty. - **v_acc** (`uint32_t`, mm): Altitude uncertainty. - **vel_acc** (`uint32_t`, mm/s): Speed uncertainty. - **hdg_acc** (`uint32_t`, degE5): Heading / track uncertainty

--- chunk_id: chunk-0087
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 212
content_hash: 1bef85791615f287
prev_chunk_id: chunk-0086
next_chunk_id: chunk-0088
section_heading: POWER_STATUS (msg id 125, dialect common)
document_type: technical_reference

## POWER_STATUS (msg id 125, dialect common)

Power supply status

### Fields

- **Vcc** (`uint16_t`, mV): 5V rail voltage. - **Vservo** (`uint16_t`, mV): Servo rail voltage. - **flags** (`uint16_t`): Bitmap of power supply status flags. ### SERIAL_CONTROL (msg id 126, dialect common)
Control a serial port. This can be used for raw access to an onboard serial peripheral such as a GPS or telemetry radio. It is designed to make it possible to update the devices firmware via MAVLink messages or change the devices settings. A message with zero bytes can be used to change just the baudrate. ### Fields

- **device** (`uint8_t`): Serial control device type. - **flags** (`uint8_t`): Bitmap of serial control flags. - **timeout** (`uint16_t`, ms): Timeout for reply data
- **baudrate** (`uint32_t`, bits/s): Baudrate of transfer. Zero means no change. - **count** (`uint8_t`, bytes): how many bytes in this transfer
- **data** (`uint8_t[70]`): serial data
- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID

--- chunk_id: chunk-0088
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 210
content_hash: a24e7365fd31b5e1
prev_chunk_id: chunk-0087
next_chunk_id: chunk-0089
section_heading: GPS_RTK (msg id 127, dialect common)
document_type: technical_reference

## GPS_RTK (msg id 127, dialect common)

RTK GPS data. Gives information on the relative baseline calculation the GPS is reporting

### Fields

- **time_last_baseline_ms** (`uint32_t`, ms): Time since boot of last baseline message received. - **rtk_receiver_id** (`uint8_t`): Identification of connected RTK receiver. - **wn** (`uint16_t`): GPS Week Number of last baseline
- **tow** (`uint32_t`, ms): GPS Time of Week of last baseline
- **rtk_health** (`uint8_t`): GPS-specific health report for RTK data. - **rtk_rate** (`uint8_t`, Hz): Rate of baseline messages being received by GPS
- **nsats** (`uint8_t`): Current number of sats used for RTK calculation. - **baseline_coords_type** (`uint8_t`): Coordinate system of baseline
- **baseline_a_mm** (`int32_t`, mm): Current baseline in ECEF x or NED north component. - **baseline_b_mm** (`int32_t`, mm): Current baseline in ECEF y or NED east component. - **baseline_c_mm** (`int32_t`, mm): Current baseline in ECEF z or NED down component. - **accuracy** (`uint32_t`): Current estimate of baseline accuracy. - **iar_num_hypotheses** (`int32_t`): Current number of integer ambiguity hypotheses.

--- chunk_id: chunk-0089
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 210
content_hash: b1e72a69a8bd62da
prev_chunk_id: chunk-0088
next_chunk_id: chunk-0090
section_heading: GPS2_RTK (msg id 128, dialect common)
document_type: technical_reference

## GPS2_RTK (msg id 128, dialect common)

RTK GPS data. Gives information on the relative baseline calculation the GPS is reporting

### Fields

- **time_last_baseline_ms** (`uint32_t`, ms): Time since boot of last baseline message received. - **rtk_receiver_id** (`uint8_t`): Identification of connected RTK receiver. - **wn** (`uint16_t`): GPS Week Number of last baseline
- **tow** (`uint32_t`, ms): GPS Time of Week of last baseline
- **rtk_health** (`uint8_t`): GPS-specific health report for RTK data. - **rtk_rate** (`uint8_t`, Hz): Rate of baseline messages being received by GPS
- **nsats** (`uint8_t`): Current number of sats used for RTK calculation. - **baseline_coords_type** (`uint8_t`): Coordinate system of baseline
- **baseline_a_mm** (`int32_t`, mm): Current baseline in ECEF x or NED north component. - **baseline_b_mm** (`int32_t`, mm): Current baseline in ECEF y or NED east component. - **baseline_c_mm** (`int32_t`, mm): Current baseline in ECEF z or NED down component. - **accuracy** (`uint32_t`): Current estimate of baseline accuracy. - **iar_num_hypotheses** (`int32_t`): Current number of integer ambiguity hypotheses.

--- chunk_id: chunk-0090
source_document: messages_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 306
content_hash: d390d3987e91e5bf
prev_chunk_id: chunk-0089
next_chunk_id: chunk-0091
section_heading: SCALED_IMU3 (msg id 129, dialect common)
document_type: technical_reference

## SCALED_IMU3 (msg id 129, dialect common)

The RAW IMU readings for 3rd 9DOF sensor setup. This message should contain the scaled values to the described units

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **xacc** (`int16_t`, mG): X acceleration
- **yacc** (`int16_t`, mG): Y acceleration
- **zacc** (`int16_t`, mG): Z acceleration
- **xgyro** (`int16_t`, mrad/s): Angular speed around X axis
- **ygyro** (`int16_t`, mrad/s): Angular speed around Y axis
- **zgyro** (`int16_t`, mrad/s): Angular speed around Z axis
- **xmag** (`int16_t`, mgauss): X Magnetic field
- **ymag** (`int16_t`, mgauss): Y Magnetic field
- **zmag** (`int16_t`, mgauss): Z Magnetic field
- **temperature** (`int16_t`, cdegC): Temperature, 0: IMU does not provide temperature values. If the IMU is at 0C it must send 1 (0.01C). ### DATA_TRANSMISSION_HANDSHAKE (msg id 130, dialect common)
Handshake message to initiate, control and stop image streaming when using the Image Transmission Protocol: https://mavlink.io/en/services/image_transmission.html. ### Fields

- **type** (`uint8_t`): Type of requested/acknowledged data. - **size** (`uint32_t`, bytes): total data size (set on ACK only). - **width** (`uint16_t`): Width of a matrix or image. - **height** (`uint16_t`): Height of a matrix or image. - **packets** (`uint16_t`): Number of packets being sent (set on ACK only). - **payload** (`uint8_t`, bytes): Payload size per packet (normally 253 byte, see DATA field size in message ENCAPSULATED_DATA) (set on ACK only). - **jpg_quality** (`uint8_t`, %): JPEG quality. Values: [1-100].

--- chunk_id: chunk-0091
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: 4b791c7bf94e454a
prev_chunk_id: chunk-0090
next_chunk_id: chunk-0092
section_heading: MAVLink messages batch 5
document_type: technical_reference

# MAVLink messages batch 5

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0092
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: de1f0b728655fd80
prev_chunk_id: chunk-0091
next_chunk_id: chunk-0093
section_heading: ENCAPSULATED_DATA (msg id 131, dialect common)
document_type: technical_reference

## ENCAPSULATED_DATA (msg id 131, dialect common)

Data packet for images sent using the Image Transmission Protocol: https://mavlink.io/en/services/image_transmission.html. ### Fields

- **seqnr** (`uint16_t`): sequence number (starting with 0 on every transmission)
- **data** (`uint8_t[253]`): image data bytes

### DISTANCE_SENSOR (msg id 132, dialect common)
Distance sensor information for an onboard rangefinder. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **min_distance** (`uint16_t`, cm): Minimum distance the sensor can measure
- **max_distance** (`uint16_t`, cm): Maximum distance the sensor can measure
- **current_distance** (`uint16_t`, cm): Current distance reading
- **type** (`uint8_t`): Type of distance sensor. - **id** (`uint8_t`): Onboard ID of the sensor
- **orientation** (`uint8_t`): Direction the sensor faces. downward-facing: ROTATION_PITCH_270, upward-facing: ROTATION_PITCH_90, backward-facing: ROTATION_PITCH_180, forward-facing: ROTATION_NONE, left-facing: ROTATION_YAW_90, right-facing: ROTATION_YAW_270
- **covariance** (`uint8_t`, cm^2): Measurement variance. Max standard deviation is 6cm. UINT8_MAX if unknown. - **horizontal_fov** (`float`, rad): Horizontal Field of View (angle) where the distance measurement is valid and the field of view is known. Otherwise this is set to 0. - **vertical_fov** (`float`, rad): Vertical Field of View (angle) where the distance measurement is valid and the field of view is known. Otherwise this is set to 0. - **quaternion** (`float[4]`): Quaternion of the sensor orientation in vehicle body frame (w, x, y, z order, zero-rotation is 1, 0, 0, 0). Zero-rotation is along the vehicle body x-axis. This field is required if the orientation is set to MAV_SENSOR_ROTATION_CUSTOM. Set it to 0 if invalid."
- **signal_quality** (`uint8_t`, %): Signal quality of the sensor. Specific to each sensor type, representing the relation of the signal strength with the target reflectivity, distance, size or aspect, but normalised as a percentage. 0 = unknown/unset signal quality, 1 = invalid signal, 100 = perfect signal.

--- chunk_id: chunk-0093
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 189
content_hash: a01d7fd28a499497
prev_chunk_id: chunk-0092
next_chunk_id: chunk-0094
section_heading: TERRAIN_REQUEST (msg id 133, dialect common)
document_type: technical_reference

## TERRAIN_REQUEST (msg id 133, dialect common)

Request for terrain data and terrain status. See terrain protocol docs: https://mavlink.io/en/services/terrain.html

### Fields

- **lat** (`int32_t`, degE7): Latitude of SW corner of first grid
- **lon** (`int32_t`, degE7): Longitude of SW corner of first grid
- **grid_spacing** (`uint16_t`, m): Grid spacing
- **mask** (`uint64_t`): Bitmask of requested 4x4 grids (row major 8x7 array of grids, 56 bits)

### TERRAIN_DATA (msg id 134, dialect common)
Terrain data sent from GCS. The lat/lon and grid_spacing must be the same as a lat/lon from a TERRAIN_REQUEST. See terrain protocol docs: https://mavlink.io/en/services/terrain.html

### Fields

- **lat** (`int32_t`, degE7): Latitude of SW corner of first grid
- **lon** (`int32_t`, degE7): Longitude of SW corner of first grid
- **grid_spacing** (`uint16_t`, m): Grid spacing
- **gridbit** (`uint8_t`): bit within the terrain request mask
- **data** (`int16_t[16]`, m): Terrain data MSL

--- chunk_id: chunk-0094
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 202
content_hash: 271bddb91321cd86
prev_chunk_id: chunk-0093
next_chunk_id: chunk-0095
section_heading: TERRAIN_CHECK (msg id 135, dialect common)
document_type: technical_reference

## TERRAIN_CHECK (msg id 135, dialect common)

Request that the vehicle report terrain height at the given location (expected response is a TERRAIN_REPORT). Used by GCS to check if vehicle has all terrain data needed for a mission. ### Fields

- **lat** (`int32_t`, degE7): Latitude
- **lon** (`int32_t`, degE7): Longitude

### TERRAIN_REPORT (msg id 136, dialect common)
Streamed from drone to report progress of terrain map download (initiated by TERRAIN_REQUEST), or sent as a response to a TERRAIN_CHECK request. See terrain protocol docs: https://mavlink.io/en/services/terrain.html

### Fields

- **lat** (`int32_t`, degE7): Latitude
- **lon** (`int32_t`, degE7): Longitude
- **spacing** (`uint16_t`): grid spacing (zero if terrain at this location unavailable)
- **terrain_height** (`float`, m): Terrain height MSL
- **current_height** (`float`, m): Current vehicle height above lat/lon terrain height
- **pending** (`uint16_t`): Number of 4x4 terrain blocks waiting to be received or read from disk
- **loaded** (`uint16_t`): Number of 4x4 terrain blocks in memory

--- chunk_id: chunk-0095
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 258
content_hash: 1bdd03869cb153c3
prev_chunk_id: chunk-0094
next_chunk_id: chunk-0096
section_heading: SCALED_PRESSURE2 (msg id 137, dialect common)
document_type: technical_reference

## SCALED_PRESSURE2 (msg id 137, dialect common)

Barometer readings for 2nd barometer

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **press_abs** (`float`, hPa): Absolute pressure
- **press_diff** (`float`, hPa): Differential pressure
- **temperature** (`int16_t`, cdegC): Absolute pressure temperature
- **temperature_press_diff** (`int16_t`, cdegC): Differential pressure temperature (0, if not available). Report values of 0 (or 1) as 1 cdegC. ### ATT_POS_MOCAP (msg id 138, dialect common)
Motion capture attitude and position

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **q** (`float[4]`): Attitude quaternion (w, x, y, z order, zero-rotation is 1, 0, 0, 0)
- **x** (`float`, m): X position (NED)
- **y** (`float`, m): Y position (NED)
- **z** (`float`, m): Z position (NED)
- **covariance** (`float[21]`): Row-major representation of a pose 6x6 cross-covariance matrix upper right triangle (states: x, y, z, roll, pitch, yaw; first six entries are the first ROW, next five entries are the second ROW, etc.). If unknown, assign NaN value to first element in the array.

--- chunk_id: chunk-0096
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 186
content_hash: 0cc065b3b8dfdb7d
prev_chunk_id: chunk-0095
next_chunk_id: chunk-0097
section_heading: SET_ACTUATOR_CONTROL_TARGET (msg id 139, dialect common)
document_type: technical_reference

## SET_ACTUATOR_CONTROL_TARGET (msg id 139, dialect common)

Set the vehicle attitude and body angular rates. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **group_mlx** (`uint8_t`): Actuator group. The "_mlx" indicates this is a multi-instance message and a MAVLink parser should use this field to difference between instances. - **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **controls** (`float[8]`): Actuator controls. Normed to -1..+1 where 0 is neutral position. Throttle for single rotation direction motors is 0..1, negative range for reverse direction. Standard mapping for attitude controls (group 0): (index 0-7): roll, pitch, yaw, throttle, flaps, spoilers, airbrakes, landing gear. Load a pass-through mixer to repurpose them as generic outputs.

--- chunk_id: chunk-0097
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: e0d2ec9d046f69d4
prev_chunk_id: chunk-0096
next_chunk_id: chunk-0098
section_heading: ACTUATOR_CONTROL_TARGET (msg id 140, dialect common)
document_type: technical_reference

## ACTUATOR_CONTROL_TARGET (msg id 140, dialect common)

Set the vehicle attitude and body angular rates. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **group_mlx** (`uint8_t`): Actuator group. The "_mlx" indicates this is a multi-instance message and a MAVLink parser should use this field to difference between instances. - **controls** (`float[8]`): Actuator controls. Normed to -1..+1 where 0 is neutral position. Throttle for single rotation direction motors is 0..1, negative range for reverse direction. Standard mapping for attitude controls (group 0): (index 0-7): roll, pitch, yaw, throttle, flaps, spoilers, airbrakes, landing gear. Load a pass-through mixer to repurpose them as generic outputs.

--- chunk_id: chunk-0098
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 3bdc97869d632186
prev_chunk_id: chunk-0097
next_chunk_id: chunk-0099
section_heading: ALTITUDE (msg id 141, dialect common)
document_type: technical_reference

## ALTITUDE (msg id 141, dialect common)

The current system altitude. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **altitude_monotonic** (`float`, m): This altitude measure is initialized on system boot and monotonic (it is never reset, but represents the local altitude change). The only guarantee on this field is that it will never be reset and is consistent within a flight. The recommended value for this field is the uncorrected barometric altitude at boot time. This altitude will also drift and vary between flights. - **altitude_amsl** (`float`, m): This altitude measure is strictly above mean sea level and might be non-monotonic (it might reset on events like GPS lock or when a new QNH value is set). It should be the altitude to which global altitude waypoints are compared to. Note that it is *not* the GPS altitude, however, most GPS modules already output MSL by default and not the WGS84 altitude. - **altitude_local** (`float`, m): This is the local altitude in the local coordinate frame. It is not the altitude above home, but in reference to the coordinate origin (0, 0, 0). It is up-positive. - **altitude_relative** (`float`, m): This is the altitude above the home position. It resets on each change of the current home position. - **altitude_terrain** (`float`, m): This is the altitude above terrain. It might be fed by a terrain database or an altimeter. Values smaller than -1000 should be interpreted as unknown. - **bottom_clearance** (`float`, m): This is not the altitude, but the clear space below the system according to the fused clearance estimate. It generally should max out at the maximum range of e.g. the laser altimeter. It is generally a moving target. A negative value indicates no measurement available.

--- chunk_id: chunk-0099
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 252
content_hash: f1f4a680a9301451
prev_chunk_id: chunk-0098
next_chunk_id: chunk-0100
section_heading: RESOURCE_REQUEST (msg id 142, dialect common)
document_type: technical_reference

## RESOURCE_REQUEST (msg id 142, dialect common)

The autopilot is requesting a resource (file, binary, other type of data)

### Fields

- **request_id** (`uint8_t`): Request ID. This ID should be reused when sending back URI contents
- **uri_type** (`uint8_t`): The type of requested URI. 0 = a file via URL. 1 = a UAVCAN binary
- **uri** (`uint8_t[120]`): The requested unique resource identifier (URI). It is not necessarily a straight domain name (depends on the URI type enum)
- **transfer_type** (`uint8_t`): The way the autopilot wants to receive the URI. 0 = MAVLink FTP. 1 = binary stream. - **storage** (`uint8_t[120]`): The storage path the autopilot wants the URI to be stored in. Will only be valid if the transfer_type has a storage associated (e.g. MAVLink FTP). ### SCALED_PRESSURE3 (msg id 143, dialect common)
Barometer readings for 3rd barometer

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **press_abs** (`float`, hPa): Absolute pressure
- **press_diff** (`float`, hPa): Differential pressure
- **temperature** (`int16_t`, cdegC): Absolute pressure temperature
- **temperature_press_diff** (`int16_t`, cdegC): Differential pressure temperature (0, if not available). Report values of 0 (or 1) as 1 cdegC.

--- chunk_id: chunk-0100
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 09d81c9cc842b7a4
prev_chunk_id: chunk-0099
next_chunk_id: chunk-0101
section_heading: FOLLOW_TARGET (msg id 144, dialect common)
document_type: technical_reference

## FOLLOW_TARGET (msg id 144, dialect common)

Current motion information from a designated system

### Fields

- **timestamp** (`uint64_t`, ms): Timestamp (time since system boot). - **est_capabilities** (`uint8_t`): bit positions for tracker reporting capabilities (POS = 0, VEL = 1, ACCEL = 2, ATT + RATES = 3)
- **lat** (`int32_t`, degE7): Latitude (WGS84)
- **lon** (`int32_t`, degE7): Longitude (WGS84)
- **alt** (`float`, m): Altitude (MSL)
- **vel** (`float[3]`, m/s): target velocity (0,0,0) for unknown
- **acc** (`float[3]`, m/s/s): linear target acceleration (0,0,0) for unknown
- **attitude_q** (`float[4]`): (0 0 0 0 for unknown)
- **rates** (`float[3]`): (0 0 0 for unknown)
- **position_cov** (`float[3]`): eph epv
- **custom_state** (`uint64_t`): button states or switches of a tracker device

### CONTROL_SYSTEM_STATE (msg id 146, dialect common)
The smoothed, monotonic system state used to feed the control loops of the system. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **x_acc** (`float`, m/s/s): X acceleration in body frame
- **y_acc** (`float`, m/s/s): Y acceleration in body frame
- **z_acc** (`float`, m/s/s): Z acceleration in body frame
- **x_vel** (`float`, m/s): X velocity in body frame
- **y_vel** (`float`, m/s): Y velocity in body frame
- **z_vel** (`float`, m/s): Z velocity in body frame
- **x_pos** (`float`, m): X position in local frame
- **y_pos** (`float`, m): Y position in local frame
- **z_pos** (`float`, m): Z position in local frame
- **airspeed** (`float`, m/s): Airspeed, set to -1 if unknown
- **vel_variance** (`float[3]`): Variance of body velocity estimate
- **pos_variance** (`float[3]`): Variance in local position
- **q** (`float[4]`): The attitude, represented as Quaternion
- **roll_rate** (`float`, rad/s): Angular rate in roll axis
- **pitch_rate** (`float`, rad/s): Angular rate in pitch axis
- **yaw_rate** (`float`, rad/s): Angular rate in yaw axis

--- chunk_id: chunk-0101
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 492
content_hash: a31ec0969e839bf3
prev_chunk_id: chunk-0100
next_chunk_id: chunk-0102
section_heading: BATTERY_STATUS (msg id 147, dialect common)
document_type: technical_reference

## BATTERY_STATUS (msg id 147, dialect common)

Battery information. Updates GCS with flight controller battery status. Smart batteries also use this message, but may additionally send BATTERY_INFO. ### Fields

- **id** (`uint8_t`): Battery ID
- **battery_function** (`uint8_t`): Function of the battery
- **type** (`uint8_t`): Type (chemistry) of the battery
- **temperature** (`int16_t`, cdegC): Temperature of the battery. INT16_MAX for unknown temperature. - **voltages** (`uint16_t[10]`, mV): Battery voltage of cells 1 to 10 (see voltages_ext for cells 11-14). Cells in this field above the valid cell count for this battery should have the UINT16_MAX value. If individual cell voltages are unknown or not measured for this battery, then the overall battery voltage should be filled in cell 0, with all others set to UINT16_MAX. If the voltage of the battery is greater than (UINT16_MAX - 1), then cell 0 should be set to (UINT16_MAX - 1), and cell 1 to the remaining voltage. This can be extended to multiple cells if the total voltage is greater than 2 * (UINT16_MAX - 1). - **current_battery** (`int16_t`, cA): Battery current, -1: autopilot does not measure the current. Value may overflow/rollover for very high currents (> 327.67A)
- **current_consumed** (`int32_t`, mAh): Consumed charge, -1: autopilot does not provide consumption estimate
- **energy_consumed** (`int32_t`, hJ): Consumed energy, -1: autopilot does not provide energy consumption estimate
- **battery_remaining** (`int8_t`, %): Remaining battery energy. Values: [0-100], -1: autopilot does not estimate the remaining battery. - **time_remaining** (`int32_t`, s): Remaining battery time, 0: autopilot does not provide remaining battery time estimate
- **charge_state** (`uint8_t`): State for extent of discharge, provided by autopilot for warning or external reactions
- **voltages_ext** (`uint16_t[4]`, mV): Battery voltages for cells 11 to 14. Cells above the valid cell count for this battery should have a value of 0, where zero indicates not supported (note, this is different than for the voltages field and allows empty byte truncation). If the measured value is 0 then 1 should be sent instead. - **mode** (`uint8_t`): Battery mode. Default (0) is that battery mode reporting is not supported or battery is in normal-use mode. - **fault_bitmask** (`uint32_t`): Fault/health indications. These should be set when charge_state is MAV_BATTERY_CHARGE_STATE_FAILED or MAV_BATTERY_CHARGE_STATE_UNHEALTHY (if not, fault reporting is not supported).

--- chunk_id: chunk-0102
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 297
content_hash: 67eb2595e0e44d79
prev_chunk_id: chunk-0101
next_chunk_id: chunk-0103
section_heading: LANDING_TARGET (msg id 149, dialect common)
document_type: technical_reference

## LANDING_TARGET (msg id 149, dialect common)

The location of a landing target. See: https://mavlink.io/en/services/landing_target.html

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **target_num** (`uint8_t`): The ID of the target if multiple targets are present
- **frame** (`uint8_t`): Coordinate frame used for following fields. - **angle_x** (`float`, rad): X-axis angular offset of the target from the center of the image
- **angle_y** (`float`, rad): Y-axis angular offset of the target from the center of the image
- **distance** (`float`, m): Distance to the target from the vehicle
- **size_x** (`float`, rad): Size of target along x-axis
- **size_y** (`float`, rad): Size of target along y-axis
- **x** (`float`, m): X Position of the landing target in MAV_FRAME
- **y** (`float`, m): Y Position of the landing target in MAV_FRAME
- **z** (`float`, m): Z Position of the landing target in MAV_FRAME
- **q** (`float[4]`): Quaternion of landing target orientation (w, x, y, z order, zero-rotation is 1, 0, 0, 0)
- **type** (`uint8_t`): Type of landing target
- **position_valid** (`uint8_t`): Position fields (x, y, z, q, type) contain valid target position information (MAV_BOOL_FALSE: invalid values). Values not equal to 0 or 1 are invalid.

--- chunk_id: chunk-0103
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 280
content_hash: 3001bf0886e45ec8
prev_chunk_id: chunk-0102
next_chunk_id: chunk-0104
section_heading: FENCE_STATUS (msg id 162, dialect common)
document_type: technical_reference

## FENCE_STATUS (msg id 162, dialect common)

Status of geo-fencing. Sent in extended status stream when fencing enabled. ### Fields

- **breach_status** (`uint8_t`): Breach status (0 if currently inside fence, 1 if outside). - **breach_count** (`uint16_t`): Number of fence breaches. - **breach_type** (`uint8_t`): Last breach type. - **breach_time** (`uint32_t`, ms): Time (since boot) of last breach. - **breach_mitigation** (`uint8_t`): Active action to prevent fence breach

### MAG_CAL_REPORT (msg id 192, dialect common)
Reports results of completed compass calibration. Sent until MAG_CAL_ACK received. ### Fields

- **compass_id** (`uint8_t`): Compass being calibrated. - **cal_mask** (`uint8_t`): Bitmask of compasses being calibrated. - **cal_status** (`uint8_t`): Calibration Status. - **autosaved** (`uint8_t`): 0=requires a MAV_CMD_DO_ACCEPT_MAG_CAL, 1=saved to parameters. - **fitness** (`float`, mgauss): RMS milligauss residuals. - **ofs_x** (`float`): X offset. - **ofs_y** (`float`): Y offset. - **ofs_z** (`float`): Z offset. - **diag_x** (`float`): X diagonal (matrix 11). - **diag_y** (`float`): Y diagonal (matrix 22). - **diag_z** (`float`): Z diagonal (matrix 33). - **offdiag_x** (`float`): X off-diagonal (matrix 12 and 21). - **offdiag_y** (`float`): Y off-diagonal (matrix 13 and 31). - **offdiag_z** (`float`): Z off-diagonal (matrix 32 and 23). - **orientation_confidence** (`float`): Confidence in orientation (higher is better). - **old_orientation** (`uint8_t`): orientation before calibration. - **new_orientation** (`uint8_t`): orientation after calibration. - **scale_factor** (`float`): field radius correction factor

--- chunk_id: chunk-0104
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 228
content_hash: a4624fbea7d1b4cd
prev_chunk_id: chunk-0103
next_chunk_id: chunk-0105
section_heading: EFI_STATUS (msg id 225, dialect common)
document_type: technical_reference

## EFI_STATUS (msg id 225, dialect common)

EFI status output

### Fields

- **health** (`uint8_t`): EFI health status
- **ecu_index** (`float`): ECU index
- **rpm** (`float`): RPM
- **fuel_consumed** (`float`, cm^3): Fuel consumed
- **fuel_flow** (`float`, cm^3/min): Fuel flow rate
- **engine_load** (`float`, %): Engine load
- **throttle_position** (`float`, %): Throttle position
- **spark_dwell_time** (`float`, ms): Spark dwell time
- **barometric_pressure** (`float`, kPa): Barometric pressure
- **intake_manifold_pressure** (`float`, kPa): Intake manifold pressure(
- **intake_manifold_temperature** (`float`, degC): Intake manifold temperature
- **cylinder_head_temperature** (`float`, degC): Cylinder head temperature
- **ignition_timing** (`float`, deg): Ignition timing (Crank angle degrees)
- **injection_time** (`float`, ms): Injection time
- **exhaust_gas_temperature** (`float`, degC): Exhaust gas temperature
- **throttle_out** (`float`, %): Output throttle
- **pt_compensation** (`float`): Pressure/temperature compensation
- **ignition_voltage** (`float`, V): Supply voltage to EFI sparking system. Zero in this value means "unknown", so if the supply voltage really is zero volts use 0.0001 instead. - **fuel_pressure** (`float`, kPa): Fuel pressure. Zero in this value means "unknown", so if the fuel pressure really is zero kPa use 0.0001 instead.

--- chunk_id: chunk-0105
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 333
content_hash: c4d942b3b7caf51c
prev_chunk_id: chunk-0104
next_chunk_id: chunk-0106
section_heading: ESTIMATOR_STATUS (msg id 230, dialect common)
document_type: technical_reference

## ESTIMATOR_STATUS (msg id 230, dialect common)

Estimator status message including flags, innovation test ratios and estimated accuracies. The flags message is an integer bitmask containing information on which EKF outputs are valid. See the ESTIMATOR_STATUS_FLAGS enum definition for further information. The innovation test ratios show the magnitude of the sensor innovation divided by the innovation check threshold. Under normal operation the innovation test ratios should be below 0.5 with occasional values up to 1.0. Values greater than 1.0 should be rare under normal operation and indicate that a measurement has been rejected by the filter. The user should be notified if an innovation test ratio greater than 1.0 is recorded. Notifications for values in the range between 0.5 and 1.0 should be optional and controllable by the user. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **flags** (`uint16_t`): Bitmap indicating which EKF outputs are valid. - **vel_ratio** (`float`): Velocity innovation test ratio
- **pos_horiz_ratio** (`float`): Horizontal position innovation test ratio
- **pos_vert_ratio** (`float`): Vertical position innovation test ratio
- **mag_ratio** (`float`): Magnetometer innovation test ratio
- **hagl_ratio** (`float`): Height above terrain innovation test ratio
- **tas_ratio** (`float`): True airspeed innovation test ratio
- **pos_horiz_accuracy** (`float`, m): Horizontal position 1-STD accuracy relative to the EKF local origin
- **pos_vert_accuracy** (`float`, m): Vertical position 1-STD accuracy relative to the EKF local origin

--- chunk_id: chunk-0106
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 249
content_hash: 0c4330a0228da20d
prev_chunk_id: chunk-0105
next_chunk_id: chunk-0107
section_heading: WIND_COV (msg id 231, dialect common)
document_type: technical_reference

## WIND_COV (msg id 231, dialect common)

Wind estimate from vehicle. Note that despite the name, this message does not actually contain any covariances but instead variability and accuracy fields in terms of standard deviation (1-STD). ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **wind_x** (`float`, m/s): Wind in North (NED) direction (NAN if unknown)
- **wind_y** (`float`, m/s): Wind in East (NED) direction (NAN if unknown)
- **wind_z** (`float`, m/s): Wind in down (NED) direction (NAN if unknown)
- **var_horiz** (`float`, m/s): Variability of wind in XY, 1-STD estimated from a 1 Hz lowpassed wind estimate (NAN if unknown)
- **var_vert** (`float`, m/s): Variability of wind in Z, 1-STD estimated from a 1 Hz lowpassed wind estimate (NAN if unknown)
- **wind_alt** (`float`, m): Altitude (MSL) that this measurement was taken at (NAN if unknown)
- **horiz_accuracy** (`float`, m/s): Horizontal speed 1-STD accuracy (0 if unknown)
- **vert_accuracy** (`float`, m/s): Vertical speed 1-STD accuracy (0 if unknown)

--- chunk_id: chunk-0107
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 341
content_hash: 96a560120a7ad05d
prev_chunk_id: chunk-0106
next_chunk_id: chunk-0108
section_heading: GPS_INPUT (msg id 232, dialect common)
document_type: technical_reference

## GPS_INPUT (msg id 232, dialect common)

GPS sensor input message. This is a raw sensor value sent by the GPS. This is NOT the global position estimate of the system. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **gps_id** (`uint8_t`): ID of the GPS for multiple GPS inputs
- **ignore_flags** (`uint16_t`): Bitmap indicating which GPS input flags fields to ignore. All other fields must be provided. - **time_week_ms** (`uint32_t`, ms): GPS time (from start of GPS week)
- **time_week** (`uint16_t`): GPS week number
- **fix_type** (`uint8_t`): GNSS fix type
- **lat** (`int32_t`, degE7): Latitude (WGS84)
- **lon** (`int32_t`, degE7): Longitude (WGS84)
- **alt** (`float`, m): Altitude (MSL). Positive for up. - **hdop** (`float`): GPS HDOP horizontal dilution of position (unitless). If unknown, set to: UINT16_MAX
- **vdop** (`float`): GPS VDOP vertical dilution of position (unitless). If unknown, set to: UINT16_MAX
- **vn** (`float`, m/s): GPS velocity in north direction in earth-fixed NED frame
- **ve** (`float`, m/s): GPS velocity in east direction in earth-fixed NED frame
- **vd** (`float`, m/s): GPS velocity in down direction in earth-fixed NED frame
- **speed_accuracy** (`float`, m/s): GPS speed accuracy
- **horiz_accuracy** (`float`, m): GPS horizontal accuracy
- **vert_accuracy** (`float`, m): GPS vertical accuracy
- **satellites_visible** (`uint8_t`): Number of satellites visible. - **yaw** (`uint16_t`, cdeg): Yaw of vehicle relative to Earth's North, zero means not available, use 36000 for north

--- chunk_id: chunk-0108
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 209
content_hash: e0a67924616e6cb9
prev_chunk_id: chunk-0107
next_chunk_id: chunk-0109
section_heading: GPS_RTCM_DATA (msg id 233, dialect common)
document_type: technical_reference

## GPS_RTCM_DATA (msg id 233, dialect common)

RTCM message for injecting into the onboard GPS (used for DGPS)

### Fields

- **flags** (`uint8_t`): LSB: 1 means message is fragmented, next 2 bits are the fragment ID, the remaining 5 bits are used for the sequence ID. Messages are only to be flushed to the GPS when the entire message has been reconstructed on the autopilot. The fragment ID specifies which order the fragments should be assembled into a buffer, while the sequence ID is used to detect a mismatch between different buffers. The buffer is considered fully reconstructed when either all 4 fragments are present, or all the fragments before the first fragment with a non full payload is received. This management is used to ensure that normal GPS operation doesn't corrupt RTCM data, and to recover from a unreliable transport delivery order. - **len** (`uint8_t`, bytes): data length
- **data** (`uint8_t[180]`): RTCM message (may be fragmented)

--- chunk_id: chunk-0109
source_document: messages_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 272
content_hash: e9edc30df1871d2a
prev_chunk_id: chunk-0108
next_chunk_id: chunk-0110
section_heading: HIGH_LATENCY (msg id 234, dialect common)
document_type: technical_reference

## HIGH_LATENCY (msg id 234, dialect common)

Message appropriate for high latency connections like Iridium

### Fields

- **base_mode** (`uint8_t`): Bitmap of enabled system modes. - **custom_mode** (`uint32_t`): A bitfield for use for autopilot-specific flags. - **landed_state** (`uint8_t`): The landed state. Is set to MAV_LANDED_STATE_UNDEFINED if landed state is unknown. - **roll** (`int16_t`, cdeg): roll
- **pitch** (`int16_t`, cdeg): pitch
- **heading** (`uint16_t`, cdeg): heading
- **throttle** (`int8_t`, %): throttle (percentage)
- **heading_sp** (`int16_t`, cdeg): heading setpoint
- **latitude** (`int32_t`, degE7): Latitude
- **longitude** (`int32_t`, degE7): Longitude
- **altitude_amsl** (`int16_t`, m): Altitude above mean sea level
- **altitude_sp** (`int16_t`, m): Altitude setpoint relative to the home position
- **airspeed** (`uint8_t`, m/s): airspeed
- **airspeed_sp** (`uint8_t`, m/s): airspeed setpoint
- **groundspeed** (`uint8_t`, m/s): groundspeed
- **climb_rate** (`int8_t`, m/s): climb rate
- **gps_nsat** (`uint8_t`): Number of satellites visible. If unknown, set to UINT8_MAX
- **gps_fix_type** (`uint8_t`): GPS Fix type. - **battery_remaining** (`uint8_t`, %): Remaining battery (percentage)
- **temperature** (`int8_t`, degC): Autopilot temperature (degrees C)
- **temperature_air** (`int8_t`, degC): Air temperature (degrees C) from airspeed sensor
- **failsafe** (`uint8_t`): failsafe (each bit represents a failsafe where 0=ok, 1=failsafe active (bit0:RC, bit1:batt, bit2:GPS, bit3:GCS, bit4:fence)
- **wp_num** (`uint8_t`): current waypoint number
- **wp_distance** (`uint16_t`, m): distance to target

--- chunk_id: chunk-0110
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: a3c17d53cc08fbee
prev_chunk_id: chunk-0109
next_chunk_id: chunk-0111
section_heading: MAVLink messages batch 6
document_type: technical_reference

# MAVLink messages batch 6

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0111
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 308
content_hash: 5914faf45dc05c4d
prev_chunk_id: chunk-0110
next_chunk_id: chunk-0112
section_heading: HIGH_LATENCY2 (msg id 235, dialect common)
document_type: technical_reference

## HIGH_LATENCY2 (msg id 235, dialect common)

Message appropriate for high latency connections like Iridium (version 2)

### Fields

- **timestamp** (`uint32_t`, ms): Timestamp (milliseconds since boot or Unix epoch)
- **type** (`uint8_t`): Type of the MAV (quadrotor, helicopter, etc.)
- **autopilot** (`uint8_t`): Autopilot type / class. Use MAV_AUTOPILOT_INVALID for components that are not flight controllers. - **custom_mode** (`uint16_t`): A bitfield for use for autopilot-specific flags (2 byte version). - **latitude** (`int32_t`, degE7): Latitude
- **longitude** (`int32_t`, degE7): Longitude
- **altitude** (`int16_t`, m): Altitude above mean sea level
- **target_altitude** (`int16_t`, m): Altitude setpoint
- **heading** (`uint8_t`, deg/2): Heading
- **target_heading** (`uint8_t`, deg/2): Heading setpoint
- **target_distance** (`uint16_t`, dam): Distance to target waypoint or position
- **throttle** (`uint8_t`, %): Throttle
- **airspeed** (`uint8_t`, m/s*5): Airspeed
- **airspeed_sp** (`uint8_t`, m/s*5): Airspeed setpoint
- **groundspeed** (`uint8_t`, m/s*5): Groundspeed
- **windspeed** (`uint8_t`, m/s*5): Windspeed
- **wind_heading** (`uint8_t`, deg/2): Wind heading
- **eph** (`uint8_t`, dm): Maximum error horizontal position since last message
- **epv** (`uint8_t`, dm): Maximum error vertical position since last message
- **temperature_air** (`int8_t`, degC): Air temperature
- **climb_rate** (`int8_t`, dm/s): Maximum climb rate magnitude since last message
- **battery** (`int8_t`, %): Battery level (-1 if field not provided). - **wp_num** (`uint16_t`): Current waypoint number
- **failure_flags** (`uint16_t`): Bitmap of failure flags. - **custom0** (`int8_t`): Field for custom payload. - **custom1** (`int8_t`): Field for custom payload. - **custom2** (`int8_t`): Field for custom payload.

--- chunk_id: chunk-0112
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: 0f7ee4febad57a15
prev_chunk_id: chunk-0111
next_chunk_id: chunk-0113
section_heading: VIBRATION (msg id 241, dialect common)
document_type: technical_reference

## VIBRATION (msg id 241, dialect common)

Vibration levels and accelerometer clipping

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **vibration_x** (`float`): Vibration levels on X-axis
- **vibration_y** (`float`): Vibration levels on Y-axis
- **vibration_z** (`float`): Vibration levels on Z-axis
- **clipping_0** (`uint32_t`): first accelerometer clipping count
- **clipping_1** (`uint32_t`): second accelerometer clipping count
- **clipping_2** (`uint32_t`): third accelerometer clipping count

### HOME_POSITION (msg id 242, dialect common)
Contains the home position. The home position is the default position that the system will return to and land on. The position must be set automatically by the system during the takeoff, and may also be explicitly set using MAV_CMD_DO_SET_HOME. The global and local positions encode the position in the respective coordinate frames, while the q parameter encodes the orientation of the surface. Under normal conditions it describes the heading and terrain slope, which can be used by the aircraft to adjust the approach. The approach 3D vector describes the point to which the system should fly in normal flight mode and then perform a landing sequence along the vector. Note: this message can be requested by sending the MAV_CMD_REQUEST_MESSAGE with param1=242. ### Fields

- **latitude** (`int32_t`, degE7): Latitude (WGS84)
- **longitude** (`int32_t`, degE7): Longitude (WGS84)
- **altitude** (`int32_t`, mm): Altitude (MSL). Positive for up. - **x** (`float`, m): Local X position of this position in the local coordinate frame (NED)
- **y** (`float`, m): Local Y position of this position in the local coordinate frame (NED)
- **z** (`float`, m): Local Z position of this position in the local coordinate frame (NED: positive "down")
- **q** (`float[4]`): Quaternion indicating world-to-surface-normal and heading transformation of the takeoff position. Used to indicate the heading and slope of the ground. All fields should be set to NaN if an accurate quaternion for both heading and surface slope cannot be supplied. - **approach_x** (`float`, m): Local X position of the end of the approach vector. Multicopters should set this position based on their takeoff path. Grass-landing fixed wing aircraft should set it the same way as multicopters.

--- chunk_id: chunk-0113
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 266
content_hash: 96915d3d6bda9e3d
prev_chunk_id: chunk-0112
next_chunk_id: chunk-0114
section_heading: VIBRATION (msg id 241, dialect common)
document_type: technical_reference

Multicopters should set this position based on their takeoff path. Grass-landing fixed wing aircraft should set it the same way as multicopters. Runway-landing fixed wing aircraft should set it to the opposite direction of the takeoff, assuming the takeoff happened from the threshold / touchdown zone. - **approach_y** (`float`, m): Local Y position of the end of the approach vector. Multicopters should set this position based on their takeoff path. Grass-landing fixed wing aircraft should set it the same way as multicopters. Runway-landing fixed wing aircraft should set it to the opposite direction of the takeoff, assuming the takeoff happened from the threshold / touchdown zone. - **approach_z** (`float`, m): Local Z position of the end of the approach vector. Multicopters should set this position based on their takeoff path. Grass-landing fixed wing aircraft should set it the same way as multicopters. Runway-landing fixed wing aircraft should set it to the opposite direction of the takeoff, assuming the takeoff happened from the threshold / touchdown zone. - **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.

--- chunk_id: chunk-0114
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: 8ea25ca1033e92c5
prev_chunk_id: chunk-0113
next_chunk_id: chunk-0115
section_heading: SET_HOME_POSITION (msg id 243, dialect common)
document_type: technical_reference

## SET_HOME_POSITION (msg id 243, dialect common)

Sets the home position. The home position is the default position that the system will return to and land on. The position is set automatically by the system during the takeoff (and may also be set using this message). The global and local positions encode the position in the respective coordinate frames, while the q parameter encodes the orientation of the surface. Under normal conditions it describes the heading and terrain slope, which can be used by the aircraft to adjust the approach. The approach 3D vector describes the point to which the system should fly in normal flight mode and then perform a landing sequence along the vector. Note: the current home position may be emitted in a HOME_POSITION message on request (using MAV_CMD_REQUEST_MESSAGE with param1=242). ### Fields

- **target_system** (`uint8_t`): System ID. - **latitude** (`int32_t`, degE7): Latitude (WGS84)
- **longitude** (`int32_t`, degE7): Longitude (WGS84)
- **altitude** (`int32_t`, mm): Altitude (MSL). Positive for up. - **x** (`float`, m): Local X position of this position in the local coordinate frame (NED)
- **y** (`float`, m): Local Y position of this position in the local coordinate frame (NED)
- **z** (`float`, m): Local Z position of this position in the local coordinate frame (NED: positive "down")
- **q** (`float[4]`): World to surface normal and heading transformation of the takeoff position. Used to indicate the heading and slope of the ground
- **approach_x** (`float`, m): Local X position of the end of the approach vector. Multicopters should set this position based on their takeoff path. Grass-landing fixed wing aircraft should set it the same way as multicopters. Runway-landing fixed wing aircraft should set it to the opposite direction of the takeoff, assuming the takeoff happened from the threshold / touchdown zone. - **approach_y** (`float`, m): Local Y position of the end of the approach vector. Multicopters should set this position based on their takeoff path. Grass-landing fixed wing aircraft should set it the same way as multicopters. Runway-landing fixed wing aircraft should set it to the opposite direction of the takeoff, assuming the takeoff happened from the threshold / touchdown zone. - **approach_z** (`float`, m): Local Z position of the end of the approach vector. Multicopters should set this position based on their takeoff path.

--- chunk_id: chunk-0115
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 125
content_hash: 5da0fe4e0df4e0f2
prev_chunk_id: chunk-0114
next_chunk_id: chunk-0116
section_heading: SET_HOME_POSITION (msg id 243, dialect common)
document_type: technical_reference

- **approach_z** (`float`, m): Local Z position of the end of the approach vector. Multicopters should set this position based on their takeoff path. Grass-landing fixed wing aircraft should set it the same way as multicopters. Runway-landing fixed wing aircraft should set it to the opposite direction of the takeoff, assuming the takeoff happened from the threshold / touchdown zone. - **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.

--- chunk_id: chunk-0116
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 197
content_hash: ecc406a62fb75b21
prev_chunk_id: chunk-0115
next_chunk_id: chunk-0117
section_heading: MESSAGE_INTERVAL (msg id 244, dialect common)
document_type: technical_reference

## MESSAGE_INTERVAL (msg id 244, dialect common)

The interval between messages for a particular MAVLink message ID. This message is sent in response to the MAV_CMD_REQUEST_MESSAGE command with param1=244 (this message) and param2=message_id (the id of the message for which the interval is required). This interface replaces DATA_STREAM. ### Fields

- **message_id** (`uint16_t`): The ID of the requested MAVLink message. v1.0 is limited to 254 messages. - **interval_us** (`int32_t`, us): The interval between two messages. A value of -1 indicates this stream is disabled, 0 indicates it is not available, > 0 indicates the interval at which it is sent. ### EXTENDED_SYS_STATE (msg id 245, dialect common)
Provides state for additional features

### Fields

- **vtol_state** (`uint8_t`): The VTOL state if applicable. Is set to MAV_VTOL_STATE_UNDEFINED if UAV is not in VTOL configuration. - **landed_state** (`uint8_t`): The landed state. Is set to MAV_LANDED_STATE_UNDEFINED if landed state is unknown.

--- chunk_id: chunk-0117
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 182
content_hash: 16bc78dff9870ff1
prev_chunk_id: chunk-0116
next_chunk_id: chunk-0118
section_heading: ADSB_VEHICLE (msg id 246, dialect common)
document_type: technical_reference

## ADSB_VEHICLE (msg id 246, dialect common)

The location and information of an ADSB vehicle

### Fields

- **ICAO_address** (`uint32_t`): ICAO address
- **lat** (`int32_t`, degE7): Latitude
- **lon** (`int32_t`, degE7): Longitude
- **altitude_type** (`uint8_t`): ADSB altitude type. - **altitude** (`int32_t`, mm): Altitude (ASL)
- **heading** (`uint16_t`, cdeg): Course over ground
- **hor_velocity** (`uint16_t`, cm/s): The horizontal velocity
- **ver_velocity** (`int16_t`, cm/s): The vertical velocity. Positive is up
- **callsign** (`char[9]`): The callsign, 8+null
- **emitter_type** (`uint8_t`): ADSB emitter type. - **tslc** (`uint8_t`, s): Time since last communication. This is the age of the ADS-B information in this message, in seconds. - **flags** (`uint16_t`): Bitmap to indicate various statuses including valid data fields
- **squawk** (`uint16_t`): Squawk code. Note that the code is in decimal: e.g. 7700 (general emergency) is encoded as binary 0b0001_1110_0001_0100, not(!) as 0b0000_111_111_000_000

--- chunk_id: chunk-0118
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 408
content_hash: db331500508faef4
prev_chunk_id: chunk-0117
next_chunk_id: chunk-0119
section_heading: COLLISION (msg id 247, dialect common)
document_type: technical_reference

## COLLISION (msg id 247, dialect common)

Information about a potential collision

### Fields

- **src** (`uint8_t`): Collision data source
- **id** (`uint32_t`): Unique identifier, domain based on src field
- **action** (`uint8_t`): Action that is being taken to avoid this collision
- **threat_level** (`uint8_t`): How concerned the aircraft is about this collision
- **time_to_minimum_delta** (`float`, s): Estimated time until collision occurs
- **altitude_minimum_delta** (`float`, m): Closest vertical distance between vehicle and object
- **horizontal_minimum_delta** (`float`, m): Closest horizontal distance between vehicle and object

### V2_EXTENSION (msg id 248, dialect common)
Message implementing parts of the V2 payload specs in V1 frames for transitional support. ### Fields

- **target_network** (`uint8_t`): Network ID (0 for broadcast)
- **target_system** (`uint8_t`): System ID (0 for broadcast)
- **target_component** (`uint8_t`): Component ID (0 for broadcast)
- **message_type** (`uint16_t`): A code that identifies the software component that understands this message (analogous to USB device classes or mime type strings). If this code is less than 32768, it is considered a 'registered' protocol extension and the corresponding entry should be added to https://github.com/mavlink/mavlink/definition_files/extension_message_ids.xml. Software creators can register blocks of message IDs as needed (useful for GCS specific metadata, etc...). Message_types greater than 32767 are considered local experiments and should not be checked in to any widely distributed codebase. - **payload** (`uint8_t[249]`): Variable length payload. The length must be encoded in the payload as part of the message_type protocol, e.g. by including the length as payload data, or by terminating the payload data with a non-zero marker. This is required in order to reconstruct zero-terminated payloads that are (or otherwise would be) trimmed by MAVLink 2 empty-byte truncation. The entire content of the payload block is opaque unless you understand the encoding message_type. The particular encoding used can be extension specific and might not always be documented as part of the MAVLink specification.

--- chunk_id: chunk-0119
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 217
content_hash: afc77897ded54f89
prev_chunk_id: chunk-0118
next_chunk_id: chunk-0120
section_heading: MEMORY_VECT (msg id 249, dialect common)
document_type: technical_reference

## MEMORY_VECT (msg id 249, dialect common)

Send raw controller memory. The use of this message is discouraged for normal packets, but a quite efficient way for testing new messages and getting experimental debug output. ### Fields

- **address** (`uint16_t`): Starting address of the debug variables
- **ver** (`uint8_t`): Version code of the type variable. 0=unknown, type ignored and assumed int16_t. 1=as below
- **type** (`uint8_t`): Type code of the memory variables. for ver = 1: 0=16 x int16_t, 1=16 x uint16_t, 2=16 x Q15, 3=16 x 1Q14
- **value** (`int8_t[32]`): Memory contents at specified address

### DEBUG_VECT (msg id 250, dialect common)
To debug something using a named 3D vector. ### Fields

- **name** (`char[10]`): Name
- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **x** (`float`): x
- **y** (`float`): y
- **z** (`float`): z

--- chunk_id: chunk-0120
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 370
content_hash: 37ba46c530ac3843
prev_chunk_id: chunk-0119
next_chunk_id: chunk-0121
section_heading: NAMED_VALUE_FLOAT (msg id 251, dialect common)
document_type: technical_reference

## NAMED_VALUE_FLOAT (msg id 251, dialect common)

Send a key-value pair as float. The use of this message is discouraged for normal packets, but a quite efficient way for testing new messages and getting experimental debug output. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **name** (`char[10]`): Name of the debug variable
- **value** (`float`): Floating point value

### NAMED_VALUE_INT (msg id 252, dialect common)
Send a key-value pair as integer. The use of this message is discouraged for normal packets, but a quite efficient way for testing new messages and getting experimental debug output. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **name** (`char[10]`): Name of the debug variable
- **value** (`int32_t`): Signed integer value

### STATUSTEXT (msg id 253, dialect common)
Status text message. These messages are printed in yellow in the COMM console of QGroundControl. WARNING: They consume quite some bandwidth, so use only for important status and error messages. If implemented wisely, these messages are buffered on the MCU and sent only at a limited rate (e.g. 10 Hz). ### Fields

- **severity** (`uint8_t`): Severity of status. Relies on the definitions within RFC-5424. - **text** (`char[50]`): Status text message, without null termination character. UTF-8 encoded. - **id** (`uint16_t`): Unique (opaque) identifier for this statustext message. May be used to reassemble a logical long-statustext message from a sequence of chunks. A value of zero indicates this is the only chunk in the sequence and the message can be emitted immediately. - **chunk_seq** (`uint8_t`): This chunk's sequence number; indexing is from zero. Any null character in the text field is taken to mean this was the last chunk.

--- chunk_id: chunk-0121
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 250
content_hash: 2ac59522ee5ebb9b
prev_chunk_id: chunk-0120
next_chunk_id: chunk-0122
section_heading: DEBUG (msg id 254, dialect common)
document_type: technical_reference

## DEBUG (msg id 254, dialect common)

Send a debug value. The index is used to discriminate between values. These values show up in the plot of QGroundControl as DEBUG N. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **ind** (`uint8_t`): index of debug variable
- **value** (`float`): DEBUG value

### SETUP_SIGNING (msg id 256, dialect common)
Setup a MAVLink2 signing key. If called with secret_key of all zero and zero initial_timestamp will disable signing

### Fields

- **target_system** (`uint8_t`): system id of the target
- **target_component** (`uint8_t`): component ID of the target
- **secret_key** (`uint8_t[32]`): signing key
- **initial_timestamp** (`uint64_t`): initial timestamp

### BUTTON_CHANGE (msg id 257, dialect common)
Report button state change. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **last_change_ms** (`uint32_t`, ms): Time of last change of button state. - **state** (`uint8_t`): Bitmap for state of buttons. ### PLAY_TUNE (msg id 258, dialect common)
Control vehicle tone generation (buzzer). ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **tune** (`char[30]`): tune in board specific format
- **tune2** (`char[200]`): tune extension (appended to tune)

--- chunk_id: chunk-0122
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: bf0494b4e672be95
prev_chunk_id: chunk-0121
next_chunk_id: chunk-0123
section_heading: CAMERA_INFORMATION (msg id 259, dialect common)
document_type: technical_reference

## CAMERA_INFORMATION (msg id 259, dialect common)

Information about a camera. Can be requested with a MAV_CMD_REQUEST_MESSAGE command. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **vendor_name** (`uint8_t[32]`): Name of the camera vendor
- **model_name** (`uint8_t[32]`): Name of the camera model
- **firmware_version** (`uint32_t`): Version of the camera firmware, encoded as: `(Dev & 0xff) << 24 + (Patch & 0xff) << 16 + (Minor & 0xff) << 8 + (Major & 0xff)`. Use 0 if not known. - **focal_length** (`float`, mm): Focal length. Use NaN if not known. - **sensor_size_h** (`float`, mm): Image sensor size horizontal. Use NaN if not known. - **sensor_size_v** (`float`, mm): Image sensor size vertical. Use NaN if not known. - **resolution_h** (`uint16_t`, pix): Horizontal image resolution. Use 0 if not known. - **resolution_v** (`uint16_t`, pix): Vertical image resolution. Use 0 if not known. - **lens_id** (`uint8_t`): Reserved for a lens ID. Use 0 if not known. - **flags** (`uint32_t`): Bitmap of camera capability flags. - **cam_definition_version** (`uint16_t`): Camera definition version (iteration). Use 0 if not known. - **cam_definition_uri** (`char[140]`): Camera definition URI (if any, otherwise only basic functions will be available). HTTP- (http://) and MAVLink FTP- (mavlinkftp://) formatted URIs are allowed (and both must be supported by any GCS that implements the Camera Protocol). The definition file may be xz compressed, which will be indicated by the file extension .xml.xz (a GCS that implements the protocol must support decompressing the file). The string needs to be zero terminated. Use a zero-length string if not known. - **gimbal_device_id** (`uint8_t`): Gimbal id of a gimbal associated with this camera. This is the component id of the gimbal device, or 1-6 for non mavlink gimbals. Use 0 if no gimbal is associated with the camera. - **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id).

--- chunk_id: chunk-0123
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 486
content_hash: d925f6e038279aac
prev_chunk_id: chunk-0122
next_chunk_id: chunk-0124
section_heading: CAMERA_SETTINGS (msg id 260, dialect common)
document_type: technical_reference

## CAMERA_SETTINGS (msg id 260, dialect common)

Settings of a camera. Can be requested with a MAV_CMD_REQUEST_MESSAGE command. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **mode_id** (`uint8_t`): Camera mode
- **zoomLevel** (`float`): Current zoom level as a percentage of the full range (0.0 to 100.0, NaN if not known)
- **focusLevel** (`float`): Current focus level as a percentage of the full range (0.0 to 100.0, NaN if not known)
- **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id). ### STORAGE_INFORMATION (msg id 261, dialect common)
Information about a storage medium. This message is sent in response to a request with MAV_CMD_REQUEST_MESSAGE and whenever the status of the storage changes (STORAGE_STATUS). Use MAV_CMD_REQUEST_MESSAGE.param2 to indicate the index/id of requested storage: 0 for all, 1 for first, 2 for second, etc. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **storage_id** (`uint8_t`): Storage ID (1 for first, 2 for second, etc.)
- **storage_count** (`uint8_t`): Number of storage devices
- **status** (`uint8_t`): Status of storage
- **total_capacity** (`float`, MiB): Total capacity. If storage is not ready (STORAGE_STATUS_READY) value will be ignored. - **used_capacity** (`float`, MiB): Used capacity. If storage is not ready (STORAGE_STATUS_READY) value will be ignored. - **available_capacity** (`float`, MiB): Available storage capacity. If storage is not ready (STORAGE_STATUS_READY) value will be ignored. - **read_speed** (`float`, MiB/s): Read speed. - **write_speed** (`float`, MiB/s): Write speed. - **type** (`uint8_t`): Type of storage
- **name** (`char[32]`): Textual storage name to be used in UI (microSD 1, Internal Memory, etc.) This is a NULL terminated string. If it is exactly 32 characters long, add a terminating NULL. If this string is empty, the generic type is shown to the user. - **storage_usage** (`uint8_t`): Flags indicating whether this instance is preferred storage for photos, videos, etc. Note: Implementations should initially set the flags on the system-default storage id used for saving media (if possible/supported). This setting can then be overridden using MAV_CMD_SET_STORAGE_USAGE. If the media usage flags are not set, a GCS may assume storage ID 1 is the default storage for all media types.

--- chunk_id: chunk-0124
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 208
content_hash: e0ee69c43bee0542
prev_chunk_id: chunk-0123
next_chunk_id: chunk-0125
section_heading: CAMERA_CAPTURE_STATUS (msg id 262, dialect common)
document_type: technical_reference

## CAMERA_CAPTURE_STATUS (msg id 262, dialect common)

Information about the status of a capture. Can be requested with a MAV_CMD_REQUEST_MESSAGE command. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **image_status** (`uint8_t`): Current status of image capturing (0: idle, 1: capture in progress, 2: interval set but idle, 3: interval set and capture in progress)
- **video_status** (`uint8_t`): Current status of video capturing (0: idle, 1: capture in progress)
- **image_interval** (`float`, s): Image capture interval
- **recording_time_ms** (`uint32_t`, ms): Elapsed time since recording started (0: Not supported/available). A GCS should compute recording time and use non-zero values of this field to correct any discrepancy. - **available_capacity** (`float`, MiB): Available storage capacity. - **image_count** (`int32_t`): Total number of images captured ('forever', or until reset using MAV_CMD_STORAGE_FORMAT). - **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id).

--- chunk_id: chunk-0125
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: 1795398c577ec697
prev_chunk_id: chunk-0124
next_chunk_id: chunk-0126
section_heading: CAMERA_IMAGE_CAPTURED (msg id 263, dialect common)
document_type: technical_reference

## CAMERA_IMAGE_CAPTURED (msg id 263, dialect common)

Information about a captured image. This is emitted every time a message is captured. MAV_CMD_REQUEST_MESSAGE can be used to (re)request this message for a specific sequence number or range of sequence numbers:
        MAV_CMD_REQUEST_MESSAGE.param2 indicates the sequence number the first image to send, or set to -1 to send the message for all sequence numbers. MAV_CMD_REQUEST_MESSAGE.param3 is used to specify a range of messages to send:
        set to 0 (default) to send just the the message for the sequence number in param 2,
        set to -1 to send the message for the sequence number in param 2 and all the following sequence numbers,
        set to the sequence number of the final message in the range. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **time_utc** (`uint64_t`, us): Timestamp (time since UNIX epoch) in UTC. 0 for unknown. - **camera_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id). Field name is usually camera_device_id. - **lat** (`int32_t`, degE7): Latitude where image was taken
- **lon** (`int32_t`, degE7): Longitude where capture was taken
- **alt** (`int32_t`, mm): Altitude (MSL) where image was taken
- **relative_alt** (`int32_t`, mm): Altitude above ground
- **q** (`float[4]`): Quaternion of camera orientation (w, x, y, z order, zero-rotation is 1, 0, 0, 0)
- **image_index** (`int32_t`): Zero based index of this image (i.e. a new image will have index CAMERA_CAPTURE_STATUS.image count -1)
- **capture_result** (`int8_t`): Image was captured successfully (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **file_url** (`char[205]`): URL of image taken. Either local storage or http://foo.jpg if camera provides an HTTP interface.

--- chunk_id: chunk-0126
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 193
content_hash: 9fc46353c349069f
prev_chunk_id: chunk-0125
next_chunk_id: chunk-0127
section_heading: FLIGHT_INFORMATION (msg id 264, dialect common)
document_type: technical_reference

## FLIGHT_INFORMATION (msg id 264, dialect common)

Flight information. This includes time since boot for arm, takeoff, and land, and a flight number. Takeoff and landing values reset to zero on arm. This can be requested using MAV_CMD_REQUEST_MESSAGE. Note, some fields are misnamed - timestamps are from boot (not UTC) and the flight_uuid is a sequence number. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **arming_time_utc** (`uint64_t`, us): Timestamp at arming (since system boot). Set to 0 on boot. Set value on arming. Note, field is misnamed UTC. - **takeoff_time_utc** (`uint64_t`, us): Timestamp at takeoff (since system boot). Set to 0 at boot and on arming. Note, field is misnamed UTC. - **flight_uuid** (`uint64_t`): Flight number. Note, field is misnamed UUID. - **landing_time** (`uint32_t`, ms): Timestamp at landing (in ms since system boot). Set to 0 at boot and on arming.

--- chunk_id: chunk-0127
source_document: messages_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 108
content_hash: 028221ca20709fef
prev_chunk_id: chunk-0126
next_chunk_id: chunk-0128
section_heading: MOUNT_ORIENTATION (msg id 265, dialect common)
document_type: technical_reference

## MOUNT_ORIENTATION (msg id 265, dialect common)

Orientation of a mount

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **roll** (`float`, deg): Roll in global frame (set to NaN for invalid). - **pitch** (`float`, deg): Pitch in global frame (set to NaN for invalid). - **yaw** (`float`, deg): Yaw relative to vehicle (set to NaN for invalid). - **yaw_absolute** (`float`, deg): Yaw in absolute frame relative to Earth's North, north is 0 (set to NaN for invalid).

--- chunk_id: chunk-0128
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: e261d1fb2a9cbae2
prev_chunk_id: chunk-0127
next_chunk_id: chunk-0129
section_heading: MAVLink messages batch 7
document_type: technical_reference

# MAVLink messages batch 7

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0129
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 222
content_hash: f7ad1cf4dde46533
prev_chunk_id: chunk-0128
next_chunk_id: chunk-0130
section_heading: LOGGING_DATA (msg id 266, dialect common)
document_type: technical_reference

## LOGGING_DATA (msg id 266, dialect common)

A message containing logged data (see also MAV_CMD_LOGGING_START)

### Fields

- **target_system** (`uint8_t`): system ID of the target
- **target_component** (`uint8_t`): component ID of the target
- **sequence** (`uint16_t`): sequence number (can wrap)
- **length** (`uint8_t`, bytes): data length
- **first_message_offset** (`uint8_t`, bytes): offset into data where first message starts. This can be used for recovery, when a previous message got lost (set to UINT8_MAX if no start exists). - **data** (`uint8_t[249]`): logged data

### LOGGING_DATA_ACKED (msg id 267, dialect common)
A message containing logged data which requires a LOGGING_ACK to be sent back

### Fields

- **target_system** (`uint8_t`): system ID of the target
- **target_component** (`uint8_t`): component ID of the target
- **sequence** (`uint16_t`): sequence number (can wrap)
- **length** (`uint8_t`, bytes): data length
- **first_message_offset** (`uint8_t`, bytes): offset into data where first message starts. This can be used for recovery, when a previous message got lost (set to UINT8_MAX if no start exists). - **data** (`uint8_t[249]`): logged data

--- chunk_id: chunk-0130
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 288
content_hash: 3f47829a0a5a89d7
prev_chunk_id: chunk-0129
next_chunk_id: chunk-0131
section_heading: LOGGING_ACK (msg id 268, dialect common)
document_type: technical_reference

## LOGGING_ACK (msg id 268, dialect common)

An ack for a LOGGING_DATA_ACKED message

### Fields

- **target_system** (`uint8_t`): system ID of the target
- **target_component** (`uint8_t`): component ID of the target
- **sequence** (`uint16_t`): sequence number (must match the one in LOGGING_DATA_ACKED)

### VIDEO_STREAM_INFORMATION (msg id 269, dialect common)
Information about video stream. It may be requested using MAV_CMD_REQUEST_MESSAGE, where param2 indicates the video stream id: 0 for all streams, 1 for first, 2 for second, etc. ### Fields

- **stream_id** (`uint8_t`): Video Stream ID (1 for first, 2 for second, etc.)
- **count** (`uint8_t`): Number of streams available. - **type** (`uint8_t`): Type of stream. - **flags** (`uint16_t`): Bitmap of stream status flags. - **framerate** (`float`, Hz): Frame rate. - **resolution_h** (`uint16_t`, pix): Horizontal resolution. - **resolution_v** (`uint16_t`, pix): Vertical resolution. - **bitrate** (`uint32_t`, bits/s): Bit rate. - **rotation** (`uint16_t`, deg): Video image rotation clockwise. - **hfov** (`uint16_t`, deg): Horizontal Field of view. - **name** (`char[32]`): Stream name. - **uri** (`char[160]`): Video stream URI (TCP or RTSP URI ground station should connect to) or port number (UDP port ground station should listen to). - **encoding** (`uint8_t`): Encoding of stream. - **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id).

--- chunk_id: chunk-0131
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: a972530c483a0050
prev_chunk_id: chunk-0130
next_chunk_id: chunk-0132
section_heading: VIDEO_STREAM_STATUS (msg id 270, dialect common)
document_type: technical_reference

## VIDEO_STREAM_STATUS (msg id 270, dialect common)

Information about the status of a video stream. It may be requested using MAV_CMD_REQUEST_MESSAGE. ### Fields

- **stream_id** (`uint8_t`): Video Stream ID (1 for first, 2 for second, etc.)
- **flags** (`uint16_t`): Bitmap of stream status flags
- **framerate** (`float`, Hz): Frame rate
- **resolution_h** (`uint16_t`, pix): Horizontal resolution
- **resolution_v** (`uint16_t`, pix): Vertical resolution
- **bitrate** (`uint32_t`, bits/s): Bit rate
- **rotation** (`uint16_t`, deg): Video image rotation clockwise
- **hfov** (`uint16_t`, deg): Horizontal Field of view
- **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id). ### CAMERA_FOV_STATUS (msg id 271, dialect common)
Information about the field of view of a camera. Can be requested with a MAV_CMD_REQUEST_MESSAGE command. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **lat_camera** (`int32_t`, degE7): Latitude of camera (INT32_MAX if unknown). - **lon_camera** (`int32_t`, degE7): Longitude of camera (INT32_MAX if unknown). - **alt_camera** (`int32_t`, mm): Altitude (MSL) of camera (INT32_MAX if unknown). - **lat_image** (`int32_t`, degE7): Latitude of center of image (INT32_MAX if unknown, INT32_MIN if at infinity, not intersecting with horizon). - **lon_image** (`int32_t`, degE7): Longitude of center of image (INT32_MAX if unknown, INT32_MIN if at infinity, not intersecting with horizon). - **alt_image** (`int32_t`, mm): Altitude (MSL) of center of image (INT32_MAX if unknown, INT32_MIN if at infinity, not intersecting with horizon). - **q** (`float[4]`): Quaternion of camera orientation (w, x, y, z order, zero-rotation is 1, 0, 0, 0)
- **hfov** (`float`, deg): Horizontal field of view (NaN if unknown). - **vfov** (`float`, deg): Vertical field of view (NaN if unknown). - **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id).

--- chunk_id: chunk-0132
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 294
content_hash: 34740a53e96f2baa
prev_chunk_id: chunk-0131
next_chunk_id: chunk-0133
section_heading: CAMERA_TRACKING_IMAGE_STATUS (msg id 275, dialect common)
document_type: technical_reference

## CAMERA_TRACKING_IMAGE_STATUS (msg id 275, dialect common)

Camera tracking status, sent while in active tracking. Use MAV_CMD_SET_MESSAGE_INTERVAL to define message interval. ### Fields

- **tracking_status** (`uint8_t`): Current tracking status
- **tracking_mode** (`uint8_t`): Current tracking mode
- **target_data** (`uint8_t`): Defines location of target data
- **point_x** (`float`): Current tracked point x value if CAMERA_TRACKING_MODE_POINT (normalized 0..1, 0 is left, 1 is right), NAN if unknown
- **point_y** (`float`): Current tracked point y value if CAMERA_TRACKING_MODE_POINT (normalized 0..1, 0 is top, 1 is bottom), NAN if unknown
- **radius** (`float`): Current tracked radius if CAMERA_TRACKING_MODE_POINT (normalized 0..1, 0 is image left, 1 is image right), NAN if unknown
- **rec_top_x** (`float`): Current tracked rectangle top x value if CAMERA_TRACKING_MODE_RECTANGLE (normalized 0..1, 0 is left, 1 is right), NAN if unknown
- **rec_top_y** (`float`): Current tracked rectangle top y value if CAMERA_TRACKING_MODE_RECTANGLE (normalized 0..1, 0 is top, 1 is bottom), NAN if unknown
- **rec_bottom_x** (`float`): Current tracked rectangle bottom x value if CAMERA_TRACKING_MODE_RECTANGLE (normalized 0..1, 0 is left, 1 is right), NAN if unknown
- **rec_bottom_y** (`float`): Current tracked rectangle bottom y value if CAMERA_TRACKING_MODE_RECTANGLE (normalized 0..1, 0 is top, 1 is bottom), NAN if unknown
- **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id).

--- chunk_id: chunk-0133
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: d935e12d7c03e021
prev_chunk_id: chunk-0132
next_chunk_id: chunk-0134
section_heading: CAMERA_TRACKING_GEO_STATUS (msg id 276, dialect common)
document_type: technical_reference

## CAMERA_TRACKING_GEO_STATUS (msg id 276, dialect common)

Camera tracking status, sent while in active tracking. Use MAV_CMD_SET_MESSAGE_INTERVAL to define message interval. ### Fields

- **tracking_status** (`uint8_t`): Current tracking status
- **lat** (`int32_t`, degE7): Latitude of tracked object
- **lon** (`int32_t`, degE7): Longitude of tracked object
- **alt** (`float`, m): Altitude of tracked object(AMSL, WGS84)
- **h_acc** (`float`, m): Horizontal accuracy. NAN if unknown
- **v_acc** (`float`, m): Vertical accuracy. NAN if unknown
- **vel_n** (`float`, m/s): North velocity of tracked object. NAN if unknown
- **vel_e** (`float`, m/s): East velocity of tracked object. NAN if unknown
- **vel_d** (`float`, m/s): Down velocity of tracked object. NAN if unknown
- **vel_acc** (`float`, m/s): Velocity accuracy. NAN if unknown
- **dist** (`float`, m): Distance between camera and tracked object. NAN if unknown
- **hdg** (`float`, rad): Heading in radians, in NED. NAN if unknown
- **hdg_acc** (`float`, rad): Accuracy of heading, in NED. NAN if unknown
- **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id).

--- chunk_id: chunk-0134
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 281
content_hash: 383262775500d426
prev_chunk_id: chunk-0133
next_chunk_id: chunk-0135
section_heading: CAMERA_THERMAL_RANGE (msg id 277, dialect common)
document_type: technical_reference

## CAMERA_THERMAL_RANGE (msg id 277, dialect common)

Camera absolute thermal range. This can be streamed when the associated VIDEO_STREAM_STATUS `flag` field bit VIDEO_STREAM_STATUS_FLAGS_THERMAL_RANGE_ENABLED is set, but a GCS may choose to only request it for the current active stream. Use MAV_CMD_SET_MESSAGE_INTERVAL to define message interval (param3 indicates the stream id of the current camera, or 0 for all streams, param4 indicates the target camera_device_id for autopilot-attached cameras or 0 for MAVLink cameras). ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **stream_id** (`uint8_t`): Video Stream ID (1 for first, 2 for second, etc.)
- **camera_device_id** (`uint8_t`): Camera id of a non-MAVLink camera attached to an autopilot (1-6). 0 if the component is a MAVLink camera (with its own component id). - **max** (`float`, degC): Temperature max. - **max_point_x** (`float`): Temperature max point x value (normalized 0..1, 0 is left, 1 is right), NAN if unknown. - **max_point_y** (`float`): Temperature max point y value (normalized 0..1, 0 is top, 1 is bottom), NAN if unknown. - **min** (`float`, degC): Temperature min. - **min_point_x** (`float`): Temperature min point x value (normalized 0..1, 0 is left, 1 is right), NAN if unknown. - **min_point_y** (`float`): Temperature min point y value (normalized 0..1, 0 is top, 1 is bottom), NAN if unknown.

--- chunk_id: chunk-0135
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 206
content_hash: c515ef6a9ac29e75
prev_chunk_id: chunk-0134
next_chunk_id: chunk-0136
section_heading: GIMBAL_MANAGER_INFORMATION (msg id 280, dialect common)
document_type: technical_reference

## GIMBAL_MANAGER_INFORMATION (msg id 280, dialect common)

Information about a high level gimbal manager. This message should be requested by a ground station using MAV_CMD_REQUEST_MESSAGE. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **cap_flags** (`uint32_t`): Bitmap of gimbal capability flags. - **gimbal_device_id** (`uint8_t`): Gimbal device ID that this gimbal manager is responsible for. Component ID of gimbal device (or 1-6 for non-MAVLink gimbal). - **roll_min** (`float`, rad): Minimum hardware roll angle (positive: rolling to the right, negative: rolling to the left)
- **roll_max** (`float`, rad): Maximum hardware roll angle (positive: rolling to the right, negative: rolling to the left)
- **pitch_min** (`float`, rad): Minimum pitch angle (positive: up, negative: down)
- **pitch_max** (`float`, rad): Maximum pitch angle (positive: up, negative: down)
- **yaw_min** (`float`, rad): Minimum yaw angle (positive: to the right, negative: to the left)
- **yaw_max** (`float`, rad): Maximum yaw angle (positive: to the right, negative: to the left)

--- chunk_id: chunk-0136
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 409
content_hash: 9275ac19793090ec
prev_chunk_id: chunk-0135
next_chunk_id: chunk-0137
section_heading: GIMBAL_MANAGER_STATUS (msg id 281, dialect common)
document_type: technical_reference

## GIMBAL_MANAGER_STATUS (msg id 281, dialect common)

Current status about a high level gimbal manager. This message should be broadcast at a low regular rate (e.g. 5Hz). ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **flags** (`uint32_t`): High level gimbal manager flags currently applied. - **gimbal_device_id** (`uint8_t`): Gimbal device ID that this gimbal manager is responsible for. Component ID of gimbal device (or 1-6 for non-MAVLink gimbal). - **primary_control_sysid** (`uint8_t`): System ID of MAVLink component with primary control, 0 for none. - **primary_control_compid** (`uint8_t`): Component ID of MAVLink component with primary control, 0 for none. - **secondary_control_sysid** (`uint8_t`): System ID of MAVLink component with secondary control, 0 for none. - **secondary_control_compid** (`uint8_t`): Component ID of MAVLink component with secondary control, 0 for none. ### GIMBAL_MANAGER_SET_ATTITUDE (msg id 282, dialect common)
High level message to control a gimbal's attitude. This message is to be sent to the gimbal manager (e.g. from a ground station). Angles and rates can be set to NaN according to use case. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **flags** (`uint32_t`): High level gimbal manager flags to use. - **gimbal_device_id** (`uint8_t`): Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals). - **q** (`float[4]`): Quaternion components, w, x, y, z (1 0 0 0 is the null-rotation, the frame is depends on whether the flag GIMBAL_MANAGER_FLAGS_YAW_LOCK is set)
- **angular_velocity_x** (`float`, rad/s): X component of angular velocity, positive is rolling to the right, NaN to be ignored. - **angular_velocity_y** (`float`, rad/s): Y component of angular velocity, positive is pitching up, NaN to be ignored. - **angular_velocity_z** (`float`, rad/s): Z component of angular velocity, positive is yawing to the right, NaN to be ignored.

--- chunk_id: chunk-0137
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: 9d4aed18d0ac737c
prev_chunk_id: chunk-0136
next_chunk_id: chunk-0138
section_heading: GIMBAL_DEVICE_INFORMATION (msg id 283, dialect common)
document_type: technical_reference

## GIMBAL_DEVICE_INFORMATION (msg id 283, dialect common)

Information about a low level gimbal. This message should be requested by the gimbal manager or a ground station using MAV_CMD_REQUEST_MESSAGE. The maximum angles and rates are the limits by hardware. However, the limits by software used are likely different/smaller and dependent on mode/settings/etc.. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **vendor_name** (`char[32]`): Name of the gimbal vendor. - **model_name** (`char[32]`): Name of the gimbal model. - **custom_name** (`char[32]`): Custom name of the gimbal given to it by the user. - **firmware_version** (`uint32_t`): Version of the gimbal firmware, encoded as: `(Dev & 0xff) << 24 + (Patch & 0xff) << 16 + (Minor & 0xff) << 8 + (Major & 0xff)`. - **hardware_version** (`uint32_t`): Version of the gimbal hardware, encoded as: `(Dev & 0xff) << 24 + (Patch & 0xff) << 16 + (Minor & 0xff) << 8 + (Major & 0xff)`. - **uid** (`uint64_t`): UID of gimbal hardware (0 if unknown). - **cap_flags** (`uint16_t`): Bitmap of gimbal capability flags. - **custom_cap_flags** (`uint16_t`): Bitmap for use for gimbal-specific capability flags. - **roll_min** (`float`, rad): Minimum hardware roll angle (positive: rolling to the right, negative: rolling to the left). NAN if unknown. - **roll_max** (`float`, rad): Maximum hardware roll angle (positive: rolling to the right, negative: rolling to the left). NAN if unknown. - **pitch_min** (`float`, rad): Minimum hardware pitch angle (positive: up, negative: down). NAN if unknown. - **pitch_max** (`float`, rad): Maximum hardware pitch angle (positive: up, negative: down). NAN if unknown. - **yaw_min** (`float`, rad): Minimum hardware yaw angle (positive: to the right, negative: to the left). NAN if unknown. - **yaw_max** (`float`, rad): Maximum hardware yaw angle (positive: to the right, negative: to the left). NAN if unknown. - **gimbal_device_id** (`uint8_t`): This field is to be used if the gimbal manager and the gimbal device are the same component and hence have the same component ID. This field is then set to a number between 1-6. If the component ID is separate, this field is not required and must be set to 0. - **cap_flags2** (`uint32_t`): Extended bitmap of gimbal capability flags (32 bit). For backwards compatibility, the lower 16 bits should also be set in cap_flags. Ground stations should prefer this field if non-zero.

--- chunk_id: chunk-0138
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 368
content_hash: 6adcbbbf30108f6f
prev_chunk_id: chunk-0137
next_chunk_id: chunk-0139
section_heading: GIMBAL_DEVICE_SET_ATTITUDE (msg id 284, dialect common)
document_type: technical_reference

## GIMBAL_DEVICE_SET_ATTITUDE (msg id 284, dialect common)

Low level message to control a gimbal device's attitude. This message is to be sent from the gimbal manager to the gimbal device component. The quaternion and angular velocities can be set to NaN according to use case. For the angles encoded in the quaternion and the angular velocities holds:
	  If the flag GIMBAL_DEVICE_FLAGS_YAW_IN_VEHICLE_FRAME is set, then they are relative to the vehicle heading (vehicle frame). If the flag GIMBAL_DEVICE_FLAGS_YAW_IN_EARTH_FRAME is set, then they are relative to absolute North (earth frame). If neither of these flags are set, then (for backwards compatibility) it holds:
	  If the flag GIMBAL_DEVICE_FLAGS_YAW_LOCK is set, then they are relative to absolute North (earth frame),
	  else they are relative to the vehicle heading (vehicle frame). Setting both GIMBAL_DEVICE_FLAGS_YAW_IN_VEHICLE_FRAME and GIMBAL_DEVICE_FLAGS_YAW_IN_EARTH_FRAME is not allowed. These rules are to ensure backwards compatibility. New implementations should always set either GIMBAL_DEVICE_FLAGS_YAW_IN_VEHICLE_FRAME or GIMBAL_DEVICE_FLAGS_YAW_IN_EARTH_FRAME. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **flags** (`uint16_t`): Low level gimbal flags. - **q** (`float[4]`): Quaternion components, w, x, y, z (1 0 0 0 is the null-rotation). The frame is described in the message description. Set fields to NaN to be ignored. - **angular_velocity_x** (`float`, rad/s): X component of angular velocity (positive: rolling to the right). The frame is described in the message description. NaN to be ignored. - **angular_velocity_y** (`float`, rad/s): Y component of angular velocity (positive: pitching up). The frame is described in the message description. NaN to be ignored. - **angular_velocity_z** (`float`, rad/s): Z component of angular velocity (positive: yawing to the right). The frame is described in the message description. NaN to be ignored.

--- chunk_id: chunk-0139
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: 81f2ab62d034e9d6
prev_chunk_id: chunk-0138
next_chunk_id: chunk-0140
section_heading: GIMBAL_DEVICE_ATTITUDE_STATUS (msg id 285, dialect common)
document_type: technical_reference

## GIMBAL_DEVICE_ATTITUDE_STATUS (msg id 285, dialect common)

Message reporting the status of a gimbal device. This message should be broadcast by a gimbal device component at a low regular rate (e.g. 5 Hz). For the angles encoded in the quaternion and the angular velocities holds:
	  If the flag GIMBAL_DEVICE_FLAGS_YAW_IN_VEHICLE_FRAME is set, then they are relative to the vehicle heading (vehicle frame). If the flag GIMBAL_DEVICE_FLAGS_YAW_IN_EARTH_FRAME is set, then they are relative to absolute North (earth frame). If neither of these flags are set, then (for backwards compatibility) it holds:
	  If the flag GIMBAL_DEVICE_FLAGS_YAW_LOCK is set, then they are relative to absolute North (earth frame),
	  else they are relative to the vehicle heading (vehicle frame). Other conditions of the flags are not allowed. The quaternion and angular velocities in the other frame can be calculated from delta_yaw and delta_yaw_velocity as
	  q_earth = q_delta_yaw * q_vehicle and w_earth = w_delta_yaw_velocity + w_vehicle (if not NaN). If neither the GIMBAL_DEVICE_FLAGS_YAW_IN_VEHICLE_FRAME nor the GIMBAL_DEVICE_FLAGS_YAW_IN_EARTH_FRAME flag is set,
	  then (for backwards compatibility) the data in the delta_yaw and delta_yaw_velocity fields are to be ignored. New implementations should always set either GIMBAL_DEVICE_FLAGS_YAW_IN_VEHICLE_FRAME or GIMBAL_DEVICE_FLAGS_YAW_IN_EARTH_FRAME,
	  and always should set delta_yaw and delta_yaw_velocity either to the proper value or NaN. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **flags** (`uint16_t`): Current gimbal flags set. - **q** (`float[4]`): Quaternion components, w, x, y, z (1 0 0 0 is the null-rotation). The frame is described in the message description. - **angular_velocity_x** (`float`, rad/s): X component of angular velocity (positive: rolling to the right). The frame is described in the message description. NaN if unknown. - **angular_velocity_y** (`float`, rad/s): Y component of angular velocity (positive: pitching up). The frame is described in the message description. NaN if unknown. - **angular_velocity_z** (`float`, rad/s): Z component of angular velocity (positive: yawing to the right). The frame is described in the message description. NaN if unknown. - **failure_flags** (`uint32_t`): Failure flags (0 for no failure)
- **delta_yaw** (`float`, rad): Yaw angle relating the quaternions in earth and body frames (see message description). NaN if unknown. - **delta_yaw_velocity** (`float`, rad/s): Yaw angular velocity relating the angular velocities in earth and body frames (see message description). NaN if unknown.

--- chunk_id: chunk-0140
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 101
content_hash: 386cf76427adc902
prev_chunk_id: chunk-0139
next_chunk_id: chunk-0141
section_heading: GIMBAL_DEVICE_ATTITUDE_STATUS (msg id 285, dialect common)
document_type: technical_reference

- **delta_yaw_velocity** (`float`, rad/s): Yaw angular velocity relating the angular velocities in earth and body frames (see message description). NaN if unknown. - **gimbal_device_id** (`uint8_t`): This field is to be used if the gimbal manager and the gimbal device are the same component and hence have the same component ID. This field is then set a number between 1-6. If the component ID is separate, this field is not required and must be set to 0.

--- chunk_id: chunk-0141
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 338
content_hash: a85cc2b1ff7987ec
prev_chunk_id: chunk-0140
next_chunk_id: chunk-0142
section_heading: AUTOPILOT_STATE_FOR_GIMBAL_DEVICE (msg id 286, dialect common)
document_type: technical_reference

## AUTOPILOT_STATE_FOR_GIMBAL_DEVICE (msg id 286, dialect common)

Low level message containing autopilot state relevant for a gimbal device. This message is to be sent from the autopilot to the gimbal device component. The data of this message are for the gimbal device's estimator corrections, in particular horizon compensation, as well as indicates autopilot control intentions, e.g. feed forward angular control in the z-axis. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **time_boot_us** (`uint64_t`, us): Timestamp (time since system boot). - **q** (`float[4]`): Quaternion components of autopilot attitude: w, x, y, z (1 0 0 0 is the null-rotation, Hamilton convention). - **q_estimated_delay_us** (`uint32_t`, us): Estimated delay of the attitude data. 0 if unknown. - **vx** (`float`, m/s): X Speed in NED (North, East, Down). NAN if unknown. - **vy** (`float`, m/s): Y Speed in NED (North, East, Down). NAN if unknown. - **vz** (`float`, m/s): Z Speed in NED (North, East, Down). NAN if unknown. - **v_estimated_delay_us** (`uint32_t`, us): Estimated delay of the speed data. 0 if unknown. - **feed_forward_angular_velocity_z** (`float`, rad/s): Feed forward Z component of angular velocity (positive: yawing to the right). NaN to be ignored. This is to indicate if the autopilot is actively yawing. - **estimator_status** (`uint16_t`): Bitmap indicating which estimator outputs are valid. - **landed_state** (`uint8_t`): The landed state. Is set to MAV_LANDED_STATE_UNDEFINED if landed state is unknown. - **angular_velocity_z** (`float`, rad/s): Z component of angular velocity in NED (North, East, Down). 0 if unknown. Use 0.00001 to represent a measured value of zero.

--- chunk_id: chunk-0142
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: e5a51279d40b5ec1
prev_chunk_id: chunk-0141
next_chunk_id: chunk-0143
section_heading: GIMBAL_MANAGER_SET_PITCHYAW (msg id 287, dialect common)
document_type: technical_reference

## GIMBAL_MANAGER_SET_PITCHYAW (msg id 287, dialect common)

Set gimbal manager pitch and yaw angles (high rate message). This message is to be sent to the gimbal manager (e.g. from a ground station) and will be ignored by gimbal devices. Angles and rates can be set to NaN according to use case. Use MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW for low-rate adjustments that require confirmation. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **flags** (`uint32_t`): High level gimbal manager flags to use. - **gimbal_device_id** (`uint8_t`): Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals). - **pitch** (`float`, rad): Pitch angle (positive: up, negative: down, NaN to be ignored). - **yaw** (`float`, rad): Yaw angle (positive: to the right, negative: to the left, NaN to be ignored). - **pitch_rate** (`float`, rad/s): Pitch angular rate (positive: up, negative: down, NaN to be ignored). - **yaw_rate** (`float`, rad/s): Yaw angular rate (positive: to the right, negative: to the left, NaN to be ignored).

--- chunk_id: chunk-0143
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 249
content_hash: b804c6827d36c791
prev_chunk_id: chunk-0142
next_chunk_id: chunk-0144
section_heading: GIMBAL_MANAGER_SET_MANUAL_CONTROL (msg id 288, dialect common)
document_type: technical_reference

## GIMBAL_MANAGER_SET_MANUAL_CONTROL (msg id 288, dialect common)

High level message to control a gimbal manually. The angles or angular rates are unitless; the actual rates will depend on internal gimbal manager settings/configuration (e.g. set by parameters). This message is to be sent to the gimbal manager (e.g. from a ground station). Angles and rates can be set to NaN according to use case. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **flags** (`uint32_t`): High level gimbal manager flags. - **gimbal_device_id** (`uint8_t`): Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals). - **pitch** (`float`): Pitch angle unitless (-1..1, positive: up, negative: down, NaN to be ignored). - **yaw** (`float`): Yaw angle unitless (-1..1, positive: to the right, negative: to the left, NaN to be ignored). - **pitch_rate** (`float`): Pitch angular rate unitless (-1..1, positive: up, negative: down, NaN to be ignored). - **yaw_rate** (`float`): Yaw angular rate unitless (-1..1, positive: to the right, negative: to the left, NaN to be ignored).

--- chunk_id: chunk-0144
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 233
content_hash: 97bdc9a4a4353b67
prev_chunk_id: chunk-0143
next_chunk_id: chunk-0145
section_heading: ESC_INFO (msg id 290, dialect common)
document_type: technical_reference

## ESC_INFO (msg id 290, dialect common)

ESC information for lower rate streaming. Recommended streaming rate 1Hz. See ESC_STATUS for higher-rate ESC data. ### Fields

- **index** (`uint8_t`): Index of the first ESC in this message (ESC are indexed in motor order). minValue = 0, maxValue = 60, increment = 4. - **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude the number. - **counter** (`uint16_t`): Counter of data packets received. - **count** (`uint8_t`): Total number of ESCs in all messages of this type. Message fields with an index higher than this should be ignored because they contain invalid data. - **connection_type** (`uint8_t`): Connection type protocol for all ESC. - **info** (`uint8_t`): Information regarding online/offline status of each ESC. - **failure_flags** (`uint16_t[4]`): Bitmap of ESC failure flags. - **error_count** (`uint32_t[4]`): Number of reported errors by each ESC since boot. - **temperature** (`int16_t[4]`, cdegC): Temperature of each ESC. INT16_MAX: if data not supplied by ESC.

--- chunk_id: chunk-0145
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 180
content_hash: 30b609ce38baa535
prev_chunk_id: chunk-0144
next_chunk_id: chunk-0146
section_heading: ESC_STATUS (msg id 291, dialect common)
document_type: technical_reference

## ESC_STATUS (msg id 291, dialect common)

ESC information for higher rate streaming. Recommended streaming rate is ~10 Hz. Information that changes more slowly is sent in ESC_INFO. It should typically only be streamed on high-bandwidth links (i.e. to a companion computer). ### Fields

- **index** (`uint8_t`): Index of the first ESC in this message (ESC are indexed in motor order). minValue = 0, maxValue = 60, increment = 4. - **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude the number. - **rpm** (`int32_t[4]`, rpm): Reported motor RPM from each ESC (negative for reverse rotation). - **voltage** (`float[4]`, V): Voltage measured from each ESC. - **current** (`float[4]`, A): Current measured from each ESC.

--- chunk_id: chunk-0146
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 348
content_hash: 656285034c49f70c
prev_chunk_id: chunk-0145
next_chunk_id: chunk-0147
section_heading: AIRSPEED (msg id 295, dialect common)
document_type: technical_reference

## AIRSPEED (msg id 295, dialect common)

Airspeed information from a sensor. ### Fields

- **id** (`uint8_t`): Sensor ID. - **airspeed** (`float`, m/s): Calibrated airspeed (CAS). - **temperature** (`int16_t`, cdegC): Temperature. - **raw_press** (`float`, hPa): Raw differential pressure. - **flags** (`uint8_t`): Airspeed sensor flags. ### GLOBAL_POSITION_SENSOR (msg id 296, dialect common)
Reports measurement/estimate from a global position sensor. Used as navigation fusion source and optionally displayed in the UI. ### Fields

- **target_system** (`uint8_t`): System ID (ID of target system, normally autopilot and ground station). - **target_component** (`uint8_t`): Component ID (normally 0 for broadcast). - **id** (`uint8_t`): Sensor ID
- **time_usec** (`uint64_t`, us): Timestamp of message transmission (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **processing_time** (`uint32_t`, us): The time spent in processing the sensor data that is the basis for this position. The recipient can use this to improve time alignment of the data. This is the time between measurement (e.g. camera exposure time) and transmission of this message. Set to NaN if not known. - **source** (`uint8_t`): Source of position/estimate (such as GNSS, estimator, etc.)
- **flags** (`uint8_t`): Status flags
- **lat** (`int32_t`, degE7): Latitude (WGS84)
- **lon** (`int32_t`, degE7): Longitude (WGS84)
- **alt_ellipsoid** (`float`, m): Altitude (WGS84 elipsoid), preferred if available
- **alt** (`float`, m): Altitude (MSL - position-system specific value) use if no alt_ellipsoid available
- **eph** (`float`, m): Standard deviation of horizontal position error
- **epv** (`float`, m): Standard deviation of vertical position error

--- chunk_id: chunk-0147
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 317
content_hash: 6cace1d76d7b65d5
prev_chunk_id: chunk-0146
next_chunk_id: chunk-0148
section_heading: WIFI_CONFIG_AP (msg id 299, dialect common)
document_type: technical_reference

## WIFI_CONFIG_AP (msg id 299, dialect common)

Configure WiFi AP SSID, password, and mode. This message is re-emitted as an acknowledgement by the AP. The message may also be explicitly requested using MAV_CMD_REQUEST_MESSAGE

### Fields

- **ssid** (`char[32]`): Name of Wi-Fi network (SSID). Blank to leave it unchanged when setting. Current SSID when sent back as a response. - **password** (`char[64]`): Password. Blank for an open AP. MD5 hash when message is sent back as a response. - **mode** (`int8_t`): WiFi Mode. - **response** (`int8_t`): Message acceptance response (sent back to GS). ### PROTOCOL_VERSION (msg id 300, dialect common)
Version and capability of protocol version. This message can be requested with MAV_CMD_REQUEST_MESSAGE and is used as part of the handshaking to establish which MAVLink version should be used on the network. Every node should respond to a request for PROTOCOL_VERSION to enable the handshaking. Library implementers should consider adding this into the default decoding state machine to allow the protocol core to respond directly. ### Fields

- **version** (`uint16_t`): Currently active MAVLink version number * 100: v1.0 is 100, v2.0 is 200, etc. - **min_version** (`uint16_t`): Minimum MAVLink version supported
- **max_version** (`uint16_t`): Maximum MAVLink version supported (set to the same value as version by default)
- **spec_version_hash** (`uint8_t[8]`): The first 8 bytes (not characters printed in hex!) of the git hash. - **library_version_hash** (`uint8_t[8]`): The first 8 bytes (not characters printed in hex!) of the git hash.

--- chunk_id: chunk-0148
source_document: messages_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 310
content_hash: a27f6d303535e4f7
prev_chunk_id: chunk-0147
next_chunk_id: chunk-0149
section_heading: AIS_VESSEL (msg id 301, dialect common)
document_type: technical_reference

## AIS_VESSEL (msg id 301, dialect common)

The location and information of an AIS vessel

### Fields

- **MMSI** (`uint32_t`): Mobile Marine Service Identifier, 9 decimal digits
- **lat** (`int32_t`, degE7): Latitude
- **lon** (`int32_t`, degE7): Longitude
- **COG** (`uint16_t`, cdeg): Course over ground
- **heading** (`uint16_t`, cdeg): True heading
- **velocity** (`uint16_t`, cm/s): Speed over ground
- **turn_rate** (`int8_t`, ddeg/s): Turn rate, 0.1 degrees per second
- **navigational_status** (`uint8_t`): Navigational status
- **type** (`uint8_t`): Type of vessels
- **dimension_bow** (`uint16_t`, m): Distance from lat/lon location to bow
- **dimension_stern** (`uint16_t`, m): Distance from lat/lon location to stern
- **dimension_port** (`uint8_t`, m): Distance from lat/lon location to port side
- **dimension_starboard** (`uint8_t`, m): Distance from lat/lon location to starboard side
- **callsign** (`char[7]`): The vessel callsign. Characters are encoded as 7-bit ASCII, but only characters in the [AIS 6-bit ASCII subset](https://en.wikipedia.org/wiki/Six-bit_character_code#AIS_SixBit_ASCII) are permitted. Also set AIS_FLAGS_VALID_CALLSIGN if valid. The string is NULL-terminated if it is shorter than the array length. - **name** (`char[20]`): The vessel name. Characters are encoded as 7-bit ASCII, but only characters in the [AIS 6-bit ASCII subset](https://en.wikipedia.org/wiki/Six-bit_character_code#AIS_SixBit_ASCII) are permitted. Also set AIS_FLAGS_VALID_NAME if valid. The string is NULL-terminated if it is shorter than the array length. - **tslc** (`uint16_t`, s): Time since last communication. This is the age of the AIS information in this message, in seconds. - **flags** (`uint16_t`): Bitmask to indicate various statuses including valid data fields

--- chunk_id: chunk-0149
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: 6bbb699749ca858f
prev_chunk_id: chunk-0148
next_chunk_id: chunk-0150
section_heading: MAVLink messages batch 8
document_type: technical_reference

# MAVLink messages batch 8

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0150
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 389
content_hash: f91088427ffd40f3
prev_chunk_id: chunk-0149
next_chunk_id: chunk-0151
section_heading: UAVCAN_NODE_STATUS (msg id 310, dialect common)
document_type: technical_reference

## UAVCAN_NODE_STATUS (msg id 310, dialect common)

General status information of an UAVCAN node. Please refer to the definition of the UAVCAN message "uavcan.protocol.NodeStatus" for the background information. The UAVCAN specification is available at http://uavcan.org. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **uptime_sec** (`uint32_t`, s): Time since the start-up of the node. - **health** (`uint8_t`): Generalized node health status. - **mode** (`uint8_t`): Generalized operating mode. - **sub_mode** (`uint8_t`): Not used currently. - **vendor_specific_status_code** (`uint16_t`): Vendor-specific status information. ### UAVCAN_NODE_INFO (msg id 311, dialect common)
General information describing a particular UAVCAN node. Please refer to the definition of the UAVCAN service "uavcan.protocol.GetNodeInfo" for the background information. This message should be emitted by the system whenever a new node appears online, or an existing node reboots. The message may also be explicitly requested using MAV_CMD_REQUEST_MESSAGE. It is also not prohibited to emit this message unconditionally at a low frequency. The DroneCAN specification is available at https://dronecan.github.io/Specification/1._Introduction/. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **uptime_sec** (`uint32_t`, s): Time since the start-up of the node. - **name** (`char[80]`): Node name string. For example, "sapog.px4.io". - **hw_version_major** (`uint8_t`): Hardware major version number. - **hw_version_minor** (`uint8_t`): Hardware minor version number. - **hw_unique_id** (`uint8_t[16]`): Hardware unique 128-bit ID. - **sw_version_major** (`uint8_t`): Software major version number. - **sw_version_minor** (`uint8_t`): Software minor version number. - **sw_vcs_commit** (`uint32_t`): Version control system (VCS) revision identifier (e.g. git short commit hash). 0 if unknown.

--- chunk_id: chunk-0151
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 188
content_hash: 4ea5beb456fa2571
prev_chunk_id: chunk-0150
next_chunk_id: chunk-0152
section_heading: PARAM_EXT_REQUEST_READ (msg id 320, dialect common)
document_type: technical_reference

## PARAM_EXT_REQUEST_READ (msg id 320, dialect common)

Request to read the value of a parameter with either the param_id string id or param_index. PARAM_EXT_VALUE should be emitted in response. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **param_id** (`char[16]`): Parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_index** (`int16_t`): Parameter index. Set to -1 to use the Parameter ID field as identifier (else param_id will be ignored)

### PARAM_EXT_REQUEST_LIST (msg id 321, dialect common)
Request all parameters of this component. All parameters should be emitted in response as PARAM_EXT_VALUE. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID

--- chunk_id: chunk-0152
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 320
content_hash: 3ac1acfd898363cd
prev_chunk_id: chunk-0151
next_chunk_id: chunk-0153
section_heading: PARAM_EXT_VALUE (msg id 322, dialect common)
document_type: technical_reference

## PARAM_EXT_VALUE (msg id 322, dialect common)

Emit the value of a parameter. The inclusion of param_count and param_index in the message allows the recipient to keep track of received parameters and allows them to re-request missing parameters after a loss or timeout. ### Fields

- **param_id** (`char[16]`): Parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_value** (`char[128]`): Parameter value
- **param_type** (`uint8_t`): Parameter type. - **param_count** (`uint16_t`): Total number of parameters
- **param_index** (`uint16_t`): Index of this parameter

### PARAM_EXT_SET (msg id 323, dialect common)
Set a parameter value. In order to deal with message loss (and retransmission of PARAM_EXT_SET), when setting a parameter value and the new value is the same as the current value, you will immediately get a PARAM_ACK_ACCEPTED response. If the current state is PARAM_ACK_IN_PROGRESS, you will accordingly receive a PARAM_ACK_IN_PROGRESS in response. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **param_id** (`char[16]`): Parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_value** (`char[128]`): Parameter value
- **param_type** (`uint8_t`): Parameter type.

--- chunk_id: chunk-0153
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 477
content_hash: 76211730f508a974
prev_chunk_id: chunk-0152
next_chunk_id: chunk-0154
section_heading: PARAM_EXT_ACK (msg id 324, dialect common)
document_type: technical_reference

## PARAM_EXT_ACK (msg id 324, dialect common)

Response from a PARAM_EXT_SET message. ### Fields

- **param_id** (`char[16]`): Parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_value** (`char[128]`): Parameter value (new value if PARAM_ACK_ACCEPTED, current value otherwise)
- **param_type** (`uint8_t`): Parameter type. - **param_result** (`uint8_t`): Result code. ### OBSTACLE_DISTANCE (msg id 330, dialect common)
Obstacle distances in front of the sensor, starting from the left in increment degrees to the right

### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **sensor_type** (`uint8_t`): Class id of the distance sensor type. - **distances** (`uint16_t[72]`, cm): Distance of obstacles around the vehicle with index 0 corresponding to north + angle_offset, unless otherwise specified in the frame. A value of 0 is valid and means that the obstacle is practically touching the sensor. A value of max_distance +1 means no obstacle is present. A value of UINT16_MAX for unknown/not used. In a array element, one unit corresponds to 1cm. - **increment** (`uint8_t`, deg): Angular width in degrees of each array element. Increment direction is clockwise. This field is ignored if increment_f is non-zero. - **min_distance** (`uint16_t`, cm): Minimum distance the sensor can measure. - **max_distance** (`uint16_t`, cm): Maximum distance the sensor can measure. - **increment_f** (`float`, deg): Angular width in degrees of each array element as a float. If non-zero then this value is used instead of the uint8_t increment field. Positive is clockwise direction, negative is counter-clockwise. - **angle_offset** (`float`, deg): Relative angle offset of the 0-index element in the distances array. Value of 0 corresponds to forward. Positive is clockwise direction, negative is counter-clockwise. - **frame** (`uint8_t`): Coordinate frame of reference for the yaw rotation and offset of the sensor data. Defaults to MAV_FRAME_GLOBAL, which is north aligned. For body-mounted sensors use MAV_FRAME_BODY_FRD, which is vehicle front aligned.

--- chunk_id: chunk-0154
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 453
content_hash: 3a503208d94f90f8
prev_chunk_id: chunk-0153
next_chunk_id: chunk-0155
section_heading: ODOMETRY (msg id 331, dialect common)
document_type: technical_reference

## ODOMETRY (msg id 331, dialect common)

Odometry message to communicate odometry information with an external interface. Fits ROS REP 147 standard for aerial vehicles (http://www.ros.org/reps/rep-0147.html). ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **frame_id** (`uint8_t`): Coordinate frame of reference for the pose data. - **child_frame_id** (`uint8_t`): Coordinate frame of reference for the velocity in free space (twist) data. - **x** (`float`, m): X Position
- **y** (`float`, m): Y Position
- **z** (`float`, m): Z Position
- **q** (`float[4]`): Quaternion components, w, x, y, z (1 0 0 0 is the null-rotation)
- **vx** (`float`, m/s): X linear speed
- **vy** (`float`, m/s): Y linear speed
- **vz** (`float`, m/s): Z linear speed
- **rollspeed** (`float`, rad/s): Roll angular speed
- **pitchspeed** (`float`, rad/s): Pitch angular speed
- **yawspeed** (`float`, rad/s): Yaw angular speed
- **pose_covariance** (`float[21]`): Row-major representation of a 6x6 pose cross-covariance matrix upper right triangle (states: x, y, z, roll, pitch, yaw; first six entries are the first ROW, next five entries are the second ROW, etc.). If unknown, assign NaN value to first element in the array. - **velocity_covariance** (`float[21]`): Row-major representation of a 6x6 velocity cross-covariance matrix upper right triangle (states: vx, vy, vz, rollspeed, pitchspeed, yawspeed; first six entries are the first ROW, next five entries are the second ROW, etc.). If unknown, assign NaN value to first element in the array. - **reset_counter** (`uint8_t`): Estimate reset counter. This should be incremented when the estimate resets in any of the dimensions (position, velocity, attitude, angular speed). This is designed to be used when e.g an external SLAM system detects a loop-closure and the estimate jumps. - **estimator_type** (`uint8_t`): Type of estimator that is providing the odometry. - **quality** (`int8_t`, %): Optional odometry quality metric as a percentage. -1 = odometry has failed, 0 = unknown/unset quality, 1 = worst quality, 100 = best quality

--- chunk_id: chunk-0155
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 316
content_hash: f2a1a1361906755b
prev_chunk_id: chunk-0154
next_chunk_id: chunk-0156
section_heading: TRAJECTORY_REPRESENTATION_WAYPOINTS (msg id 332, dialect common)
document_type: technical_reference

## TRAJECTORY_REPRESENTATION_WAYPOINTS (msg id 332, dialect common)

Describe a trajectory using an array of up-to 5 waypoints in the local frame (MAV_FRAME_LOCAL_NED). ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **valid_points** (`uint8_t`): Number of valid points (up-to 5 waypoints are possible)
- **pos_x** (`float[5]`, m): X-coordinate of waypoint, set to NaN if not being used
- **pos_y** (`float[5]`, m): Y-coordinate of waypoint, set to NaN if not being used
- **pos_z** (`float[5]`, m): Z-coordinate of waypoint, set to NaN if not being used
- **vel_x** (`float[5]`, m/s): X-velocity of waypoint, set to NaN if not being used
- **vel_y** (`float[5]`, m/s): Y-velocity of waypoint, set to NaN if not being used
- **vel_z** (`float[5]`, m/s): Z-velocity of waypoint, set to NaN if not being used
- **acc_x** (`float[5]`, m/s/s): X-acceleration of waypoint, set to NaN if not being used
- **acc_y** (`float[5]`, m/s/s): Y-acceleration of waypoint, set to NaN if not being used
- **acc_z** (`float[5]`, m/s/s): Z-acceleration of waypoint, set to NaN if not being used
- **pos_yaw** (`float[5]`, rad): Yaw angle, set to NaN if not being used
- **vel_yaw** (`float[5]`, rad/s): Yaw rate, set to NaN if not being used
- **command** (`uint16_t[5]`): MAV_CMD command id of waypoint, set to UINT16_MAX if not being used.

--- chunk_id: chunk-0156
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 196
content_hash: 456f8f4200ef2f2c
prev_chunk_id: chunk-0155
next_chunk_id: chunk-0157
section_heading: TRAJECTORY_REPRESENTATION_BEZIER (msg id 333, dialect common)
document_type: technical_reference

## TRAJECTORY_REPRESENTATION_BEZIER (msg id 333, dialect common)

Describe a trajectory using an array of up-to 5 bezier control points in the local frame (MAV_FRAME_LOCAL_NED). ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **valid_points** (`uint8_t`): Number of valid control points (up-to 5 points are possible)
- **pos_x** (`float[5]`, m): X-coordinate of bezier control points. Set to NaN if not being used
- **pos_y** (`float[5]`, m): Y-coordinate of bezier control points. Set to NaN if not being used
- **pos_z** (`float[5]`, m): Z-coordinate of bezier control points. Set to NaN if not being used
- **delta** (`float[5]`, s): Bezier time horizon. Set to NaN if velocity/acceleration should not be incorporated
- **pos_yaw** (`float[5]`, rad): Yaw. Set to NaN for unchanged

--- chunk_id: chunk-0157
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 416
content_hash: c00b98a231bed0db
prev_chunk_id: chunk-0156
next_chunk_id: chunk-0158
section_heading: CELLULAR_STATUS (msg id 334, dialect common)
document_type: technical_reference

## CELLULAR_STATUS (msg id 334, dialect common)

Cellular network status as reported by a particular modem. This is primarily intended for logging, but a GCS may choose to display link_tx_rate and link_rx_rate. Note that a value of 0 in the id field indicates that the sender does not support reporting of multiple modems. Message data should be from a single modem, but that is not guaranteed. ### Fields

- **status** (`uint8_t`): Cellular modem status
- **failure_reason** (`uint8_t`): Failure reason when status in in CELLULAR_STATUS_FLAG_FAILED
- **type** (`uint8_t`): Cellular network radio type: gsm, cdma, lte... - **quality** (`uint8_t`): Signal quality in percent. If unknown, set to UINT8_MAX
- **mcc** (`uint16_t`): Mobile country code. If unknown, set to UINT16_MAX
- **mnc** (`uint16_t`): Mobile network code. If unknown, set to UINT16_MAX
- **lac** (`uint16_t`): Location area code. If unknown, set to 0
- **id** (`uint8_t`): Cellular modem instance number. Indexed from 1. - **link_tx_rate** (`uint32_t`, KiB/s): Download rate. - **link_rx_rate** (`uint32_t`, KiB/s): Upload rate. - **cell_tower_id** (`char[9]`): ID of the currently connected cell tower. This must be NULL terminated if the length is less than 9 human-readable chars, and without the null termination (NULL) byte if the length is exactly 9 chars. - **band_number** (`uint8_t`): LTE frequency band number. - **band_frequency** (`float`, MHz): LTE radio frequency. - **channel_number** (`uint32_t`): The channel number (CN). Absolute radio-frequency (ARFCN) / E-UTRA (EARFCN) / UTRA (UARFCN) / New radio (NR_CH). - **rx_level** (`float`, dBm): On 3G is Received Signal Code Power (RSCP). On LTE is Reference Signal Received Power (RSRP). On 5G is New Radio Reference Signal Received Power (NR_RSRP). - **tx_level** (`float`, dBm): Transmitter (modem) signal absolute power level. - **rx_quality** (`float`, dBm): On 3G is Receiver Quality (RxQual). On LTE is Reference Signal Received Quality (RSRQ). On 5G is New Radio Reference Signal Received Quality (NR_RSRQ). - **sinr** (`float`, dB): Signal to interference plus noise ratio (SINR).

--- chunk_id: chunk-0158
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: 8c2b6e1d055c6147
prev_chunk_id: chunk-0157
next_chunk_id: chunk-0159
section_heading: ISBD_LINK_STATUS (msg id 335, dialect common)
document_type: technical_reference

## ISBD_LINK_STATUS (msg id 335, dialect common)

Status of the Iridium SBD link. ### Fields

- **timestamp** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **last_heartbeat** (`uint64_t`, us): Timestamp of the last successful sbd session. The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **failed_sessions** (`uint16_t`): Number of failed SBD sessions. - **successful_sessions** (`uint16_t`): Number of successful SBD sessions. - **signal_quality** (`uint8_t`): Signal quality equal to the number of bars displayed on the ISU signal strength indicator. Range is 0 to 5, where 0 indicates no signal and 5 indicates maximum signal strength. - **ring_pending** (`uint8_t`): 1: Ring call pending, 0: No call pending. - **tx_session_pending** (`uint8_t`): 1: Transmission session pending, 0: No transmission session pending. - **rx_session_pending** (`uint8_t`): 1: Receiving session pending, 0: No receiving session pending.

--- chunk_id: chunk-0159
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 265
content_hash: f0b609f67ec129a7
prev_chunk_id: chunk-0158
next_chunk_id: chunk-0160
section_heading: CELLULAR_CONFIG (msg id 336, dialect common)
document_type: technical_reference

## CELLULAR_CONFIG (msg id 336, dialect common)

Configure cellular modems. This message is re-emitted as an acknowledgement by the modem. The message may also be explicitly requested using MAV_CMD_REQUEST_MESSAGE. ### Fields

- **enable_lte** (`uint8_t`): Enable/disable LTE. 0: setting unchanged, 1: disabled, 2: enabled. Current setting when sent back as a response. - **enable_pin** (`uint8_t`): Enable/disable PIN on the SIM card. 0: setting unchanged, 1: disabled, 2: enabled. Current setting when sent back as a response. - **pin** (`char[16]`): PIN sent to the SIM card. Blank when PIN is disabled. Empty when message is sent back as a response. - **new_pin** (`char[16]`): New PIN when changing the PIN. Blank to leave it unchanged. Empty when message is sent back as a response. - **apn** (`char[32]`): Name of the cellular APN. Blank to leave it unchanged. Current APN when sent back as a response. - **puk** (`char[16]`): Required PUK code in case the user failed to authenticate 3 times with the PIN. Empty when message is sent back as a response. - **roaming** (`uint8_t`): Enable/disable roaming. 0: setting unchanged, 1: disabled, 2: enabled. Current setting when sent back as a response. - **response** (`uint8_t`): Message acceptance response (sent back to GS).

--- chunk_id: chunk-0160
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 270
content_hash: ab52975de3a6a724
prev_chunk_id: chunk-0159
next_chunk_id: chunk-0161
section_heading: RAW_RPM (msg id 339, dialect common)
document_type: technical_reference

## RAW_RPM (msg id 339, dialect common)

RPM sensor data message. ### Fields

- **index** (`uint8_t`): Index of this RPM sensor (0-indexed)
- **frequency** (`float`, rpm): Indicated rate

### UTM_GLOBAL_POSITION (msg id 340, dialect common)
The global position resulting from GPS and sensor fusion. ### Fields

- **time** (`uint64_t`, us): Time of applicability of position (microseconds since UNIX epoch). - **uas_id** (`uint8_t[18]`): Unique UAS ID. - **lat** (`int32_t`, degE7): Latitude (WGS84)
- **lon** (`int32_t`, degE7): Longitude (WGS84)
- **alt** (`int32_t`, mm): Altitude (WGS84)
- **relative_alt** (`int32_t`, mm): Altitude above ground
- **vx** (`int16_t`, cm/s): Ground X speed (latitude, positive north)
- **vy** (`int16_t`, cm/s): Ground Y speed (longitude, positive east)
- **vz** (`int16_t`, cm/s): Ground Z speed (altitude, positive down)
- **h_acc** (`uint16_t`, mm): Horizontal position uncertainty (standard deviation)
- **v_acc** (`uint16_t`, mm): Altitude uncertainty (standard deviation)
- **vel_acc** (`uint16_t`, cm/s): Speed uncertainty (standard deviation)
- **next_lat** (`int32_t`, degE7): Next waypoint, latitude (WGS84)
- **next_lon** (`int32_t`, degE7): Next waypoint, longitude (WGS84)
- **next_alt** (`int32_t`, mm): Next waypoint, altitude (WGS84)
- **update_rate** (`uint16_t`, cs): Time until next update. Set to 0 if unknown or in data driven mode. - **flight_state** (`uint8_t`): Flight state
- **flags** (`uint8_t`): Bitwise OR combination of the data available flags.

--- chunk_id: chunk-0161
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 309
content_hash: aa890d8d5fd849c7
prev_chunk_id: chunk-0160
next_chunk_id: chunk-0162
section_heading: PARAM_ERROR (msg id 345, dialect common)
document_type: technical_reference

## PARAM_ERROR (msg id 345, dialect common)

Parameter set/get error. Returned from a MAVLink node in response to an error in the parameter protocol, for example failing to set a parameter because it does not exist. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **param_id** (`char[16]`): Parameter id. Terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **param_index** (`int16_t`): Parameter index. Will be -1 if the param ID field should be used as an identifier (else the param id will be ignored)
- **error** (`uint8_t`): Error being returned to client. ### DEBUG_FLOAT_ARRAY (msg id 350, dialect common)
Large debug/prototyping array. The message uses the maximum available payload for data. The array_id and name fields are used to discriminate between messages in code and in user interfaces (respectively). Do not use in production code. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **name** (`char[10]`): Name, for human-friendly display in a Ground Control Station
- **array_id** (`uint16_t`): Unique ID used to discriminate between arrays
- **data** (`float[58]`): data

--- chunk_id: chunk-0162
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 212
content_hash: 7a05bc50899ff9bb
prev_chunk_id: chunk-0161
next_chunk_id: chunk-0163
section_heading: ORBIT_EXECUTION_STATUS (msg id 360, dialect common)
document_type: technical_reference

## ORBIT_EXECUTION_STATUS (msg id 360, dialect common)

Vehicle status report that is sent out while orbit execution is in progress (see MAV_CMD_DO_ORBIT). ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **radius** (`float`, m): Radius of the orbit circle. Positive values orbit clockwise, negative values orbit counter-clockwise. - **frame** (`uint8_t`): The coordinate system of the fields: x, y, z. - **x** (`int32_t`): X coordinate of center point. Coordinate system depends on frame field: local = x position in meters * 1e4, global = latitude in degrees * 1e7. - **y** (`int32_t`): Y coordinate of center point. Coordinate system depends on frame field: local = x position in meters * 1e4, global = latitude in degrees * 1e7. - **z** (`float`, m): Altitude of center point. Coordinate system depends on frame field.

--- chunk_id: chunk-0163
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: d15d91b20b4e0d12
prev_chunk_id: chunk-0162
next_chunk_id: chunk-0164
section_heading: SMART_BATTERY_INFO (msg id 370, dialect common)
document_type: technical_reference

## SMART_BATTERY_INFO (msg id 370, dialect common)

Smart Battery information (static/infrequent update). Use for updates from: smart battery to flight stack, flight stack to GCS. Use BATTERY_STATUS for the frequent battery updates. ### Fields

- **id** (`uint8_t`): Battery ID
- **battery_function** (`uint8_t`): Function of the battery
- **type** (`uint8_t`): Type (chemistry) of the battery
- **capacity_full_specification** (`int32_t`, mAh): Capacity when full according to manufacturer, -1: field not provided. - **capacity_full** (`int32_t`, mAh): Capacity when full (accounting for battery degradation), -1: field not provided. - **cycle_count** (`uint16_t`): Charge/discharge cycle count. UINT16_MAX: field not provided. - **serial_number** (`char[16]`): Serial number in ASCII characters, 0 terminated. All 0: field not provided. - **device_name** (`char[50]`): Static device name in ASCII characters, 0 terminated. All 0: field not provided. Encode as manufacturer name then product name separated using an underscore. - **weight** (`uint16_t`, g): Battery weight. 0: field not provided. - **discharge_minimum_voltage** (`uint16_t`, mV): Minimum per-cell voltage when discharging. If not supplied set to UINT16_MAX value. - **charging_minimum_voltage** (`uint16_t`, mV): Minimum per-cell voltage when charging. If not supplied set to UINT16_MAX value. - **resting_minimum_voltage** (`uint16_t`, mV): Minimum per-cell voltage when resting. If not supplied set to UINT16_MAX value. - **charging_maximum_voltage** (`uint16_t`, mV): Maximum per-cell voltage when charged. 0: field not provided. - **cells_in_series** (`uint8_t`): Number of battery cells in series. 0: field not provided. - **discharge_maximum_current** (`uint32_t`, mA): Maximum pack discharge current. 0: field not provided. - **discharge_maximum_burst_current** (`uint32_t`, mA): Maximum pack discharge burst current. 0: field not provided. - **manufacture_date** (`char[11]`): Manufacture date (DD/MM/YYYY) in ASCII characters, 0 terminated. All 0: field not provided.

--- chunk_id: chunk-0164
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 250
content_hash: c63f36610bdbd59a
prev_chunk_id: chunk-0163
next_chunk_id: chunk-0165
section_heading: FIGURE_EIGHT_EXECUTION_STATUS (msg id 361, dialect common)
document_type: technical_reference

## FIGURE_EIGHT_EXECUTION_STATUS (msg id 361, dialect common)

Vehicle status report that is sent out while figure eight execution is in progress (see MAV_CMD_DO_FIGURE_EIGHT). This may typically send at low rates: of the order of 2Hz. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **major_radius** (`float`, m): Major axis radius of the figure eight. Positive: orbit the north circle clockwise. Negative: orbit the north circle counter-clockwise. - **minor_radius** (`float`, m): Minor axis radius of the figure eight. Defines the radius of two circles that make up the figure. - **orientation** (`float`, rad): Orientation of the figure eight major axis with respect to true north in [-pi,pi). - **frame** (`uint8_t`): The coordinate system of the fields: x, y, z. - **x** (`int32_t`): X coordinate of center point. Coordinate system depends on frame field. - **y** (`int32_t`): Y coordinate of center point. Coordinate system depends on frame field. - **z** (`float`, m): Altitude of center point. Coordinate system depends on frame field.

--- chunk_id: chunk-0165
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: 4dde53954d8c3f8c
prev_chunk_id: chunk-0164
next_chunk_id: chunk-0166
section_heading: FUEL_STATUS (msg id 371, dialect common)
document_type: technical_reference

## FUEL_STATUS (msg id 371, dialect common)

Fuel status. This message provides "generic" fuel level information for  in a GCS and for triggering failsafes in an autopilot. The fuel type and associated units for fields in this message are defined in the enum MAV_FUEL_TYPE. The reported `consumed_fuel` and `remaining_fuel` must only be supplied if measured: they must not be inferred from the `maximum_fuel` and the other value. A recipient can assume that if these fields are supplied they are accurate. If not provided, the recipient can infer `remaining_fuel` from `maximum_fuel` and `consumed_fuel` on the assumption that the fuel was initially at its maximum (this is what battery monitors assume). Note however that this is an assumption, and the UI should prompt the user appropriately (i.e. notify user that they should fill the tank before boot). This kind of information may also be sent in fuel-specific messages such as BATTERY_STATUS_V2. If both messages are sent for the same fuel system, the ids and corresponding information must match. This should be streamed (nominally at 0.1 Hz). ### Fields

- **id** (`uint8_t`): Fuel ID. Must match ID of other messages for same fuel system, such as BATTERY_STATUS_V2. - **maximum_fuel** (`float`): Capacity when full. Must be provided. - **consumed_fuel** (`float`): Consumed fuel (measured). This value should not be inferred: if not measured set to NaN. NaN: field not provided. - **remaining_fuel** (`float`): Remaining fuel until empty (measured). The value should not be inferred: if not measured set to NaN. NaN: field not provided. - **percent_remaining** (`uint8_t`, %): Percentage of remaining fuel, relative to full. Values: [0-100], UINT8_MAX: field not provided. - **flow_rate** (`float`): Positive value when emptying/using, and negative if filling/replacing. NaN: field not provided. - **temperature** (`float`, K): Fuel temperature. NaN: field not provided. - **fuel_type** (`uint32_t`): Fuel type. Defines units for fuel capacity and consumption fields above.

--- chunk_id: chunk-0166
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: 8010a933cdfd33f1
prev_chunk_id: chunk-0165
next_chunk_id: chunk-0167
section_heading: BATTERY_INFO (msg id 372, dialect common)
document_type: technical_reference

## BATTERY_INFO (msg id 372, dialect common)

Battery information that is static, or requires infrequent update. This message should requested using MAV_CMD_REQUEST_MESSAGE and/or streamed at very low rate. BATTERY_STATUS_V2 is used for higher-rate battery status information. ### Fields

- **id** (`uint8_t`): Battery ID
- **battery_function** (`uint8_t`): Function of the battery. - **type** (`uint8_t`): Type (chemistry) of the battery. - **state_of_health** (`uint8_t`, %): State of Health (SOH) estimate. Typically 100% at the time of manufacture and will decrease over time and use. -1: field not provided. - **cells_in_series** (`uint8_t`): Number of battery cells in series. 0: field not provided. - **cycle_count** (`uint16_t`): Lifetime count of the number of charge/discharge cycles (https://en.wikipedia.org/wiki/Charge_cycle). UINT16_MAX: field not provided. - **weight** (`uint16_t`, g): Battery weight. 0: field not provided. - **discharge_minimum_voltage** (`float`, V): Minimum per-cell voltage when discharging. 0: field not provided. - **charging_minimum_voltage** (`float`, V): Minimum per-cell voltage when charging. 0: field not provided. - **resting_minimum_voltage** (`float`, V): Minimum per-cell voltage when resting. 0: field not provided. - **charging_maximum_voltage** (`float`, V): Maximum per-cell voltage when charged. 0: field not provided. - **charging_maximum_current** (`float`, A): Maximum pack continuous charge current. 0: field not provided. - **nominal_voltage** (`float`, V): Battery nominal voltage. Used for conversion between Wh and Ah. 0: field not provided. - **discharge_maximum_current** (`float`, A): Maximum pack discharge current. 0: field not provided. - **discharge_maximum_burst_current** (`float`, A): Maximum pack discharge burst current. 0: field not provided. - **design_capacity** (`float`, Ah): Fully charged design capacity. 0: field not provided. - **full_charge_capacity** (`float`, Ah): Predicted battery capacity when fully charged (accounting for battery degradation). NAN: field not provided. - **manufacture_date** (`char[9]`): Manufacture date (DDMMYYYY) in ASCII characters, 0 terminated. All 0: field not provided. - **serial_number** (`char[32]`): Serial number in ASCII characters, 0 terminated. All 0: field not provided. - **name** (`char[50]`): Battery device name. Formatted as manufacturer name then product name, separated with an underscore (in ASCII characters), 0 terminated. All 0: field not provided.

--- chunk_id: chunk-0167
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 293
content_hash: eb5bce57a1c841a6
prev_chunk_id: chunk-0166
next_chunk_id: chunk-0168
section_heading: GENERATOR_STATUS (msg id 373, dialect common)
document_type: technical_reference

## GENERATOR_STATUS (msg id 373, dialect common)

Telemetry of power generation system. Alternator or mechanical generator. ### Fields

- **status** (`uint64_t`): Status flags. - **generator_speed** (`uint16_t`, rpm): Speed of electrical generator or alternator. UINT16_MAX: field not provided. - **battery_current** (`float`, A): Current into/out of battery. Positive for out. Negative for in. NaN: field not provided. - **load_current** (`float`, A): Current going to the UAV. If battery current not available this is the DC current from the generator. Positive for out. Negative for in. NaN: field not provided
- **power_generated** (`float`, W): The power being generated. NaN: field not provided
- **bus_voltage** (`float`, V): Voltage of the bus seen at the generator, or battery bus if battery bus is controlled by generator and at a different voltage to main bus. - **rectifier_temperature** (`int16_t`, degC): The temperature of the rectifier or power converter. INT16_MAX: field not provided. - **bat_current_setpoint** (`float`, A): The target battery current. Positive for out. Negative for in. NaN: field not provided
- **generator_temperature** (`int16_t`, degC): The temperature of the mechanical motor, fuel cell core or generator. INT16_MAX: field not provided. - **runtime** (`uint32_t`, s): Seconds this generator has run since it was rebooted. UINT32_MAX: field not provided. - **time_until_maintenance** (`int32_t`, s): Seconds until this generator requires maintenance. A negative value indicates maintenance is past-due. INT32_MAX: field not provided.

--- chunk_id: chunk-0168
source_document: messages_batch_08.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 72
content_hash: 515b53f4df4fb088
prev_chunk_id: chunk-0167
next_chunk_id: chunk-0169
section_heading: ACTUATOR_OUTPUT_STATUS (msg id 375, dialect common)
document_type: technical_reference

## ACTUATOR_OUTPUT_STATUS (msg id 375, dialect common)

The raw values of the actuator outputs (e.g. on Pixhawk, from MAIN, AUX ports). This message supersedes SERVO_OUTPUT_RAW. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (since system boot). - **active** (`uint32_t`): Active outputs
- **actuator** (`float[32]`): Servo / motor output array values. Zero values indicate unused channels.

--- chunk_id: chunk-0169
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: 57c7763b63dd5c36
prev_chunk_id: chunk-0168
next_chunk_id: chunk-0170
section_heading: MAVLink messages batch 9
document_type: technical_reference

# MAVLink messages batch 9

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0170
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 337
content_hash: 220ccf6de13f0de4
prev_chunk_id: chunk-0169
next_chunk_id: chunk-0171
section_heading: RELAY_STATUS (msg id 376, dialect common)
document_type: technical_reference

## RELAY_STATUS (msg id 376, dialect common)

Reports the on/off state of relays, as controlled by MAV_CMD_DO_SET_RELAY. Message streaming should be requested using MAV_CMD_SET_MESSAGE_INTERVAL. Note that it should not be sent on every relay state change to avoid flooding the link. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **on** (`uint16_t`): Relay states. Relay instance numbers are represented as individual bits in this mask by offset. - **present** (`uint16_t`): Relay present. Relay instance numbers are represented as individual bits in this mask by offset. Bits will be true if a relay instance is configured. ### TIME_ESTIMATE_TO_TARGET (msg id 380, dialect common)
Time/duration estimates for various events and actions given the current vehicle state and position. ### Fields

- **safe_return** (`int32_t`, s): Estimated time to complete the vehicle's configured "safe return" action from its current position (e.g. RTL, Smart RTL, etc.). -1 indicates that the vehicle is landed, or that no time estimate available. - **land** (`int32_t`, s): Estimated time for vehicle to complete the LAND action from its current position. -1 indicates that the vehicle is landed, or that no time estimate available. - **mission_next_item** (`int32_t`, s): Estimated time for reaching/completing the currently active mission item. -1 means no time estimate available. - **mission_end** (`int32_t`, s): Estimated time for completing the current mission. -1 means no mission active and/or no estimate available. - **commanded_action** (`int32_t`, s): Estimated time for completing the current commanded action (i.e. Go To, Takeoff, Land, etc.). -1 means no action active and/or no estimate available.

--- chunk_id: chunk-0171
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 252
content_hash: cfa90e2114d86c13
prev_chunk_id: chunk-0170
next_chunk_id: chunk-0172
section_heading: TUNNEL (msg id 385, dialect common)
document_type: technical_reference

## TUNNEL (msg id 385, dialect common)

Message for transporting "arbitrary" variable-length data from one component to another (broadcast is not forbidden, but discouraged). The encoding of the data is usually extension specific, i.e. determined by the source, and is usually not documented as part of the MAVLink specification. ### Fields

- **target_system** (`uint8_t`): System ID (can be 0 for broadcast, but this is discouraged)
- **target_component** (`uint8_t`): Component ID (can be 0 for broadcast, but this is discouraged)
- **payload_type** (`uint16_t`): A code that identifies the content of the payload (0 for unknown, which is the default). If this code is less than 32768, it is a 'registered' payload type and the corresponding code should be added to the MAV_TUNNEL_PAYLOAD_TYPE enum. Software creators can register blocks of types as needed. Codes greater than 32767 are considered local experiments and should not be checked in to any widely distributed codebase. - **payload_length** (`uint8_t`): Length of the data transported in payload
- **payload** (`uint8_t[128]`): Variable length payload. The payload length is defined by payload_length. The entire content of this block is opaque unless you understand the encoding specified by payload_type.

--- chunk_id: chunk-0172
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 302
content_hash: 92db01ff3fdfb79f
prev_chunk_id: chunk-0171
next_chunk_id: chunk-0173
section_heading: CAN_FRAME (msg id 386, dialect common)
document_type: technical_reference

## CAN_FRAME (msg id 386, dialect common)

A forwarded CAN frame as requested by MAV_CMD_CAN_FORWARD. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **bus** (`uint8_t`): Bus number
- **len** (`uint8_t`): Frame length
- **id** (`uint32_t`): Frame ID
- **data** (`uint8_t[8]`): Frame data

### CANFD_FRAME (msg id 387, dialect common)
A forwarded CANFD frame as requested by MAV_CMD_CAN_FORWARD. These are separated from CAN_FRAME as they need different handling (eg. TAO handling)

### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **bus** (`uint8_t`): bus number
- **len** (`uint8_t`): Frame length
- **id** (`uint32_t`): Frame ID
- **data** (`uint8_t[64]`): Frame data

### CAN_FILTER_MODIFY (msg id 388, dialect common)
Modify the filter of what CAN messages to forward over the mavlink. This can be used to make CAN forwarding work well on low bandwidth links. The filtering is applied on bits 8 to 24 of the CAN id (2nd and 3rd bytes) which corresponds to the DroneCAN message ID for DroneCAN. Filters with more than 16 IDs can be constructed by sending multiple CAN_FILTER_MODIFY messages. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **bus** (`uint8_t`): bus number
- **operation** (`uint8_t`): what operation to perform on the filter list. See CAN_FILTER_OP enum. - **num_ids** (`uint8_t`): number of IDs in filter list
- **ids** (`uint16_t[16]`): filter IDs, length num_ids

--- chunk_id: chunk-0173
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: e0726723d11013c7
prev_chunk_id: chunk-0172
next_chunk_id: chunk-0174
section_heading: ONBOARD_COMPUTER_STATUS (msg id 390, dialect common)
document_type: technical_reference

## ONBOARD_COMPUTER_STATUS (msg id 390, dialect common)

Hardware status sent by an onboard computer. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number. - **uptime** (`uint32_t`, ms): Time since system boot. - **type** (`uint8_t`): Type of the onboard computer: 0: Mission computer primary, 1: Mission computer backup 1, 2: Mission computer backup 2, 3: Compute node, 4-5: Compute spares, 6-9: Payload computers. - **cpu_cores** (`uint8_t[8]`): CPU usage on the component in percent (100 - idle). A value of UINT8_MAX implies the field is unused. - **cpu_combined** (`uint8_t[10]`): Combined CPU usage as the last 10 slices of 100 MS (a histogram). This allows to identify spikes in load that max out the system, but only for a short amount of time. A value of UINT8_MAX implies the field is unused. - **gpu_cores** (`uint8_t[4]`): GPU usage on the component in percent (100 - idle). A value of UINT8_MAX implies the field is unused. - **gpu_combined** (`uint8_t[10]`): Combined GPU usage as the last 10 slices of 100 MS (a histogram). This allows to identify spikes in load that max out the system, but only for a short amount of time. A value of UINT8_MAX implies the field is unused. - **temperature_board** (`int8_t`, degC): Temperature of the board. A value of INT8_MAX implies the field is unused. - **temperature_core** (`int8_t[8]`, degC): Temperature of the CPU core. A value of INT8_MAX implies the field is unused. - **fan_speed** (`int16_t[4]`, rpm): Fan speeds. A value of INT16_MAX implies the field is unused. - **ram_usage** (`uint32_t`, MiB): Amount of used RAM on the component system. A value of UINT32_MAX implies the field is unused. - **ram_total** (`uint32_t`, MiB): Total amount of RAM on the component system. A value of UINT32_MAX implies the field is unused. - **storage_type** (`uint32_t[4]`): Storage type: 0: HDD, 1: SSD, 2: EMMC, 3: SD card (non-removable), 4: SD card (removable). A value of UINT32_MAX implies the field is unused. - **storage_usage** (`uint32_t[4]`, MiB): Amount of used storage space on the component system. A value of UINT32_MAX implies the field is unused. - **storage_total** (`uint32_t[4]`, MiB): Total amount of storage space on the component system. A value of UINT32_MAX implies the field is unused.

--- chunk_id: chunk-0174
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 164
content_hash: 1371cc8cc4747310
prev_chunk_id: chunk-0173
next_chunk_id: chunk-0175
section_heading: ONBOARD_COMPUTER_STATUS (msg id 390, dialect common)
document_type: technical_reference

- **storage_total** (`uint32_t[4]`, MiB): Total amount of storage space on the component system. A value of UINT32_MAX implies the field is unused. - **link_type** (`uint32_t[6]`): Link type: 0-9: UART, 10-19: Wired network, 20-29: Wifi, 30-39: Point-to-point proprietary, 40-49: Mesh proprietary
- **link_tx_rate** (`uint32_t[6]`, KiB/s): Network traffic from the component system. A value of UINT32_MAX implies the field is unused. - **link_rx_rate** (`uint32_t[6]`, KiB/s): Network traffic to the component system. A value of UINT32_MAX implies the field is unused. - **link_tx_max** (`uint32_t[6]`, KiB/s): Network capacity from the component system. A value of UINT32_MAX implies the field is unused. - **link_rx_max** (`uint32_t[6]`, KiB/s): Network capacity to the component system. A value of UINT32_MAX implies the field is unused. - **status_flags** (`uint16_t`): Bitmap of status flags.

--- chunk_id: chunk-0175
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 202
content_hash: 5a2cc38ed0ecd24f
prev_chunk_id: chunk-0174
next_chunk_id: chunk-0176
section_heading: COMPONENT_INFORMATION (msg id 395, dialect common)
document_type: technical_reference

## COMPONENT_INFORMATION (msg id 395, dialect common)

Component information message, which may be requested using MAV_CMD_REQUEST_MESSAGE. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **general_metadata_file_crc** (`uint32_t`): CRC32 of the general metadata file (general_metadata_uri). - **general_metadata_uri** (`char[100]`): MAVLink FTP URI for the general metadata file (COMP_METADATA_TYPE_GENERAL), which may be compressed with xz. The file contains general component metadata, and may contain URI links for additional metadata (see COMP_METADATA_TYPE). The information is static from boot, and may be generated at compile time. The string needs to be zero terminated. - **peripherals_metadata_file_crc** (`uint32_t`): CRC32 of peripherals metadata file (peripherals_metadata_uri). - **peripherals_metadata_uri** (`char[100]`): (Optional) MAVLink FTP URI for the peripherals metadata file (COMP_METADATA_TYPE_PERIPHERALS), which may be compressed with xz. This contains data about "attached components" such as UAVCAN nodes. The peripherals are in a separate file because the information must be generated dynamically at runtime. The string needs to be zero terminated.

--- chunk_id: chunk-0176
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 261
content_hash: 1d53db49a1ac94cc
prev_chunk_id: chunk-0175
next_chunk_id: chunk-0177
section_heading: COMPONENT_INFORMATION_BASIC (msg id 396, dialect common)
document_type: technical_reference

## COMPONENT_INFORMATION_BASIC (msg id 396, dialect common)

Basic component information data. Should be requested using MAV_CMD_REQUEST_MESSAGE on startup, or when required. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **capabilities** (`uint64_t`): Component capability flags
- **time_manufacture_s** (`uint32_t`, s): Date of manufacture as a UNIX Epoch time (since 1.1.1970) in seconds. - **vendor_name** (`char[32]`): Name of the component vendor. Needs to be zero terminated. The field is optional and can be empty/all zeros. - **model_name** (`char[32]`): Name of the component model. Needs to be zero terminated. The field is optional and can be empty/all zeros. - **software_version** (`char[24]`): Software version. The recommended format is SEMVER: 'major.minor.patch'  (any format may be used). The field must be zero terminated if it has a value. The field is optional and can be empty/all zeros. - **hardware_version** (`char[24]`): Hardware version. The recommended format is SEMVER: 'major.minor.patch'  (any format may be used). The field must be zero terminated if it has a value. The field is optional and can be empty/all zeros. - **serial_number** (`char[32]`): Hardware serial number. The field must be zero terminated if it has a value. The field is optional and can be empty/all zeros.

--- chunk_id: chunk-0177
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 234
content_hash: 5c5b1a423dd856eb
prev_chunk_id: chunk-0176
next_chunk_id: chunk-0178
section_heading: COMPONENT_METADATA (msg id 397, dialect common)
document_type: technical_reference

## COMPONENT_METADATA (msg id 397, dialect common)

Component metadata message, which may be requested using MAV_CMD_REQUEST_MESSAGE. This contains the MAVLink FTP URI and CRC for the component's general metadata file. The file must be hosted on the component, and may be xz compressed. The file CRC can be used for file caching. The general metadata file can be read to get the locations of other metadata files (COMP_METADATA_TYPE) and translations, which may be hosted either on the vehicle or the internet. For more information see: https://mavlink.io/en/services/component_information.html. Note: Camera components should use CAMERA_INFORMATION instead, and autopilots may use both this message and AUTOPILOT_VERSION. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **file_crc** (`uint32_t`): CRC32 of the general metadata file. - **uri** (`char[100]`): MAVLink FTP URI for the general metadata file (COMP_METADATA_TYPE_GENERAL), which may be compressed with xz. The file contains general component metadata, and may contain URI links for additional metadata (see COMP_METADATA_TYPE). The information is static from boot, and may be generated at compile time. The string needs to be zero terminated.

--- chunk_id: chunk-0178
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 336
content_hash: 61a096c90093bd0b
prev_chunk_id: chunk-0177
next_chunk_id: chunk-0179
section_heading: PLAY_TUNE_V2 (msg id 400, dialect common)
document_type: technical_reference

## PLAY_TUNE_V2 (msg id 400, dialect common)

Play vehicle tone/tune (buzzer). Supported tunes can be determined using SUPPORTED_TUNES. Supersedes message PLAY_TUNE. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **format** (`uint32_t`): Tune format
- **tune** (`char[248]`): Tune definition as a NULL-terminated string. ### SUPPORTED_TUNES (msg id 401, dialect common)
Tune formats supported by vehicle, i.e. via PLAY_TUNE_V2. This should be emitted as response to MAV_CMD_REQUEST_MESSAGE. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **format** (`uint32_t`): Bitfield of supported tune formats. ### EVENT (msg id 410, dialect common)
Event message. Each new event from a particular component gets a new sequence number. The same message might be sent multiple times if (re-)requested. Most events are broadcast, some can be specific to a target component (as receivers keep track of the sequence for missed events, all events need to be broadcast. Thus we use destination_component instead of target_component). ### Fields

- **destination_component** (`uint8_t`): Component ID
- **destination_system** (`uint8_t`): System ID
- **id** (`uint32_t`): Event ID (as defined in the component metadata)
- **event_time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot when the event happened). - **sequence** (`uint16_t`): Sequence number. - **log_levels** (`uint8_t`): Log levels: 4 bits MSB: internal (for logging purposes), 4 bits LSB: external. Levels: Emergency = 0, Alert = 1, Critical = 2, Error = 3, Warning = 4, Notice = 5, Info = 6, Debug = 7, Protocol = 8, Disabled = 9
- **arguments** (`uint8_t[40]`): Arguments (depend on event ID).

--- chunk_id: chunk-0179
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 237
content_hash: 628383fb5efa5040
prev_chunk_id: chunk-0178
next_chunk_id: chunk-0180
section_heading: CURRENT_EVENT_SEQUENCE (msg id 411, dialect common)
document_type: technical_reference

## CURRENT_EVENT_SEQUENCE (msg id 411, dialect common)

Regular broadcast for the current latest event sequence number for a component. This is used to check for dropped events. ### Fields

- **sequence** (`uint16_t`): Sequence number. - **flags** (`uint8_t`): Flag bitset. ### REQUEST_EVENT (msg id 412, dialect common)
Request one or more events to be (re-)sent. If first_sequence==last_sequence, only a single event is requested. Note that first_sequence can be larger than last_sequence (because the sequence number can wrap). Each sequence will trigger an EVENT or EVENT_ERROR response. ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **first_sequence** (`uint16_t`): First sequence number of the requested event. - **last_sequence** (`uint16_t`): Last sequence number of the requested event. ### RESPONSE_EVENT_ERROR (msg id 413, dialect common)
Response to a REQUEST_EVENT in case of an error (e.g. the event is not available anymore). ### Fields

- **target_system** (`uint8_t`): System ID
- **target_component** (`uint8_t`): Component ID
- **sequence** (`uint16_t`): Sequence number. - **sequence_oldest_available** (`uint16_t`): Oldest Sequence number that is still available after the sequence set in REQUEST_EVENT. - **reason** (`uint8_t`): Error reason.

--- chunk_id: chunk-0180
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 260
content_hash: 35593be46735f7d8
prev_chunk_id: chunk-0179
next_chunk_id: chunk-0181
section_heading: AVAILABLE_MODES (msg id 435, dialect common)
document_type: technical_reference

## AVAILABLE_MODES (msg id 435, dialect common)

Information about a flight mode. The message can be enumerated to get information for all modes, or requested for a particular mode, using MAV_CMD_REQUEST_MESSAGE. Specify 0 in param2 to request that the message is emitted for all available modes or the specific index for just one mode. The modes must be available/settable for the current vehicle/frame type. Each mode should only be emitted once (even if it is both standard and custom). Note that the current mode should be emitted in CURRENT_MODE, and that if the mode list can change then AVAILABLE_MODES_MONITOR must be emitted on first change and subsequently streamed. See https://mavlink.io/en/services/standard_modes.html

### Fields

- **number_modes** (`uint8_t`): The total number of available modes for the current vehicle type. - **mode_index** (`uint8_t`): The current mode index within number_modes, indexed from 1. The index is not guaranteed to be persistent, and may change between reboots or if the set of modes change. - **standard_mode** (`uint8_t`): Standard mode. - **custom_mode** (`uint32_t`): A bitfield for use for autopilot-specific flags
- **properties** (`uint32_t`): Mode properties. - **mode_name** (`char[35]`): Name of custom mode, with null termination character. Should be omitted for standard modes.

--- chunk_id: chunk-0181
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 278
content_hash: aacc0ebe20b82ebf
prev_chunk_id: chunk-0180
next_chunk_id: chunk-0182
section_heading: CURRENT_MODE (msg id 436, dialect common)
document_type: technical_reference

## CURRENT_MODE (msg id 436, dialect common)

Get the current mode. This should be emitted on any mode change, and broadcast at low rate (nominally 0.5 Hz). It may be requested using MAV_CMD_REQUEST_MESSAGE. See https://mavlink.io/en/services/standard_modes.html

### Fields

- **standard_mode** (`uint8_t`): Standard mode. - **custom_mode** (`uint32_t`): A bitfield for use for autopilot-specific flags
- **intended_custom_mode** (`uint32_t`): The custom_mode of the mode that was last commanded by the user (for example, with MAV_CMD_DO_SET_STANDARD_MODE, MAV_CMD_DO_SET_MODE or via RC). This should usually be the same as custom_mode. It will be different if the vehicle is unable to enter the intended mode, or has left that mode due to a failsafe condition. 0 indicates the intended custom mode is unknown/not supplied

### AVAILABLE_MODES_MONITOR (msg id 437, dialect common)
A change to the sequence number indicates that the set of AVAILABLE_MODES has changed, and that the receiver should re-request all available modes. The message is optional, and is only needed when the set of modes can change dynamically after boot. It should be emitted whenever the set of modes change. It should be streamed at low rate (nominally 0.3 Hz). See https://mavlink.io/en/services/standard_modes.html

### Fields

- **seq** (`uint8_t`): Sequence number. The value iterates sequentially whenever AVAILABLE_MODES changes (e.g. support for a new mode is added/removed dynamically).

--- chunk_id: chunk-0182
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 226
content_hash: 1495a629ba9bb763
prev_chunk_id: chunk-0181
next_chunk_id: chunk-0183
section_heading: ILLUMINATOR_STATUS (msg id 440, dialect common)
document_type: technical_reference

## ILLUMINATOR_STATUS (msg id 440, dialect common)

Illuminator status

### Fields

- **uptime_ms** (`uint32_t`, ms): Time since the start-up of the illuminator in ms
- **enable** (`uint8_t`): 0: Illuminators OFF, 1: Illuminators ON
- **mode_bitmask** (`uint8_t`): Supported illuminator modes
- **error_status** (`uint32_t`): Errors
- **mode** (`uint8_t`): Illuminator mode
- **brightness** (`float`, %): Illuminator brightness
- **strobe_period** (`float`, s): Illuminator strobing period in seconds
- **strobe_duty_cycle** (`float`, %): Illuminator strobing duty cycle
- **temp_c** (`float`): Temperature in Celsius
- **min_strobe_period** (`float`, s): Minimum strobing period in seconds
- **max_strobe_period** (`float`, s): Maximum strobing period in seconds

### WHEEL_DISTANCE (msg id 9000, dialect common)
Cumulative distance traveled for each reported wheel. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (synced to UNIX time or since system boot). - **count** (`uint8_t`): Number of wheels reported. - **distance** (`double[16]`, m): Distance reported by individual wheel encoders. Forward rotations increase values, reverse rotations decrease them. Not all wheels will necessarily have wheel encoders; the mapping of encoders to wheel positions must be agreed/understood by the endpoints.

--- chunk_id: chunk-0183
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: 8e00feb8eeff5978
prev_chunk_id: chunk-0182
next_chunk_id: chunk-0184
section_heading: WINCH_STATUS (msg id 9005, dialect common)
document_type: technical_reference

## WINCH_STATUS (msg id 9005, dialect common)

Winch status. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (synced to UNIX time or since system boot). - **line_length** (`float`, m): Length of line released. NaN if unknown
- **speed** (`float`, m/s): Speed line is being released or retracted. Positive values if being released, negative values if being retracted, NaN if unknown
- **tension** (`float`, kg): Tension on the line. NaN if unknown
- **voltage** (`float`, V): Voltage of the battery supplying the winch. NaN if unknown
- **current** (`float`, A): Current draw from the winch. NaN if unknown
- **temperature** (`int16_t`, degC): Temperature of the motor. INT16_MAX if unknown
- **status** (`uint32_t`): Status flags

### OPEN_DRONE_ID_BASIC_ID (msg id 12900, dialect common)
Data for filling the OpenDroneID Basic ID message. This and the below messages are primarily meant for feeding data to/from an OpenDroneID implementation. E.g. https://github.com/opendroneid/opendroneid-core-c. These messages are compatible with the ASTM F3411 Remote ID standard and the ASD-STAN prEN 4709-002 Direct Remote ID standard. Additional information and usage of these messages is documented at https://mavlink.io/en/services/opendroneid.html. ### Fields

- **target_system** (`uint8_t`): System ID (0 for broadcast). - **target_component** (`uint8_t`): Component ID (0 for broadcast). - **id_or_mac** (`uint8_t[20]`): Only used for drone ID data received from other UAs. See detailed description at https://mavlink.io/en/services/opendroneid.html. - **id_type** (`uint8_t`): Indicates the format for the uas_id field of this message. - **ua_type** (`uint8_t`): Indicates the type of UA (Unmanned Aircraft). - **uas_id** (`uint8_t[20]`): UAS (Unmanned Aircraft System) ID following the format specified by id_type. Shall be filled with nulls in the unused portion of the field.

--- chunk_id: chunk-0184
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 480
content_hash: 2667197daf7a99e3
prev_chunk_id: chunk-0183
next_chunk_id: chunk-0185
section_heading: OPEN_DRONE_ID_LOCATION (msg id 12901, dialect common)
document_type: technical_reference

## OPEN_DRONE_ID_LOCATION (msg id 12901, dialect common)

Data for filling the OpenDroneID Location message. The float data types are 32-bit IEEE 754. The Location message provides the location, altitude, direction and speed of the aircraft. ### Fields

- **target_system** (`uint8_t`): System ID (0 for broadcast). - **target_component** (`uint8_t`): Component ID (0 for broadcast). - **id_or_mac** (`uint8_t[20]`): Only used for drone ID data received from other UAs. See detailed description at https://mavlink.io/en/services/opendroneid.html. - **status** (`uint8_t`): Indicates whether the unmanned aircraft is on the ground or in the air. - **direction** (`uint16_t`, cdeg): Direction over ground (not heading, but direction of movement) measured clockwise from true North: 0 - 35999 centi-degrees. If unknown: 36100 centi-degrees. - **speed_horizontal** (`uint16_t`, cm/s): Ground speed. Positive only. If unknown: 25500 cm/s. If speed is larger than 25425 cm/s, use 25425 cm/s. - **speed_vertical** (`int16_t`, cm/s): The vertical speed. Up is positive. If unknown: 6300 cm/s. If speed is larger than 6200 cm/s, use 6200 cm/s. If lower than -6200 cm/s, use -6200 cm/s. - **latitude** (`int32_t`, degE7): Current latitude of the unmanned aircraft. If unknown: 0 (both Lat/Lon). - **longitude** (`int32_t`, degE7): Current longitude of the unmanned aircraft. If unknown: 0 (both Lat/Lon). - **altitude_barometric** (`float`, m): The altitude calculated from the barometric pressure. Reference is against 29.92inHg or 1013.2mb. If unknown: -1000 m. - **altitude_geodetic** (`float`, m): The geodetic altitude as defined by WGS84. If unknown: -1000 m. - **height_reference** (`uint8_t`): Indicates the reference point for the height field. - **height** (`float`, m): The current height of the unmanned aircraft above the take-off location or the ground as indicated by height_reference. If unknown: -1000 m. - **horizontal_accuracy** (`uint8_t`): The accuracy of the horizontal position. - **vertical_accuracy** (`uint8_t`): The accuracy of the vertical position. - **barometer_accuracy** (`uint8_t`): The accuracy of the barometric altitude. - **speed_accuracy** (`uint8_t`): The accuracy of the horizontal and vertical speed. - **timestamp** (`float`, s): Seconds after the full hour with reference to UTC time. Typically the GPS outputs a time-of-week value in milliseconds. First convert that to UTC and then convert for this field using ((float) (time_week_ms % (60*60*1000))) / 1000. If unknown: 0xFFFF. - **timestamp_accuracy** (`uint8_t`): The accuracy of the timestamps.

--- chunk_id: chunk-0185
source_document: messages_batch_09.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 326
content_hash: 039e3ca5aed519ee
prev_chunk_id: chunk-0184
next_chunk_id: chunk-0186
section_heading: OPEN_DRONE_ID_AUTHENTICATION (msg id 12902, dialect common)
document_type: technical_reference

## OPEN_DRONE_ID_AUTHENTICATION (msg id 12902, dialect common)

Data for filling the OpenDroneID Authentication message. The Authentication Message defines a field that can provide a means of authenticity for the identity of the UAS (Unmanned Aircraft System). The Authentication message can have two different formats. For data page 0, the fields PageCount, Length and TimeStamp are present and AuthData is only 17 bytes. For data page 1 through 15, PageCount, Length and TimeStamp are not present and the size of AuthData is 23 bytes. ### Fields

- **target_system** (`uint8_t`): System ID (0 for broadcast). - **target_component** (`uint8_t`): Component ID (0 for broadcast). - **id_or_mac** (`uint8_t[20]`): Only used for drone ID data received from other UAs. See detailed description at https://mavlink.io/en/services/opendroneid.html. - **authentication_type** (`uint8_t`): Indicates the type of authentication. - **data_page** (`uint8_t`): Allowed range is 0 - 15. - **last_page_index** (`uint8_t`): This field is only present for page 0. Allowed range is 0 - 15. See the description of struct ODID_Auth_data at https://github.com/opendroneid/opendroneid-core-c/blob/master/libopendroneid/opendroneid.h. - **length** (`uint8_t`, bytes): This field is only present for page 0. Total bytes of authentication_data from all data pages. See the description of struct ODID_Auth_data at https://github.com/opendroneid/opendroneid-core-c/blob/master/libopendroneid/opendroneid.h. - **timestamp** (`uint32_t`, s): This field is only present for page 0. 32 bit Unix Timestamp in seconds since 00:00:00 01/01/2019. - **authentication_data** (`uint8_t[23]`): Opaque authentication data. For page 0, the size is only 17 bytes. For other pages, the size is 23 bytes. Shall be filled with nulls in the unused portion of the field.

--- chunk_id: chunk-0186
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: c43613b5d44cedaf
prev_chunk_id: chunk-0185
next_chunk_id: chunk-0187
section_heading: MAVLink messages batch 10
document_type: technical_reference

# MAVLink messages batch 10

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0187
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 196
content_hash: ed442dda76473d93
prev_chunk_id: chunk-0186
next_chunk_id: chunk-0188
section_heading: OPEN_DRONE_ID_SELF_ID (msg id 12903, dialect common)
document_type: technical_reference

## OPEN_DRONE_ID_SELF_ID (msg id 12903, dialect common)

Data for filling the OpenDroneID Self ID message. The Self ID Message is an opportunity for the operator to (optionally) declare their identity and purpose of the flight. This message can provide additional information that could reduce the threat profile of a UA (Unmanned Aircraft) flying in a particular area or manner. This message can also be used to provide optional additional clarification in an emergency/remote ID system failure situation. ### Fields

- **target_system** (`uint8_t`): System ID (0 for broadcast). - **target_component** (`uint8_t`): Component ID (0 for broadcast). - **id_or_mac** (`uint8_t[20]`): Only used for drone ID data received from other UAs. See detailed description at https://mavlink.io/en/services/opendroneid.html. - **description_type** (`uint8_t`): Indicates the type of the description field. - **description** (`char[23]`): Text description or numeric value expressed as ASCII characters. Shall be filled with nulls in the unused portion of the field.

--- chunk_id: chunk-0188
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 326
content_hash: eb2d7c7b0301e9d3
prev_chunk_id: chunk-0187
next_chunk_id: chunk-0189
section_heading: OPEN_DRONE_ID_SYSTEM (msg id 12904, dialect common)
document_type: technical_reference

## OPEN_DRONE_ID_SYSTEM (msg id 12904, dialect common)

Data for filling the OpenDroneID System message. The System Message contains general system information including the operator location/altitude and possible aircraft group and/or category/class information. ### Fields

- **target_system** (`uint8_t`): System ID (0 for broadcast). - **target_component** (`uint8_t`): Component ID (0 for broadcast). - **id_or_mac** (`uint8_t[20]`): Only used for drone ID data received from other UAs. See detailed description at https://mavlink.io/en/services/opendroneid.html. - **operator_location_type** (`uint8_t`): Specifies the operator location type. - **classification_type** (`uint8_t`): Specifies the classification type of the UA. - **operator_latitude** (`int32_t`, degE7): Latitude of the operator. If unknown: 0 (both Lat/Lon). - **operator_longitude** (`int32_t`, degE7): Longitude of the operator. If unknown: 0 (both Lat/Lon). - **area_count** (`uint16_t`): Number of aircraft in the area, group or formation (default 1). Used only for swarms/multiple UA. - **area_radius** (`uint16_t`, m): Radius of the cylindrical area of the group or formation (default 0). Used only for swarms/multiple UA. - **area_ceiling** (`float`, m): Area Operations Ceiling relative to WGS84. If unknown: -1000 m. Used only for swarms/multiple UA. - **area_floor** (`float`, m): Area Operations Floor relative to WGS84. If unknown: -1000 m. Used only for swarms/multiple UA. - **category_eu** (`uint8_t`): When classification_type is MAV_ODID_CLASSIFICATION_TYPE_EU, specifies the category of the UA. - **class_eu** (`uint8_t`): When classification_type is MAV_ODID_CLASSIFICATION_TYPE_EU, specifies the class of the UA. - **operator_altitude_geo** (`float`, m): Geodetic altitude of the operator relative to WGS84. If unknown: -1000 m. - **timestamp** (`uint32_t`, s): 32 bit Unix Timestamp in seconds since 00:00:00 01/01/2019.

--- chunk_id: chunk-0189
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 341
content_hash: dc35b792341980a4
prev_chunk_id: chunk-0188
next_chunk_id: chunk-0190
section_heading: OPEN_DRONE_ID_OPERATOR_ID (msg id 12905, dialect common)
document_type: technical_reference

## OPEN_DRONE_ID_OPERATOR_ID (msg id 12905, dialect common)

Data for filling the OpenDroneID Operator ID message, which contains the CAA (Civil Aviation Authority) issued operator ID. ### Fields

- **target_system** (`uint8_t`): System ID (0 for broadcast). - **target_component** (`uint8_t`): Component ID (0 for broadcast). - **id_or_mac** (`uint8_t[20]`): Only used for drone ID data received from other UAs. See detailed description at https://mavlink.io/en/services/opendroneid.html. - **operator_id_type** (`uint8_t`): Indicates the type of the operator_id field. - **operator_id** (`char[20]`): Text description or numeric value expressed as ASCII characters. Shall be filled with nulls in the unused portion of the field. ### OPEN_DRONE_ID_MESSAGE_PACK (msg id 12915, dialect common)
An OpenDroneID message pack is a container for multiple encoded OpenDroneID messages (i.e. not in the format given for the above message descriptions but after encoding into the compressed OpenDroneID byte format). Used e.g. when transmitting on Bluetooth 5.0 Long Range/Extended Advertising or on WiFi Neighbor Aware Networking or on WiFi Beacon. ### Fields

- **target_system** (`uint8_t`): System ID (0 for broadcast). - **target_component** (`uint8_t`): Component ID (0 for broadcast). - **id_or_mac** (`uint8_t[20]`): Only used for drone ID data received from other UAs. See detailed description at https://mavlink.io/en/services/opendroneid.html. - **single_message_size** (`uint8_t`, bytes): This field must currently always be equal to 25 (bytes), since all encoded OpenDroneID messages are specified to have this length. - **msg_pack_size** (`uint8_t`): Number of encoded messages in the pack (not the number of bytes). Allowed range is 1 - 9. - **messages** (`uint8_t[225]`): Concatenation of encoded OpenDroneID messages. Shall be filled with nulls in the unused portion of the field.

--- chunk_id: chunk-0190
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 277
content_hash: 398153cfd6223166
prev_chunk_id: chunk-0189
next_chunk_id: chunk-0191
section_heading: OPEN_DRONE_ID_ARM_STATUS (msg id 12918, dialect common)
document_type: technical_reference

## OPEN_DRONE_ID_ARM_STATUS (msg id 12918, dialect common)

Transmitter (remote ID system) is enabled and ready to start sending location and other required information. This is streamed by transmitter. A flight controller uses it as a condition to arm. ### Fields

- **status** (`uint8_t`): Status level indicating if arming is allowed. - **error** (`char[50]`): Text error message, should be empty if status is good to arm. Fill with nulls in unused portion. ### OPEN_DRONE_ID_SYSTEM_UPDATE (msg id 12919, dialect common)
Update the data in the OPEN_DRONE_ID_SYSTEM message with new location information. This can be sent to update the location information for the operator when no other information in the SYSTEM message has changed. This message allows for efficient operation on radio links which have limited uplink bandwidth while meeting requirements for update frequency of the operator location. ### Fields

- **target_system** (`uint8_t`): System ID (0 for broadcast). - **target_component** (`uint8_t`): Component ID (0 for broadcast). - **operator_latitude** (`int32_t`, degE7): Latitude of the operator. If unknown: 0 (both Lat/Lon). - **operator_longitude** (`int32_t`, degE7): Longitude of the operator. If unknown: 0 (both Lat/Lon). - **operator_altitude_geo** (`float`, m): Geodetic altitude of the operator relative to WGS84. If unknown: -1000 m. - **timestamp** (`uint32_t`, s): 32 bit Unix Timestamp in seconds since 00:00:00 01/01/2019.

--- chunk_id: chunk-0191
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: ff35daec410fcb2d
prev_chunk_id: chunk-0190
next_chunk_id: chunk-0192
section_heading: HYGROMETER_SENSOR (msg id 12920, dialect common)
document_type: technical_reference

## HYGROMETER_SENSOR (msg id 12920, dialect common)

Temperature and humidity from hygrometer. ### Fields

- **id** (`uint8_t`): Hygrometer ID
- **temperature** (`int16_t`, cdegC): Temperature
- **humidity** (`uint16_t`, c%): Humidity

### SENSOR_OFFSETS (msg id 150, dialect ardupilotmega)
Offsets and calibrations values for hardware sensors. This makes it easier to debug the calibration process. ### Fields

- **mag_ofs_x** (`int16_t`): Magnetometer X offset. - **mag_ofs_y** (`int16_t`): Magnetometer Y offset. - **mag_ofs_z** (`int16_t`): Magnetometer Z offset. - **mag_declination** (`float`, rad): Magnetic declination. - **raw_press** (`int32_t`): Raw pressure from barometer. - **raw_temp** (`int32_t`): Raw temperature from barometer. - **gyro_cal_x** (`float`): Gyro X calibration. - **gyro_cal_y** (`float`): Gyro Y calibration. - **gyro_cal_z** (`float`): Gyro Z calibration. - **accel_cal_x** (`float`): Accel X calibration. - **accel_cal_y** (`float`): Accel Y calibration. - **accel_cal_z** (`float`): Accel Z calibration. ### SET_MAG_OFFSETS (msg id 151, dialect ardupilotmega)
Set the magnetometer offsets

### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **mag_ofs_x** (`int16_t`): Magnetometer X offset. - **mag_ofs_y** (`int16_t`): Magnetometer Y offset. - **mag_ofs_z** (`int16_t`): Magnetometer Z offset.

--- chunk_id: chunk-0192
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 309
content_hash: ec8750ef9cdcbb4d
prev_chunk_id: chunk-0191
next_chunk_id: chunk-0193
section_heading: MEMINFO (msg id 152, dialect ardupilotmega)
document_type: technical_reference

## MEMINFO (msg id 152, dialect ardupilotmega)

State of autopilot RAM. ### Fields

- **brkval** (`uint16_t`): Heap top. - **freemem** (`uint16_t`, bytes): Free memory. - **freemem32** (`uint32_t`, bytes): Free memory (32 bit). ### AP_ADC (msg id 153, dialect ardupilotmega)
Raw ADC output. ### Fields

- **adc1** (`uint16_t`): ADC output 1. - **adc2** (`uint16_t`): ADC output 2. - **adc3** (`uint16_t`): ADC output 3. - **adc4** (`uint16_t`): ADC output 4. - **adc5** (`uint16_t`): ADC output 5. - **adc6** (`uint16_t`): ADC output 6. ### DIGICAM_CONFIGURE (msg id 154, dialect ardupilotmega)
Configure on-board Camera Control System. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **mode** (`uint8_t`): Mode enumeration from 1 to N //P, TV, AV, M, etc. (0 means ignore). - **shutter_speed** (`uint16_t`): Divisor number //e.g. 1000 means 1/1000 (0 means ignore). - **aperture** (`uint8_t`): F stop number x 10 //e.g. 28 means 2.8 (0 means ignore). - **iso** (`uint8_t`): ISO enumeration from 1 to N //e.g. 80, 100, 200, Etc (0 means ignore). - **exposure_type** (`uint8_t`): Exposure type enumeration from 1 to N (0 means ignore). - **command_id** (`uint8_t`): Command Identity (incremental loop: 0 to 255). //A command sent multiple times will be executed or pooled just once. - **engine_cut_off** (`uint8_t`, ds): Main engine cut-off time before camera trigger (0 means no cut-off). - **extra_param** (`uint8_t`): Extra parameters enumeration (0 means ignore). - **extra_value** (`float`): Correspondent value to given extra_param.

--- chunk_id: chunk-0193
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 182
content_hash: ab646c9d22398d66
prev_chunk_id: chunk-0192
next_chunk_id: chunk-0194
section_heading: DIGICAM_CONTROL (msg id 155, dialect ardupilotmega)
document_type: technical_reference

## DIGICAM_CONTROL (msg id 155, dialect ardupilotmega)

Control on-board Camera Control System to take shots. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **session** (`uint8_t`): 0: stop, 1: start or keep it up //Session control e.g. show/hide lens. - **zoom_pos** (`uint8_t`): 1 to N //Zoom's absolute position (0 means ignore). - **zoom_step** (`int8_t`): -100 to 100 //Zooming step value to offset zoom from the current position. - **focus_lock** (`uint8_t`): 0: unlock focus or keep unlocked, 1: lock focus or keep locked, 3: re-lock focus. - **shot** (`uint8_t`): 0: ignore, 1: shot or start filming. - **command_id** (`uint8_t`): Command Identity (incremental loop: 0 to 255)//A command sent multiple times will be executed or pooled just once. - **extra_param** (`uint8_t`): Extra parameters enumeration (0 means ignore). - **extra_value** (`float`): Correspondent value to given extra_param.

--- chunk_id: chunk-0194
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 262
content_hash: b717c452c007b9fe
prev_chunk_id: chunk-0193
next_chunk_id: chunk-0195
section_heading: MOUNT_CONFIGURE (msg id 156, dialect ardupilotmega)
document_type: technical_reference

## MOUNT_CONFIGURE (msg id 156, dialect ardupilotmega)

Message to configure a camera mount, directional antenna, etc. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **mount_mode** (`uint8_t`): Mount operating mode. - **stab_roll** (`uint8_t`): (1 = yes, 0 = no). - **stab_pitch** (`uint8_t`): (1 = yes, 0 = no). - **stab_yaw** (`uint8_t`): (1 = yes, 0 = no). ### MOUNT_CONTROL (msg id 157, dialect ardupilotmega)
Message to control a camera mount, directional antenna, etc. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **input_a** (`int32_t`): Pitch (centi-degrees) or lat (degE7), depending on mount mode. - **input_b** (`int32_t`): Roll (centi-degrees) or lon (degE7) depending on mount mode. - **input_c** (`int32_t`): Yaw (centi-degrees) or alt (cm) depending on mount mode. - **save_position** (`uint8_t`): If "1" it will save current trimmed position on EEPROM (just valid for NEUTRAL and LANDING). ### MOUNT_STATUS (msg id 158, dialect ardupilotmega)
Message with some status from autopilot to GCS about camera or antenna mount. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **pointing_a** (`int32_t`, cdeg): Pitch. - **pointing_b** (`int32_t`, cdeg): Roll. - **pointing_c** (`int32_t`, cdeg): Yaw. - **mount_mode** (`uint8_t`): Mount operating mode.

--- chunk_id: chunk-0195
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: 1a5bd246332ccfb1
prev_chunk_id: chunk-0194
next_chunk_id: chunk-0196
section_heading: FENCE_POINT (msg id 160, dialect ardupilotmega)
document_type: technical_reference

## FENCE_POINT (msg id 160, dialect ardupilotmega)

A fence point. Used to set a point when from GCS -> MAV. Also used to return a point from MAV -> GCS. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **idx** (`uint8_t`): Point index (first point is 1, 0 is for return point). - **count** (`uint8_t`): Total number of points (for sanity checking). - **lat** (`float`, deg): Latitude of point. - **lng** (`float`, deg): Longitude of point. ### FENCE_FETCH_POINT (msg id 161, dialect ardupilotmega)
Request a current fence point from MAV. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **idx** (`uint8_t`): Point index (first point is 1, 0 is for return point). ### AHRS (msg id 163, dialect ardupilotmega)
Status of DCM attitude estimator. ### Fields

- **omegaIx** (`float`, rad/s): X gyro drift estimate. - **omegaIy** (`float`, rad/s): Y gyro drift estimate. - **omegaIz** (`float`, rad/s): Z gyro drift estimate. - **accel_weight** (`float`): Average accel_weight. - **renorm_val** (`float`): Average renormalisation value. - **error_rp** (`float`): Average error_roll_pitch value. - **error_yaw** (`float`): Average error_yaw value.

--- chunk_id: chunk-0196
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 230
content_hash: 99858b33c1ddf193
prev_chunk_id: chunk-0195
next_chunk_id: chunk-0197
section_heading: SIMSTATE (msg id 164, dialect ardupilotmega)
document_type: technical_reference

## SIMSTATE (msg id 164, dialect ardupilotmega)

Status of simulation environment, if used. ### Fields

- **roll** (`float`, rad): Roll angle. - **pitch** (`float`, rad): Pitch angle. - **yaw** (`float`, rad): Yaw angle. - **xacc** (`float`, m/s/s): X acceleration. - **yacc** (`float`, m/s/s): Y acceleration. - **zacc** (`float`, m/s/s): Z acceleration. - **xgyro** (`float`, rad/s): Angular speed around X axis. - **ygyro** (`float`, rad/s): Angular speed around Y axis. - **zgyro** (`float`, rad/s): Angular speed around Z axis. - **lat** (`int32_t`, degE7): Latitude. - **lng** (`int32_t`, degE7): Longitude. ### HWSTATUS (msg id 165, dialect ardupilotmega)
Status of key hardware. ### Fields

- **Vcc** (`uint16_t`, mV): Board voltage. - **I2Cerr** (`uint8_t`): I2C error count. ### RADIO (msg id 166, dialect ardupilotmega)
Status generated by radio. ### Fields

- **rssi** (`uint8_t`): Local signal strength. - **remrssi** (`uint8_t`): Remote signal strength. - **txbuf** (`uint8_t`, %): Remaining free transmitter buffer space. - **noise** (`uint8_t`): Background noise level. - **remnoise** (`uint8_t`): Remote background noise level. - **rxerrors** (`uint16_t`): Receive errors. - **fixed** (`uint16_t`): Count of error corrected packets.

--- chunk_id: chunk-0197
source_document: messages_batch_10.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 222
content_hash: b263181a99e31e66
prev_chunk_id: chunk-0196
next_chunk_id: chunk-0198
section_heading: LIMITS_STATUS (msg id 167, dialect ardupilotmega)
document_type: technical_reference

## LIMITS_STATUS (msg id 167, dialect ardupilotmega)

Status of AP_Limits. Sent in extended status stream when AP_Limits is enabled. ### Fields

- **limits_state** (`uint8_t`): State of AP_Limits. - **last_trigger** (`uint32_t`, ms): Time (since boot) of last breach. - **last_action** (`uint32_t`, ms): Time (since boot) of last recovery action. - **last_recovery** (`uint32_t`, ms): Time (since boot) of last successful recovery. - **last_clear** (`uint32_t`, ms): Time (since boot) of last all-clear. - **breach_count** (`uint16_t`): Number of fence breaches. - **mods_enabled** (`uint8_t`): AP_Limit_Module bitfield of enabled modules. - **mods_required** (`uint8_t`): AP_Limit_Module bitfield of required modules. - **mods_triggered** (`uint8_t`): AP_Limit_Module bitfield of triggered modules. ### WIND (msg id 168, dialect ardupilotmega)
Wind estimation. ### Fields

- **direction** (`float`, deg): Wind direction (that wind is coming from). - **speed** (`float`, m/s): Wind speed in ground plane. - **speed_z** (`float`, m/s): Vertical wind speed. ### DATA16 (msg id 169, dialect ardupilotmega)
Data packet, size 16. ### Fields

- **type** (`uint8_t`): Data type. - **len** (`uint8_t`, bytes): Data length. - **data** (`uint8_t[16]`): Raw data.

--- chunk_id: chunk-0198
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: a51fc78280505583
prev_chunk_id: chunk-0197
next_chunk_id: chunk-0199
section_heading: MAVLink messages batch 11
document_type: technical_reference

# MAVLink messages batch 11

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0199
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 262
content_hash: 05042495d09e86d0
prev_chunk_id: chunk-0198
next_chunk_id: chunk-0200
section_heading: DATA32 (msg id 170, dialect ardupilotmega)
document_type: technical_reference

## DATA32 (msg id 170, dialect ardupilotmega)

Data packet, size 32. ### Fields

- **type** (`uint8_t`): Data type. - **len** (`uint8_t`, bytes): Data length. - **data** (`uint8_t[32]`): Raw data. ### DATA64 (msg id 171, dialect ardupilotmega)
Data packet, size 64. ### Fields

- **type** (`uint8_t`): Data type. - **len** (`uint8_t`, bytes): Data length. - **data** (`uint8_t[64]`): Raw data. ### DATA96 (msg id 172, dialect ardupilotmega)
Data packet, size 96. ### Fields

- **type** (`uint8_t`): Data type. - **len** (`uint8_t`, bytes): Data length. - **data** (`uint8_t[96]`): Raw data. ### RANGEFINDER (msg id 173, dialect ardupilotmega)
Rangefinder reporting. ### Fields

- **distance** (`float`, m): Distance. - **voltage** (`float`, V): Raw voltage if available, zero otherwise. ### AIRSPEED_AUTOCAL (msg id 174, dialect ardupilotmega)
Airspeed auto-calibration. ### Fields

- **vx** (`float`, m/s): GPS velocity north. - **vy** (`float`, m/s): GPS velocity east. - **vz** (`float`, m/s): GPS velocity down. - **diff_pressure** (`float`, Pa): Differential pressure. - **EAS2TAS** (`float`): Estimated to true airspeed ratio. - **ratio** (`float`): Airspeed ratio. - **state_x** (`float`): EKF state x. - **state_y** (`float`): EKF state y. - **state_z** (`float`): EKF state z. - **Pax** (`float`): EKF Pax. - **Pby** (`float`): EKF Pby. - **Pcz** (`float`): EKF Pcz.

--- chunk_id: chunk-0200
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: 0a9322703a153a34
prev_chunk_id: chunk-0199
next_chunk_id: chunk-0201
section_heading: RALLY_POINT (msg id 175, dialect ardupilotmega)
document_type: technical_reference

## RALLY_POINT (msg id 175, dialect ardupilotmega)

A rally point. Used to set a point when from GCS -> MAV. Also used to return a point from MAV -> GCS. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **idx** (`uint8_t`): Point index (first point is 0). - **count** (`uint8_t`): Total number of points (for sanity checking). - **lat** (`int32_t`, degE7): Latitude of point. - **lng** (`int32_t`, degE7): Longitude of point. - **alt** (`int16_t`, m): Transit / loiter altitude relative to home. - **break_alt** (`int16_t`, m): Break altitude relative to home. - **land_dir** (`uint16_t`, cdeg): Heading to aim for when landing. - **flags** (`uint8_t`): Configuration flags. ### RALLY_FETCH_POINT (msg id 176, dialect ardupilotmega)
Request a current rally point from MAV. MAV should respond with a RALLY_POINT message. MAV should not respond if the request is invalid. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **idx** (`uint8_t`): Point index (first point is 0).

--- chunk_id: chunk-0201
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 250
content_hash: 5a2200b7bee4ec18
prev_chunk_id: chunk-0200
next_chunk_id: chunk-0202
section_heading: COMPASSMOT_STATUS (msg id 177, dialect ardupilotmega)
document_type: technical_reference

## COMPASSMOT_STATUS (msg id 177, dialect ardupilotmega)

Status of compassmot calibration. ### Fields

- **throttle** (`uint16_t`, d%): Throttle. - **current** (`float`, A): Current. - **interference** (`uint16_t`, %): Interference. - **CompensationX** (`float`): Motor Compensation X. - **CompensationY** (`float`): Motor Compensation Y. - **CompensationZ** (`float`): Motor Compensation Z. ### AHRS2 (msg id 178, dialect ardupilotmega)
Status of secondary AHRS filter if available. ### Fields

- **roll** (`float`, rad): Roll angle. - **pitch** (`float`, rad): Pitch angle. - **yaw** (`float`, rad): Yaw angle. - **altitude** (`float`, m): Altitude (MSL). - **lat** (`int32_t`, degE7): Latitude. - **lng** (`int32_t`, degE7): Longitude. ### CAMERA_STATUS (msg id 179, dialect ardupilotmega)
Camera Event. ### Fields

- **time_usec** (`uint64_t`, us): Image timestamp (since UNIX epoch, according to camera clock). - **target_system** (`uint8_t`): System ID. - **cam_idx** (`uint8_t`): Camera ID. - **img_idx** (`uint16_t`): Image index. - **event_id** (`uint8_t`): Event type. - **p1** (`float`): Parameter 1 (meaning depends on event_id, see CAMERA_STATUS_TYPES enum). - **p2** (`float`): Parameter 2 (meaning depends on event_id, see CAMERA_STATUS_TYPES enum). - **p3** (`float`): Parameter 3 (meaning depends on event_id, see CAMERA_STATUS_TYPES enum). - **p4** (`float`): Parameter 4 (meaning depends on event_id, see CAMERA_STATUS_TYPES enum).

--- chunk_id: chunk-0202
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 304
content_hash: 308676df0a91b5cb
prev_chunk_id: chunk-0201
next_chunk_id: chunk-0203
section_heading: CAMERA_FEEDBACK (msg id 180, dialect ardupilotmega)
document_type: technical_reference

## CAMERA_FEEDBACK (msg id 180, dialect ardupilotmega)

Camera Capture Feedback. ### Fields

- **time_usec** (`uint64_t`, us): Image timestamp (since UNIX epoch), as passed in by CAMERA_STATUS message (or autopilot if no CCB). - **target_system** (`uint8_t`): System ID. - **cam_idx** (`uint8_t`): Camera ID. - **img_idx** (`uint16_t`): Image index. - **lat** (`int32_t`, degE7): Latitude. - **lng** (`int32_t`, degE7): Longitude. - **alt_msl** (`float`, m): Altitude (MSL). - **alt_rel** (`float`, m): Altitude (Relative to HOME location). - **roll** (`float`, deg): Camera Roll angle (earth frame, +-180). - **pitch** (`float`, deg): Camera Pitch angle (earth frame, +-180). - **yaw** (`float`, deg): Camera Yaw (earth frame, 0-360, true). - **foc_len** (`float`, mm): Focal Length. - **flags** (`uint8_t`): Feedback flags. - **completed_captures** (`uint16_t`): Completed image captures. ### BATTERY2 (msg id 181, dialect ardupilotmega)
2nd Battery status

### Fields

- **voltage** (`uint16_t`, mV): Voltage. - **current_battery** (`int16_t`, cA): Battery current, -1: autopilot does not measure the current. ### AHRS3 (msg id 182, dialect ardupilotmega)
Status of third AHRS filter if available. This is for ANU research group (Ali and Sean). ### Fields

- **roll** (`float`, rad): Roll angle. - **pitch** (`float`, rad): Pitch angle. - **yaw** (`float`, rad): Yaw angle. - **altitude** (`float`, m): Altitude (MSL). - **lat** (`int32_t`, degE7): Latitude. - **lng** (`int32_t`, degE7): Longitude. - **v1** (`float`): Test variable1. - **v2** (`float`): Test variable2. - **v3** (`float`): Test variable3. - **v4** (`float`): Test variable4.

--- chunk_id: chunk-0203
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: 0d0935bd0043a74f
prev_chunk_id: chunk-0202
next_chunk_id: chunk-0204
section_heading: AUTOPILOT_VERSION_REQUEST (msg id 183, dialect ardupilotmega)
document_type: technical_reference

## AUTOPILOT_VERSION_REQUEST (msg id 183, dialect ardupilotmega)

Request the autopilot version from the system/component. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. ### REMOTE_LOG_DATA_BLOCK (msg id 184, dialect ardupilotmega)
Send a block of log data to remote location. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **seqno** (`uint32_t`): Log data block sequence number. - **data** (`uint8_t[200]`): Log data block. ### REMOTE_LOG_BLOCK_STATUS (msg id 185, dialect ardupilotmega)
Send Status of each log block that autopilot board might have sent. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **seqno** (`uint32_t`): Log data block sequence number. - **status** (`uint8_t`): Log data block status. ### LED_CONTROL (msg id 186, dialect ardupilotmega)
Control vehicle LEDs. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **instance** (`uint8_t`): Instance (LED instance to control or 255 for all LEDs). - **pattern** (`uint8_t`): Pattern (see LED_PATTERN_ENUM). - **custom_len** (`uint8_t`): Custom Byte Length. - **custom_bytes** (`uint8_t[24]`): Custom Bytes.

--- chunk_id: chunk-0204
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 253
content_hash: 126a60fbb6b043e5
prev_chunk_id: chunk-0203
next_chunk_id: chunk-0205
section_heading: MAG_CAL_PROGRESS (msg id 191, dialect ardupilotmega)
document_type: technical_reference

## MAG_CAL_PROGRESS (msg id 191, dialect ardupilotmega)

Reports progress of compass calibration. ### Fields

- **compass_id** (`uint8_t`): Compass being calibrated. - **cal_mask** (`uint8_t`): Bitmask of compasses being calibrated. - **cal_status** (`uint8_t`): Calibration Status. - **attempt** (`uint8_t`): Attempt number. - **completion_pct** (`uint8_t`, %): Completion percentage. - **completion_mask** (`uint8_t[10]`): Bitmask of sphere sections (see http://en.wikipedia.org/wiki/Geodesic_grid). - **direction_x** (`float`): Body frame direction vector for display. - **direction_y** (`float`): Body frame direction vector for display. - **direction_z** (`float`): Body frame direction vector for display. ### EKF_STATUS_REPORT (msg id 193, dialect ardupilotmega)
EKF Status message including flags and variances. ### Fields

- **flags** (`uint16_t`): Flags. - **velocity_variance** (`float`): Velocity variance. - **pos_horiz_variance** (`float`): Horizontal Position variance. - **pos_vert_variance** (`float`): Vertical Position variance. - **compass_variance** (`float`): Compass variance. - **terrain_alt_variance** (`float`): Terrain Altitude variance. - **airspeed_variance** (`float`): Airspeed variance. ### PID_TUNING (msg id 194, dialect ardupilotmega)
PID tuning information. ### Fields

- **axis** (`uint8_t`): Axis. - **desired** (`float`): Desired rate. - **achieved** (`float`): Achieved rate. - **FF** (`float`): FF component. - **P** (`float`): P component. - **I** (`float`): I component. - **D** (`float`): D component. - **SRate** (`float`): Slew rate. - **PDmod** (`float`): P/D oscillation modifier.

--- chunk_id: chunk-0205
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 246
content_hash: 7b7e83c95ba63932
prev_chunk_id: chunk-0204
next_chunk_id: chunk-0206
section_heading: DEEPSTALL (msg id 195, dialect ardupilotmega)
document_type: technical_reference

## DEEPSTALL (msg id 195, dialect ardupilotmega)

Deepstall path planning. ### Fields

- **landing_lat** (`int32_t`, degE7): Landing latitude. - **landing_lon** (`int32_t`, degE7): Landing longitude. - **path_lat** (`int32_t`, degE7): Final heading start point, latitude. - **path_lon** (`int32_t`, degE7): Final heading start point, longitude. - **arc_entry_lat** (`int32_t`, degE7): Arc entry point, latitude. - **arc_entry_lon** (`int32_t`, degE7): Arc entry point, longitude. - **altitude** (`float`, m): Altitude. - **expected_travel_distance** (`float`, m): Distance the aircraft expects to travel during the deepstall. - **cross_track_error** (`float`, m): Deepstall cross track error (only valid when in DEEPSTALL_STAGE_LAND). - **stage** (`uint8_t`): Deepstall stage. ### GIMBAL_REPORT (msg id 200, dialect ardupilotmega)
3 axis gimbal measurements. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **delta_time** (`float`, s): Time since last update. - **delta_angle_x** (`float`, rad): Delta angle X. - **delta_angle_y** (`float`, rad): Delta angle Y. - **delta_angle_z** (`float`, rad): Delta angle X. - **delta_velocity_x** (`float`, m/s): Delta velocity X. - **delta_velocity_y** (`float`, m/s): Delta velocity Y. - **delta_velocity_z** (`float`, m/s): Delta velocity Z. - **joint_roll** (`float`, rad): Joint ROLL. - **joint_el** (`float`, rad): Joint EL. - **joint_az** (`float`, rad): Joint AZ.

--- chunk_id: chunk-0206
source_document: messages_batch_11.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 162
content_hash: aebe5be03b029b10
prev_chunk_id: chunk-0205
next_chunk_id: chunk-0207
section_heading: GIMBAL_CONTROL (msg id 201, dialect ardupilotmega)
document_type: technical_reference

## GIMBAL_CONTROL (msg id 201, dialect ardupilotmega)

Control message for rate gimbal. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **demanded_rate_x** (`float`, rad/s): Demanded angular rate X. - **demanded_rate_y** (`float`, rad/s): Demanded angular rate Y. - **demanded_rate_z** (`float`, rad/s): Demanded angular rate Z. ### GIMBAL_TORQUE_CMD_REPORT (msg id 214, dialect ardupilotmega)
100 Hz gimbal torque command telemetry. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **rl_torque_cmd** (`int16_t`): Roll Torque Command. - **el_torque_cmd** (`int16_t`): Elevation Torque Command. - **az_torque_cmd** (`int16_t`): Azimuth Torque Command. ### GOPRO_HEARTBEAT (msg id 215, dialect ardupilotmega)
Heartbeat from a HeroBus attached GoPro. ### Fields

- **status** (`uint8_t`): Status. - **capture_mode** (`uint8_t`): Current capture mode. - **flags** (`uint8_t`): Additional status bits.

--- chunk_id: chunk-0207
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: 245058683892f6c4
prev_chunk_id: chunk-0206
next_chunk_id: chunk-0208
section_heading: MAVLink messages batch 12
document_type: technical_reference

# MAVLink messages batch 12

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0208
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 293
content_hash: caf93c92b67018c5
prev_chunk_id: chunk-0207
next_chunk_id: chunk-0209
section_heading: GOPRO_GET_REQUEST (msg id 216, dialect ardupilotmega)
document_type: technical_reference

## GOPRO_GET_REQUEST (msg id 216, dialect ardupilotmega)

Request a GOPRO_COMMAND response from the GoPro. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **cmd_id** (`uint8_t`): Command ID. ### GOPRO_GET_RESPONSE (msg id 217, dialect ardupilotmega)
Response from a GOPRO_COMMAND get request. ### Fields

- **cmd_id** (`uint8_t`): Command ID. - **status** (`uint8_t`): Status. - **value** (`uint8_t[4]`): Value. ### GOPRO_SET_REQUEST (msg id 218, dialect ardupilotmega)
Request to set a GOPRO_COMMAND with a desired. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **cmd_id** (`uint8_t`): Command ID. - **value** (`uint8_t[4]`): Value. ### GOPRO_SET_RESPONSE (msg id 219, dialect ardupilotmega)
Response from a GOPRO_COMMAND set request. ### Fields

- **cmd_id** (`uint8_t`): Command ID. - **status** (`uint8_t`): Status. ### RPM (msg id 226, dialect ardupilotmega)
RPM sensor output. ### Fields

- **rpm1** (`float`): RPM Sensor1. - **rpm2** (`float`): RPM Sensor2. ### DEVICE_OP_READ (msg id 11000, dialect ardupilotmega)
Read registers for a device. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **request_id** (`uint32_t`): Request ID - copied to reply. - **bustype** (`uint8_t`): The bus type. - **bus** (`uint8_t`): Bus number. - **address** (`uint8_t`): Bus address. - **busname** (`char[40]`): Name of device on bus (for SPI). - **regstart** (`uint8_t`): First register to read. - **count** (`uint8_t`): Count of registers to read. - **bank** (`uint8_t`): Bank number.

--- chunk_id: chunk-0209
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 226
content_hash: 9ebcc9b8befc65bf
prev_chunk_id: chunk-0208
next_chunk_id: chunk-0210
section_heading: DEVICE_OP_READ_REPLY (msg id 11001, dialect ardupilotmega)
document_type: technical_reference

## DEVICE_OP_READ_REPLY (msg id 11001, dialect ardupilotmega)

Read registers reply. ### Fields

- **request_id** (`uint32_t`): Request ID - copied from request. - **result** (`uint8_t`): 0 for success, anything else is failure code. - **regstart** (`uint8_t`): Starting register. - **count** (`uint8_t`): Count of bytes read. - **data** (`uint8_t[128]`): Reply data. - **bank** (`uint8_t`): Bank number. ### DEVICE_OP_WRITE (msg id 11002, dialect ardupilotmega)
Write registers for a device. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **request_id** (`uint32_t`): Request ID - copied to reply. - **bustype** (`uint8_t`): The bus type. - **bus** (`uint8_t`): Bus number. - **address** (`uint8_t`): Bus address. - **busname** (`char[40]`): Name of device on bus (for SPI). - **regstart** (`uint8_t`): First register to write. - **count** (`uint8_t`): Count of registers to write. - **data** (`uint8_t[128]`): Write data. - **bank** (`uint8_t`): Bank number. ### DEVICE_OP_WRITE_REPLY (msg id 11003, dialect ardupilotmega)
Write registers reply. ### Fields

- **request_id** (`uint32_t`): Request ID - copied from request. - **result** (`uint8_t`): 0 for success, anything else is failure code.

--- chunk_id: chunk-0210
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: c3be3ebbef2e60e4
prev_chunk_id: chunk-0209
next_chunk_id: chunk-0211
section_heading: SECURE_COMMAND (msg id 11004, dialect ardupilotmega)
document_type: technical_reference

## SECURE_COMMAND (msg id 11004, dialect ardupilotmega)

Send a secure command. Data should be signed with a private key corresponding with a public key known to the recipient. Signature should be over the concatenation of the sequence number (little-endian format), the operation (little-endian format) the data and the session key. For SECURE_COMMAND_GET_SESSION_KEY the session key should be zero length. The data array consists of the data followed by the signature. The sum of the data_length and the sig_length cannot be more than 220. The format of the data is command specific. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **sequence** (`uint32_t`): Sequence ID for tagging reply. - **operation** (`uint32_t`): Operation being requested. - **data_length** (`uint8_t`): Data length. - **sig_length** (`uint8_t`): Signature length. - **data** (`uint8_t[220]`): Signed data.

--- chunk_id: chunk-0211
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 301
content_hash: 09bcf1858040df45
prev_chunk_id: chunk-0210
next_chunk_id: chunk-0212
section_heading: SECURE_COMMAND_REPLY (msg id 11005, dialect ardupilotmega)
document_type: technical_reference

## SECURE_COMMAND_REPLY (msg id 11005, dialect ardupilotmega)

Reply from secure command. ### Fields

- **sequence** (`uint32_t`): Sequence ID from request. - **operation** (`uint32_t`): Operation that was requested. - **result** (`uint8_t`): Result of command. - **data_length** (`uint8_t`): Data length. - **data** (`uint8_t[220]`): Reply data. ### ADAP_TUNING (msg id 11010, dialect ardupilotmega)
Adaptive Controller tuning information. ### Fields

- **axis** (`uint8_t`): Axis. - **desired** (`float`, deg/s): Desired rate. - **achieved** (`float`, deg/s): Achieved rate. - **error** (`float`): Error between model and vehicle. - **theta** (`float`): Theta estimated state predictor. - **omega** (`float`): Omega estimated state predictor. - **sigma** (`float`): Sigma estimated state predictor. - **theta_dot** (`float`): Theta derivative. - **omega_dot** (`float`): Omega derivative. - **sigma_dot** (`float`): Sigma derivative. - **f** (`float`): Projection operator value. - **f_dot** (`float`): Projection operator derivative. - **u** (`float`): u adaptive controlled output command. ### VISION_POSITION_DELTA (msg id 11011, dialect ardupilotmega)
Camera vision based attitude and position deltas. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (synced to UNIX time or since system boot). - **time_delta_usec** (`uint64_t`, us): Time since the last reported camera frame. - **angle_delta** (`float[3]`, rad): Defines a rotation vector [roll, pitch, yaw] to the current MAV_FRAME_BODY_FRD from the previous MAV_FRAME_BODY_FRD. - **position_delta** (`float[3]`, m): Change in position to the current MAV_FRAME_BODY_FRD from the previous FRAME_BODY_FRD rotated to the current MAV_FRAME_BODY_FRD. - **confidence** (`float`, %): Normalised confidence value from 0 to 100.

--- chunk_id: chunk-0212
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 216
content_hash: 970276e3cff81ca9
prev_chunk_id: chunk-0211
next_chunk_id: chunk-0213
section_heading: AOA_SSA (msg id 11020, dialect ardupilotmega)
document_type: technical_reference

## AOA_SSA (msg id 11020, dialect ardupilotmega)

Angle of Attack and Side Slip Angle. ### Fields

- **time_usec** (`uint64_t`, us): Timestamp (since boot or Unix epoch). - **AOA** (`float`, deg): Angle of Attack. - **SSA** (`float`, deg): Side Slip Angle. ### ESC_TELEMETRY_1_TO_4 (msg id 11030, dialect ardupilotmega)
ESC Telemetry Data for ESCs 1 to 4, matching data sent by BLHeli ESCs. ### Fields

- **temperature** (`uint8_t[4]`, degC): Temperature. - **voltage** (`uint16_t[4]`, cV): Voltage. - **current** (`uint16_t[4]`, cA): Current. - **totalcurrent** (`uint16_t[4]`, mAh): Total current. - **rpm** (`uint16_t[4]`, rpm): RPM (eRPM). - **count** (`uint16_t[4]`): count of telemetry packets received (wraps at 65535). ### ESC_TELEMETRY_5_TO_8 (msg id 11031, dialect ardupilotmega)
ESC Telemetry Data for ESCs 5 to 8, matching data sent by BLHeli ESCs. ### Fields

- **temperature** (`uint8_t[4]`, degC): Temperature. - **voltage** (`uint16_t[4]`, cV): Voltage. - **current** (`uint16_t[4]`, cA): Current. - **totalcurrent** (`uint16_t[4]`, mAh): Total current. - **rpm** (`uint16_t[4]`, rpm): RPM (eRPM). - **count** (`uint16_t[4]`): count of telemetry packets received (wraps at 65535).

--- chunk_id: chunk-0213
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 238
content_hash: 651f45d19e31d6b1
prev_chunk_id: chunk-0212
next_chunk_id: chunk-0214
section_heading: ESC_TELEMETRY_9_TO_12 (msg id 11032, dialect ardupilotmega)
document_type: technical_reference

## ESC_TELEMETRY_9_TO_12 (msg id 11032, dialect ardupilotmega)

ESC Telemetry Data for ESCs 9 to 12, matching data sent by BLHeli ESCs. ### Fields

- **temperature** (`uint8_t[4]`, degC): Temperature. - **voltage** (`uint16_t[4]`, cV): Voltage. - **current** (`uint16_t[4]`, cA): Current. - **totalcurrent** (`uint16_t[4]`, mAh): Total current. - **rpm** (`uint16_t[4]`, rpm): RPM (eRPM). - **count** (`uint16_t[4]`): count of telemetry packets received (wraps at 65535). ### OSD_PARAM_CONFIG (msg id 11033, dialect ardupilotmega)
Configure an OSD parameter slot. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **request_id** (`uint32_t`): Request ID - copied to reply. - **osd_screen** (`uint8_t`): OSD parameter screen index. - **osd_index** (`uint8_t`): OSD parameter display index. - **param_id** (`char[16]`): Onboard parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **config_type** (`uint8_t`): Config type. - **min_value** (`float`): OSD parameter minimum value. - **max_value** (`float`): OSD parameter maximum value. - **increment** (`float`): OSD parameter increment.

--- chunk_id: chunk-0214
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 236
content_hash: 49e2bdb82aa38b75
prev_chunk_id: chunk-0213
next_chunk_id: chunk-0215
section_heading: OSD_PARAM_CONFIG_REPLY (msg id 11034, dialect ardupilotmega)
document_type: technical_reference

## OSD_PARAM_CONFIG_REPLY (msg id 11034, dialect ardupilotmega)

Configure OSD parameter reply. ### Fields

- **request_id** (`uint32_t`): Request ID - copied from request. - **result** (`uint8_t`): Config error type. ### OSD_PARAM_SHOW_CONFIG (msg id 11035, dialect ardupilotmega)
Read a configured an OSD parameter slot. ### Fields

- **target_system** (`uint8_t`): System ID. - **target_component** (`uint8_t`): Component ID. - **request_id** (`uint32_t`): Request ID - copied to reply. - **osd_screen** (`uint8_t`): OSD parameter screen index. - **osd_index** (`uint8_t`): OSD parameter display index. ### OSD_PARAM_SHOW_CONFIG_REPLY (msg id 11036, dialect ardupilotmega)
Read configured OSD parameter reply. ### Fields

- **request_id** (`uint32_t`): Request ID - copied from request. - **result** (`uint8_t`): Config error type. - **param_id** (`char[16]`): Onboard parameter id, terminated by NULL if the length is less than 16 human-readable chars and WITHOUT null termination (NULL) byte if the length is exactly 16 chars - applications have to provide 16+1 bytes storage if the ID is stored as string
- **config_type** (`uint8_t`): Config type. - **min_value** (`float`): OSD parameter minimum value. - **max_value** (`float`): OSD parameter maximum value. - **increment** (`float`): OSD parameter increment.

--- chunk_id: chunk-0215
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 265
content_hash: 6cd77a21dc4f741e
prev_chunk_id: chunk-0214
next_chunk_id: chunk-0216
section_heading: OBSTACLE_DISTANCE_3D (msg id 11037, dialect ardupilotmega)
document_type: technical_reference

## OBSTACLE_DISTANCE_3D (msg id 11037, dialect ardupilotmega)

Obstacle located as a 3D vector. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **sensor_type** (`uint8_t`): Class id of the distance sensor type. - **frame** (`uint8_t`): Coordinate frame of reference. - **obstacle_id** (`uint16_t`): Unique ID given to each obstacle so that its movement can be tracked. Use UINT16_MAX if object ID is unknown or cannot be determined. - **x** (`float`, m): X position of the obstacle. - **y** (`float`, m): Y position of the obstacle. - **z** (`float`, m): Z position of the obstacle. - **min_distance** (`float`, m): Minimum distance the sensor can measure. - **max_distance** (`float`, m): Maximum distance the sensor can measure. ### WATER_DEPTH (msg id 11038, dialect ardupilotmega)
Water depth

### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot)
- **id** (`uint8_t`): Onboard ID of the sensor
- **healthy** (`uint8_t`): Sensor data healthy (0=unhealthy, 1=healthy)
- **lat** (`int32_t`, degE7): Latitude
- **lng** (`int32_t`, degE7): Longitude
- **alt** (`float`, m): Altitude (MSL) of vehicle
- **roll** (`float`, rad): Roll angle
- **pitch** (`float`, rad): Pitch angle
- **yaw** (`float`, rad): Yaw angle
- **distance** (`float`, m): Distance (uncorrected)
- **temperature** (`float`, degC): Water temperature

--- chunk_id: chunk-0216
source_document: messages_batch_12.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 164
content_hash: 644bbdc5bbac60c9
prev_chunk_id: chunk-0215
next_chunk_id: chunk-0217
section_heading: MCU_STATUS (msg id 11039, dialect ardupilotmega)
document_type: technical_reference

## MCU_STATUS (msg id 11039, dialect ardupilotmega)

The MCU status, giving MCU temperature and voltage. The min and max voltages are to allow for detecting power supply instability. ### Fields

- **id** (`uint8_t`): MCU instance
- **MCU_temperature** (`int16_t`, cdegC): MCU Internal temperature
- **MCU_voltage** (`uint16_t`, mV): MCU voltage
- **MCU_voltage_min** (`uint16_t`, mV): MCU voltage minimum
- **MCU_voltage_max** (`uint16_t`, mV): MCU voltage maximum

### ESC_TELEMETRY_13_TO_16 (msg id 11040, dialect ardupilotmega)
ESC Telemetry Data for ESCs 13 to 16, matching data sent by BLHeli ESCs. ### Fields

- **temperature** (`uint8_t[4]`, degC): Temperature. - **voltage** (`uint16_t[4]`, cV): Voltage. - **current** (`uint16_t[4]`, cA): Current. - **totalcurrent** (`uint16_t[4]`, mAh): Total current. - **rpm** (`uint16_t[4]`, rpm): RPM (eRPM). - **count** (`uint16_t[4]`): count of telemetry packets received (wraps at 65535).

--- chunk_id: chunk-0217
source_document: messages_batch_13.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 17
content_hash: 6bbcbbd73b14a48d
prev_chunk_id: chunk-0216
next_chunk_id: chunk-0218
section_heading: MAVLink messages batch 13
document_type: technical_reference

# MAVLink messages batch 13

Structured extract from MAVLink XML (not live link).

--- chunk_id: chunk-0218
source_document: messages_batch_13.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: 5a0b6a98a21925a8
prev_chunk_id: chunk-0217
next_chunk_id: chunk-0219
section_heading: ESC_TELEMETRY_17_TO_20 (msg id 11041, dialect ardupilotmega)
document_type: technical_reference

## ESC_TELEMETRY_17_TO_20 (msg id 11041, dialect ardupilotmega)

ESC Telemetry Data for ESCs 17 to 20, matching data sent by BLHeli ESCs. ### Fields

- **temperature** (`uint8_t[4]`, degC): Temperature. - **voltage** (`uint16_t[4]`, cV): Voltage. - **current** (`uint16_t[4]`, cA): Current. - **totalcurrent** (`uint16_t[4]`, mAh): Total current. - **rpm** (`uint16_t[4]`, rpm): RPM (eRPM). - **count** (`uint16_t[4]`): count of telemetry packets received (wraps at 65535). ### ESC_TELEMETRY_21_TO_24 (msg id 11042, dialect ardupilotmega)
ESC Telemetry Data for ESCs 21 to 24, matching data sent by BLHeli ESCs. ### Fields

- **temperature** (`uint8_t[4]`, degC): Temperature. - **voltage** (`uint16_t[4]`, cV): Voltage. - **current** (`uint16_t[4]`, cA): Current. - **totalcurrent** (`uint16_t[4]`, mAh): Total current. - **rpm** (`uint16_t[4]`, rpm): RPM (eRPM). - **count** (`uint16_t[4]`): count of telemetry packets received (wraps at 65535). ### ESC_TELEMETRY_25_TO_28 (msg id 11043, dialect ardupilotmega)
ESC Telemetry Data for ESCs 25 to 28, matching data sent by BLHeli ESCs. ### Fields

- **temperature** (`uint8_t[4]`, degC): Temperature. - **voltage** (`uint16_t[4]`, cV): Voltage. - **current** (`uint16_t[4]`, cA): Current. - **totalcurrent** (`uint16_t[4]`, mAh): Total current. - **rpm** (`uint16_t[4]`, rpm): RPM (eRPM). - **count** (`uint16_t[4]`): count of telemetry packets received (wraps at 65535).

--- chunk_id: chunk-0219
source_document: messages_batch_13.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 166
content_hash: 441212a91fe6c731
prev_chunk_id: chunk-0218
next_chunk_id: chunk-0220
section_heading: ESC_TELEMETRY_29_TO_32 (msg id 11044, dialect ardupilotmega)
document_type: technical_reference

## ESC_TELEMETRY_29_TO_32 (msg id 11044, dialect ardupilotmega)

ESC Telemetry Data for ESCs 29 to 32, matching data sent by BLHeli ESCs. ### Fields

- **temperature** (`uint8_t[4]`, degC): Temperature. - **voltage** (`uint16_t[4]`, cV): Voltage. - **current** (`uint16_t[4]`, cA): Current. - **totalcurrent** (`uint16_t[4]`, mAh): Total current. - **rpm** (`uint16_t[4]`, rpm): RPM (eRPM). - **count** (`uint16_t[4]`): count of telemetry packets received (wraps at 65535). ### NAMED_VALUE_STRING (msg id 11060, dialect ardupilotmega)
Send a key-value pair as string. The use of this message is discouraged for normal packets, but a quite efficient way for testing new messages and getting experimental debug output. ### Fields

- **time_boot_ms** (`uint32_t`, ms): Timestamp (time since system boot). - **name** (`char[10]`): Name of the debug variable
- **value** (`char[64]`): Value of the debug variable

--- chunk_id: chunk-0220
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: 68b2f2b6a3cf404a
prev_chunk_id: chunk-0219
next_chunk_id: chunk-0221
section_heading: MAV_CMD commands batch 1
document_type: technical_reference

# MAV_CMD commands batch 1

Structured extract from common.xml MAV_CMD enum.

--- chunk_id: chunk-0221
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: b96261bc244905f5
prev_chunk_id: chunk-0220
next_chunk_id: chunk-0222
section_heading: MAV_CMD_NAV_WAYPOINT (MAV_CMD value 16)
document_type: technical_reference

## MAV_CMD_NAV_WAYPOINT (MAV_CMD value 16)

Navigate to waypoint. This is intended for use in missions (for guided commands outside of missions use MAV_CMD_DO_REPOSITION). ### Parameters

- **param1** Hold: Hold time. (ignored by fixed wing, time to stay at waypoint for rotary wing)
- **param2** Accept Radius: Acceptance radius (if the sphere with this radius is hit, the waypoint counts as reached)
- **param3** Pass Radius: 0 to pass through the WP, if > 0 radius to pass by WP. Positive value for clockwise orbit, negative value for counter-clockwise orbit. Allows trajectory control. - **param4** Yaw: Desired yaw angle at waypoint (rotary wing). NaN to use the current system yaw heading mode (e.g. yaw towards next waypoint, yaw to home, etc.). - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0222
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 313
content_hash: 2469e6a1efd5d858
prev_chunk_id: chunk-0221
next_chunk_id: chunk-0223
section_heading: MAV_CMD_NAV_LOITER_UNLIM (MAV_CMD value 17)
document_type: technical_reference

## MAV_CMD_NAV_LOITER_UNLIM (MAV_CMD value 17)

Loiter around this waypoint an unlimited amount of time

### Parameters

- **param1** : Empty
- **param2** : Empty
- **param3** Radius: Loiter radius around waypoint for forward-only moving vehicles (not multicopters). If positive loiter clockwise, else counter-clockwise
- **param4** Yaw: Desired yaw angle. NaN to use the current system yaw heading mode (e.g. yaw towards next waypoint, yaw to home, etc.). - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

### MAV_CMD_NAV_LOITER_TURNS (MAV_CMD value 18)
Loiter around this waypoint for X turns

### Parameters

- **param1** Turns: Number of turns. - **param2** Heading Required: Leave loiter circle only when track heads towards the next waypoint (MAV_BOOL_FALSE: Leave when turns complete). Values not equal to 0 or 1 are invalid. - **param3** Radius: Loiter radius around waypoint for forward-only moving vehicles (not multicopters). If positive loiter clockwise, else counter-clockwise
- **param4** Xtrack Location: Loiter circle exit location and/or path to next waypoint ("xtrack") for forward-only moving vehicles (not multicopters). 0 for the vehicle to converge towards the center xtrack when it leaves the loiter (the line between the centers of the current and next waypoint), 1 to converge to the direct line between the location that the vehicle exits the loiter radius and the next waypoint. NaN to use the current system default xtrack behaviour. - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0223
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 289
content_hash: 7368f4cfd7b95279
prev_chunk_id: chunk-0222
next_chunk_id: chunk-0224
section_heading: MAV_CMD_NAV_LOITER_TIME (MAV_CMD value 19)
document_type: technical_reference

## MAV_CMD_NAV_LOITER_TIME (MAV_CMD value 19)

Loiter at the specified latitude, longitude and altitude for a certain amount of time. Multicopter vehicles stop at the point (within a vehicle-specific acceptance radius). Forward-only moving vehicles (e.g. fixed-wing) circle the point with the specified radius/direction. If the Heading Required parameter (2) is non-zero forward moving aircraft will only leave the loiter circle once heading towards the next waypoint. ### Parameters

- **param1** Time: Loiter time (only starts once Lat, Lon and Alt is reached). - **param2** Heading Required: Leave loiter circle only when track heading towards the next waypoint (MAV_BOOL_FALSE: Leave on time expiry). Values not equal to 0 or 1 are invalid. - **param3** Radius: Loiter radius around waypoint for forward-only moving vehicles (not multicopters). If positive loiter clockwise, else counter-clockwise. - **param4** Xtrack Location: Loiter circle exit location and/or path to next waypoint ("xtrack") for forward-only moving vehicles (not multicopters). 0 for the vehicle to converge towards the center xtrack when it leaves the loiter (the line between the centers of the current and next waypoint), 1 to converge to the direct line between the location that the vehicle exits the loiter radius and the next waypoint. NaN to use the current system default xtrack behaviour. - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0224
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 284
content_hash: afed81e8a61395ec
prev_chunk_id: chunk-0223
next_chunk_id: chunk-0225
section_heading: MAV_CMD_NAV_RETURN_TO_LAUNCH (MAV_CMD value 20)
document_type: technical_reference

## MAV_CMD_NAV_RETURN_TO_LAUNCH (MAV_CMD value 20)

Return to launch location

### Parameters

- **param1** : Empty
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_NAV_LAND (MAV_CMD value 21)
Land at location. ### Parameters

- **param1** Abort Alt: Minimum target altitude if landing is aborted (0 = undefined/use system default). - **param2** Land Mode: Precision land mode. - **param3** : Empty. - **param4** Yaw Angle: Desired yaw angle. NaN to use the current system yaw heading mode (e.g. yaw towards next waypoint, yaw to home, etc.). - **param5** Latitude: Latitude. - **param6** Longitude: Longitude. - **param7** Altitude: Landing altitude (ground level in current frame). ### MAV_CMD_NAV_TAKEOFF (MAV_CMD value 22)
Takeoff from ground / hand. Vehicles that support multiple takeoff modes (e.g. VTOL quadplane) should take off using the currently configured mode. ### Parameters

- **param1** Pitch: Minimum pitch (if airspeed sensor present), desired pitch without sensor
- **param2** : Empty
- **param3** Flags: Bitmask of options flags. - **param4** Yaw: Yaw angle (if magnetometer present), ignored without magnetometer. NaN to use the current system yaw heading mode (e.g. yaw towards next waypoint, yaw to home, etc.). - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0225
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 232
content_hash: eff45e0ebf7878f4
prev_chunk_id: chunk-0224
next_chunk_id: chunk-0226
section_heading: MAV_CMD_NAV_LAND_LOCAL (MAV_CMD value 23)
document_type: technical_reference

## MAV_CMD_NAV_LAND_LOCAL (MAV_CMD value 23)

Land at local position (local frame only)

### Parameters

- **param1** Target: Landing target number (if available)
- **param2** Offset: Maximum accepted offset from desired landing position - computed magnitude from spherical coordinates: d = sqrt(x^2 + y^2 + z^2), which gives the maximum accepted distance between the desired landing position and the position where the vehicle is about to land
- **param3** Descend Rate: Landing descend rate
- **param4** Yaw: Desired yaw angle
- **param5** Y Position: Y-axis position
- **param6** X Position: X-axis position
- **param7** Z Position: Z-axis / ground level position

### MAV_CMD_NAV_TAKEOFF_LOCAL (MAV_CMD value 24)
Takeoff from local position (local frame only)

### Parameters

- **param1** Pitch: Minimum pitch (if airspeed sensor present), desired pitch without sensor
- **param2** : Empty
- **param3** Ascend Rate: Takeoff ascend rate
- **param4** Yaw: Yaw angle (if magnetometer or another yaw estimation source present), ignored without one of these
- **param5** Y Position: Y-axis position
- **param6** X Position: X-axis position
- **param7** Z Position: Z-axis position

--- chunk_id: chunk-0226
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 246
content_hash: 669b9eb510b4235f
prev_chunk_id: chunk-0225
next_chunk_id: chunk-0227
section_heading: MAV_CMD_NAV_FOLLOW (MAV_CMD value 25)
document_type: technical_reference

## MAV_CMD_NAV_FOLLOW (MAV_CMD value 25)

Vehicle following, i.e. this waypoint represents the position of a moving vehicle

### Parameters

- **param1** Following: Following logic to use (e.g. loitering or sinusoidal following) - depends on specific autopilot implementation
- **param2** Ground Speed: Ground speed of vehicle to be followed
- **param3** Radius: Radius around waypoint. If positive loiter clockwise, else counter-clockwise
- **param4** Yaw: Desired yaw angle. - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

### MAV_CMD_NAV_CONTINUE_AND_CHANGE_ALT (MAV_CMD value 30)
Continue on the current course and climb/descend to specified altitude. When the altitude is reached continue to the next command (i.e., don't proceed to the next command until the desired altitude is reached. ### Parameters

- **param1** Action: Climb or Descend (0 = Neutral, command completes when within 5m of this command's altitude, 1 = Climbing, command completes when at or above this command's altitude, 2 = Descending, command completes when at or below this command's altitude. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** Altitude: Desired altitude

--- chunk_id: chunk-0227
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 274
content_hash: 3361aebf9551ad43
prev_chunk_id: chunk-0226
next_chunk_id: chunk-0228
section_heading: MAV_CMD_NAV_LOITER_TO_ALT (MAV_CMD value 31)
document_type: technical_reference

## MAV_CMD_NAV_LOITER_TO_ALT (MAV_CMD value 31)

Begin loiter at the specified Latitude and Longitude. If Lat=Lon=0, then loiter at the current position. Don't consider the navigation command complete (don't leave loiter) until the altitude has been reached. Additionally, if the Heading Required parameter is non-zero the aircraft will not leave the loiter until heading toward the next waypoint. ### Parameters

- **param1** Heading Required: Leave loiter circle only when track heading towards the next waypoint (MAV_BOOL_FALSE: Leave when altitude reached). Values not equal to 0 or 1 are invalid. - **param2** Radius: Loiter radius around waypoint for forward-only moving vehicles (not multicopters). If positive loiter clockwise, negative counter-clockwise, 0 means no change to standard loiter. - **param3** : Empty
- **param4** Xtrack Location: Loiter circle exit location and/or path to next waypoint ("xtrack") for forward-only moving vehicles (not multicopters). 0 for the vehicle to converge towards the center xtrack when it leaves the loiter (the line between the centers of the current and next waypoint), 1 to converge to the direct line between the location that the vehicle exits the loiter radius and the next waypoint. NaN to use the current system default xtrack behaviour. - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0228
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: 2a8455f4d4ac05b2
prev_chunk_id: chunk-0227
next_chunk_id: chunk-0229
section_heading: MAV_CMD_DO_FOLLOW (MAV_CMD value 32)
document_type: technical_reference

## MAV_CMD_DO_FOLLOW (MAV_CMD value 32)

Begin following a target

### Parameters

- **param1** System ID: System ID (of the FOLLOW_TARGET beacon). Send 0 to disable follow-me and return to the default position hold mode. - **param2** : Reserved
- **param3** : Reserved
- **param4** Altitude Mode: Altitude mode: 0: Keep current altitude, 1: keep altitude difference to target, 2: go to a fixed altitude above home. - **param5** Altitude: Altitude above home. (used if mode=2)
- **param6** : Reserved
- **param7** Time to Land: Time to land in which the MAV should go to the default position hold mode after a message RX timeout. ### MAV_CMD_DO_FOLLOW_REPOSITION (MAV_CMD value 33)
Reposition the MAV after a follow target command has been sent

### Parameters

- **param1** Camera Q1: Camera q1 (where 0 is on the ray from the camera to the tracking device)
- **param2** Camera Q2: Camera q2
- **param3** Camera Q3: Camera q3
- **param4** Camera Q4: Camera q4
- **param5** Altitude Offset: altitude offset from target
- **param6** X Offset: X offset from target
- **param7** Y Offset: Y offset from target

--- chunk_id: chunk-0229
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 264
content_hash: 4f71cb8779dfa610
prev_chunk_id: chunk-0228
next_chunk_id: chunk-0230
section_heading: MAV_CMD_DO_ORBIT (MAV_CMD value 34)
document_type: technical_reference

## MAV_CMD_DO_ORBIT (MAV_CMD value 34)

Start orbiting on the circumference of a circle defined by the parameters. Setting values to NaN/INT32_MAX (as appropriate) results in using defaults. ### Parameters

- **param1** Radius: Radius of the circle. Positive: orbit clockwise. Negative: orbit counter-clockwise. NaN: Use vehicle default radius, or current radius if already orbiting. - **param2** Velocity: Tangential Velocity. NaN: Use vehicle default velocity, or current velocity if already orbiting. - **param3** Yaw Behavior: Yaw behavior of the vehicle. - **param4** Orbits: Orbit around the centre point for this many radians (i.e. for a three-quarter orbit set 270*Pi/180). 0: Orbit forever. NaN: Use vehicle default, or current value if already orbiting. - **param5** Latitude/X: Center point latitude (if no MAV_FRAME specified) / X coordinate according to MAV_FRAME. INT32_MAX (or NaN if sent in COMMAND_LONG): Use current vehicle position, or current center if already orbiting. - **param6** Longitude/Y: Center point longitude (if no MAV_FRAME specified) / Y coordinate according to MAV_FRAME. INT32_MAX (or NaN if sent in COMMAND_LONG): Use current vehicle position, or current center if already orbiting. - **param7** Altitude/Z: Center point altitude (MSL) (if no MAV_FRAME specified) / Z coordinate according to MAV_FRAME. NaN: Use current vehicle altitude.

--- chunk_id: chunk-0230
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 394
content_hash: 83ec3b06ec0ecef7
prev_chunk_id: chunk-0229
next_chunk_id: chunk-0231
section_heading: MAV_CMD_DO_FIGURE_EIGHT (MAV_CMD value 35)
document_type: technical_reference

## MAV_CMD_DO_FIGURE_EIGHT (MAV_CMD value 35)

Fly a figure eight path as defined by the parameters. Set parameters to NaN/INT32_MAX (as appropriate) to use system-default values. The command is intended for fixed wing vehicles (and VTOL hybrids flying in fixed-wing mode), allowing POI tracking for gimbals that don't support infinite rotation. This command only defines the flight path. Speed should be set independently (use e.g. MAV_CMD_DO_CHANGE_SPEED). Yaw and other degrees of freedom are not specified, and will be flight-stack specific (on vehicles where they can be controlled independent of the heading). ### Parameters

- **param1** Major Radius: Major axis radius of the figure eight. Positive: orbit the north circle clockwise. Negative: orbit the north circle counter-clockwise. NaN: The radius will be set to 2.5 times the minor radius and direction is clockwise. Must be greater or equal to two times the minor radius for feasible values. - **param2** Minor Radius: Minor axis radius of the figure eight. Defines the radius of the two circles that make up the figure. Negative value has no effect. NaN: The radius will be set to the default loiter radius. - **param3**
- **param4** Orientation: Orientation of the figure eight major axis with respect to true north (range: [-pi,pi]). NaN: use default orientation aligned to true north. - **param5** Latitude/X: Center point latitude/X coordinate according to MAV_FRAME. If no MAV_FRAME specified, MAV_FRAME_GLOBAL is assumed. INT32_MAX or NaN: Use current vehicle position, or current center if already loitering. - **param6** Longitude/Y: Center point longitude/Y coordinate according to MAV_FRAME. If no MAV_FRAME specified, MAV_FRAME_GLOBAL is assumed. INT32_MAX or NaN: Use current vehicle position, or current center if already loitering. - **param7** Altitude/Z: Center point altitude MSL/Z coordinate according to MAV_FRAME. If no MAV_FRAME specified, MAV_FRAME_GLOBAL is assumed. INT32_MAX or NaN: Use current vehicle altitude.

--- chunk_id: chunk-0231
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 293
content_hash: 762f15e5d8fe9de5
prev_chunk_id: chunk-0230
next_chunk_id: chunk-0232
section_heading: MAV_CMD_NAV_ARC_WAYPOINT (MAV_CMD value 36)
document_type: technical_reference

## MAV_CMD_NAV_ARC_WAYPOINT (MAV_CMD value 36)

Circular arc path waypoint. This defines the end/exit point and angle (param1) of an arc path from the previous waypoint. A position is required before this command to define the start of the arc (e.g. current position, a MAV_CMD_NAV_WAYPOINT, or a MAV_CMD_NAV_ARC_WAYPOINT). The resulting path is a circular arc in the NE frame, with the difference in height being defined by the difference in waypoint altitudes. ### Parameters

- **param1** Arc Angle: The angle in degrees from the starting position to the exit position of the arc in the NE frame. Positive values are CW arcs and negative values are CCW arcs. - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

### MAV_CMD_NAV_ROI (MAV_CMD value 80)
Sets the region of interest (ROI) for a sensor set or the vehicle itself. This can then be used by the vehicle's control system to control the vehicle attitude and the attitude of various sensors such as cameras. ### Parameters

- **param1** ROI Mode: Region of interest mode. - **param2** WP Index: Waypoint index/ target ID. (see MAV_ROI enum)
- **param3** ROI Index: ROI index (allows a vehicle to manage multiple ROI's)
- **param4** : Empty
- **param5** X: x the location of the fixed ROI (see MAV_FRAME)
- **param6** Y: y
- **param7** Z: z

--- chunk_id: chunk-0232
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 216
content_hash: 39306813e0717045
prev_chunk_id: chunk-0231
next_chunk_id: chunk-0233
section_heading: MAV_CMD_NAV_PATHPLANNING (MAV_CMD value 81)
document_type: technical_reference

## MAV_CMD_NAV_PATHPLANNING (MAV_CMD value 81)

Control autonomous path planning on the MAV. ### Parameters

- **param1** Local Ctrl: 0: Disable local obstacle avoidance / local path planning (without resetting map), 1: Enable local path planning, 2: Enable and reset local path planning
- **param2** Global Ctrl: 0: Disable full path planning (without resetting map), 1: Enable, 2: Enable and reset map/occupancy grid, 3: Enable and reset planned route, but not occupancy grid
- **param3** : Empty
- **param4** Yaw: Yaw angle at goal
- **param5** Latitude/X: Latitude/X of goal
- **param6** Longitude/Y: Longitude/Y of goal
- **param7** Altitude/Z: Altitude/Z of goal

### MAV_CMD_NAV_SPLINE_WAYPOINT (MAV_CMD value 82)
Navigate to waypoint using a spline path. ### Parameters

- **param1** Hold: Hold time. (ignored by fixed wing, time to stay at waypoint for rotary wing)
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** Latitude/X: Latitude/X of goal
- **param6** Longitude/Y: Longitude/Y of goal
- **param7** Altitude/Z: Altitude/Z of goal

--- chunk_id: chunk-0233
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 240
content_hash: d6ed4dbc06daca8a
prev_chunk_id: chunk-0232
next_chunk_id: chunk-0234
section_heading: MAV_CMD_NAV_VTOL_TAKEOFF (MAV_CMD value 84)
document_type: technical_reference

## MAV_CMD_NAV_VTOL_TAKEOFF (MAV_CMD value 84)

Takeoff from ground using VTOL mode, and transition to forward flight with specified heading. The command should be ignored by vehicles that dont support both VTOL and fixed-wing flight (multicopters, boats,etc.). ### Parameters

- **param1** : Empty
- **param2** Transition Heading: Front transition heading. - **param3** : Empty
- **param4** Yaw Angle: Yaw angle. NaN to use the current system yaw heading mode (e.g. yaw towards next waypoint, yaw to home, etc.). - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

### MAV_CMD_NAV_VTOL_LAND (MAV_CMD value 85)
Land using VTOL mode

### Parameters

- **param1** Land Options: Landing behaviour. - **param2** : Empty
- **param3** Approach Altitude: Approach altitude (with the same reference as the Altitude field). NaN if unspecified. - **param4** Yaw: Yaw angle. NaN to use the current system yaw heading mode (e.g. yaw towards next waypoint, yaw to home, etc.). - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Ground Altitude: Altitude (ground level) relative to the current coordinate frame. NaN to use system default landing altitude (ignore value).

--- chunk_id: chunk-0234
source_document: mav_cmd_batch_01.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 282
content_hash: 82a635a61540c935
prev_chunk_id: chunk-0233
next_chunk_id: chunk-0235
section_heading: MAV_CMD_NAV_GUIDED_ENABLE (MAV_CMD value 92)
document_type: technical_reference

## MAV_CMD_NAV_GUIDED_ENABLE (MAV_CMD value 92)

Hand control over to an external controller

### Parameters

- **param1** Enable: Guided mode on (MAV_BOOL_FALSE: Off). Values not equal to 0 or 1 are invalid. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_NAV_DELAY (MAV_CMD value 93)
Delay the next navigation command a number of seconds or until a specified time

### Parameters

- **param1** Delay: Delay (-1 to enable time-of-day fields)
- **param2** Hour: hour (24h format, UTC, -1 to ignore)
- **param3** Minute: minute (24h format, UTC, -1 to ignore)
- **param4** Second: second (24h format, UTC, -1 to ignore)
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_NAV_PAYLOAD_PLACE (MAV_CMD value 94)
Descend and place payload. Vehicle moves to specified location, descends until it detects a hanging payload has reached the ground, and then releases the payload. If ground is not detected before the reaching the maximum descent value (param1), the command will complete without releasing the payload. ### Parameters

- **param1** Max Descent: Maximum distance to descend. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0235
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: 23ac82b193bd5555
prev_chunk_id: chunk-0234
next_chunk_id: chunk-0236
section_heading: MAV_CMD commands batch 2
document_type: technical_reference

# MAV_CMD commands batch 2

Structured extract from common.xml MAV_CMD enum.

--- chunk_id: chunk-0236
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 365
content_hash: 440a923fa4549e1c
prev_chunk_id: chunk-0235
next_chunk_id: chunk-0237
section_heading: MAV_CMD_NAV_LAST (MAV_CMD value 95)
document_type: technical_reference

## MAV_CMD_NAV_LAST (MAV_CMD value 95)

NOP - This command is only used to mark the upper limit of the NAV/ACTION commands in the enumeration

### Parameters

- **param1** : Empty
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_CONDITION_DELAY (MAV_CMD value 112)
Delay mission state machine. ### Parameters

- **param1** Delay: Delay
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_CONDITION_CHANGE_ALT (MAV_CMD value 113)
Ascend/descend to target altitude at specified rate. Delay mission state machine until desired altitude reached. ### Parameters

- **param1** Rate: Descent / Ascend rate. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** Altitude: Target Altitude

### MAV_CMD_CONDITION_DISTANCE (MAV_CMD value 114)
Delay mission state machine until within desired distance of next NAV point. ### Parameters

- **param1** Distance: Distance. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_CONDITION_YAW (MAV_CMD value 115)
Reach a certain target angle. ### Parameters

- **param1** Angle: target angle [0-360]. Absolute angles: 0 is north. Relative angle: 0 is initial yaw. Direction set by param3. - **param2** Angular Speed: angular speed
- **param3** Direction: direction: -1: counter clockwise, 0: shortest direction, 1: clockwise
- **param4** Relative: Relative offset (MAV_BOOL_FALSE: absolute angle). Values not equal to 0 or 1 are invalid. - **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0237
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 269
content_hash: 0f7543ea8f9b8b12
prev_chunk_id: chunk-0236
next_chunk_id: chunk-0238
section_heading: MAV_CMD_CONDITION_LAST (MAV_CMD value 159)
document_type: technical_reference

## MAV_CMD_CONDITION_LAST (MAV_CMD value 159)

NOP - This command is only used to mark the upper limit of the CONDITION commands in the enumeration

### Parameters

- **param1** : Empty
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_SET_MODE (MAV_CMD value 176)
Set system mode. ### Parameters

- **param1** Mode: Mode flags. MAV_MODE values can be used to set some mode flag combinations. - **param2** Custom Mode: Custom system-specific mode (see target autopilot specifications for mode information). If MAV_MODE_FLAG_CUSTOM_MODE_ENABLED is set in param1 (mode) this mode is used: otherwise the field is ignored. - **param3** Custom Submode: Custom sub mode - this is system specific, please refer to the individual autopilot specifications for details. - **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_JUMP (MAV_CMD value 177)
Jump to the desired command in the mission list. Repeat this action only the specified number of times

### Parameters

- **param1** Number: Sequence number
- **param2** Repeat: Repeat count
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0238
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 326
content_hash: c3a579e6f2b86a52
prev_chunk_id: chunk-0237
next_chunk_id: chunk-0239
section_heading: MAV_CMD_DO_CHANGE_SPEED (MAV_CMD value 178)
document_type: technical_reference

## MAV_CMD_DO_CHANGE_SPEED (MAV_CMD value 178)

Change speed and/or throttle set points. The value persists until it is overridden or there is a mode change

### Parameters

- **param1** Speed Type: Speed type of value set in param2 (such as airspeed, ground speed, and so on)
- **param2** Speed: Speed (-1 indicates no change, -2 indicates return to default vehicle speed)
- **param3** Throttle: Throttle (-1 indicates no change, -2 indicates return to default vehicle throttle value)
- **param4**
- **param5**
- **param6**
- **param7**

### MAV_CMD_DO_SET_HOME (MAV_CMD value 179)
Sets the home position to either to the current position or a specified position. The home position is the default position that the system will return to and land on. The position is set automatically by the system during the takeoff (and may also be set using this command). Note: the current home position may be emitted in a HOME_POSITION message on request (using MAV_CMD_REQUEST_MESSAGE with param1=242). ### Parameters

- **param1** Use Current: Use current location (MAV_BOOL_FALSE: use specified location). Values not equal to 0 or 1 are invalid. - **param2** Roll: Roll angle (of surface). Range: -180..180 degrees. NAN or 0 means value not set. 0.01 indicates zero roll. - **param3** Pitch: Pitch angle (of surface). Range: -90..90 degrees. NAN or 0 means value not set. 0.01 means zero pitch. - **param4** Yaw: Yaw angle. NaN to use default heading. Range: -180..180 degrees. - **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0239
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 228
content_hash: 8ffc3dbdc7bc94a4
prev_chunk_id: chunk-0238
next_chunk_id: chunk-0240
section_heading: MAV_CMD_DO_SET_PARAMETER (MAV_CMD value 180)
document_type: technical_reference

## MAV_CMD_DO_SET_PARAMETER (MAV_CMD value 180)

Set a system parameter. Caution! Use of this command requires knowledge of the numeric enumeration value of the parameter. ### Parameters

- **param1** Number: Parameter number
- **param2** Value: Parameter value
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_SET_RELAY (MAV_CMD value 181)
Set a relay to a condition. The current value may optionally be reported using RELAY_STATUS. ### Parameters

- **param1** Instance: Relay instance number. - **param2** Setting: Setting. (1=on, 0=off, others possible depending on system hardware)
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_REPEAT_RELAY (MAV_CMD value 182)
Cycle a relay on and off for a desired number of cycles with a desired period. ### Parameters

- **param1** Instance: Relay instance number. - **param2** Count: Cycle count. - **param3** Time: Cycle time. - **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0240
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 342
content_hash: e9c9a4a12269671b
prev_chunk_id: chunk-0239
next_chunk_id: chunk-0241
section_heading: MAV_CMD_DO_SET_SERVO (MAV_CMD value 183)
document_type: technical_reference

## MAV_CMD_DO_SET_SERVO (MAV_CMD value 183)

Set a servo to a desired PWM value. ### Parameters

- **param1** Instance: Servo instance number. - **param2** PWM: Pulse Width Modulation. - **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_REPEAT_SERVO (MAV_CMD value 184)
Cycle a between its nominal setting and a desired PWM for a desired number of cycles with a desired period. ### Parameters

- **param1** Instance: Servo instance number. - **param2** PWM: Pulse Width Modulation. - **param3** Count: Cycle count. - **param4** Time: Cycle time. - **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_FLIGHTTERMINATION (MAV_CMD value 185)
Terminate flight immediately. Flight termination immediately and irreversibly terminates the current flight, returning the vehicle to ground. The vehicle will ignore RC or other input until it has been power-cycled. Termination may trigger safety measures, including: disabling motors and deployment of parachute on multicopters, and setting flight surfaces to initiate a landing pattern on fixed-wing). On multicopters without a parachute it may trigger a crash landing. Support for this command can be tested using the protocol bit: MAV_PROTOCOL_CAPABILITY_FLIGHT_TERMINATION. Support for this command can also be tested by sending the command with param1=0 (< 0.5); the ACK should be either MAV_RESULT_FAILED or MAV_RESULT_UNSUPPORTED. ### Parameters

- **param1** Terminate: Flight termination activated if > 0.5. Otherwise not activated and ACK with MAV_RESULT_FAILED. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0241
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 305
content_hash: 66c4e0e25feef955
prev_chunk_id: chunk-0240
next_chunk_id: chunk-0242
section_heading: MAV_CMD_DO_CHANGE_ALTITUDE (MAV_CMD value 186)
document_type: technical_reference

## MAV_CMD_DO_CHANGE_ALTITUDE (MAV_CMD value 186)

Change altitude set point. ### Parameters

- **param1** Altitude: Altitude. - **param2** Frame: Frame of new altitude. - **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_SET_ACTUATOR (MAV_CMD value 187)
Sets actuators (e.g. servos) to a desired value. The actuator numbers are mapped to specific outputs (e.g. on any MAIN or AUX PWM or UAVCAN) using a flight-stack specific mechanism (i.e. a parameter). ### Parameters

- **param1** Actuator 1: Actuator 1 value, scaled from [-1 to 1]. NaN to ignore. - **param2** Actuator 2: Actuator 2 value, scaled from [-1 to 1]. NaN to ignore. - **param3** Actuator 3: Actuator 3 value, scaled from [-1 to 1]. NaN to ignore. - **param4** Actuator 4: Actuator 4 value, scaled from [-1 to 1]. NaN to ignore. - **param5** Actuator 5: Actuator 5 value. If sent in COMMAND_LONG: value is scaled from [-1 to 1]. NaN to ignore. If sent in COMMAND_INT or MISSION_ITEM_INT: value is scaled by 1e7. INT32_MAX to ignore. - **param6** Actuator 6: Actuator 6 value. If sent in COMMAND_LONG: value is scaled from [-1 to 1]. NaN to ignore. If sent in COMMAND_INT or MISSION_ITEM_INT: value is scaled by 1e7. INT32_MAX to ignore. - **param7** Index: Index of actuator set (i.e if set to 1, Actuator 1 becomes Actuator 7)

--- chunk_id: chunk-0242
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 358
content_hash: 4bcde60f83b2f1d8
prev_chunk_id: chunk-0241
next_chunk_id: chunk-0243
section_heading: MAV_CMD_DO_RETURN_PATH_START (MAV_CMD value 188)
document_type: technical_reference

## MAV_CMD_DO_RETURN_PATH_START (MAV_CMD value 188)

Mission item to specify the start of a failsafe/landing return-path segment (the end of the segment is the next MAV_CMD_DO_LAND_START item). A vehicle that is using missions for landing (e.g. in a return mode) will join the mission on the closest path of the return-path segment (instead of MAV_CMD_DO_LAND_START or the nearest waypoint). The main use case is to minimize the failsafe flight path in corridor missions, where the inbound/outbound paths are constrained (by geofences) to the same particular path. The MAV_CMD_NAV_RETURN_PATH_START would be placed at the start of the return path. If a failsafe occurs on the outbound path the vehicle will move to the nearest point on the return path (which is parallel for this kind of mission), effectively turning round and following the shortest path to landing. If a failsafe occurs on the inbound path the vehicle is already on the return segment and will continue to landing. The Latitude/Longitude/Altitude are optional, and may be set to 0 if not needed. If specified, the item defines the waypoint at which the return segment starts. If sent using as a command, the vehicle will perform a mission landing (using the land segment if defined) or reject the command if mission landings are not supported, or no mission landing is defined. When used as a command any position information in the command is ignored. ### Parameters

- **param1** : Empty
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** Latitude: Latitudee. 0: not used. - **param6** Longitude: Longitudee. 0: not used. - **param7** Altitude: Altitudee. 0: not used.

--- chunk_id: chunk-0243
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 317
content_hash: 38548d1406fc9a91
prev_chunk_id: chunk-0242
next_chunk_id: chunk-0244
section_heading: MAV_CMD_DO_LAND_START (MAV_CMD value 189)
document_type: technical_reference

## MAV_CMD_DO_LAND_START (MAV_CMD value 189)

Mission item to mark the start of a mission landing pattern, or a command to land with a mission landing pattern. When used in a mission, this is a marker for the start of a sequence of mission items that represent a landing pattern. It should be followed by a navigation item that defines the first waypoint of the landing sequence. The start marker positional params are used only for selecting what landing pattern to use if several are defined in the mission (the selected pattern will be the one with the marker position that is closest to the vehicle when a landing is commanded). If the marker item position has zero-values for latitude, longitude, and altitude, then landing pattern selection is instead based on the position of the first waypoint in the landing sequence. When sent as a command it triggers a landing using a mission landing pattern. The location parameters are not used in this case, and should be set to 0. ### Parameters

- **param1** : Empty
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** Latitude: Latitude for landing sequence selection, or 0 (see description). Ignored in commands (set 0). - **param6** Longitude: Longitude for landing sequence selection, or 0 (see description). Ignored in commands (set 0). - **param7** Altitude: Altitude for landing sequence selection, or 0 (see description). Ignored in commands (set 0).

--- chunk_id: chunk-0244
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 281
content_hash: 3e752a504a52954c
prev_chunk_id: chunk-0243
next_chunk_id: chunk-0245
section_heading: MAV_CMD_DO_RALLY_LAND (MAV_CMD value 190)
document_type: technical_reference

## MAV_CMD_DO_RALLY_LAND (MAV_CMD value 190)

Mission command to perform a landing from a rally point. ### Parameters

- **param1** Altitude: Break altitude
- **param2** Speed: Landing speed
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_GO_AROUND (MAV_CMD value 191)
Mission command to safely abort an autonomous landing. ### Parameters

- **param1** Altitude: Altitude
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_REPOSITION (MAV_CMD value 192)
Reposition the vehicle to a specific WGS84 global position. This command is intended for guided commands (for missions use MAV_CMD_NAV_WAYPOINT instead). ### Parameters

- **param1** Speed: Ground speed, less than 0 (-1) for default
- **param2** Bitmask: Bitmask of option flags. - **param3** Radius: Loiter radius for planes. Positive values only, direction is controlled by Yaw value. A value of zero or NaN is ignored. - **param4** Yaw: Yaw heading (heading reference defined in Bitmask field). NaN to use the current system yaw heading mode (e.g. yaw towards next waypoint, yaw to home, etc.). For planes indicates loiter direction (0: clockwise, 1: counter clockwise)
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0245
source_document: mav_cmd_batch_02.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 193
content_hash: b27ca5dcdb601081
prev_chunk_id: chunk-0244
next_chunk_id: chunk-0246
section_heading: MAV_CMD_DO_PAUSE_CONTINUE (MAV_CMD value 193)
document_type: technical_reference

## MAV_CMD_DO_PAUSE_CONTINUE (MAV_CMD value 193)

If in a GPS controlled position mode, hold the current position or continue. ### Parameters

- **param1** Continue: Continue mission (MAV_BOOL_TRUE), Pause current mission or reposition command, hold current position (MAV_BOOL_FALSE). Values not equal to 0 or 1 are invalid. A VTOL capable vehicle should enter hover mode (multicopter and VTOL planes). A plane should loiter with the default loiter radius. - **param2** : Reserved
- **param3** : Reserved
- **param4** : Reserved
- **param5** : Reserved
- **param6** : Reserved
- **param7** : Reserved

### MAV_CMD_DO_SET_REVERSE (MAV_CMD value 194)
Set moving direction to forward or reverse. ### Parameters

- **param1** Reverse: Reverse direction (MAV_BOOL_FALSE: Forward direction). Values not equal to 0 or 1 are invalid. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0246
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: c62cfe096f81fab8
prev_chunk_id: chunk-0245
next_chunk_id: chunk-0247
section_heading: MAV_CMD commands batch 3
document_type: technical_reference

# MAV_CMD commands batch 3

Structured extract from common.xml MAV_CMD enum.

--- chunk_id: chunk-0247
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 177
content_hash: 9d2052c92edbe64e
prev_chunk_id: chunk-0246
next_chunk_id: chunk-0248
section_heading: MAV_CMD_DO_SET_ROI_LOCATION (MAV_CMD value 195)
document_type: technical_reference

## MAV_CMD_DO_SET_ROI_LOCATION (MAV_CMD value 195)

Sets the region of interest (ROI) to a location. This can then be used by the vehicle's control system to control the vehicle attitude and the attitude of various sensors such as cameras. This command can be sent to a gimbal manager but not to a gimbal device. A gimbal is not to react to this message. ### Parameters

- **param1** Gimbal device ID: Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals). - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** Latitude: Latitude of ROI location
- **param6** Longitude: Longitude of ROI location
- **param7** Altitude: Altitude of ROI location

--- chunk_id: chunk-0248
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 212
content_hash: 95c7589882a18354
prev_chunk_id: chunk-0247
next_chunk_id: chunk-0249
section_heading: MAV_CMD_DO_SET_ROI_WPNEXT_OFFSET (MAV_CMD value 196)
document_type: technical_reference

## MAV_CMD_DO_SET_ROI_WPNEXT_OFFSET (MAV_CMD value 196)

Sets the region of interest (ROI) to be toward next waypoint, with optional pitch/roll/yaw offset. This can then be used by the vehicle's control system to control the vehicle attitude and the attitude of various sensors such as cameras. This command can be sent to a gimbal manager but not to a gimbal device. A gimbal device is not to react to this message. ### Parameters

- **param1** Gimbal device ID: Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals). - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** Pitch Offset: Pitch offset from next waypoint, positive pitching up
- **param6** Roll Offset: Roll offset from next waypoint, positive rolling to the right
- **param7** Yaw Offset: Yaw offset from next waypoint, positive yawing to the right

--- chunk_id: chunk-0249
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 197
content_hash: d79124531dcf642d
prev_chunk_id: chunk-0248
next_chunk_id: chunk-0250
section_heading: MAV_CMD_DO_SET_ROI_NONE (MAV_CMD value 197)
document_type: technical_reference

## MAV_CMD_DO_SET_ROI_NONE (MAV_CMD value 197)

Cancels any previous ROI command returning the vehicle/sensors to default flight characteristics. This can then be used by the vehicle's control system to control the vehicle attitude and the attitude of various sensors such as cameras. This command can be sent to a gimbal manager but not to a gimbal device. A gimbal device is not to react to this message. After this command the gimbal manager should go back to manual input if available, and otherwise assume a neutral position. ### Parameters

- **param1** Gimbal device ID: Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals). - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0250
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: f5b820918e95a503
prev_chunk_id: chunk-0249
next_chunk_id: chunk-0251
section_heading: MAV_CMD_DO_SET_ROI_SYSID (MAV_CMD value 198)
document_type: technical_reference

## MAV_CMD_DO_SET_ROI_SYSID (MAV_CMD value 198)

Mount tracks system with specified system ID. Determination of target vehicle position may be done with GLOBAL_POSITION_INT or any other means. This command can be sent to a gimbal manager but not to a gimbal device. A gimbal device is not to react to this message. ### Parameters

- **param1** System ID: System ID
- **param2** Gimbal device ID: Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals). ### MAV_CMD_DO_CONTROL_VIDEO (MAV_CMD value 200)
Control onboard camera system. ### Parameters

- **param1** ID: Camera ID (-1 for all)
- **param2** Transmission: Transmission: 0: disabled, 1: enabled compressed, 2: enabled raw
- **param3** Interval: Transmission mode: 0: video stream, >0: single images every n seconds
- **param4** Recording: Recording: 0: disabled, 1: enabled compressed, 2: enabled raw
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0251
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 282
content_hash: ea57ef776e35e37f
prev_chunk_id: chunk-0250
next_chunk_id: chunk-0252
section_heading: MAV_CMD_DO_SET_ROI (MAV_CMD value 201)
document_type: technical_reference

## MAV_CMD_DO_SET_ROI (MAV_CMD value 201)

Sets the region of interest (ROI) for a sensor set or the vehicle itself. This can then be used by the vehicle's control system to control the vehicle attitude and the attitude of various sensors such as cameras. ### Parameters

- **param1** ROI Mode: Region of interest mode. - **param2** WP Index: Waypoint index/ target ID (depends on param 1). - **param3** ROI Index: Region of interest index. (allows a vehicle to manage multiple ROI's)
- **param4** : Empty
- **param5** : MAV_ROI_WPNEXT: pitch offset from next waypoint, MAV_ROI_LOCATION: latitude
- **param6** : MAV_ROI_WPNEXT: roll offset from next waypoint, MAV_ROI_LOCATION: longitude
- **param7** : MAV_ROI_WPNEXT: yaw offset from next waypoint, MAV_ROI_LOCATION: altitude

### MAV_CMD_DO_DIGICAM_CONFIGURE (MAV_CMD value 202)
Configure digital camera. This is a fallback message for systems that have not yet implemented PARAM_EXT_XXX messages and camera definition files (see https://mavlink.io/en/services/camera_def.html ). ### Parameters

- **param1** Mode: Modes: P, TV, AV, M, Etc. - **param2** Shutter Speed: Shutter speed: Divisor number for one second. - **param3** Aperture: Aperture: F stop number. - **param4** ISO: ISO number e.g. 80, 100, 200, Etc. - **param5** Exposure: Exposure type enumerator. - **param6** Command Identity: Command Identity. - **param7** Engine Cut-off: Main engine cut-off time before camera trigger. (0 means no cut-off)

--- chunk_id: chunk-0252
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 316
content_hash: 60d22366ba776765
prev_chunk_id: chunk-0251
next_chunk_id: chunk-0253
section_heading: MAV_CMD_DO_DIGICAM_CONTROL (MAV_CMD value 203)
document_type: technical_reference

## MAV_CMD_DO_DIGICAM_CONTROL (MAV_CMD value 203)

Control digital camera. This is a fallback message for systems that have not yet implemented PARAM_EXT_XXX messages and camera definition files (see https://mavlink.io/en/services/camera_def.html ). ### Parameters

- **param1** Session Control: Session control e.g. show/hide lens
- **param2** Zoom Absolute: Zoom's absolute position
- **param3** Zoom Relative: Zooming step value to offset zoom from the current position
- **param4** Focus: Focus Locking, Unlocking or Re-locking
- **param5** Shoot Command: Shooting Command
- **param6** Command Identity: Command Identity
- **param7** Shot ID: Test shot identifier. If set to 1, image will only be captured, but not counted towards internal frame count. ### MAV_CMD_DO_MOUNT_CONFIGURE (MAV_CMD value 204)
Mission command to configure a camera or antenna mount

### Parameters

- **param1** Mode: Mount operation mode
- **param2** Stabilize Roll: Stabilize roll (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param3** Stabilize Pitch: Stabilize pitch (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param4** Stabilize Yaw: Stabilize yaw (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param5** Roll Input Mode: Roll input (0 = angle body frame, 1 = angular rate, 2 = angle absolute frame)
- **param6** Pitch Input Mode: Pitch input (0 = angle body frame, 1 = angular rate, 2 = angle absolute frame)
- **param7** Yaw Input Mode: Yaw input (0 = angle body frame, 1 = angular rate, 2 = angle absolute frame)

--- chunk_id: chunk-0253
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 324
content_hash: 5e27bed601b29639
prev_chunk_id: chunk-0252
next_chunk_id: chunk-0254
section_heading: MAV_CMD_DO_MOUNT_CONTROL (MAV_CMD value 205)
document_type: technical_reference

## MAV_CMD_DO_MOUNT_CONTROL (MAV_CMD value 205)

Mission command to control a camera or antenna mount

### Parameters

- **param1** Pitch: pitch depending on mount mode (degrees or degrees/second depending on pitch input). - **param2** Roll: roll depending on mount mode (degrees or degrees/second depending on roll input). - **param3** Yaw: yaw depending on mount mode (degrees or degrees/second depending on yaw input). - **param4** Altitude: altitude depending on mount mode. - **param5** Latitude: latitude, set if appropriate mount mode. - **param6** Longitude: longitude, set if appropriate mount mode. - **param7** Mode: Mount mode. ### MAV_CMD_DO_SET_CAM_TRIGG_DIST (MAV_CMD value 206)
Mission command to set camera trigger distance for this flight. The camera is triggered each time this distance is exceeded. This command can also be used to set the shutter integration time for the camera. ### Parameters

- **param1** Distance: Camera trigger distance. 0 to stop triggering. - **param2** Shutter: Camera shutter integration time. -1 or 0 to ignore
- **param3** Trigger: Trigger camera once, immediately (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param4** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0254
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: f0d5893e63122839
prev_chunk_id: chunk-0253
next_chunk_id: chunk-0255
section_heading: MAV_CMD_DO_FENCE_ENABLE (MAV_CMD value 207)
document_type: technical_reference

## MAV_CMD_DO_FENCE_ENABLE (MAV_CMD value 207)

Enable the geofence. This can be used in a mission or via the command protocol. The persistence/lifetime of the setting is undefined. Depending on flight stack implementation it may persist until superseded, or it may revert to a system default at the end of a mission. Flight stacks typically reset the setting to system defaults on reboot. ### Parameters

- **param1** Enable: enable? (0=disable, 1=enable, 2=disable_floor_only)
- **param2** Types: Fence types to enable or disable as a bitmask. 0: field is unused/all fences should be enabled or disabled (for compatibility reasons). Parameter is ignored if param1=2. - **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_PARACHUTE (MAV_CMD value 208)
Mission item/command to release a parachute or enable/disable auto release. ### Parameters

- **param1** Action: Action
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0255
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 201
content_hash: c4e1ad439faee4e0
prev_chunk_id: chunk-0254
next_chunk_id: chunk-0256
section_heading: MAV_CMD_DO_MOTOR_TEST (MAV_CMD value 209)
document_type: technical_reference

## MAV_CMD_DO_MOTOR_TEST (MAV_CMD value 209)

Command to perform motor test. ### Parameters

- **param1** Instance: Motor instance number (from 1 to max number of motors on the vehicle). - **param2** Throttle Type: Throttle type (whether the Throttle Value in param3 is a percentage, PWM value, etc.)
- **param3** Throttle: Throttle value. - **param4** Timeout: Timeout between tests that are run in sequence. - **param5** Motor Count: Motor count. Number of motors to test in sequence: 0/1=one motor, 2= two motors, etc. The Timeout (param4) is used between tests. - **param6** Test Order: Motor test order. - **param7** : Empty

### MAV_CMD_DO_INVERTED_FLIGHT (MAV_CMD value 210)
Change to/from inverted flight. ### Parameters

- **param1** Inverted: Inverted flight (MAV_BOOL_False: normal flight). Values not equal to 0 or 1 are invalid. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0256
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 210
content_hash: 652ae44d36b0ed1b
prev_chunk_id: chunk-0255
next_chunk_id: chunk-0257
section_heading: MAV_CMD_DO_GRIPPER (MAV_CMD value 211)
document_type: technical_reference

## MAV_CMD_DO_GRIPPER (MAV_CMD value 211)

Mission command to operate a gripper. ### Parameters

- **param1** Gripper ID: Gripper ID. 1-6 for an autopilot connected gripper. In missions this may be set to 1-6 for an autopilot gripper, or the gripper component id for a MAVLink gripper. 0 targets all grippers. - **param2** Action: Gripper action to perform. - **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_AUTOTUNE_ENABLE (MAV_CMD value 212)
Enable/disable autotune. ### Parameters

- **param1** Enable: Enable autotune (MAV_BOOL_FALSE: disable autotune). Values not equal to 0 or 1 are invalid. - **param2** Axis: Specify axes for which autotuning is enabled/disabled. 0 indicates the field is unused (for compatibility reasons). If 0 the autopilot will follow its default behaviour, which is usually to tune all axes. - **param3** : Empty. - **param4** : Empty. - **param5** : Empty. - **param6** : Empty. - **param7** : Empty.

--- chunk_id: chunk-0257
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 286
content_hash: c1ab85da2bc67816
prev_chunk_id: chunk-0256
next_chunk_id: chunk-0258
section_heading: MAV_CMD_NAV_SET_YAW_SPEED (MAV_CMD value 213)
document_type: technical_reference

## MAV_CMD_NAV_SET_YAW_SPEED (MAV_CMD value 213)

Sets a desired vehicle turn angle and speed change. ### Parameters

- **param1** Yaw: Yaw angle to adjust steering by. - **param2** Speed: Speed. - **param3** Angle: Relative final angle (MAV_BOOL_FALSE: Absolute angle). Values not equal to 0 or 1 are invalid. - **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_SET_CAM_TRIGG_INTERVAL (MAV_CMD value 214)
Mission command to set camera trigger interval for this flight. If triggering is enabled, the camera is triggered each time this interval expires. This command can also be used to set the shutter integration time for the camera. ### Parameters

- **param1** Trigger Cycle: Camera trigger cycle time. -1 or 0 to ignore. - **param2** Shutter Integration: Camera shutter integration time. Should be less than trigger cycle time. -1 or 0 to ignore. - **param3** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0258
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 350
content_hash: c883aa02630a872e
prev_chunk_id: chunk-0257
next_chunk_id: chunk-0259
section_heading: MAV_CMD_DO_MOUNT_CONTROL_QUAT (MAV_CMD value 220)
document_type: technical_reference

## MAV_CMD_DO_MOUNT_CONTROL_QUAT (MAV_CMD value 220)

Mission command to control a camera or antenna mount, using a quaternion as reference. ### Parameters

- **param1** Q1: quaternion param q1, w (1 in null-rotation)
- **param2** Q2: quaternion param q2, x (0 in null-rotation)
- **param3** Q3: quaternion param q3, y (0 in null-rotation)
- **param4** Q4: quaternion param q4, z (0 in null-rotation)
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_GUIDED_MASTER (MAV_CMD value 221)
set id of master controller

### Parameters

- **param1** System ID: System ID
- **param2** Component ID: Component ID
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_DO_GUIDED_LIMITS (MAV_CMD value 222)
Set limits for external control

### Parameters

- **param1** Timeout: Timeout - maximum time that external controller will be allowed to control vehicle. 0 means no timeout. - **param2** Min Altitude: Altitude (MSL) min - if vehicle moves below this alt, the command will be aborted and the mission will continue. 0 means no lower altitude limit. - **param3** Max Altitude: Altitude (MSL) max - if vehicle moves above this alt, the command will be aborted and the mission will continue. 0 means no upper altitude limit. - **param4** Horiz. Move Limit: Horizontal move limit - if vehicle moves more than this distance from its location at the moment the command was executed, the command will be aborted and the mission will continue. 0 means no horizontal move limit. - **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0259
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 185
content_hash: e1891e37c15f8591
prev_chunk_id: chunk-0258
next_chunk_id: chunk-0260
section_heading: MAV_CMD_DO_ENGINE_CONTROL (MAV_CMD value 223)
document_type: technical_reference

## MAV_CMD_DO_ENGINE_CONTROL (MAV_CMD value 223)

Control vehicle engine. This is interpreted by the vehicles engine controller to change the target engine state. It is intended for vehicles with internal combustion engines

### Parameters

- **param1** Start Engine: Start engine (MAV_BOOL_False: Stop engine). Values not equal to 0 or 1 are invalid. - **param2** Cold Start: Cold start engine (MAV_BOOL_FALSE: Warm start). Values not equal to 0 or 1 are invalid. Controls use of choke where applicable
- **param3** Height Delay: Height delay. This is for commanding engine start only after the vehicle has gained the specified height. Used in VTOL vehicles during takeoff to start engine after the aircraft is off the ground. Zero for no delay. - **param4** Options: A bitmask of options for engine control
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0260
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 369
content_hash: 38647bc6403517e1
prev_chunk_id: chunk-0259
next_chunk_id: chunk-0261
section_heading: MAV_CMD_DO_SET_MISSION_CURRENT (MAV_CMD value 224)
document_type: technical_reference

## MAV_CMD_DO_SET_MISSION_CURRENT (MAV_CMD value 224)

Set the mission item with sequence number seq as the current item and emit MISSION_CURRENT (whether or not the mission number changed). If a mission is currently being executed, the system will continue to this new mission item on the shortest path, skipping any intermediate mission items. Note that mission jump repeat counters are not reset unless param2 is set (see MAV_CMD_DO_JUMP param2). This command may trigger a mission state-machine change on some systems: for example from MISSION_STATE_NOT_STARTED or MISSION_STATE_PAUSED to MISSION_STATE_ACTIVE. If the system is in mission mode, on those systems this command might therefore start, restart or resume the mission. If the system is not in mission mode this command must not trigger a switch to mission mode. The mission may be "reset" using param2. Resetting sets jump counters to initial values (to reset counters without changing the current mission item set the param1 to `-1`). Resetting also explicitly changes a mission state of MISSION_STATE_COMPLETE to MISSION_STATE_PAUSED or MISSION_STATE_ACTIVE, potentially allowing it to resume when it is (next) in a mission mode. The command will ACK with MAV_RESULT_FAILED if the sequence number is out of range (including if there is no mission item). ### Parameters

- **param1** Number: Mission sequence value to set. -1 for the current mission item (use to reset mission without changing current mission item). - **param2** Reset Mission: Reset mission (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. Resets jump counters to initial values and changes mission state "completed" to be "active" or "paused". - **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0261
source_document: mav_cmd_batch_03.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 72
content_hash: 447ac4152449feb5
prev_chunk_id: chunk-0260
next_chunk_id: chunk-0262
section_heading: MAV_CMD_DO_LAST (MAV_CMD value 240)
document_type: technical_reference

## MAV_CMD_DO_LAST (MAV_CMD value 240)

NOP - This command is only used to mark the upper limit of the DO commands in the enumeration

### Parameters

- **param1** : Empty
- **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0262
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: 4b1cc5f5e5a510f7
prev_chunk_id: chunk-0261
next_chunk_id: chunk-0263
section_heading: MAV_CMD commands batch 4
document_type: technical_reference

# MAV_CMD commands batch 4

Structured extract from common.xml MAV_CMD enum.

--- chunk_id: chunk-0263
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 333
content_hash: 5596415b8b870c1b
prev_chunk_id: chunk-0262
next_chunk_id: chunk-0264
section_heading: MAV_CMD_PREFLIGHT_CALIBRATION (MAV_CMD value 241)
document_type: technical_reference

## MAV_CMD_PREFLIGHT_CALIBRATION (MAV_CMD value 241)

Trigger calibration. This command will be only accepted if in pre-flight mode. Except for Temperature Calibration, only one sensor should be set in a single message and all others should be zero. ### Parameters

- **param1** Gyro Temperature: 1: gyro calibration, 3: gyro temperature calibration
- **param2** Magnetometer: Magnetometer calibration action. - **param3** Ground Pressure: Ground pressure calibration. Values not equal to 0 or 1 are invalid. - **param4** Remote Control: 1: radio RC calibration, 2: RC trim calibration
- **param5** Accelerometer: Accelerometer calibration action. - **param6** Compmot or Airspeed: 1: APM: compass/motor interference calibration (PX4: airspeed calibration, deprecated), 2: airspeed calibration
- **param7** ESC or Baro: 1: ESC calibration, 3: barometer temperature calibration

### MAV_CMD_PREFLIGHT_SET_SENSOR_OFFSETS (MAV_CMD value 242)
Set sensor offsets. This command will be only accepted if in pre-flight mode. ### Parameters

- **param1** Sensor Type: Sensor to adjust the offsets for: 0: gyros, 1: accelerometer, 2: magnetometer, 3: barometer, 4: optical flow, 5: second magnetometer, 6: third magnetometer
- **param2** X Offset: X axis offset (or generic dimension 1), in the sensor's raw units
- **param3** Y Offset: Y axis offset (or generic dimension 2), in the sensor's raw units
- **param4** Z Offset: Z axis offset (or generic dimension 3), in the sensor's raw units
- **param5** 4th Dimension: Generic dimension 4, in the sensor's raw units
- **param6** 5th Dimension: Generic dimension 5, in the sensor's raw units
- **param7** 6th Dimension: Generic dimension 6, in the sensor's raw units

--- chunk_id: chunk-0264
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: a4fd846bbb3fe071
prev_chunk_id: chunk-0263
next_chunk_id: chunk-0265
section_heading: MAV_CMD_PREFLIGHT_UAVCAN (MAV_CMD value 243)
document_type: technical_reference

## MAV_CMD_PREFLIGHT_UAVCAN (MAV_CMD value 243)

Trigger UAVCAN configuration (actuator ID assignment and direction mapping). Note that this maps to the legacy UAVCAN v0 function UAVCAN_ENUMERATE, which is intended to be executed just once during initial vehicle configuration (it is not a normal pre-flight command and has been poorly named). ### Parameters

- **param1** Actuator ID: 1: Trigger actuator ID assignment and direction mapping. 0: Cancel command. - **param2** : Reserved
- **param3** : Reserved
- **param4** : Reserved
- **param5** : Reserved
- **param6** : Reserved
- **param7** : Reserved

### MAV_CMD_PREFLIGHT_STORAGE (MAV_CMD value 245)
Request storage of different parameter values and logs. This command will be only accepted if in pre-flight mode. ### Parameters

- **param1** Parameter Storage: Action to perform on the persistent parameter storage
- **param2** Mission Storage: Action to perform on the persistent mission storage
- **param3** Logging Rate: Onboard logging: 0: Ignore, 1: Start default rate logging, -1: Stop logging, > 1: logging rate (e.g. set to 1000 for 1000 Hz logging)
- **param4** : Reserved
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

--- chunk_id: chunk-0265
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 258
content_hash: d02d3bf817a53d7c
prev_chunk_id: chunk-0264
next_chunk_id: chunk-0266
section_heading: MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN (MAV_CMD value 246)
document_type: technical_reference

## MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN (MAV_CMD value 246)

Request the reboot or shutdown of system components. ### Parameters

- **param1** Autopilot: Action to take for autopilot. - **param2** Companion: Action to take for onboard computer. - **param3** Component Action: Action to take for component specified in param4. - **param4** Component ID: MAVLink Component ID targeted in param3 (0 for all components). - **param5** : Reserved (set to 0)
- **param6** Conditions: Conditions under which reboot/shutdown is allowed. - **param7** : WIP: ID (e.g. camera ID -1 for all IDs)

### MAV_CMD_OVERRIDE_GOTO (MAV_CMD value 252)
Override current mission with command to pause mission, pause mission and move to position, continue/resume mission. When param 1 indicates that the mission is paused (MAV_GOTO_DO_HOLD), param 2 defines whether it holds in place or moves to another position. ### Parameters

- **param1** Continue: MAV_GOTO_DO_HOLD: pause mission and either hold or move to specified position (depending on param2), MAV_GOTO_DO_CONTINUE: resume mission. - **param2** Position: MAV_GOTO_HOLD_AT_CURRENT_POSITION: hold at current position, MAV_GOTO_HOLD_AT_SPECIFIED_POSITION: hold at specified position. - **param3** Frame: Coordinate frame of hold point. - **param4** Yaw: Desired yaw angle. - **param5** Latitude/X: Latitude/X position. - **param6** Longitude/Y: Longitude/Y position. - **param7** Altitude/Z: Altitude/Z position.

--- chunk_id: chunk-0266
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 266
content_hash: b54e1cd640e60761
prev_chunk_id: chunk-0265
next_chunk_id: chunk-0267
section_heading: MAV_CMD_OBLIQUE_SURVEY (MAV_CMD value 260)
document_type: technical_reference

## MAV_CMD_OBLIQUE_SURVEY (MAV_CMD value 260)

Mission command to set a Camera Auto Mount Pivoting Oblique Survey (Replaces CAM_TRIGG_DIST for this purpose). The camera is triggered each time this distance is exceeded, then the mount moves to the next position. Params 4~6 set-up the angle limits and number of positions for oblique survey, where mount-enabled vehicles automatically roll the camera between shots to emulate an oblique camera setup (providing an increased HFOV). This command can also be used to set the shutter integration time for the camera. ### Parameters

- **param1** Distance: Camera trigger distance. 0 to stop triggering. - **param2** Shutter: Camera shutter integration time. 0 to ignore
- **param3** Min Interval: The minimum interval in which the camera is capable of taking subsequent pictures repeatedly. 0 to ignore. - **param4** Positions: Total number of roll positions at which the camera will capture photos (images captures spread evenly across the limits defined by param5). - **param5** Roll Angle: Angle limits that the camera can be rolled to left and right of center. - **param6** Pitch Angle: Fixed pitch angle that the camera will hold in oblique mode if the mount is actuated in the pitch axis. - **param7** : Empty

--- chunk_id: chunk-0267
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 320
content_hash: 4abb871660f6fc00
prev_chunk_id: chunk-0266
next_chunk_id: chunk-0268
section_heading: MAV_CMD_DO_SET_STANDARD_MODE (MAV_CMD value 262)
document_type: technical_reference

## MAV_CMD_DO_SET_STANDARD_MODE (MAV_CMD value 262)

Enable the specified standard MAVLink mode. If the specified mode is not supported, the vehicle should ACK with MAV_RESULT_FAILED. See https://mavlink.io/en/services/standard_modes.html

### Parameters

- **param1** Standard Mode: The mode to set. - **param2**
- **param3**
- **param4**
- **param5**
- **param6**
- **param7**

### MAV_CMD_MISSION_START (MAV_CMD value 300)
start running a mission

### Parameters

- **param1** First Item: first_item: the first mission item to run
- **param2** Last Item: last_item:  the last mission item to run (after this item is run, the mission ends)

### MAV_CMD_ACTUATOR_TEST (MAV_CMD value 310)
Actuator testing command. This is similar to MAV_CMD_DO_MOTOR_TEST but operates on the level of output functions, i.e. it is possible to test Motor1 independent from which output it is configured on. Autopilots must NACK this command with MAV_RESULT_TEMPORARILY_REJECTED while armed. ### Parameters

- **param1** Value: Output value: 1 means maximum positive output, 0 to center servos or minimum motor thrust (expected to spin), -1 for maximum negative (if not supported by the motors, i.e. motor is not reversible, smaller than 0 maps to NaN). And NaN maps to disarmed (stop the motors). - **param2** Timeout: Timeout after which the test command expires and the output is restored to the previous value. A timeout has to be set for safety reasons. A timeout of 0 means to restore the previous value immediately. - **param3**
- **param4**
- **param5** Output Function: Actuator Output function
- **param6**
- **param7**

--- chunk_id: chunk-0268
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 229
content_hash: 4fdbcc4f1dfce1dd
prev_chunk_id: chunk-0267
next_chunk_id: chunk-0269
section_heading: MAV_CMD_CONFIGURE_ACTUATOR (MAV_CMD value 311)
document_type: technical_reference

## MAV_CMD_CONFIGURE_ACTUATOR (MAV_CMD value 311)

Actuator configuration command. ### Parameters

- **param1** Configuration: Actuator configuration action
- **param2**
- **param3**
- **param4**
- **param5** Output Function: Actuator Output function
- **param6**
- **param7**

### MAV_CMD_COMPONENT_ARM_DISARM (MAV_CMD value 400)
Arms / Disarms a component

### Parameters

- **param1** Arm: Arm (MAV_BOOL_FALSE: disarm). Values not equal to 0 or 1 are invalid. - **param2** Force: 0: arm-disarm unless prevented by safety checks (i.e. when landed), 21196: force arming/disarming (e.g. allow arming to override preflight checks and disarming in flight)

### MAV_CMD_RUN_PREARM_CHECKS (MAV_CMD value 401)
Instructs a target system to run pre-arm checks. This allows preflight checks to be run on demand, which may be useful on systems that normally run them at low rate, or which do not trigger checks when the armable state might have changed. This command should return MAV_RESULT_ACCEPTED if it will run the checks. The results of the checks are usually then reported in SYS_STATUS messages (this is system-specific). The command should return MAV_RESULT_TEMPORARILY_REJECTED if the system is already armed.

--- chunk_id: chunk-0269
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: aeb62efd3a2b0779
prev_chunk_id: chunk-0268
next_chunk_id: chunk-0270
section_heading: MAV_CMD_ILLUMINATOR_ON_OFF (MAV_CMD value 405)
document_type: technical_reference

## MAV_CMD_ILLUMINATOR_ON_OFF (MAV_CMD value 405)

Turns illuminators ON/OFF. An illuminator is a light source that is used for lighting up dark areas external to the system: e.g. a torch or searchlight (as opposed to a light source for illuminating the system itself, e.g. an indicator light). ### Parameters

- **param1** Enable: Illuminators on/off (MAV_BOOL_TRUE: illuminators on). Values not equal to 0 or 1 are invalid. ### MAV_CMD_DO_ILLUMINATOR_CONFIGURE (MAV_CMD value 406)
Configures illuminator settings. An illuminator is a light source that is used for lighting up dark areas external to the system: e.g. a torch or searchlight (as opposed to a light source for illuminating the system itself, e.g. an indicator light). ### Parameters

- **param1** Mode: Mode
- **param2** Brightness: 0%: Off, 100%: Max Brightness
- **param3** Strobe Period: Strobe period in seconds where 0 means strobing is not used
- **param4** Strobe Duty: Strobe duty cycle where 100% means it is on constantly and 0 means strobing is not used

--- chunk_id: chunk-0270
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: e86d35d46cdd22b0
prev_chunk_id: chunk-0269
next_chunk_id: chunk-0271
section_heading: MAV_CMD_GET_HOME_POSITION (MAV_CMD value 410)
document_type: technical_reference

## MAV_CMD_GET_HOME_POSITION (MAV_CMD value 410)

Request the home position from the vehicle. The vehicle will ACK the command and emit the HOME_POSITION message. ### Parameters

- **param1** : Reserved
- **param2** : Reserved
- **param3** : Reserved
- **param4** : Reserved
- **param5** : Reserved
- **param6** : Reserved
- **param7** : Reserved

### MAV_CMD_INJECT_FAILURE (MAV_CMD value 420)
Inject artificial failure for testing purposes. Note that autopilots should implement an additional protection before accepting this command such as a specific param setting. ### Parameters

- **param1** Failure unit: The unit which is affected by the failure. - **param2** Failure type: The type how the failure manifests itself. - **param3** Instance: Instance affected by failure (0 to signal all). Takes precedence over Instance bitmask (param4) when not NaN. Set to NaN to use Instance bitmask instead. - **param4** Instance bitmask: Bitmask of instances affected by the failure (bit 0 = first instance, bit 1 = second instance, etc.). Used only when Instance (param3) is NaN.

--- chunk_id: chunk-0271
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: cac2106ca64d37f3
prev_chunk_id: chunk-0270
next_chunk_id: chunk-0272
section_heading: MAV_CMD_START_RX_PAIR (MAV_CMD value 500)
document_type: technical_reference

## MAV_CMD_START_RX_PAIR (MAV_CMD value 500)

Starts receiver pairing. ### Parameters

- **param1** RC Type: RC type. - **param2** RC Sub Type: RC sub type. ### MAV_CMD_GET_MESSAGE_INTERVAL (MAV_CMD value 510)
Request the interval between messages for a particular MAVLink message ID. The receiver should ACK the command and then emit its response in a MESSAGE_INTERVAL message. ### Parameters

- **param1** Message ID: The MAVLink message ID

### MAV_CMD_SET_MESSAGE_INTERVAL (MAV_CMD value 511)
Set the interval between messages for a particular MAVLink message ID. This interface replaces REQUEST_DATA_STREAM. ### Parameters

- **param1** Message ID: The MAVLink message ID
- **param2** Interval: The interval between two messages. -1: disable. 0: request default rate (which may be zero). - **param3** Req Param 3: Use for index ID, if required. Otherwise, the use of this parameter (if any) must be defined in the requested message. By default assumed not used (0). When used as an index ID, 0 means "all instances", "1" means the first instance in the sequence (the emitted message will have an id of 0 if message ids are 0-indexed, or 1 if index numbers start from one). - **param4** Req Param 4: The use of this parameter (if any), must be defined in the requested message. By default assumed not used (0). - **param5** Req Param 5: The use of this parameter (if any), must be defined in the requested message. By default assumed not used (0/NaN). - **param6** Req Param 6: The use of this parameter (if any), must be defined in the requested message. By default assumed not used (0/NaN). - **param7** Response Target: Target address of message stream (if message has target address fields). 0: Flight-stack default (recommended), 1: address of requester, 2: broadcast.

--- chunk_id: chunk-0272
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 257
content_hash: b093f07d193d7a25
prev_chunk_id: chunk-0271
next_chunk_id: chunk-0273
section_heading: MAV_CMD_REQUEST_MESSAGE (MAV_CMD value 512)
document_type: technical_reference

## MAV_CMD_REQUEST_MESSAGE (MAV_CMD value 512)

Request the target system(s) emit a single instance of a specified message (i.e. a "one-shot" version of MAV_CMD_SET_MESSAGE_INTERVAL). ### Parameters

- **param1** Message ID: The MAVLink message ID of the requested message. - **param2** Req Param 1: Use for index ID, if required. Otherwise, the use of this parameter (if any) must be defined in the requested message. By default assumed not used (0). - **param3** Req Param 2: The use of this parameter (if any), must be defined in the requested message. By default assumed not used (0). - **param4** Req Param 3: The use of this parameter (if any), must be defined in the requested message. By default assumed not used (0). - **param5** Req Param 4: The use of this parameter (if any), must be defined in the requested message. By default assumed not used (0). - **param6** Req Param 5: The use of this parameter (if any), must be defined in the requested message. By default assumed not used (0). - **param7** Response Target: Target address for requested message (if message has target address fields). 0: Flight-stack default, 1: address of requester, 2: broadcast.

--- chunk_id: chunk-0273
source_document: mav_cmd_batch_04.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 230
content_hash: f7f6e5675cb96a6c
prev_chunk_id: chunk-0272
next_chunk_id: chunk-0274
section_heading: MAV_CMD_REQUEST_PROTOCOL_VERSION (MAV_CMD value 519)
document_type: technical_reference

## MAV_CMD_REQUEST_PROTOCOL_VERSION (MAV_CMD value 519)

Request MAVLink protocol version compatibility. All receivers should ACK the command and then emit their capabilities in an PROTOCOL_VERSION message

### Parameters

- **param1** Protocol: Request supported protocol versions by all nodes on the network (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param2** : Reserved (all remaining params)

### MAV_CMD_REQUEST_AUTOPILOT_CAPABILITIES (MAV_CMD value 520)
Request autopilot capabilities. The receiver should ACK the command and then emit its capabilities in an AUTOPILOT_VERSION message

### Parameters

- **param1** Version: Request autopilot version (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param2** : Reserved (all remaining params)

### MAV_CMD_REQUEST_CAMERA_INFORMATION (MAV_CMD value 521)
Request camera information (CAMERA_INFORMATION). ### Parameters

- **param1** Capabilities: Request camera capabilities (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param2** : Reserved (all remaining params)

### MAV_CMD_REQUEST_CAMERA_SETTINGS (MAV_CMD value 522)
Request camera settings (CAMERA_SETTINGS). ### Parameters

- **param1** Settings: Request camera settings (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param2** : Reserved (all remaining params)

--- chunk_id: chunk-0274
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: b1010121d0159225
prev_chunk_id: chunk-0273
next_chunk_id: chunk-0275
section_heading: MAV_CMD commands batch 5
document_type: technical_reference

# MAV_CMD commands batch 5

Structured extract from common.xml MAV_CMD enum.

--- chunk_id: chunk-0275
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 206
content_hash: dba540ff15d42bcd
prev_chunk_id: chunk-0274
next_chunk_id: chunk-0276
section_heading: MAV_CMD_REQUEST_STORAGE_INFORMATION (MAV_CMD value 525)
document_type: technical_reference

## MAV_CMD_REQUEST_STORAGE_INFORMATION (MAV_CMD value 525)

Request storage information (STORAGE_INFORMATION). Use the command's target_component to target a specific component's storage. ### Parameters

- **param1** Storage ID: Storage ID (0 for all, 1 for first, 2 for second, etc.)
- **param2** Information: Request storage information (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param3** : Reserved (all remaining params)

### MAV_CMD_STORAGE_FORMAT (MAV_CMD value 526)
Format a storage medium. Once format is complete, a STORAGE_INFORMATION message is sent. Use the command's target_component to target a specific component's storage. ### Parameters

- **param1** Storage ID: Storage ID (1 for first, 2 for second, etc.)
- **param2** Format: Format storage (and reset image log). Values not equal to 0 or 1 are invalid. - **param3** Reset Image Log: Reset Image Log (without formatting storage medium). This will reset CAMERA_CAPTURE_STATUS.image_count and CAMERA_IMAGE_CAPTURED.image_index. Values not equal to 0 or 1 are invalid. - **param4** : Reserved (all remaining params)

--- chunk_id: chunk-0276
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 213
content_hash: 8e64b74a3eb4de95
prev_chunk_id: chunk-0275
next_chunk_id: chunk-0277
section_heading: MAV_CMD_REQUEST_CAMERA_CAPTURE_STATUS (MAV_CMD value 527)
document_type: technical_reference

## MAV_CMD_REQUEST_CAMERA_CAPTURE_STATUS (MAV_CMD value 527)

Request camera capture status (CAMERA_CAPTURE_STATUS)

### Parameters

- **param1** Capture Status: Request camera capture status (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param2** : Reserved (all remaining params)

### MAV_CMD_REQUEST_FLIGHT_INFORMATION (MAV_CMD value 528)
Request flight information (FLIGHT_INFORMATION)

### Parameters

- **param1** Flight Information: Request flight information (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param2** : Reserved (all remaining params)

### MAV_CMD_RESET_CAMERA_SETTINGS (MAV_CMD value 529)
Reset all camera settings to Factory Default

### Parameters

- **param1** Reset: Reset all settings (MAV_BOOL_TRUE). Values not equal to 0 or 1 are invalid. - **param2** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission.

--- chunk_id: chunk-0277
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 268
content_hash: 26eb35fd50dcc2c2
prev_chunk_id: chunk-0276
next_chunk_id: chunk-0278
section_heading: MAV_CMD_SET_CAMERA_MODE (MAV_CMD value 530)
document_type: technical_reference

## MAV_CMD_SET_CAMERA_MODE (MAV_CMD value 530)

Set camera running mode. Use NaN for reserved values. GCS will send a MAV_CMD_REQUEST_VIDEO_STREAM_STATUS command after a mode change if the camera supports video streaming. ### Parameters

- **param1** id: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param2** Camera Mode: Camera mode
- **param3**
- **param4**
- **param7**

### MAV_CMD_SET_CAMERA_ZOOM (MAV_CMD value 531)
Set camera zoom. Camera must respond with a CAMERA_SETTINGS message (on success). ### Parameters

- **param1** Zoom Type: Zoom type
- **param2** Zoom Value: Zoom value. The range of valid values depend on the zoom type. - **param3** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param4**

--- chunk_id: chunk-0278
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 309
content_hash: 6b6f27f8d8f08780
prev_chunk_id: chunk-0277
next_chunk_id: chunk-0279
section_heading: MAV_CMD_SET_CAMERA_FOCUS (MAV_CMD value 532)
document_type: technical_reference

## MAV_CMD_SET_CAMERA_FOCUS (MAV_CMD value 532)

Set camera focus. Camera must respond with a CAMERA_SETTINGS message (on success). ### Parameters

- **param1** Focus Type: Focus type
- **param2** Focus Value: Focus value
- **param3** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param4**

### MAV_CMD_SET_STORAGE_USAGE (MAV_CMD value 533)
Set that a particular storage is the preferred location for saving photos, videos, and/or other media (e.g. to set that an SD card is used for storing videos). There can only be one preferred save location for each particular media type: setting a media usage flag will clear/reset that same flag if set on any other storage. If no flag is set the system should use its default storage. A target system can choose to always use default storage, in which case it should ACK the command with MAV_RESULT_UNSUPPORTED. A target system can choose to not allow a particular storage to be set as preferred storage, in which case it should ACK the command with MAV_RESULT_DENIED. ### Parameters

- **param1** Storage ID: Storage ID (1 for first, 2 for second, etc.)
- **param2** Usage: Usage flags

--- chunk_id: chunk-0279
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 224
content_hash: a83be985576746b7
prev_chunk_id: chunk-0278
next_chunk_id: chunk-0280
section_heading: MAV_CMD_SET_CAMERA_SOURCE (MAV_CMD value 534)
document_type: technical_reference

## MAV_CMD_SET_CAMERA_SOURCE (MAV_CMD value 534)

Set camera source. Changes the camera's active sources on cameras with multiple image sensors. ### Parameters

- **param1** device id: Component Id of camera to address or 1-6 for non-MAVLink cameras, 0 for all cameras. - **param2** primary source: Primary Source
- **param3** secondary source: Secondary Source. If non-zero the second source will be displayed as picture-in-picture. ### MAV_CMD_JUMP_TAG (MAV_CMD value 600)
Tagged jump target. Can be jumped to with MAV_CMD_DO_JUMP_TAG. ### Parameters

- **param1** Tag: Tag. ### MAV_CMD_DO_JUMP_TAG (MAV_CMD value 601)
Jump to the matching tag in the mission list. Repeat this action for the specified number of times. A mission should contain a single matching tag for each jump. If this is not the case then a jump to a missing tag should complete the mission, and a jump where there are multiple matching tags should always select the one with the lowest mission sequence number. ### Parameters

- **param1** Tag: Target tag to jump to. - **param2** Repeat: Repeat count.

--- chunk_id: chunk-0280
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 416
content_hash: bb31cf9d2e9b777e
prev_chunk_id: chunk-0279
next_chunk_id: chunk-0281
section_heading: MAV_CMD_DO_SET_GLOBAL_ORIGIN (MAV_CMD value 611)
document_type: technical_reference

## MAV_CMD_DO_SET_GLOBAL_ORIGIN (MAV_CMD value 611)

Sets the GNSS coordinates of the vehicle local origin (0,0,0) position. Vehicle should emit GPS_GLOBAL_ORIGIN irrespective of whether the origin is changed. This enables transform between the local coordinate frame and the global (GNSS) coordinate frame, which may be necessary when (for example) indoor and outdoor settings are connected and the MAV should move from in- to outdoor. This command supersedes SET_GPS_GLOBAL_ORIGIN. Should be sent in a COMMAND_INT (Expected frame is MAV_FRAME_GLOBAL, and this should be assumed when sent in COMMAND_LONG). ### Parameters

- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

### MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW (MAV_CMD value 1000)
Set gimbal manager pitch/yaw setpoints (low rate command). It is possible to set combinations of the values below. E.g. an angle as well as a desired angular rate can be used to get to this angle at a certain angular rate, or an angular rate only will result in continuous turning. NaN is to be used to signal unset. Note: only the gimbal manager will react to this command - it will be ignored by a gimbal device. Use GIMBAL_MANAGER_SET_PITCHYAW if you need to stream pitch/yaw setpoints at higher rate. ### Parameters

- **param1** Pitch angle: Pitch angle (positive to pitch up, relative to vehicle for FOLLOW mode, relative to world horizon for LOCK mode). - **param2** Yaw angle: Yaw angle (positive to yaw to the right, relative to vehicle for FOLLOW mode, absolute to North for LOCK mode). - **param3** Pitch rate: Pitch rate (positive to pitch up). - **param4** Yaw rate: Yaw rate (positive to yaw to the right). - **param5** Gimbal manager flags: Gimbal manager flags to use. - **param7** Gimbal device ID: Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals).

--- chunk_id: chunk-0281
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 276
content_hash: 0e82b48ea788fb46
prev_chunk_id: chunk-0280
next_chunk_id: chunk-0282
section_heading: MAV_CMD_DO_GIMBAL_MANAGER_CONFIGURE (MAV_CMD value 1001)
document_type: technical_reference

## MAV_CMD_DO_GIMBAL_MANAGER_CONFIGURE (MAV_CMD value 1001)

Gimbal configuration to set which sysid/compid is in primary and secondary control. ### Parameters

- **param1** sysid primary control: Sysid for primary control (0: no one in control, -1: leave unchanged, -2: set itself in control (for missions where the own sysid is still unknown), -3: remove control if currently in control). - **param2** compid primary control: Compid for primary control (0: no one in control, -1: leave unchanged, -2: set itself in control (for missions where the own sysid is still unknown), -3: remove control if currently in control). - **param3** sysid secondary control: Sysid for secondary control (0: no one in control, -1: leave unchanged, -2: set itself in control (for missions where the own sysid is still unknown), -3: remove control if currently in control). - **param4** compid secondary control: Compid for secondary control (0: no one in control, -1: leave unchanged, -2: set itself in control (for missions where the own sysid is still unknown), -3: remove control if currently in control). - **param7** Gimbal device ID: Component ID of gimbal device to address (or 1-6 for non-MAVLink gimbal), 0 for all gimbal device components. Send command multiple times for more than one gimbal (but not all gimbals).

--- chunk_id: chunk-0282
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: f299ef9386587a40
prev_chunk_id: chunk-0281
next_chunk_id: chunk-0283
section_heading: MAV_CMD_IMAGE_START_CAPTURE (MAV_CMD value 2000)
document_type: technical_reference

## MAV_CMD_IMAGE_START_CAPTURE (MAV_CMD value 2000)

Start image capture sequence. CAMERA_IMAGE_CAPTURED must be emitted after each capture. Param1 (id) may be used to specify the target camera: 0: all cameras, 1 to 6: autopilot-connected cameras, 7-255: MAVLink camera component ID. It is needed in order to target specific cameras connected to the autopilot, or specific sensors in a multi-sensor camera (neither of which have a distinct MAVLink component ID). It is also needed to specify the target camera in missions. When used in a mission, an autopilot should execute the MAV_CMD for a specified local camera (param1 = 1-6), or resend it as a command if it is intended for a MAVLink camera (param1 = 7 - 255), setting the command's target_component as the param1 value (and setting param1 in the command to zero). If the param1 is 0 the autopilot should do both. When sent in a command the target MAVLink address is set using target_component. If addressed specifically to an autopilot: param1 should be used in the same way as it is for missions (though command should NACK with MAV_RESULT_DENIED if a specified local camera does not exist). If addressed to a MAVLink camera, param 1 can be used to address all cameras (0), or to separately address 1 to 7 individual sensors. Other values should be NACKed with MAV_RESULT_DENIED. If the command is broadcast (target_component is 0) then param 1 should be set to 0 (any other value should be NACKED with MAV_RESULT_DENIED). An autopilot would trigger any local cameras and forward the command to all channels. ### Parameters

- **param1** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param2** Interval: Desired elapsed time between two consecutive pictures (in seconds). Minimum values depend on hardware (typically greater than 2 seconds). - **param3** Total Images: Total number of images to capture. 0 to capture forever/until MAV_CMD_IMAGE_STOP_CAPTURE. - **param4** Sequence Number: Capture sequence number starting from 1. This is only valid for single-capture (param3 == 1), otherwise set to 0.

--- chunk_id: chunk-0283
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 61
content_hash: 683964cf6087773f
prev_chunk_id: chunk-0282
next_chunk_id: chunk-0284
section_heading: MAV_CMD_IMAGE_START_CAPTURE (MAV_CMD value 2000)
document_type: technical_reference

- **param4** Sequence Number: Capture sequence number starting from 1. This is only valid for single-capture (param3 == 1), otherwise set to 0. Increment the capture ID for each capture command to prevent double captures when a command is re-transmitted. - **param5**
- **param6**
- **param7**

--- chunk_id: chunk-0284
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: feaa78600e5000ae
prev_chunk_id: chunk-0283
next_chunk_id: chunk-0285
section_heading: MAV_CMD_IMAGE_STOP_CAPTURE (MAV_CMD value 2001)
document_type: technical_reference

## MAV_CMD_IMAGE_STOP_CAPTURE (MAV_CMD value 2001)

Stop image capture sequence. Param1 (id) may be used to specify the target camera: 0: all cameras, 1 to 6: autopilot-connected cameras, 7-255: MAVLink camera component ID. It is needed in order to target specific cameras connected to the autopilot, or specific sensors in a multi-sensor camera (neither of which have a distinct MAVLink component ID). It is also needed to specify the target camera in missions. When used in a mission, an autopilot should execute the MAV_CMD for a specified local camera (param1 = 1-6), or resend it as a command if it is intended for a MAVLink camera (param1 = 7 - 255), setting the command's target_component as the param1 value (and setting param1 in the command to zero). If the param1 is 0 the autopilot should do both. When sent in a command the target MAVLink address is set using target_component. If addressed specifically to an autopilot: param1 should be used in the same way as it is for missions (though command should NACK with MAV_RESULT_DENIED if a specified local camera does not exist). If addressed to a MAVLink camera, param1 can be used to address all cameras (0), or to separately address 1 to 7 individual sensors. Other values should be NACKed with MAV_RESULT_DENIED. If the command is broadcast (target_component is 0) then param 1 should be set to 0 (any other value should be NACKED with MAV_RESULT_DENIED). An autopilot would trigger any local cameras and forward the command to all channels. ### Parameters

- **param1** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param2**
- **param3**
- **param4**
- **param5**
- **param6**
- **param7**

--- chunk_id: chunk-0285
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 201
content_hash: 26d8b5373f603345
prev_chunk_id: chunk-0284
next_chunk_id: chunk-0286
section_heading: MAV_CMD_REQUEST_CAMERA_IMAGE_CAPTURE (MAV_CMD value 2002)
document_type: technical_reference

## MAV_CMD_REQUEST_CAMERA_IMAGE_CAPTURE (MAV_CMD value 2002)

Re-request a CAMERA_IMAGE_CAPTURED message. ### Parameters

- **param1** Number: Sequence number for missing CAMERA_IMAGE_CAPTURED message
- **param2**
- **param3**
- **param4**
- **param5**
- **param6**
- **param7**

### MAV_CMD_DO_TRIGGER_CONTROL (MAV_CMD value 2003)
Enable or disable on-board camera triggering system. ### Parameters

- **param1** Enable: Trigger enable/disable (0 for disable, 1 for start), -1 to ignore
- **param2** Reset: 1 to reset the trigger sequence, -1 or 0 to ignore
- **param3** Pause: 1 to pause triggering, but without switching the camera off or retracting it. -1 to ignore
- **param4** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission.

--- chunk_id: chunk-0286
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: 9139f2451b6fe8bf
prev_chunk_id: chunk-0285
next_chunk_id: chunk-0287
section_heading: MAV_CMD_CAMERA_TRACK_POINT (MAV_CMD value 2004)
document_type: technical_reference

## MAV_CMD_CAMERA_TRACK_POINT (MAV_CMD value 2004)

If the camera supports point visual tracking (CAMERA_CAP_FLAGS_HAS_TRACKING_POINT is set), this command allows to initiate the tracking. ### Parameters

- **param1** Point x: Point to track x value (normalized 0..1, 0 is left, 1 is right). - **param2** Point y: Point to track y value (normalized 0..1, 0 is top, 1 is bottom). - **param3** Radius: Point radius (normalized 0..1, 0 is one pixel, 1 is full image width). - **param4** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission.

--- chunk_id: chunk-0287
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: 77ee5ce8bebc7843
prev_chunk_id: chunk-0286
next_chunk_id: chunk-0288
section_heading: MAV_CMD_CAMERA_TRACK_RECTANGLE (MAV_CMD value 2005)
document_type: technical_reference

## MAV_CMD_CAMERA_TRACK_RECTANGLE (MAV_CMD value 2005)

If the camera supports rectangle visual tracking (CAMERA_CAP_FLAGS_HAS_TRACKING_RECTANGLE is set), this command allows to initiate the tracking. ### Parameters

- **param1** Top left corner x: Top left corner of rectangle x value (normalized 0..1, 0 is left, 1 is right). - **param2** Top left corner y: Top left corner of rectangle y value (normalized 0..1, 0 is top, 1 is bottom). - **param3** Bottom right corner x: Bottom right corner of rectangle x value (normalized 0..1, 0 is left, 1 is right). - **param4** Bottom right corner y: Bottom right corner of rectangle y value (normalized 0..1, 0 is top, 1 is bottom). - **param5** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission.

--- chunk_id: chunk-0288
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 232
content_hash: 8f70fc058de00a8e
prev_chunk_id: chunk-0287
next_chunk_id: chunk-0289
section_heading: MAV_CMD_CAMERA_STOP_TRACKING (MAV_CMD value 2010)
document_type: technical_reference

## MAV_CMD_CAMERA_STOP_TRACKING (MAV_CMD value 2010)

Stops ongoing tracking. ### Parameters

- **param1** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. ### MAV_CMD_VIDEO_START_CAPTURE (MAV_CMD value 2500)
Starts video capture (recording). ### Parameters

- **param1** Stream ID: Video Stream ID (0 for all streams)
- **param2** Status Frequency: Frequency CAMERA_CAPTURE_STATUS messages should be sent while recording (0 for no messages, otherwise frequency)
- **param3** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param4**
- **param5**
- **param6**
- **param7**

--- chunk_id: chunk-0289
source_document: mav_cmd_batch_05.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 237
content_hash: d2ad20cbecc4ec51
prev_chunk_id: chunk-0288
next_chunk_id: chunk-0290
section_heading: MAV_CMD_VIDEO_STOP_CAPTURE (MAV_CMD value 2501)
document_type: technical_reference

## MAV_CMD_VIDEO_STOP_CAPTURE (MAV_CMD value 2501)

Stop the current video capture (recording). ### Parameters

- **param1** Stream ID: Video Stream ID (0 for all streams)
- **param2** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. - **param3**
- **param4**
- **param5**
- **param6**
- **param7**

### MAV_CMD_VIDEO_START_STREAMING (MAV_CMD value 2502)
Start video streaming

### Parameters

- **param1** Stream ID: Video Stream ID (0 for all streams, 1 for first, 2 for second, etc.)
- **param2** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission.

--- chunk_id: chunk-0290
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: 72cdee9d098202ac
prev_chunk_id: chunk-0289
next_chunk_id: chunk-0291
section_heading: MAV_CMD commands batch 6
document_type: technical_reference

# MAV_CMD commands batch 6

Structured extract from common.xml MAV_CMD enum.

--- chunk_id: chunk-0291
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 197
content_hash: 967c5541e728f2ed
prev_chunk_id: chunk-0290
next_chunk_id: chunk-0292
section_heading: MAV_CMD_VIDEO_STOP_STREAMING (MAV_CMD value 2503)
document_type: technical_reference

## MAV_CMD_VIDEO_STOP_STREAMING (MAV_CMD value 2503)

Stop the given video stream

### Parameters

- **param1** Stream ID: Video Stream ID (0 for all streams, 1 for first, 2 for second, etc.)
- **param2** Target Camera ID: Target camera ID. 7 to 255: MAVLink camera component id. 1 to 6 for cameras attached to the autopilot, which don't have a distinct component id. 0: all cameras. This is used to target specific autopilot-connected cameras. It is also used to target specific cameras when the MAV_CMD is used in a mission. ### MAV_CMD_REQUEST_VIDEO_STREAM_INFORMATION (MAV_CMD value 2504)
Request video stream information (VIDEO_STREAM_INFORMATION)

### Parameters

- **param1** Stream ID: Video Stream ID (0 for all streams, 1 for first, 2 for second, etc.)

### MAV_CMD_REQUEST_VIDEO_STREAM_STATUS (MAV_CMD value 2505)
Request video stream status (VIDEO_STREAM_STATUS)

### Parameters

- **param1** Stream ID: Video Stream ID (0 for all streams, 1 for first, 2 for second, etc.)

--- chunk_id: chunk-0292
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 238
content_hash: 2b52c72fa6cf46f6
prev_chunk_id: chunk-0291
next_chunk_id: chunk-0293
section_heading: MAV_CMD_LOGGING_START (MAV_CMD value 2510)
document_type: technical_reference

## MAV_CMD_LOGGING_START (MAV_CMD value 2510)

Request to start streaming logging data over MAVLink (see also LOGGING_DATA message)

### Parameters

- **param1** Format: Format: 0: ULog
- **param2** : Reserved (set to 0)
- **param3** : Reserved (set to 0)
- **param4** : Reserved (set to 0)
- **param5** : Reserved (set to 0)
- **param6** : Reserved (set to 0)
- **param7** : Reserved (set to 0)

### MAV_CMD_LOGGING_STOP (MAV_CMD value 2511)
Request to stop streaming log data over MAVLink

### Parameters

- **param1** : Reserved (set to 0)
- **param2** : Reserved (set to 0)
- **param3** : Reserved (set to 0)
- **param4** : Reserved (set to 0)
- **param5** : Reserved (set to 0)
- **param6** : Reserved (set to 0)
- **param7** : Reserved (set to 0)

### MAV_CMD_AIRFRAME_CONFIGURATION (MAV_CMD value 2520)
Mission/command MAV_CMD_AIRFRAME_CONFIGURATION. ### Parameters

- **param1** Landing Gear ID: Landing gear ID (default: 0, -1 for all)
- **param2** Landing Gear Position: Landing gear position (Down: 0, Up: 1, NaN for no change)
- **param3**
- **param4**
- **param5**
- **param6**
- **param7**

--- chunk_id: chunk-0293
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 242
content_hash: 111dcf751c7c8bae
prev_chunk_id: chunk-0292
next_chunk_id: chunk-0294
section_heading: MAV_CMD_CONTROL_HIGH_LATENCY (MAV_CMD value 2600)
document_type: technical_reference

## MAV_CMD_CONTROL_HIGH_LATENCY (MAV_CMD value 2600)

Request to start/stop transmitting over the high latency telemetry

### Parameters

- **param1** Enable: Start transmission over high latency telemetry (MAV_BOOL_FALSE: stop transmission). Values not equal to 0 or 1 are invalid. - **param2** : Empty
- **param3** : Empty
- **param4** : Empty
- **param5** : Empty
- **param6** : Empty
- **param7** : Empty

### MAV_CMD_PANORAMA_CREATE (MAV_CMD value 2800)
Create a panorama at the current position

### Parameters

- **param1** Horizontal Angle: Viewing angle horizontal of the panorama (+- 0.5 the total angle)
- **param2** Vertical Angle: Viewing angle vertical of panorama. - **param3** Horizontal Speed: Speed of the horizontal rotation. - **param4** Vertical Speed: Speed of the vertical rotation. ### MAV_CMD_DO_VTOL_TRANSITION (MAV_CMD value 3000)
Request VTOL transition

### Parameters

- **param1** State: The target VTOL state. For normal transitions, only MAV_VTOL_STATE_MC and MAV_VTOL_STATE_FW can be used. - **param2** Immediate: Force immediate transition to the specified MAV_VTOL_STATE. 1: Force immediate, 0: normal transition. Can be used, for example, to trigger an emergency "Quadchute". Caution: Can be dangerous/damage vehicle, depending on autopilot implementation of this command.

--- chunk_id: chunk-0294
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: 5f477f0ce04270c9
prev_chunk_id: chunk-0293
next_chunk_id: chunk-0295
section_heading: MAV_CMD_ARM_AUTHORIZATION_REQUEST (MAV_CMD value 3001)
document_type: technical_reference

## MAV_CMD_ARM_AUTHORIZATION_REQUEST (MAV_CMD value 3001)

Request authorization to arm the vehicle to a external entity, the arm authorizer is responsible to request all data that is needs from the vehicle before authorize or deny the request. If approved the COMMAND_ACK message progress field should be set with period of time that this authorization is valid in seconds. If the authorization is denied COMMAND_ACK.result_param2 should be set with one of the reasons in MAV_ARM_AUTH_DENIED_REASON. ### Parameters

- **param1** System ID: Vehicle system id, this way ground station can request arm authorization on behalf of any vehicle

### MAV_CMD_SET_GUIDED_SUBMODE_STANDARD (MAV_CMD value 4000)
This command sets the submode to standard guided when vehicle is in guided mode. The vehicle holds position and altitude and the user can input the desired velocities along all three axes.

--- chunk_id: chunk-0295
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: afa347e3edc6b8cd
prev_chunk_id: chunk-0294
next_chunk_id: chunk-0296
section_heading: MAV_CMD_SET_GUIDED_SUBMODE_CIRCLE (MAV_CMD value 4001)
document_type: technical_reference

## MAV_CMD_SET_GUIDED_SUBMODE_CIRCLE (MAV_CMD value 4001)

This command sets submode circle when vehicle is in guided mode. Vehicle flies along a circle facing the center of the circle. The user can input the velocity along the circle and change the radius. If no input is given the vehicle will hold position. ### Parameters

- **param1** Radius: Radius of desired circle in CIRCLE_MODE
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Target latitude of center of circle in CIRCLE_MODE
- **param6** Longitude: Target longitude of center of circle in CIRCLE_MODE

### MAV_CMD_CONDITION_GATE (MAV_CMD value 4501)
Delay mission state machine until gate has been reached. ### Parameters

- **param1** Geometry: Geometry: 0: orthogonal to path between previous and next waypoint. - **param2** UseAltitude: Use altitude (MAV_BOOL_FALSE: ignore altitude). Values not equal to 0 or 1 are invalid. - **param3** : Empty
- **param4** : Empty
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

--- chunk_id: chunk-0296
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 252
content_hash: 159c32ae44f53c8e
prev_chunk_id: chunk-0295
next_chunk_id: chunk-0297
section_heading: MAV_CMD_NAV_FENCE_RETURN_POINT (MAV_CMD value 5000)
document_type: technical_reference

## MAV_CMD_NAV_FENCE_RETURN_POINT (MAV_CMD value 5000)

Fence return point (there can only be one such point in a geofence definition). If rally points are supported they should be used instead. ### Parameters

- **param1** : Reserved
- **param2** : Reserved
- **param3** : Reserved
- **param4** : Reserved
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

### MAV_CMD_NAV_FENCE_POLYGON_VERTEX_INCLUSION (MAV_CMD value 5001)
Fence vertex for an inclusion polygon (the polygon must not be self-intersecting). The vehicle must stay within this area. Minimum of 3 vertices required. The vertices for a polygon must be sent sequentially, each with param1 set to the total number of vertices in the polygon. ### Parameters

- **param1** Vertex Count: Polygon vertex count. This is the number of vertices in the current polygon (all vertices will have the same number). - **param2** Inclusion Group: Vehicle must be inside ALL inclusion zones in a single group, vehicle must be inside at least one group, must be the same for all points in each polygon
- **param3** : Reserved
- **param4** : Reserved
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** : Reserved

--- chunk_id: chunk-0297
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 220
content_hash: d68944befb17ee91
prev_chunk_id: chunk-0296
next_chunk_id: chunk-0298
section_heading: MAV_CMD_NAV_FENCE_POLYGON_VERTEX_EXCLUSION (MAV_CMD value 5002)
document_type: technical_reference

## MAV_CMD_NAV_FENCE_POLYGON_VERTEX_EXCLUSION (MAV_CMD value 5002)

Fence vertex for an exclusion polygon (the polygon must not be self-intersecting). The vehicle must stay outside this area. Minimum of 3 vertices required. The vertices for a polygon must be sent sequentially, each with param1 set to the total number of vertices in the polygon. ### Parameters

- **param1** Vertex Count: Polygon vertex count. This is the number of vertices in the current polygon (all vertices will have the same number). - **param2** : Reserved
- **param3** : Reserved
- **param4** : Reserved
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** : Reserved

### MAV_CMD_NAV_FENCE_CIRCLE_INCLUSION (MAV_CMD value 5003)
Circular fence area. The vehicle must stay inside this area. ### Parameters

- **param1** Radius: Radius. - **param2** Inclusion Group: Vehicle must be inside ALL inclusion zones in a single group, vehicle must be inside at least one group
- **param3** : Reserved
- **param4** : Reserved
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** : Reserved

--- chunk_id: chunk-0298
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 282
content_hash: c8a09d7019f9525a
prev_chunk_id: chunk-0297
next_chunk_id: chunk-0299
section_heading: MAV_CMD_NAV_FENCE_CIRCLE_EXCLUSION (MAV_CMD value 5004)
document_type: technical_reference

## MAV_CMD_NAV_FENCE_CIRCLE_EXCLUSION (MAV_CMD value 5004)

Circular fence area. The vehicle must stay outside this area. ### Parameters

- **param1** Radius: Radius. - **param2** : Reserved
- **param3** : Reserved
- **param4** : Reserved
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** : Reserved

### MAV_CMD_NAV_RALLY_POINT (MAV_CMD value 5100)
Rally point. You can have multiple rally points defined. ### Parameters

- **param1** : Reserved
- **param2** : Reserved
- **param3** : Reserved
- **param4** : Reserved
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude

### MAV_CMD_UAVCAN_GET_NODE_INFO (MAV_CMD value 5200)
Commands the vehicle to respond with a sequence of messages UAVCAN_NODE_INFO, one message per every UAVCAN node that is online. Note that some of the response messages can be lost, which the receiver can detect easily by checking whether every received UAVCAN_NODE_STATUS has a matching message UAVCAN_NODE_INFO received earlier; if not, this command should be sent again in order to request re-transmission of the node information messages. ### Parameters

- **param1** : Reserved (set to 0)
- **param2** : Reserved (set to 0)
- **param3** : Reserved (set to 0)
- **param4** : Reserved (set to 0)
- **param5** : Reserved (set to 0)
- **param6** : Reserved (set to 0)
- **param7** : Reserved (set to 0)

--- chunk_id: chunk-0299
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 73028a8596b176d7
prev_chunk_id: chunk-0298
next_chunk_id: chunk-0300
section_heading: MAV_CMD_DO_SET_SAFETY_SWITCH_STATE (MAV_CMD value 5300)
document_type: technical_reference

## MAV_CMD_DO_SET_SAFETY_SWITCH_STATE (MAV_CMD value 5300)

Change state of safety switch. ### Parameters

- **param1** Desired State: New safety switch state. - **param2** : Empty. - **param3** : Empty. - **param4** : Empty
- **param5** : Empty. - **param6** : Empty. - **param7** : Empty. ### MAV_CMD_DO_ADSB_OUT_IDENT (MAV_CMD value 10001)
Trigger the start of an ADSB-out IDENT. This should only be used when requested to do so by an Air Traffic Controller in controlled airspace. This starts the IDENT which is then typically held for 18 seconds by the hardware per the Mode A, C, and S transponder spec. ### Parameters

- **param1** : Reserved (set to 0)
- **param2** : Reserved (set to 0)
- **param3** : Reserved (set to 0)
- **param4** : Reserved (set to 0)
- **param5** : Reserved (set to 0)
- **param6** : Reserved (set to 0)
- **param7** : Reserved (set to 0)

### MAV_CMD_PAYLOAD_PREPARE_DEPLOY (MAV_CMD value 30001)
Deploy payload on a Lat / Lon / Alt position. This includes the navigation to reach the required release position and velocity. ### Parameters

- **param1** Operation Mode: Operation mode. 0: prepare single payload deploy (overwriting previous requests), but do not execute it. 1: execute payload deploy immediately (rejecting further deploy commands during execution, but allowing abort). 2: add payload deploy to existing deployment list. - **param2** Approach Vector: Desired approach vector in compass heading. A negative value indicates the system can define the approach vector at will. - **param3** Ground Speed: Desired ground speed at release time. This can be overridden by the airframe in case it needs to meet minimum airspeed. A negative value indicates the system can define the ground speed at will. - **param4** Altitude Clearance: Minimum altitude clearance to the release position. A negative value indicates the system can define the clearance at will. - **param5** Latitude: Latitude. - **param6** Longitude: Longitude. - **param7** Altitude: Altitude (MSL)

--- chunk_id: chunk-0300
source_document: mav_cmd_batch_06.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 197
content_hash: 2cd894e9901d084a
prev_chunk_id: chunk-0299
next_chunk_id: chunk-0301
section_heading: MAV_CMD_PAYLOAD_CONTROL_DEPLOY (MAV_CMD value 30002)
document_type: technical_reference

## MAV_CMD_PAYLOAD_CONTROL_DEPLOY (MAV_CMD value 30002)

Control the payload deployment. ### Parameters

- **param1** Operation Mode: Operation mode. 0: Abort deployment, continue normal mission. 1: switch to payload deployment mode. 100: delete first payload deployment request. 101: delete all payload deployment requests. - **param2** : Reserved
- **param3** : Reserved
- **param4** : Reserved
- **param5** : Reserved
- **param6** : Reserved
- **param7** : Reserved

### MAV_CMD_FIXED_MAG_CAL_YAW (MAV_CMD value 42006)
Magnetometer calibration based on provided known yaw. This allows for fast calibration using WMM field tables in the vehicle, given only the known yaw of the vehicle. If Latitude and longitude are both zero then use the current vehicle location. ### Parameters

- **param1** Yaw: Yaw of vehicle in earth frame. - **param2** CompassMask: CompassMask, 0 for all. - **param3** Latitude: Latitude. - **param4** Longitude: Longitude. - **param5** : Empty. - **param6** : Empty. - **param7** : Empty.

--- chunk_id: chunk-0301
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 14
content_hash: 8e16c834900eb820
prev_chunk_id: chunk-0300
next_chunk_id: chunk-0302
section_heading: MAV_CMD commands batch 7
document_type: technical_reference

# MAV_CMD commands batch 7

Structured extract from common.xml MAV_CMD enum.

--- chunk_id: chunk-0302
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 230
content_hash: 0c46e25c2796a86d
prev_chunk_id: chunk-0301
next_chunk_id: chunk-0303
section_heading: MAV_CMD_DO_WINCH (MAV_CMD value 42600)
document_type: technical_reference

## MAV_CMD_DO_WINCH (MAV_CMD value 42600)

Command to operate winch. ### Parameters

- **param1** Instance: Winch instance number. - **param2** Action: Action to perform. - **param3** Length: Length of line to release (negative to wind). - **param4** Rate: Release rate (negative to wind). - **param5** : Empty. - **param6** : Empty. - **param7** : Empty. ### MAV_CMD_GUIDED_CHANGE_SPEED (MAV_CMD value 43000)
Change flight speed at a given rate. This slews the vehicle at a controllable rate between it's previous speed and the new one. ### Parameters

- **param1** speed type: Airspeed or groundspeed. - **param2** speed target: Target Speed
- **param3** speed rate-of-change: Acceleration rate, 0 to take effect instantly

### MAV_CMD_GUIDED_CHANGE_ALTITUDE (MAV_CMD value 43001)
Change target altitude at a given rate. This slews the vehicle at a controllable rate between it's previous altitude and the new one. ### Parameters

- **param3** alt rate-of-change: Rate of change, toward new altitude. 0 for maximum rate change. Positive numbers only, as negative numbers will not converge on the new target alt. - **param7** target alt: Target Altitude

--- chunk_id: chunk-0303
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 376
content_hash: 5e0177c727f0f26f
prev_chunk_id: chunk-0302
next_chunk_id: chunk-0304
section_heading: MAV_CMD_GUIDED_CHANGE_HEADING (MAV_CMD value 43002)
document_type: technical_reference

## MAV_CMD_GUIDED_CHANGE_HEADING (MAV_CMD value 43002)

Change to target direction at a given rate, overriding previous heading/s. This slews the vehicle at a controllable rate between its previous heading and the new one. ### Parameters

- **param1** Heading Type: Course-over-ground or raw vehicle heading. - **param2** Heading Target: Target heading. - **param3** Heading Rate of Change: Maximum centripetal acceleration, i.e. rate of change toward new heading. ### MAV_CMD_EXTERNAL_POSITION_ESTIMATE (MAV_CMD value 43003)
Provide an external position estimate for use when dead-reckoning. This is meant to be used for occasional position resets that may be provided by a external system such as a remote pilot using landmarks over a video link. ### Parameters

- **param1** transmission_time: Timestamp that this message was sent as a time in the transmitters time domain. The sender should wrap this time back to zero based on required timing accuracy for the application and the limitations of a 32 bit float. For example, wrapping at 10 hours would give approximately 1ms accuracy. Recipient must handle time wrap in any timing jitter correction applied to this field. Wrap rollover time should not be at not more than 250 seconds, which would give approximately 10 microsecond accuracy. - **param2** processing_time: The time spent in processing the sensor data that is the basis for this position. The recipient can use this to improve time alignment of the data. Set to zero if not known. - **param3** accuracy: estimated one standard deviation accuracy of the measurement. Set to NaN if not known. - **param4** : Empty
- **param5** Latitude: Latitude
- **param6** Longitude: Longitude
- **param7** Altitude: Altitude, not used. Should be sent as NaN. May be supported in a future version of this message.

--- chunk_id: chunk-0304
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 228
content_hash: beb335718e647651
prev_chunk_id: chunk-0303
next_chunk_id: chunk-0305
section_heading: MAV_CMD_WAYPOINT_USER_1 (MAV_CMD value 31000)
document_type: technical_reference

## MAV_CMD_WAYPOINT_USER_1 (MAV_CMD value 31000)

User defined waypoint item. Ground Station will show the Vehicle as flying through this item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

### MAV_CMD_WAYPOINT_USER_2 (MAV_CMD value 31001)
User defined waypoint item. Ground Station will show the Vehicle as flying through this item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

### MAV_CMD_WAYPOINT_USER_3 (MAV_CMD value 31002)
User defined waypoint item. Ground Station will show the Vehicle as flying through this item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

--- chunk_id: chunk-0305
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 233
content_hash: 87858bba00113513
prev_chunk_id: chunk-0304
next_chunk_id: chunk-0306
section_heading: MAV_CMD_WAYPOINT_USER_4 (MAV_CMD value 31003)
document_type: technical_reference

## MAV_CMD_WAYPOINT_USER_4 (MAV_CMD value 31003)

User defined waypoint item. Ground Station will show the Vehicle as flying through this item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

### MAV_CMD_WAYPOINT_USER_5 (MAV_CMD value 31004)
User defined waypoint item. Ground Station will show the Vehicle as flying through this item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

### MAV_CMD_SPATIAL_USER_1 (MAV_CMD value 31005)
User defined spatial item. Ground Station will not show the Vehicle as flying through this item. Example: ROI item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

--- chunk_id: chunk-0306
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: 9bdb598254548e4a
prev_chunk_id: chunk-0305
next_chunk_id: chunk-0307
section_heading: MAV_CMD_SPATIAL_USER_2 (MAV_CMD value 31006)
document_type: technical_reference

## MAV_CMD_SPATIAL_USER_2 (MAV_CMD value 31006)

User defined spatial item. Ground Station will not show the Vehicle as flying through this item. Example: ROI item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

### MAV_CMD_SPATIAL_USER_3 (MAV_CMD value 31007)
User defined spatial item. Ground Station will not show the Vehicle as flying through this item. Example: ROI item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

### MAV_CMD_SPATIAL_USER_4 (MAV_CMD value 31008)
User defined spatial item. Ground Station will not show the Vehicle as flying through this item. Example: ROI item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

--- chunk_id: chunk-0307
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: b497492d4ec37239
prev_chunk_id: chunk-0306
next_chunk_id: chunk-0308
section_heading: MAV_CMD_SPATIAL_USER_5 (MAV_CMD value 31009)
document_type: technical_reference

## MAV_CMD_SPATIAL_USER_5 (MAV_CMD value 31009)

User defined spatial item. Ground Station will not show the Vehicle as flying through this item. Example: ROI item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** Latitude: Latitude unscaled
- **param6** Longitude: Longitude unscaled
- **param7** Altitude: Altitude (MSL)

### MAV_CMD_USER_1 (MAV_CMD value 31010)
User defined command. Ground Station will not show the Vehicle as flying through this item. Example: MAV_CMD_DO_SET_PARAMETER item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** : User defined
- **param6** : User defined
- **param7** : User defined

### MAV_CMD_USER_2 (MAV_CMD value 31011)
User defined command. Ground Station will not show the Vehicle as flying through this item. Example: MAV_CMD_DO_SET_PARAMETER item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** : User defined
- **param6** : User defined
- **param7** : User defined

--- chunk_id: chunk-0308
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 240
content_hash: 8f68aaff19028906
prev_chunk_id: chunk-0307
next_chunk_id: chunk-0309
section_heading: MAV_CMD_USER_3 (MAV_CMD value 31012)
document_type: technical_reference

## MAV_CMD_USER_3 (MAV_CMD value 31012)

User defined command. Ground Station will not show the Vehicle as flying through this item. Example: MAV_CMD_DO_SET_PARAMETER item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** : User defined
- **param6** : User defined
- **param7** : User defined

### MAV_CMD_USER_4 (MAV_CMD value 31013)
User defined command. Ground Station will not show the Vehicle as flying through this item. Example: MAV_CMD_DO_SET_PARAMETER item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** : User defined
- **param6** : User defined
- **param7** : User defined

### MAV_CMD_USER_5 (MAV_CMD value 31014)
User defined command. Ground Station will not show the Vehicle as flying through this item. Example: MAV_CMD_DO_SET_PARAMETER item. ### Parameters

- **param1** : User defined
- **param2** : User defined
- **param3** : User defined
- **param4** : User defined
- **param5** : User defined
- **param6** : User defined
- **param7** : User defined

--- chunk_id: chunk-0309
source_document: mav_cmd_batch_07.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 104
content_hash: 614428840fa8f5ac
prev_chunk_id: chunk-0308
next_chunk_id: null
section_heading: MAV_CMD_CAN_FORWARD (MAV_CMD value 32000)
document_type: technical_reference

## MAV_CMD_CAN_FORWARD (MAV_CMD value 32000)

Request forwarding of CAN packets from the given CAN bus to this component via this MAVLink channel. CAN Frames are sent using CAN_FRAME and CANFD_FRAME messages

### Parameters

- **param1** bus: Bus number (0 to disable forwarding, 1 for first bus, 2 for 2nd bus, 3 for 3rd bus). - **param2** : Empty. - **param3** : Empty. - **param4** : Empty. - **param5** : Empty. - **param6** : Empty. - **param7** : Empty.
