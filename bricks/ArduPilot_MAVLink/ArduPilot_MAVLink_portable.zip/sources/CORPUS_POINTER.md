# MAVLink corpus

- `docs/corpus/ardupilot_mavlink/docs_snapshot/` HTML + `xml/`
- `docs/corpus/ardupilot_mavlink/structured_md/` build inputs
- No live MAVLink; definitions from mavlink/mavlink XML + ArduPilot docs
