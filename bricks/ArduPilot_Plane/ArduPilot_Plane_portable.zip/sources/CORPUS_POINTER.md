Ops rebuild with expanded diagnose/prearm/vibration/uavcan pages. 56 HTML.
