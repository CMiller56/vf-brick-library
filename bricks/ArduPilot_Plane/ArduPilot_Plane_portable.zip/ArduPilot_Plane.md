---
kb_id: ardupilot-plane-operations-doctrine
title: ArduPilot Plane — Operations & Doctrine
author: ArduPilot Dev Team
created_date: 2026-07-18
classification: Internal
confidence_level: High
domain_tags: ["ardupilot", "plane", "ops", "failsafe"]
entity_mentions: ["System Assembly", "System Overview", "system with"]
document_type: Technical Reference
primary_subject: ArduPilot Plane flight modes, failsafes, setup, TECS, prearm, log diagnosis
intended_audience: Plane operators, maintainers
sources: [{"filename": "acro-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/acro-mode.html", "page_count": 1}, {"filename": "airspeed.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/airspeed.html", "page_count": 1}, {"filename": "apms-failsafe-function.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/apms-failsafe-function.html", "page_count": 1}, {"filename": "arduplane-setup.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/arduplane-setup.html", "page_count": 1}, {"filename": "arming-your-plane.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/arming-your-plane.html", "page_count": 1}, {"filename": "auto-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/auto-mode.html", "page_count": 1}, {"filename": "automatic-landing.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/automatic-landing.html", "page_count": 1}, {"filename": "autotune-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/autotune-mode.html", "page_count": 1}, {"filename": "circle-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/circle-mode.html", "page_count": 1}, {"filename": "common-accelerometer-calibration.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-accelerometer-calibration.html", "page_count": 1}, {"filename": "common-apm-navigation-extended-kalman-filter-overview.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-apm-navigation-extended-kalman-filter-overview.html", "page_count": 1}, {"filename": "common-autopilots.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-autopilots.html", "page_count": 1}, {"filename": "common-canbus-setup-advanced.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-canbus-setup-advanced.html", "page_count": 1}, {"filename": "common-compass-calibration-in-mission-planner.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-compass-calibration-in-mission-planner.html", "page_count": 1}, {"filename": "common-connect-mission-planner-autopilot.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-connect-mission-planner-autopilot.html", "page_count": 1}, {"filename": "common-diagnosing-problems-using-logs.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-diagnosing-problems-using-logs.html", "page_count": 1}, {"filename": "common-downloading-and-analyzing-data-logs-in-mission-planner.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-downloading-and-analyzing-data-logs-in-mission-planner.html", "page_count": 1}, {"filename": "common-geofencing-landing-page.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-geofencing-landing-page.html", "page_count": 1}, {"filename": "common-gps-blending.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-gps-blending.html", "page_count": 1}, {"filename": "common-gps-how-it-works.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-gps-how-it-works.html", "page_count": 1}, {"filename": "common-imu-batchsampling.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-imu-batchsampling.html", "page_count": 1}, {"filename": "common-loading-firmware-onto-pixhawk.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-loading-firmware-onto-pixhawk.html", "page_count": 1}, {"filename": "common-logs.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-logs.html", "page_count": 1}, {"filename": "common-magnetic-interference.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-magnetic-interference.html", "page_count": 1}, {"filename": "common-mavlink-mission-command-messages-mav_cmd.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-mavlink-mission-command-messages-mav_cmd.html", "page_count": 1}, {"filename": "common-measuring-vibration.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-measuring-vibration.html", "page_count": 1}, {"filename": "common-power-module-configuration-in-mission-planner.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-power-module-configuration-in-mission-planner.html", "page_count": 1}, {"filename": "common-powering-the-pixhawk.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-powering-the-pixhawk.html", "page_count": 1}, {"filename": "common-prearm-safety-checks.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-prearm-safety-checks.html", "page_count": 1}, {"filename": "common-radio-control-calibration.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-radio-control-calibration.html", "page_count": 1}, {"filename": "common-rc-transmitter-flight-mode-configuration.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-rc-transmitter-flight-mode-configuration.html", "page_count": 1}, {"filename": "common-serial-options.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-serial-options.html", "page_count": 1}, {"filename": "common-telemetry-landingpage.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-telemetry-landingpage.html", "page_count": 1}, {"filename": "common-tuning.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-tuning.html", "page_count": 1}, {"filename": "common-uavcan-escs.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-uavcan-escs.html", "page_count": 1}, {"filename": "common-uavcan-setup-advanced.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-uavcan-setup-advanced.html", "page_count": 1}, {"filename": "common-vibration-damping.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/common-vibration-damping.html", "page_count": 1}, {"filename": "cruise-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/cruise-mode.html", "page_count": 1}, {"filename": "fbwa-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/fbwa-mode.html", "page_count": 1}, {"filename": "fbwb-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/fbwb-mode.html", "page_count": 1}, {"filename": "first-flight-landing-page.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/first-flight-landing-page.html", "page_count": 1}, {"filename": "flight-modes.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/flight-modes.html", "page_count": 1}, {"filename": "geofencing.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/geofencing.html", "page_count": 1}, {"filename": "guided-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/guided-mode.html", "page_count": 1}, {"filename": "loiter-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/loiter-mode.html", "page_count": 1}, {"filename": "manual-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/manual-mode.html", "page_count": 1}, {"filename": "mission-planner-telemetry-logs.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/mission-planner-telemetry-logs.html", "page_count": 1}, {"filename": "mode_autoland.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/mode_autoland.html", "page_count": 1}, {"filename": "navigation-tuning.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/navigation-tuning.html", "page_count": 1}, {"filename": "plane-configuration-landing-page.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/plane-configuration-landing-page.html", "page_count": 1}, {"filename": "rtl-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/rtl-mode.html", "page_count": 1}, {"filename": "stabilize-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/stabilize-mode.html", "page_count": 1}, {"filename": "takeoff-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/takeoff-mode.html", "page_count": 1}, {"filename": "tecs-total-energy-control-system-for-speed-height-tuning-guide.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/tecs-total-energy-control-system-for-speed-height-tuning-guide.html", "page_count": 1}, {"filename": "thermal-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/thermal-mode.html", "page_count": 1}, {"filename": "training-mode.html", "path": "docs/corpus/ardupilot_plane/docs_snapshot/plane/docs/training-mode.html", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-07-18T17:23:50.316837", "page_count": 56, "extraction_methods": {"html": 56}, "avg_extraction_quality": 0.95, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "confidence_level", "created_date", "entity_mentions", "ingest_provenance", "kb_id", "sources"]
brick_role: ops_doctrine
kb_name: ArduPilot_Plane
created: 2026-07-18T17:23:50.320264
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 351
template: technical_reference
domain: general
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-18T17:24:02.900239
  chunk_count: 351
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: acro-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 498
content_hash: b61e5f334c495ccf
prev_chunk_id: null
next_chunk_id: chunk-0001
document_type: technical_reference

ACRO Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- ACRO Mode
Edit on GitHub

# ACRO Mode
# ¶
ACRO (for acrobatic) is a mode for advanced users that provides rate
based stabilization with optional attitude lock. It is a good choice for people
who want to push their plane harder than you can in
FLY BY WIRE A (FBWA)
or
STABILIZE
mode without
flying in
MANUAL
. This is the mode to use for rolls,
loops and other basic aerobatic maneuvers, or if you just want an “on
rails” manual flying mode. Note

rate stabilization is not enabled by default for the YAW axis. Set
YAW_RATE_ENABLE
= 1 to enable yaw axis rate stabilization. Be careful since this will prevent any turns by aileron alone and require application of rudder also to turn. Also, do not enable this if the plane has no yaw control. To use this mode you need to set up
ACRO_YAW_RATE
(if using yaw rate controller),
ACRO_ROLL_RATE
and
ACRO_PITCH_RATE
. These default to 180 degrees/second (and 0, ie no limit, for yaw.However, for AUTOTUNE on yaw axis to work, it must be set to a non-zero value.

--- chunk_id: chunk-0001
source_document: acro-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: bf15042f06dd55c2
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
document_type: technical_reference

To use this mode you need to set up
ACRO_YAW_RATE
(if using yaw rate controller),
ACRO_ROLL_RATE
and
ACRO_PITCH_RATE
. These default to 180 degrees/second (and 0, ie no limit, for yaw.However, for AUTOTUNE on yaw axis to work, it must be set to a non-zero value. 90 degrees/second is suggested), and control how responsive your
plane will be about each axis. It is also necessary to have the plane tuned well (see
Tuning QuickStart
)

When flying in ACRO the aircraft will resist changes to its existing attitude
if you have no stick input. So if you roll the plane to a 30 degree bank
angle with 10 degrees pitch and then let go of the sticks, the plane
should hold that attitude short term. This applies upside down as well, so if you
roll the plane upside down and let go of the sticks the plane will try
to hold the inverted attitude short term or until you move the sticks again. Note

the internal controllers will resist attitude changes, but drift due to turbulence or miss-trimming will result in gradual attitude changes. See ACRO MODE ATTITUDE LOCKING section below. When you apply aileron or elevator stick the plane will rotate about
that axis (in body frame) at a rate proportional to the amount of stick
movement. So if you apply half deflection on the aileron stick then the
plane will start rolling at half of
ACRO_ROLL_RATE
. Note

the
MAN_EXPO_ROLL
,
MAN_EXPO_PITCH
, and
MAN_EXPO_RUDDER
parameters will apply exponential to the stick inputs, if non-zero, in this mode. This is for users with transmitters which do not provide this function and desire to “soften” stick feel around neutral. So to perform a simple horizontal roll, just start in level flight then
hold the aileron stick hard over while leaving the elevator stick alone. The plane will apply elevator correction to try to resist pitch changes while
rolling, including applying inverse elevator while inverted. But to exactly hold the
pitch attitude during multiple rolls without drift,
ACRO_LOCKING
must be enabled. Performing a loop is just as simple - just start with wings level then
pull back on the elevator stick while leaving the aileron alone. The
controller will try to hold your roll attitude through the loop.

--- chunk_id: chunk-0002
source_document: acro-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 366
content_hash: f93d1566a851b0d8
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
document_type: technical_reference

Performing a loop is just as simple - just start with wings level then
pull back on the elevator stick while leaving the aileron alone. The
controller will try to hold your roll attitude through the loop. You can
stop the loop upside down if you like as part of maneuvers such as
Immelman turns or cuban eights. Note that if you are using ACRO mode to try and teach yourself aerobatic
flying then it is highly recommended that you setup a
geo-fence
in case you get disoriented. Warning

It is very easy to stall your plane in ACRO mode, and if you
stall you should change to MANUAL mode to recover. make sure you know the limitations of your airframe, and what the
correct stall recovery procedure is. This varies a lot between
airframes. Search for stall recovery tutorials for R/C aircraft and
read them

don’t overload your airframe, only fly ACRO mode with a plane capable of surviving full control surface deflections at any speed. make sure you have enough airspeed for whatever maneuver you are
attempting. Throttle and speed control is completely under manual
pilot control in ACRO mode

practice stall recovery before trying anything too fancy. Make sure
you practice when you have plenty of altitude to give you time to try
different recovery strategies

It can be a lot of fun flying ACRO mode, but you can also easily stall
and crash hard. Automatic stall detection and recovery in autopilots is
an area of research, and is not yet implemented in Plane, so if you do
stall then recovery is up to you. The best mode for recovery is MANUAL.

--- chunk_id: chunk-0003
source_document: acro-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: af7a8fe2672600cb
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: ACRO MODE ATTITUDE LOCKING
document_type: technical_reference

## ACRO MODE ATTITUDE LOCKING
### ¶
By enabling the
ACRO_LOCKING
parameter, whatever attitude (roll and pitch angle) the pilot places the plane in, upon releasing the sticks, the autopilot will not only resist rate changes (caused by trim or turbulence), but also attempt to hold and correct back to that attitude. Note that his requires that the plane be properly tuned (see
Tuning
). It is recommended that it be set to “2”, instead of “1”, in order to use a quarternion based control system with much better performance than the older system. In order for this to be effective, yaw rate control (
YAW_RATE_ENABLE
) must be “1” and the yaw rate controller tuned using
Autotune
for best performance. ### ACRO Mode YAW Rate Control
### ¶
As of version 4.2, ArduPilot provides the option for utilization of a rate controller for YAW, which behaves in the same manner as the pitch and roll controllers, explained above, but for the YAW axis controlled by the Rudder stick, assuming the vehicle has a rudder control surface. To enable this functionality, set
YAW_RATE_ENABLE
to 1. When enabled, the
ACRO_YAW_RATE
parameter can be used to adjust maximum yaw rate demanded at rudder stick full deflections in ACRO mode. Before use, the controller should be tuned, either manually or using AutoTune. See
Automatic Tuning with AUTOTUNE
or the YAW tuning section of the
Manual Tuning page
. Note

using this controller will give the feel of a ‘heading hold’ yaw axis. While not exactly “heading” holding, it does resist any yaw rate change not commanded by the pilot. This means the pilot will need to “fly the tail” in turns. Just banking will not generate a clean turn. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0004
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 480
content_hash: 32ef9aa1ede9f626
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
document_type: technical_reference

Using an Airspeed Sensor — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
ARSPD_USE
Airspeed Sensor Type
Autopilot Airspeed Connection
I2C
DroneCAN
Analog Airspeed sensor
Installing the Pitot Tubes
Checking operation
Calibration
Miscalibration Safeguards
Failure
Balloon Drop
Airspeed sensors available from ArduPilot Partners:
I2C
DroneCAN
Other Topics
Calibrating an Airspeed Sensor
Pitot Tube Considerations
Mocking an Airspeed Sensor for Bench Testing
Analog Airspeed Sensors
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
Drive Calculator Motor/Propeller Analyzer
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Tether
PPM Encoder
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Peripheral Hardware
- Using an Airspeed Sensor
Edit on GitHub

# Using an Airspeed Sensor
# ¶
Plane supports the use of an airspeed sensor, which can help in windy
conditions, slow flight and autonomous landings. It is not recommended
for most new users, however, as it does require additional tuning and
adds one more layer of control to set up. The following sections explain how to wire sensors to the autopilot and set them up. After you install an airspeed sensor don’t forget to
calibrate it
!

--- chunk_id: chunk-0005
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 193
content_hash: dacf018ebbc76b59
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: ARSPD_USE
document_type: technical_reference

## ARSPD_USE
### ¶
ARSPD_USE
enables airspeed use for automatic throttle modes instead of
TRIM_THROTTLE
as the target throttle setting (altered by
TECS (Total Energy Control System) for Speed and Height Tuning Guide
as needed during altitude control) . The autopilot continues to display and log airspeed if set to 0, but only airspeed sensor readings are used for control if set to 1. It will only use airspeed sensor readings for control when throttle is idle, if set to 2 (useful for gliders with airspeed sensors behind propellers). If an airspeed sensor is used, the throttle stick will set the target airspeed in CRUISE and FBWB, while maintaining altitude target. In AUTO and GUIDED, it will use the
AIRSPEED_CRUISE
value unless
THROTTLE_NUDGE
is enabled and throttle stick is used to alter it, or a MAVLink command to change speed is sent to the vehicle.

--- chunk_id: chunk-0006
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 208
content_hash: b24b33683925d46f
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: Airspeed Sensor Type
document_type: technical_reference

## Airspeed Sensor Type
### ¶
Airspeed sensors can be either analog or digital. The analog sensors connect to an A/D converter input pin on the autopilot, while digital sensors connect to the autopilot’s external I2C bus using the SDA and SCL external digital I/O pins or via DroneCAN. The type is set by the
ARSPD_TYPE
parameter. Analog sensors are type 2, DroneCAN sensors as type 8, and supported I2C bus digital sensors by other numbers. If there is no sensor, be sure to set the
ARSPD_TYPE
to 0. ArduPilot calculates an sensor-less airspeed estimate that is used if no sensor is present or fails. ARSPD_TYPE
must be set to zero in order to display this value if no sensor is present. Warning

Many airspeed sensors are sensitive to light. Unless you are certain that the particular sensor used is not light sensitive, in order to avoid measurement errors, the sensor should be shielded from light.

--- chunk_id: chunk-0007
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 345
content_hash: b814c9ab9c1a3020
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Autopilot Airspeed Connection
document_type: technical_reference

## Autopilot Airspeed Connection
### ¶
A list of digital and DroneCAN airspeed sensors are listed
below
. ### I2C
### ¶
Connect the airspeed sensor to autopilots’s I2C port (or I2C splitter
module). The
ARSPD_BUS
parameter must be set for the bus used to connect the sensor. Normally this defaults to “1” , and corresponds to the I2C bus normally designated for connecting the sensor. But if it is attached to another I2C bus (eg. compass, or on some autopilots its been mistakenly assigned) it will need to be changed to “0”. If the sensor fails to initialize (a GCS message will be sent if this is the case), then try changing the bus number and rebooting. To enable the digital airspeed sensor, connect the autopilot to Mission
Planner (or APM Planner for OS X), and select the Optional Hardware/Airspeed
tab under the CONFIG menu. Using the drop-down box for Type, select your sensor’s type. The Pin dropdown is not used and can be ignored. Check the “Use Airpeed” box to use it in control, or leave it unchecked during in-flight calibration discussed below to check its operation before use. ### DroneCAN
### ¶
Attach the sensor to the AutoPilot’s DroneCAN port and select DroneCAN in the above mentioned Type dropdown box and check the “Use Airspeed” box as appropriate. ### Analog Airspeed sensor
### ¶
Analog sensors are now largely discontinued. Digital sensors are much more accurate and consistent over temperature. ArduPilot still supports these analog sensors, but they are not preferred. See
Analog Airspeed Sensors
.

--- chunk_id: chunk-0008
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 253
content_hash: 9966fb4ca117c915
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: Installing the Pitot Tubes
document_type: technical_reference

## Installing the Pitot Tubes
### ¶
When you place the airspeed sensor in your aircraft, use the pitot tube
set in the kit (the kit comes with a single tube to measure both static
and total pressure). In the case of the
EasyStar
, you’ll need to push
it through the foam in the cockpit so it points straight into the
airstream (drill or cut a small hole in the foam first). Make sure the holes in the side of the tube are not covered. They should be at least 1 centimeter out past the nose. First connect
the two tubes coming out the back to the airspeed sensor. The tube
coming straight out the back should go into the top port and the tube
exiting at an angle should connect to the bottom port on the airspeed
sensor. If you are using Plane in an aircraft with the propeller in the nose,
the pitot tube must be mounted out on one wing, at least a foot from the
fuselage to be outside the prop flow. See
Pitot Tube Considerations
for more information on pitot tubes and placement considerations.

--- chunk_id: chunk-0009
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 8fecd7f0ac40e034
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Checking operation
document_type: technical_reference

## Checking operation
### ¶
You can check the airspeed reading with Mission Planner or another
ground station. Just blow on the pitot tube or press your finger over it and observe the response. In
still air oscillation between zero and small values (2-3) is normal. The
airspeed varies with the square root of the pressure, so for
differential pressures near zero it varies quite a bit with very small
pressure changes, while at flying speeds it takes much greater pressure
changes to produce a similar change in speed. If you see mostly 0, 1, 2,
with an occasional bounce to 3 or 4, consider it normal. You will not
see that sort of variability at flying speeds. ### Calibration
### ¶
The airspeed sensor reading is automatically zeroed by the autopilot during
initialization and value set in the
ARSPD_OFFSET
automatically, so it is good practice during windy conditions to placea loose fitting cover over the pitot tube that shields the front hole
and the four small side holes from the wind. This cover should be fitted
prior to power on and removed before flight. If you forget to do this,
you can always place the cover and repeat the airspeed auto-zero using
the Mission Planner’s PREFLIGHT CALIBRATE => Do Action. Note

the
DLVR
type airspeed sensors do not require calibration at initialization and allow
ARSPD_SKIP_CAL
to be set to “1”, avoiding the need to cover the pitot during initialization. The airspeed reading scale factor is adjusted using the
ARSPD_RATIO
parameter. Plane has an automatic calibration function that will adjust
the value of
ARSPD_RATIO
automatically provided the plane is flown with
frequent direction changes. A normal model flying field circuit pattern
or loiter will achieve the required direction changes, cross-country
flying will not. To enable automatic airspeed sensor calibration, set
the value of
ARSPD_AUTOCAL
to 1. See
Calibrating an Airspeed Sensor
for more details.

--- chunk_id: chunk-0010
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 261
content_hash: 5895a12e7ac2e7c8
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Miscalibration Safeguards
document_type: technical_reference

## Miscalibration Safeguards
### ¶
In order to help prevent Airspeed sensor use when its been miss-calibrated either during ground static calibration during the power up sequence, or by accidental parameter changes to offset or ratio, three parameters are available. If the ground speed is consistently lower than the reported airspeed for a few seconds by
ARSPD_WIND_MAX
, i.e. the apparent wind speed is greater than that amount, the sensor can be disabled to avoid erroneous reporting. It can be allowed to re-enable if the apparent wind falls back below that value. These actions are controlled by
ARSPD_OPTIONS
. You can also elect to have a GCS text message sent after the ground static calibration which reports the value of the calibration (
ARSPD_OFFSET
). This value should not change significantly (10-20 points) from power-up to power-up significantly. If it does, then you may have forgotten to cover the pitot during power up and need to recalibrate. This option can be selected in the
ARSPD_OPTIONS
bitmask parameter. You can also send a warning to the Ground Control Station if the apparent wind exceeds
ARSPD_WIND_WARN
. This can be used instead of, or together with the above

--- chunk_id: chunk-0011
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 356
content_hash: 74477ce7439f95e4
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Failure
document_type: technical_reference

## Failure
### ¶
A failing airspeed sensor can lead to the aircraft stalling or over-speeding, this is something that is hard for ArduPilot to detect. Likewise, accidentally miscalibrating the offset during ground initialization can occur if the pitot tube is not covered to prevent wind upsetting the calibration, and can result in wildly inaccurate readings. The parameters below can be used to help detect these conditions and warn of, and/or disable, a failed sensor. ARSPD_WIND_MAX
can be used to set the maximum expected wind speed the vehicle should ever see. This is then be used
in combination with the GPS ground speed to detect a airspeed sensor error. ARSPD_WIND_WARN
can be set to a lower speed to give
some warning to the operator before the airspeed sensor is disabled. ARSPD_OPTIONS
can be set to allow sensors to be disabled
based on this wind speed metric, a second option bit allows then to be re-enabled if the speed error is resolved. AHRS_WIND_MAX
sets the maximum allowable airspeed and ground speed difference that will ever be used for navigation. By default, these functions are disabled. EKF3 affinity and lane switching
is another option for dealing with airspeed sensor failure. ### Balloon Drop
### ¶
In the special case of a high altitude balloon drop, the EKF will declare the airspeed sensor faulty since there is gps speed but no airspeed due to air density. This can result in TECS miss-applying pitch. In this special case , the
AHRS_OPTIONS
bit 2 can be set to prevent EKF from declaring the airspeed sensor as faulty and continue to use it.

--- chunk_id: chunk-0012
source_document: airspeed.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 206
content_hash: 051f641c0b895297
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: Airspeed sensors available from ArduPilot Partners:
document_type: technical_reference

## Airspeed sensors available from ArduPilot Partners:
### ¶
### I2C
### ¶
4525DO
CUAV

Holybro

Matek 4525DO

mRobotics

TBS

ASP5033
Qiotek ASP5033

DLVR
Matek DLVR

TBS


### DroneCAN
### ¶
3DR ASUAV
3DR ASUAV DroneCAN Airspeed/Barometer

6897
Foxtech AEROFOX Airspeed/Compass

Amphenol AUAV (static and dynamic pressure)
Beyond Robotix Air Data Module

Matek DroneCAN AUAV Airspeed/Baro

UAV-DEV GmbH DroneCAN Airspeed and Barometer Sensor - AUAV

ASP5033
Qiotek DroneCAN 5033

DLVR
Foxtech AEROFOX Airspeed/Compass

Holybro DroneCAN DLVR

Matek DroneCAN DLVR

TBS

MS4525
MakeFlyEasy DroneCAN Airspeed

TBS

MS5611
Avionics Anonymous Airspeed + Temp

### Other Topics
### ¶
Calibrating an Airspeed Sensor
Pitot Tube Considerations
Mocking an Airspeed Sensor for Bench Testing
Analog Airspeed Sensors





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0013
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: 3ef997b46915fb49
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
document_type: technical_reference

Plane Failsafe Function — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
RC Failsafe
GCS Failsafe
Configuring for valid RC outputs while in RC Failsafe
Battery Failsafe
Failsafe Parameters and their Meanings
Failsafe Diagnosis in Logs or GCS
Independent Watchdog
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
- Plane Failsafe Function
Edit on GitHub

# Plane Failsafe Function
# ¶
Plane has a limited failsafe function which is designed to do four
things:

Detects a RC Failsafe condition and then initiating a defined response, such as returning to home. Detection of an RC Failsafe is either a complete loss, or corruption, of RC signals, or the receiver sets a FS bit in its data stream for those protocols supporting it (SBUS, etc.), or that the throttle channel PWM value falls below a certain point set by
THR_FS_VALUE
. This RC failsafe must be enabled by setting
THR_FAILSAFE
= 1. Optionally, detect loss of telemetry (GCS Failsafe) and take an programmable action, such as switching to return to launch (RTL) mode. Either of the above have two phases: Short Failsafe which occurs a programmable time after loss of RC or telemetry, which allows optionally circling to try to recover the signals, and if the loss persists longer, a Long Failsafe which determines what long term action is to be taken.

--- chunk_id: chunk-0014
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 269
content_hash: 914d23718fd84b98
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
document_type: technical_reference

Optionally, detect loss of telemetry (GCS Failsafe) and take an programmable action, such as switching to return to launch (RTL) mode. Either of the above have two phases: Short Failsafe which occurs a programmable time after loss of RC or telemetry, which allows optionally circling to try to recover the signals, and if the loss persists longer, a Long Failsafe which determines what long term action is to be taken. Detect loss of GPS for more than 20 seconds and switch into Dead Reckoning mode until GPS signal is regained. See
https://youtu.be/0VMx2u8MlUU
for a demo. Optionally, detect low battery conditions (low voltage/remaining capacity) and initiate a programmable response, such as returning to home. ArduPilot supports this on multiple batteries. Here’s what the failsafe
will not do
:

Detect if one or more individual RC channel has failed or become disconnected

Detect if you’re flying too far away or are about to hit the ground

Detect autopilot hardware failures, such as low-power brownouts or in-air reboots

Detect if the Plane software is not operating correctly

Detect other problems with the aircraft, such as motor failures

Otherwise stop you from making setup or flight mistakes

Note

See
Advanced Failsafe Configuration
for extended failsafe configurations.

--- chunk_id: chunk-0015
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 97
content_hash: 3e83b2706af07344
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: RC Failsafe
document_type: technical_reference

## RC Failsafe
### ¶
### Radio Signal Failure
### ¶
If the received signal is lost or the control information corrupted for greater than
RC_FS_TIMEOUT
(default = 1 sec), or the receiver sets its “failsafe bit” in protocols which have this (like Sbus, FPort, etc.), or RC_OVERRIDES are lost if
using a GCS only
is being used, then an RC Failsafe condition occurs and the actions described in the
RC Failsafe Actions

--- chunk_id: chunk-0016
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: 7563a253f4196f82
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: section below will be taken, if the
document_type: technical_reference

section below will be taken, if the
THR_FAILSAFE
parameter is 1. Note

by setting
RC_OPTIONS
bit 2, you can force ArduPilot to ignore the “failsafe” bits in the protocol, and only initiate RC Failsafe due to missing or corrupted control information. ### Throttle Failsafe
### ¶
In addition, if the throttle signal falls below a threshold set by
THR_FS_VALUE
and the
THR_FAILSAFE
is = 1, an RC Failsafe condition will be entered, a Ground Control Station text message (“Throttle Failsafe On”) will be sent (to differentiate from a Radio Signal Failure Failsafe), and the actions described in the RC Failsafe Actions section below will be taken. ### Throttle Failsafe Setup
### ¶
Note

Throttle Failsafe is not required. If you wish to have failsafe protection against RC signal loss, but not setup a throttle signal controlled failsafe, then set
THR_FS_VALUE
lower than the lowest RC throttle signal that can be sent to the autopilot from the receiver. In order to activate the Throttle Failsafe, the throttle signal received by the autopilot must be below
THR_FS_VALUE
. Once setup, this can be controlled by the pilot to initiate Throttle failsafe intentionally (for testing, or instead of setting up an RTL position on the flight mode switch), or by having the receiver, itself, send that value when it loses RC signal. Note

having the receiver send a pre-set failsafe throttle value upon signal loss is NOT recommended and can lead to issues if a battery level failsafe is setup in QuadPlanes. Setting the receiver to send “no pulses” is much preferred. However, some very old receivers will only send a low throttle level in failsafe, see the section below,
Old Receivers
. The system must be setup such that the throttle channel’s signal can go below
THR_FS_VALUE
(Default is 950), but still be above it for normal low throttle stick operation. Before doing the
RC Calibration
setup step which determines normal operating ranges for the throttle channel and others, make sure that the low throttle stick position on your transmitter is above
THR_FS_VALUE
. This can be done several ways:

When you do the
RC Calibration
setup step, change the trim tab for the throttle channel to adjust its signal 40-50us above
THR_FS_VALUE
at low throttle stick. This will be the normal operating position.

--- chunk_id: chunk-0017
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 484
content_hash: 596bbd295d7ff3af
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: section below will be taken, if the
document_type: technical_reference

This can be done several ways:

When you do the
RC Calibration
setup step, change the trim tab for the throttle channel to adjust its signal 40-50us above
THR_FS_VALUE
at low throttle stick. This will be the normal operating position. Lowering the trim tab and setting the
THR_FS_VALUE
to that value allows initiating a failsafe at low trim. Setup a transmitter switch that you will use to force failsafe such that it forces the throttle channel signal, using a mix, to below
THR_FS_VALUE
when activated, allowing normal operation otherwise. ### RC Failsafe Operation
### ¶
When RC Failsafe is entered, all RC inputs (except throttle in the case of Throttle Failsafe), are ignored as the autopilot takes its failsafe actions. First, the autopilot will go into Short Failsafe when it detects RC Failsafe for more than 0.5 seconds. A message will be displayed on your Ground Control Station(GCS), or OSD, if its message panel is enabled, that a Short Failsafe is active, and the autopilot will take the
FS_SHORT_ACTN
, if enabled. The default is CIRCLE mode. This is intended to possibly allow the vehicle’s changing orientation to re-acquire the signal, but other actions can be assigned. See
FS_SHORT_ACTN parameter below
for how each mode responds to the selected action value. If the condition causing the Short Failsafe is removed, the vehicle will return to the previous mode, and a message will be displayed that Short Failsafe is cleared. If it was a Throttle Failsafe that caused the RC Failsafe, and throttle was increased in order to exit, then an additional message will be sent stating that the Throttle Failsafe is OFF. If the condition causing the Short Failsafe persists longer than
FS_LONG_TIMEOUT
seconds the autopilot will go into Long Failsafe, send a message to the GCS that it has been entered, and execute the
FS_LONG_ACTN
action, if enabled. The default setting for Long Failsafe action to take is RTL (Return to Launch). See
FS_LONG_ACTN parameter below
for how each mode responds to the selected action value. If the RC Failsafe condition is later exited, a message will be displayed that the Long Failsafe is cleared, but the flight mode will not revert.

--- chunk_id: chunk-0018
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: 9d970731cedb4e66
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: section below will be taken, if the
document_type: technical_reference

See
FS_LONG_ACTN parameter below
for how each mode responds to the selected action value. If the RC Failsafe condition is later exited, a message will be displayed that the Long Failsafe is cleared, but the flight mode will not revert. If it was a Throttle Failsafe that caused the RC Failsafe, and throttle was increased in order to exit, then an additional message will be sent stating that the Throttle Failsafe is OFF. Note

The action set by
FS_LONG_ACTN
will continue even if your RC signal is reacquired, if the flight mode is the same as it was before the failsafe action began. Once RC signal is reacquired, the
FS_LONG_ACTN
can be exited via a mode change on the
FLTMODE_CH
. If the mode on the RC transmitter was changed during the failsafe period, then this changed mode is entered after the RC signal is restored. In addition, other failsafes, such as battery failsafe, can also change the mode, if they occur subsequently to the RC signal loss. ### Bench Testing RC Failsafe
### ¶
Power up the system and verify that you are seeing RC control in the Mission Planner SETUP->Mandatory Hardware->Radio Calibration tab and in a non-auto mode (Manual, Stabilize, FBW are ok). Check that normal throttle movements to idle do NOT trigger a failsafe and normal control stick movements are observed

Switch to Mission Planners DATA View tab. Turn off the transmitter. You should see the flight mode switch to
FS_SHORT_ACTN
. After
FS_LONG_TIMEOUT
sec, if enabled, the flight mode should then switch to
FS_LONG_ACTN
. Turn the transmitter back on and change flight modes. The Long Failsafe flight mode should change to the selected mode. If Throttle Failsafe is setup (ie via trim tab or transmitter switch). Check that it operates correctly by activating it and watching for Short and Long Failsafes to occur. If you observe this behavior, your RC Failsafe function has been set up correctly. If not, recheck that the parameters above have been set correctly. ### Older Receivers
### ¶
Some very old RC receivers cannot be set to send “no pulses” when losing RC signal and simple hold the ROLL/PITCH/YAW RC channels at their last value and set the throttle channel to its minimum PWM value (low throttle).

--- chunk_id: chunk-0019
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 150
content_hash: d914fee9165a6d8c
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: section below will be taken, if the
document_type: technical_reference

If not, recheck that the parameters above have been set correctly. ### Older Receivers
### ¶
Some very old RC receivers cannot be set to send “no pulses” when losing RC signal and simple hold the ROLL/PITCH/YAW RC channels at their last value and set the throttle channel to its minimum PWM value (low throttle). For those, the only way to setup an RC failsafe is to set the
THR_FS_VALUE
to slightly above that value and use the transmitters trim tab to raise the idle stick value 40-50us above that for normal operation. Note

be sure to do
ESC calibration
after you have setup the failsafes and throttle ranges. Transmitter Tutorials:

Spektrum Setup

--- chunk_id: chunk-0020
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 410
content_hash: 4c6597bb957c94ac
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
section_heading: GCS Failsafe
document_type: technical_reference

## GCS Failsafe
### ¶
How it works. When flying while using telemetry on the GCS, the
autopilot can be programmed to trigger into failsafe mode if it loses
telemetry from its primary GCS (set by
MAV_GCS_SYSID
). In the event that the autopilot stops receiving MAVlink
(telemetry protocol) heartbeat messages from it,
FS_LONG_ACTN
applies just as in the case of a long Throttle Failsafe. See
FS_LONG_ACTN parameter below
for how each mode responds to the selected action value. Setup. Set
FS_GCS_ENABL
to 1 to enable it. Connect to the Mission Planner via telemetry. Verify on the bottom
right corner of the HUD that you are armed and “flying” in a non auto mode
(Manual, Stabilize, FBW are ok). Be sure you have the GCS connected or failsafe will occur immediately, possibly starting the motors! Unplug the telemetry radio getting telemetry from the primary GCS. After a few minutes power off
your autopilot. (Remember the autopilot will not go fully into failsafe
until
FS_LONG_TIMEOUT
seconds of MAVLink inactivity have passed). Connect your autopilot to the mission planner and pull the logs. Verify on the log that the autopilot went into RTL after
FS_LONG_TIMEOUT
sec of MAVLink inactivity. ### Configuring for Ground Control Station Control beyond RC range
### ¶
If the telemetry range exceeds the RC transmitter range, then it may be desired to prevent loss of RC signal from initiating a failsafe. Reliance on the above GCS failsafe would be then be used to provide failsafe protection. In order to prevent the RC system from interfering with GCS operation, set
THR_FAILSAFE
= 2. This prevents the RC failsafe action from being taken, but still detects the failsafe condition and ignores the RC inputs, preventing possible interference to Ground Control Station control of the vehicle. Control via the RC system can be resumed once back into its range.

--- chunk_id: chunk-0021
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 409
content_hash: 5c36187ad95b16ce
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: Configuring for valid RC outputs while in RC Failsafe
document_type: technical_reference

## Configuring for valid RC outputs while in RC Failsafe
### ¶
Normally, the RC channels are ignored when in RC Failsafe (except the throttle channel, but for failsafe detection exit only). Sometimes it is desirable to allow the preset signal loss values( for receivers capable of this ), to be used in the event of an RC failsafe. For example, parachute activation, or other controls via RC passthrough (see
Auxiliary Functions
) could be desired when in RC failsafe. For receivers with this capability and which use a FS data bit, setting
RC_OPTIONS
bit 2 to “1”, can accomplish this. In this case, the FS bit is ignored. Upon RC signal loss the receiver would go to its pre-set channel outputs values, but a failsafe action would not be taken by ArduPilot, since the receiver is still outputting valid data as far as ArduPilot can detect. The fixed RC channel values would processed as normal by ArduPilot. Note

In this setup, it is usually necessary to make sure that the flight mode channel will force an RTL or AUTO mission to return the vehicle when the receiver loses RC signal, since no failsafe action will be taken, otherwise. The values of the flight control channels for Roll, Pitch, Yaw and Throttle need to be appropriately set also (usually neutral positions). Warning

Since the autopilot cannot know if the RC link is lost in this configuration, it is possible to get into dangerous situations, especially with QuadPlanes. For example, you are low on battery and far away, and the battery failsafe is active and attempting a VTOL land to prevent a crash. As it drops out of RC range, it will switch to the RC failsafe mode set in the receiver, and attempt to execute that, canceling the battery failsafe action, and ultimately resulting in a crash.

--- chunk_id: chunk-0022
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 402
content_hash: ccac02d6a4ff472e
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
section_heading: Battery Failsafe
document_type: technical_reference

## Battery Failsafe
### ¶
Note

This failsafe requires the vehicle have a working
Power Module
. Note

ArduPilot supports up to 10 batteries/power monitors. All the  discussion below applies to those optional batteries also. Each can trigger a failsafe and each can have different actions and setup values. In addition, a group of batteries can be treated as a single unit, see
BATTx_MONITOR
= 10. Note

the battery low failsafe voltage must be higher than the battery critical failsafe voltage or a pre-arm error will occur. ### When the failsafe will trigger
### ¶
If enabled and set-up correctly the battery failsafe will trigger if the main battery’s

voltage drops below the voltage held in the
BATT_LOW_VOLT
parameter (or FS_BATT_VOLTAGE in older versions) for more than 10 seconds. If set to zero (the Plane default value) the voltage based trigger will be disabled. remaining capacity falls below the
BATT_LOW_MAH
parameter (or FS_BATT_MAH in older versions) 20% of the battery’s full capacity is a good choice (i.e. “1000” for a 5000mAh battery). If set to zero the capacity based trigger will be disabled (i.e. only voltage will be used)


### What will happen
### ¶
When the failsafe is triggered:

Buzzer will play a loud low-battery alarm

LEDs will flash yellow

A warning message will be displayed on the ground station’s HUD (if telemetry is connected)

BATT_FS_LOW_ACT
will be executed


### Two-Stage Battery Failsafe
### ¶
Plane includes a two-layer battery failsafe. This allows setting up a follow-up action if the battery voltage or remaining capacity falls below an even lower threshold. BATT_CRT_VOLT
- holds the secondary (lower) voltage threshold. Set to zero to disable. Default is zero. BATT_CRT_MAH
- holds the secondary (lower) capacity threshold. Set to zero to disable. Default is zero. BATT_FS_CRT_ACT
- holds the secondary action to take.

--- chunk_id: chunk-0023
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 246
content_hash: ed6a723e9f023ed7
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: Battery Failsafe
document_type: technical_reference

Default is zero. BATT_FS_CRT_ACT
- holds the secondary action to take. A reasonable setup would be to have
BATT_FS_LOW_ACT
= 1 (RTL) and
BATT_FS_CRT_ACT
= 2 (Land)


### Advanced Battery Failsafe Settings
### ¶
BATT_FS_VOLTSRC
allows configuring whether the raw battery voltage or a sag corrected voltage is used

BATT_LOW_TIMER
can configure how long the voltage must be below the threshold for the failsafe to trigger

BATTx_
parameters can be setup to trigger the failsafe on other batteries


### Battery Failsafe Actions
### ¶
The following is a description of the actions that can be taken for battery failsafes:

Value

Action

Description

0

Warn Only

Do nothing except warn

1

RTL

Switch to
RTL
mode

2

Land

Switch to AUTO mode and execute nearest DO_LAND sequence, if in mission

3

Terminate

Disarm

4

QLAND

If QuadPlane, switch to
QLAND Mode
, otherwise do nothing

5

Parachute

Trigger Parachute (Critical action only)

6

LOITER_TO_QLAND

If QuadPlane, switch to LOITER_TO_QLAND mode,
otherwise do nothing

7

AUTOLAND or RTL

If Fixed Wing, switch to AUTOLAND if available (see
AUTOLAND Mode
. If
unavailable or QuadPlane switch to RTL

--- chunk_id: chunk-0024
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 313
content_hash: a9d8c04448e00aef
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: Failsafe Parameters and their Meanings
document_type: technical_reference

## Failsafe Parameters and their Meanings
### ¶
### Short failsafe action (
### FS_SHORT_ACTN
### )
### ¶
The action to immediately take on a RC failsafe event . No Action is ever taken for Short FailSafe in these modes:

CIRCLE

RTL

TAKEOFF

QRTL

QLAND

LOITER to Alt and QLAND

FS_SHORT_ACTN
= 3 disables taking action in ANY mode

Note

if in AutoLanding in AUTO or AUTOLAND, it will always continue to the landing


In QuadPlanes, Short FailSafe will force QLAND by default, RTL if bit 20 of
Q_OPTIONS
is set, or QRTL if bit 5 of
Q_OPTIONS
is set, if entered from these modes:

QSTABILIZE

QHOVER

QLOITER

QACRO

QAUTOTUNE

Otherwise:

FS_SHORT_ACTN

Mode

Action Taken

0 - CONTINUE if in
AUTO, or CIRCLE

MANUAL

CIRCLE unless
emergency landing
switch is active,
then FBWA

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

No Change

AUTO

THERMAL

AVOID_ADSB

GUIDED

FS_SHORT_ACTN

Mode

Action Taken

1 -CIRCLE

MANUAL

CIRCLE unless
emergency landing
switch is active,
then FBWA

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

CIRCLE

AUTO

THERMAL

AVOID_ADSB

GUIDED

FS_SHORT_ACTN

Mode

Action Taken

2 -GLIDE
or
4 - FBWB(ALT HOLD)

MANUAL

GLIDE/FBWB unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

GLIDE/FBWB

AUTO

THERMAL

AVOID_ADSB

GUIDED


### Long failsafe action (
### FS_LONG_ACTN
### )
### ¶
The action to take on a long (
FS_LONG_TIMEOUT
seconds) RC failsafe event.

--- chunk_id: chunk-0025
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 560
content_hash: 71f17b37cd4ad7e9
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: Failsafe Parameters and their Meanings
document_type: technical_reference

## Failsafe Parameters and their Meanings
### ¶
### Short failsafe action (
### FS_SHORT_ACTN
### )
### ¶
The action to immediately take on a RC failsafe event . No Action is ever taken for Short FailSafe in these modes:

CIRCLE

RTL

TAKEOFF

QRTL

QLAND

LOITER to Alt and QLAND

FS_SHORT_ACTN
= 3 disables taking action in ANY mode

Note

if in AutoLanding in AUTO or AUTOLAND, it will always continue to the landing


In QuadPlanes, Short FailSafe will force QLAND by default, RTL if bit 20 of
Q_OPTIONS
is set, or QRTL if bit 5 of
Q_OPTIONS
is set, if entered from these modes:

QSTABILIZE

QHOVER

QLOITER

QACRO

QAUTOTUNE

Otherwise:

FS_SHORT_ACTN

Mode

Action Taken

0 - CONTINUE if in
AUTO, or CIRCLE

MANUAL

CIRCLE unless
emergency landing
switch is active,
then FBWA

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

No Change

AUTO

THERMAL

AVOID_ADSB

GUIDED

FS_SHORT_ACTN

Mode

Action Taken

1 -CIRCLE

MANUAL

CIRCLE unless
emergency landing
switch is active,
then FBWA

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

CIRCLE

AUTO

THERMAL

AVOID_ADSB

GUIDED

FS_SHORT_ACTN

Mode

Action Taken

2 -GLIDE
or
4 - FBWB(ALT HOLD)

MANUAL

GLIDE/FBWB unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

GLIDE/FBWB

AUTO

THERMAL

AVOID_ADSB

GUIDED


### Long failsafe action (
### FS_LONG_ACTN
### )
### ¶
The action to take on a long (
FS_LONG_TIMEOUT
seconds) RC failsafe event. No Action is ever taken for Long FailSafe in these modes:

RTL

QRTL

QLAND

LOITER to Alt and QLAND

In QuadPlanes, Long FailSafe will force QLAND by default, RTL if bit 20 of
Q_OPTIONS
is set, or QRTL if bit 5 of
Q_OPTIONS
is set, if entered from these modes:

QSTABILIZE

QHOVER

QLOITER

QACRO

QAUTOTUNE

Otherwise:

FS_LONG_ACTN

Mode

Action Taken

0 - CONTINUE if in
AUTO, or RTL

MANUAL

RTL unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

No Change

AVOID_ADSB

GUIDED

FS_LONG_ACTN

Mode

Action Taken

1 - RTL

MANUAL

RTL unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

RTL

AVOID_ADSB

GUIDED

FS_LONG_ACTN

Mode

Action Taken

2 - GLIDE or
4- AUTO or
3- PARACHUTE

MANUAL

GLIDE,AUTO or PARACHUTE
unless emergency
landing switch is
active, then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

GLIDE,AUTO or PARACHUTE

AVOID_ADSB

GUIDED


### GCS failsafe enable (
### FS_GCS_ENABL
### )
### ¶
Enable ground control station telemetry failsafe.

--- chunk_id: chunk-0026
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 538
content_hash: 9ed04be8511080fa
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: Failsafe Parameters and their Meanings
document_type: technical_reference

No Action is ever taken for Short FailSafe in these modes:

CIRCLE

RTL

TAKEOFF

QRTL

QLAND

LOITER to Alt and QLAND

FS_SHORT_ACTN
= 3 disables taking action in ANY mode

Note

if in AutoLanding in AUTO or AUTOLAND, it will always continue to the landing


In QuadPlanes, Short FailSafe will force QLAND by default, RTL if bit 20 of
Q_OPTIONS
is set, or QRTL if bit 5 of
Q_OPTIONS
is set, if entered from these modes:

QSTABILIZE

QHOVER

QLOITER

QACRO

QAUTOTUNE

Otherwise:

FS_SHORT_ACTN

Mode

Action Taken

0 - CONTINUE if in
AUTO, or CIRCLE

MANUAL

CIRCLE unless
emergency landing
switch is active,
then FBWA

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

No Change

AUTO

THERMAL

AVOID_ADSB

GUIDED

FS_SHORT_ACTN

Mode

Action Taken

1 -CIRCLE

MANUAL

CIRCLE unless
emergency landing
switch is active,
then FBWA

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

CIRCLE

AUTO

THERMAL

AVOID_ADSB

GUIDED

FS_SHORT_ACTN

Mode

Action Taken

2 -GLIDE
or
4 - FBWB(ALT HOLD)

MANUAL

GLIDE/FBWB unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

GLIDE/FBWB

AUTO

THERMAL

AVOID_ADSB

GUIDED


### Long failsafe action (
### FS_LONG_ACTN
### )
### ¶
The action to take on a long (
FS_LONG_TIMEOUT
seconds) RC failsafe event. No Action is ever taken for Long FailSafe in these modes:

RTL

QRTL

QLAND

LOITER to Alt and QLAND

In QuadPlanes, Long FailSafe will force QLAND by default, RTL if bit 20 of
Q_OPTIONS
is set, or QRTL if bit 5 of
Q_OPTIONS
is set, if entered from these modes:

QSTABILIZE

QHOVER

QLOITER

QACRO

QAUTOTUNE

Otherwise:

FS_LONG_ACTN

Mode

Action Taken

0 - CONTINUE if in
AUTO, or RTL

MANUAL

RTL unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

No Change

AVOID_ADSB

GUIDED

FS_LONG_ACTN

Mode

Action Taken

1 - RTL

MANUAL

RTL unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

RTL

AVOID_ADSB

GUIDED

FS_LONG_ACTN

Mode

Action Taken

2 - GLIDE or
4- AUTO or
3- PARACHUTE

MANUAL

GLIDE,AUTO or PARACHUTE
unless emergency
landing switch is
active, then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

GLIDE,AUTO or PARACHUTE

AVOID_ADSB

GUIDED


### GCS failsafe enable (
### FS_GCS_ENABL
### )
### ¶
Enable ground control station telemetry failsafe. Failsafe will trigger
after
FS_LONG_TIMEOUT
seconds of no MAVLink heartbeat or RC Override messages.

--- chunk_id: chunk-0027
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 409
content_hash: b19887a8b0eb6c75
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
section_heading: Failsafe Parameters and their Meanings
document_type: technical_reference

No Action is ever taken for Long FailSafe in these modes:

RTL

QRTL

QLAND

LOITER to Alt and QLAND

In QuadPlanes, Long FailSafe will force QLAND by default, RTL if bit 20 of
Q_OPTIONS
is set, or QRTL if bit 5 of
Q_OPTIONS
is set, if entered from these modes:

QSTABILIZE

QHOVER

QLOITER

QACRO

QAUTOTUNE

Otherwise:

FS_LONG_ACTN

Mode

Action Taken

0 - CONTINUE if in
AUTO, or RTL

MANUAL

RTL unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

No Change

AVOID_ADSB

GUIDED

FS_LONG_ACTN

Mode

Action Taken

1 - RTL

MANUAL

RTL unless
emergency landing
switch is active,
then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

RTL

AVOID_ADSB

GUIDED

FS_LONG_ACTN

Mode

Action Taken

2 - GLIDE or
4- AUTO or
3- PARACHUTE

MANUAL

GLIDE,AUTO or PARACHUTE
unless emergency
landing switch is
active, then GLIDE

ACRO

STABILIZE

FBWA

FBWB

CRUISE

AUTOTUNE

TRAINING

LOITER

THERMAL

CIRCLE

TAKEOFF

AUTO

GLIDE,AUTO or PARACHUTE

AVOID_ADSB

GUIDED


### GCS failsafe enable (
### FS_GCS_ENABL
### )
### ¶
Enable ground control station telemetry failsafe. Failsafe will trigger
after
FS_LONG_TIMEOUT
seconds of no MAVLink heartbeat or RC Override messages. Warning

Enabling this option opens up the possibility of your plane going into failsafe mode and running the motor on the ground if it loses contact with your ground station. While the code attempts to verify that the plane is indeed flying and not on the ground before entering this failsafe, it is safer if this option is enabled on an electric plane, to either use a separate motor arming switch or remove the propeller in any ground testing, if possible. There are three possible enabled settings. Seeing
FS_GCS_ENABL
to 1 means that GCS failsafe will be triggered when the aircraft has not received a MAVLink HEARTBEAT message.

--- chunk_id: chunk-0028
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 234
content_hash: 1202bcc459fc184f
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
section_heading: Failsafe Parameters and their Meanings
document_type: technical_reference

There are three possible enabled settings. Seeing
FS_GCS_ENABL
to 1 means that GCS failsafe will be triggered when the aircraft has not received a MAVLink HEARTBEAT message. Setting
FS_GCS_ENABL
to 2 means that GCS failsafe will be triggered on either a loss of HEARTBEAT messages, or a RADIO_STATUS message from a MAVLink enabled telemetry radio indicating that the ground station is not receiving status updates from the aircraft, which is indicated by the RADIO_STATUS.remrssi field being zero (this may happen if you have a one way link due to asymmetric noise on the ground station and aircraft radios).Setting
FS_GCS_ENABL
to 3 means that GCS failsafe will be triggered by Heartbeat(like option one), but only in AUTO mode. WARNING: Enabling this option opens up the possibility of your plane going into failsafe mode and running the motor on the ground it it loses contact with your ground station. If this option is enabled on an electric plane then you should enable
ARMING_REQUIRE
. VALUE
MEANING
0
Disabled
1
Heartbeat
2
Heartbeat and REMRSSI
3
Heartbeat and AUTO

--- chunk_id: chunk-0029
source_document: apms-failsafe-function.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 186
content_hash: 346a733ea8ec14ef
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: Failsafe Diagnosis in Logs or GCS
document_type: technical_reference

## Failsafe Diagnosis in Logs or GCS
### ¶
GCSs will often display text indicating the type of failsafe encountered, such as “Failsafe Short event on: type=1/reason=3”. Type and Reason can be determined using the table below:

TYPE
MEANING
0
None
1
Short Failsafe
2
Long Failsafe
3
GCS Failsafe
REASON
MEANING
0
Unknown
1
RC Command
2
GCS Command
3
Radio Failsafe
4
Battery Failsafe
5
GCS Failsafe
6
EKF Failsafe
7
GPS Glitch
10
Fence Breached
11
Terrain
19
Crash
25+
General unspecific

### Independent Watchdog
### ¶
See
Independent Watchdog and Crash Dump
for details. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0030
source_document: arduplane-setup.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: fce5cc7c07b16f4f
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
document_type: technical_reference

Setup for Plane — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
- Setup for Plane
Edit on GitHub

# Setup for Plane
# ¶
Just want to get up and running as fast as possible? Here’s a guide to
the simplest approach. There’s a lot more Plane can do, but this will
give you a taste:

Note

This section assumes that you’ve already chosen and built a frame (Plane, Flying Wing, V-Tail, QuadPlane, Tilt-Rotor, etc.) and have
selected your autopilot
. Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Airframe Specific Setup Guides




Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0031
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: 7ac49378724952e6
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
document_type: technical_reference

Arming Plane — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Center of Gravity
Starting up and calibrating Plane
Pre-Arm Safety Checks
Arming Plane
Configuring Arming
Arming Checks
IMPORTANT: RC Transmitter Calibration
How to Arm
How to Disarm
Visual and Audible signals
Throttle output when disarmed
Diagnosing failure to arm
In Landing Sequence Pre-Arm Failure
Check that it is ready to arm
Try arming
Rudder arming
Reasons for refusing to arm
Takeoff
Tuning Quickstart
Automatic Tuning
Tuning in Detail
Tuning Configuration Values for Common Airframes
Measuring Vibration
Transmitter based tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
First Flight
- Arming Plane
Edit on GitHub

# Arming Plane
# ¶
Before you can fly your plane you need to arm it. Arming the aircraft
before flight has two purposes:

prevent the motor from turning when the pilot is not ready to fly (a
safety feature)

prevent takeoff before the autopilot is fully configured and ready to
fly

The key thing that arming does is to enable the motor. You will not be
able to start the motor (ie. control the throttle) until the aircraft is
armed. Note
: If you have
AHRS_EKF_TYPE
set to 2 or 3 (you are using one of the EKFs) then it is particularly important that you have arming checks enabled for INS. Flying EKF without arming checks may cause a
crash. Warning

This feature in no way removes the need to respect the
prop! When the plane is powered, ALWAYS avoid placing hands in
the vicinity of the propeller, even when the throttle is
disarmed. If all is not well with the autopilot electronics or software
there is always a slight possibility that signal could unintentionally
reach the motor.

--- chunk_id: chunk-0032
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 97
content_hash: 0f3cfc2d98d532ce
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
document_type: technical_reference

When the plane is powered, ALWAYS avoid placing hands in
the vicinity of the propeller, even when the throttle is
disarmed. If all is not well with the autopilot electronics or software
there is always a slight possibility that signal could unintentionally
reach the motor. Even though this is unlikely (and made even less likely
by safety features such as this) it only takes one time to chew up a
finger or hand!

--- chunk_id: chunk-0033
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 273
content_hash: d16a963273f278f7
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
section_heading: Configuring Arming
document_type: technical_reference

## Configuring Arming
### ¶
There are three parameters which control how arming works:

ARMING_REQUIRE
: this controls whether an arming step is
required. The default is 1, meaning that arming is required before
takeoff. If set to 0 then arming is not required (the plane starts
off armed). ARMING_SKIPCHK
: this controls what checks the autopilot does
before arming is allowed. The default is 0, meaning all checks are
done. Most users should leave it at 0, as the arming checks are
important to ensure the autopilot is ready. See below. ARMING_RUDDER
: This parameter allows you to configure rudder
based arming/disarming. The default is 1, meaning you are able to
arm with right rudder. If you set this to 2 you can also disarm
with left rudder. If you set this to 0 then you will only be able
to arm/disarm via a ground station or RC channel input using its RCx_OPTION. Warning

if
ARMING_RUDDER
is set to 2, then held left rudder can disarm the vehicle in ANY mode, if the autopilot judges that the vehicle is not flying. This flying check CAN be incorrect under certain extreme circumstances, and disarming of the vehicle while still in flight, while rare, could occur.

--- chunk_id: chunk-0034
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: 54d8a34b3d0ac3aa
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: Arming Checks
document_type: technical_reference

## Arming Checks
### ¶
Before allowing arming the autopilot checks a set of conditions. All
conditions must pass for arming to be allowed. If any condition fails
then a message explaining what failed is set to the GCS. Any or all of the
Pre-Arming Checks can be disabled, but it is not recommended. See the
Pre-Arm Safety Checks
topic for more information. ### IMPORTANT: RC Transmitter Calibration
### ¶
It is essential that your RC radio transmitter be calibrated correctly
before continuing. Please see the
Calibrate your RC input
wiki page if you don’t know how to calibrate your radio. When calibrating your RC input you should also be careful to set the
minimum value of the throttle (usually RC3_MIN) to the minimum value
when in normal flight control. Don’t set it to the value used by your
transmitter when in throttle failsafe or you won’t be able to arm using
the rudder as the autopilot will think you are at a non-zero throttle level.

--- chunk_id: chunk-0035
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 252
content_hash: 11728d9ca6102852
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: How to Arm
document_type: technical_reference

## How to Arm
### ¶
When you are ready to fly you can ask Plane to arm. This can be done in
three ways:

Rudder Arming
. Hold the rudder stick fully to the right and the
throttle stick fully down for 3 seconds. Note

when rudder arming in QuadPlanes with an autotakeoff, the motors will spin at
Q_M_SPIN_ARM
and not takeoff until the rudder stick is returned to neutral. Similarly, for normal plane MODE TAKEOFF, or NAV_TAKEOFFs, the arming will not actually occur until the rudder stick is returned to neutral to prevent the takeoff starting with full right rudder. If setup, you can use one of the
RC_xOPTION switches
that includes that function. See switch option “153”, “154, or “160”. GCS Arming
. Press the arming button on your ground station

Location of the Arm/Disarm button in Mission Planner (button circled in red near the bottom of the image). ¶

Note

Plane does not allow arming in RTL, QRTL, or QLAND modes. Arming in other throttle controlled modes, like LOITER,CRUISE,etc. is possible, but only if actually flying (ie after an accidental inflight disarm, watchdog reset, etc.)

--- chunk_id: chunk-0036
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 322
content_hash: aa2c410316309655
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
section_heading: How to Disarm
document_type: technical_reference

## How to Disarm
### ¶
If setup, you can use one of the
RC_xOPTION
switches that includes that function. See switch option “81”, “153, or “154”. Warning

This is
UNCONDITIONAL
. If done while in flight, all motors disarm and you must have throttle at idle before re-arming can occur! It is also possible to disarm using the transmitter. This is done holding throttle at minimum and rudder to the left for 2
seconds. In ArduPlane this condition could be accidentally triggered by
pilots while flying so there are additional requirements prior to disarm:

You need to allow rudder disarming by changing
ARMING_RUDDER
parameter to 2 (ArmOrDisarm) or use the ARM/DISARM switch function provided by
setting an RC channel’s RCx_OPTION to 153. The autopilot needs to make sure that you are not actually
flying. There is an algorithm for this that uses the
airspeed sensor
readings. So you need this source available and giving values lower
enough (in a windy day you might not be able to disarm even landed
if the plane thinks you are still flying)

You can also disarm without using the transmitter with one of the
following methods:

use a ground station to issue a disarm command

use the safety switch on your aircraft (if using a
Safety Switch
)

after an auto-landing (either via mission or QLAND in QuadPlane) the plane will automatically disarm after 20
seconds if still on the ground (controlled by
LAND_DISARMDELAY
parameter)

--- chunk_id: chunk-0037
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 178
content_hash: 0ba4478ae8ea19d8
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
section_heading: Visual and Audible signals
document_type: technical_reference

## Visual and Audible signals
### ¶
ArduPlane will provide visual and audio clues to the arming state if
your autopilot has notification LEDs and a buzzer. The clues are:

if the autopilot is disarmed, but is ready to arm then the large
3-colour LED will be flashing green

if the autopilot is armed and ready to fly the large 3-colour LED is
solid green

when the autopilot is ready to arm it will play a “ready to arm”
sound on the buzzer

when the autopilot is armed or disarmed it will play the
corresponding sound

See the
sounds page
to listen to what the
buzzer sounds like for each state. Unless the
ARMING_OPTIONS
bit 1 is set, text messages will be sent to the GCS to indicate when arming or disarming has occurred.

--- chunk_id: chunk-0038
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: a940b51b37b13ef0
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: Throttle output when disarmed
document_type: technical_reference

## Throttle output when disarmed
### ¶
When the plane is disarmed the throttle channel will not respond to
pilot input. There are two possible behaviors you can configure:

ARMING_REQUIRE
= 1. When disarmed the minimum value for the throttle
channel (normally RC3_MIN) will be sent to the throttle channel

ARMING_REQUIRE
= 2. When disarmed no pulses are sent to the throttle
channel. Note that some ESCs will beep to complain that they are
powered on without a control signal or even refuse to initialize and operate. ### Diagnosing failure to arm
### ¶
It can be frustrating if your plane refuses to arm. To diagnose arming
issues follow this guide

### In Landing Sequence Pre-Arm Failure
### ¶
If the last mission item was a landing sequence or land command, then arming is prevented and a “Prearm: In Landing Sequence” message is presented. This can occur after an autoland, or if the autopilot is booted before RC is established and the failsafe mode uses a landing sequence (ie
Using DO_LAND_START
and
RTL_AUTOLAND
is set, QLAND, etc.). This may be cleared by restarting the mission using the GCS or
Auxiliary Functions
switch, or rebooting with RC active. ### Check that it is ready to arm
### ¶
If your board has a “ready to arm” LED (the large LED in the middle of
the board on a Pixhawk, for example) then that LED should be flashing green when the
board is ready to arm. If it is flashing yellow then that indicates that
one of the arming checks is not passing. ### Try arming
### ¶
Try sending an arm command with your GCS. If arming is refused then a
message will be sent from the autopilot to the GCS indicating why it is
refusing to arm. ### Rudder arming
### ¶
If you are using right-rudder + zero-throttle to arm and you don’t get a
message on your GCS giving a arming failure reason then it may be that
your RC calibration is a bit off and the autopilot is not quite seeing
zero throttle or isn’t quite seeing full right rudder. ### Reasons for refusing to arm
### ¶
When the autopilot refuses to arm it sends a STATUSTEXT MAVLink message
to the GCS explaining why it is refusing.

--- chunk_id: chunk-0039
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 521
content_hash: b3acc6a87a3847d8
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: Throttle output when disarmed
document_type: technical_reference

### Rudder arming
### ¶
If you are using right-rudder + zero-throttle to arm and you don’t get a
message on your GCS giving a arming failure reason then it may be that
your RC calibration is a bit off and the autopilot is not quite seeing
zero throttle or isn’t quite seeing full right rudder. ### Reasons for refusing to arm
### ¶
When the autopilot refuses to arm it sends a STATUSTEXT MAVLink message
to the GCS explaining why it is refusing. Some possible reasons why the
autopilot can refuse to arm are (See the
Pre-Arm Safety Checks
topic for more information):

barometer not healthy
. This is very rare. If it happens
repeatedly then you may have a barometer hardware fault. airspeed not healthy
. If you have a airspeed sensor fitted and
the autopilot is not getting an airspeed reading it will refuse to
arm. logging not available
. If your microSD card has failed or is
corrupt then logging won’t be available and you cannot arm. gyros not healthy
. If the gyros have failed the autopilot will
refuse to arm. This is rare, and if it happens repeatedly then you
may have a hardware failure. gyros not calibrated
. This happens when the automatic gyro
calibration at startup didn’t converge. Try rebooting the autopilot
with the plane held still. accels not healthy
. If the accelerometers have failed the
autopilot will refuse to arm. Try recalibrating your accelerometers. GPS accuracy errors
. There are 4 types of GPS arming errors that
can be reported. They are “GPS vert vel error”, “GPS speed error”,
“GPS horiz error”, “GPS numsats”. Try moving your plane for better
GPS reception or switching off any RF sources (such as a FPV
transmitter) that may be interfering with your GPS. Mag yaw error
. This happens when your compass is badly out of
alignment. Check your compass orientation and re-do your compass
calibration or move your plane further away from any magnetic
materials. EKF warmup
. This happens when the EKF is still warming up. Wait
another 10 seconds and try again. AHRS not healthy
. This means the EKF is not healthy. Often this is due to large variations in GPS position and/or velocity reports, even if a solid 3D lock is reported by the GPS and HDOP is low.

--- chunk_id: chunk-0040
source_document: arming-your-plane.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: ddbc7fd7a1fe1165
prev_chunk_id: chunk-0039
next_chunk_id: chunk-0041
section_heading: Throttle output when disarmed
document_type: technical_reference

This means the EKF is not healthy. Often this is due to large variations in GPS position and/or velocity reports, even if a solid 3D lock is reported by the GPS and HDOP is low. Be sure your GPS has a clear “view” of the sky with no obstructions. If the error persists then try rebooting your board. 3D accel cal needed
. This happens when you have not done a 3D
accelerometer calibration. Inconsistent accelerometers
. This happens when you have multiple
IMUs (such as the Pixhawk which has two) and they are not consistent. This can be caused by temperature changes. If the error doesn’t clear
itself after a minute you will need to redo your accelerometer
calibration. Inconsistent gyros
. This happens when you have multiple gyros and
they are not reporting consistent values. If the error does not clear
itself after 30 seconds then you will need to reboot. Limit errors
. The arming checks some of your parameter settings
to make sure they are in a reasonable range. The checks are
“ROLL_LIMIT_DEG too small”, “PTCH_LIM_MAX_DEG too small”,
“PTCH_LIM_MIN_DEG too large”, “invalid THR_FS_VALUE”. GPS n has not been fully configured
. This happens with a uBlox
GPS where the GPS driver is unable to fully configure the GPS for
the settings that are being requested. This can be caused by a bad
wire between the autopilot and GPS, or by a bad response from the
GPS. If the message is about “GPS 0” then it is the first GPS. If
it is “GPS 1” then it is the 2nd GPS. If you get a failure for the
2nd GPS and don’t have two GPS modules installed then set GPS_TYPE2
to zero to disable the 2nd GPS






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0041
source_document: auto-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: b627e37a944d8de0
prev_chunk_id: chunk-0040
next_chunk_id: chunk-0042
document_type: technical_reference

AUTO Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- AUTO Mode
Edit on GitHub

# AUTO Mode
# ¶
In AUTO mode Plane will follow a mission (a set of GPS waypoints and other
commands) set by your ground station. When re-entering AUTO
mode Plane will continue from whatever mission item it was last doing,
unless you have reset the mission. If the mission ends with an item that does not continue indefinitely (like LOITER UNLIMITED), an RTL will be executed. When in AUTO Plane will by default allow the pilot to influence the
flight of the plane by using “stick mixing”, which allows for aileron,
elevator and rudder input to steer the plane in a way that can override
the autopilot control. Whether this is enabled is determined by the
STICK_MIXING
option. By default stick mixing behaves the same as
FLY BY WIRE_A (FBWA)
mode. The speed during the mission is nominally at
AIRSPEED_CRUISE
when using an airspeed sensor, or at whatever speed results from
TRIM_THROTTLE
without an airspeed sensor. Setting
THROTTLE_NUDGE
= 1 allows the speed to be increased if the throttle stick is above mid-stick up to
AIRSPEED_MAX
or
THR_MAX
, when using or not using an airspeed sensor, respectively.

--- chunk_id: chunk-0042
source_document: auto-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: adcdca847f264643
prev_chunk_id: chunk-0041
next_chunk_id: chunk-0043
document_type: technical_reference

The speed during the mission is nominally at
AIRSPEED_CRUISE
when using an airspeed sensor, or at whatever speed results from
TRIM_THROTTLE
without an airspeed sensor. Setting
THROTTLE_NUDGE
= 1 allows the speed to be increased if the throttle stick is above mid-stick up to
AIRSPEED_MAX
or
THR_MAX
, when using or not using an airspeed sensor, respectively. Warning

“Home” position is always supposed to be your Plane’s actual
GPS takeoff location:

It is very important to acquire GPS lock before arming in order for
RTL, Loiter, Auto or any GPS dependent mode to work properly. For Plane the home position is initially established at the time the
plane acquires its GPS lock. It is then continuously updated as long as
the autopilot is disarmed. This means if you execute an RTL in Plane, it will return to the location where it was when it was armed - assuming it had acquired GPS lock. Consider the use of
Rally Points
to avoid returning directly to your arming point on RTL.

--- chunk_id: chunk-0043
source_document: auto-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 240
content_hash: db295a454998c05e
prev_chunk_id: chunk-0042
next_chunk_id: chunk-0044
section_heading: MISSION INTERRUPTION
document_type: technical_reference

## MISSION INTERRUPTION
### ¶
Changing out of AUTO Mode leaves whatever mission item being executed in a “suspended” state. Re-entry into AUTO mode later will either resume execution of the mission where it was left or restart the mission depending on the value of the
MIS_RESTART
parameter. By default, it will resume. If you were on the way to Waypoint 3 when changed modes out of AUTO, if re-entered, it will immediately head for Waypoint 3 and continue the mission. You can reset the mission back to the beginning using either the
RCx_OPTION
switch “24”, or via a MAVLink command. Mission Planner has a button in its “Actions” tab of the DATA screen to “Restart Mission”. If
MIS_RESTART
is set to “1”, the the mission will be reset to the start every time AUTO mode is entered. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0044
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 312
content_hash: 71719b965c23a3e2
prev_chunk_id: chunk-0043
next_chunk_id: chunk-0045
document_type: technical_reference

Automatic Landing — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Introducing Plane
Flight Features
Automatic Takeoff
Automatic Landing
Configuring for Automatic Landing
Basic Autolanding
Improving the landing
Inverted Flight
Stall Prevention
Geo-Fencing in Plane
Terrain Following
Soaring
Automated Aerobatics (prior to 4.4)
Automated Aerobatics (4.4 and later)
Moving Vehicle/Ship Takeoff/Landing
High Altitude Glider Drop Pullup
Fixed Wing FAQ
Ready to Fly vehicles
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Plane Introduction
Flight Features
- Automatic Landing
Edit on GitHub

# Automatic Landing
# ¶
This article explains how to autonomously land Plane as part of a mission plan or the new AUTOLAND mode (available in ver 4.7(dev/latest) and later, see
AUTOLAND Mode
), and includes information about how a landing can be safely aborted. Switching to AUTO mode and executing an autolanding can also be done as an RTL action using the
DO_LAND_START
mission command.

--- chunk_id: chunk-0045
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 366
content_hash: cacfe451cbe95d99
prev_chunk_id: chunk-0044
next_chunk_id: chunk-0046
section_heading: Configuring for Automatic Landing
document_type: technical_reference

## Configuring for Automatic Landing
### ¶
To autoland the plane you need to add a
NAV_LAND
command to the end of your mission indicating the latitude, longitude and altitude of your desired touchdown point and if aborting the autoland is allowed. When the preceding waypoint is reached, it will descend and navigate to the touchdown point. In most cases, the altitude should be set to 0. During the final flare portion of the landing, the autopilot will shut down the throttle and hold the current heading, controlled by the parameters described below. Note

the altitude is relative to home, which is set at arming. If you arm while holding for a hand launch, this means home altitude will be several meters above the ground! Warning

often the internal temperature of the vehicle, and hence that of the baro, will change significantly during the flight. While most baros are temperature compensated, this is not usually extremely accurate, leading to the home alt potentially drifting a few meters. This can cause inaccurate flare height to occur. This often occurs when quickly arming the vehicle after riding to the flying site in a car on cold or hot days, or when heat from a component like a video transmitter raises the cabin temperature during a flight after arming. For many vehicles, most of the parameters associated with autolanding can be left at their defaults. The basic parameters are covered below in the Basic Autolanding Section for vehicles not using an airspeed sensor and/or rangefinder. For more advanced configuration, see the sections listed below:

Aborting an Autolanding
Precision Autolanding
RangeFinder Autolanding
Using Reverse Thrust in Autolanding
Using DO_LAND_START

--- chunk_id: chunk-0046
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 444
content_hash: 25a4d6c6f6af99b1
prev_chunk_id: chunk-0045
next_chunk_id: chunk-0047
section_heading: Basic Autolanding
document_type: technical_reference

## Basic Autolanding
### ¶
The phases of an autolanding are:

Passing final approach waypoint

Navigating to the flare point on a “glide-slope” (ie controlled descent)

Flare and touchdown

### Setting Up the Approach Waypoint
### ¶
The autolanding begins after reaching the last navigation waypoint before the NAV_LAND waypoint (where you want to touchdown and land). This waypoint must be far enough from the touchdown point and at an altitude that a reasonable glide slope can be obtained. Without an airspeed sensor, the speed will be that of normal waypoint navigation, which without an airspeed sensor is primarily controlled by
TRIM_THROTTLE
. It is important to have a glide slope that is obtainable with the
TECS_SINK_MAX
rate of the vehicle and preferably, well below that rate. You can lower the approach airspeed in order to reduce the time in the flare, and possible overshoot of landing point, by adjusting the
TECS_LAND_THR
to a lower value than
TRIM_THROTTLE
. Be careful, not to lower it so much as to cause a stall on approach. In addition, the last navigation waypoint before NAV_LAND must be far enough away that any turns made by the mission to that waypoint will have already be completed and the vehicle back on track in a line to the landing point. Usually, two waypoints are used. The first to allow any mission item (including aborted go-arounds for an autoland reattempt) to get aligned to another waypoint setup closer to the touchdown point but still providing a nice glide slope. We will designate the last waypoint before the NAV_LAND as the “final approach” waypoint and the one before it the “pre-approach” waypoint, as shown above. The next figure shows these waypoints
incorrectly
placed, without sufficient spacing:

The above shows a planned approach with the pre-approach waypoint 440m away from touchdown at 50m altitude, the final approach waypoint at 220m away and 25m altitude, giving a supposedly gentle glide slope of 6 degrees (which is a 1.7m/s descent at 15m/s airspeed).

--- chunk_id: chunk-0047
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: 24b36996f9fb1046
prev_chunk_id: chunk-0046
next_chunk_id: chunk-0048
section_heading: Basic Autolanding
document_type: technical_reference

We will designate the last waypoint before the NAV_LAND as the “final approach” waypoint and the one before it the “pre-approach” waypoint, as shown above. The next figure shows these waypoints
incorrectly
placed, without sufficient spacing:

The above shows a planned approach with the pre-approach waypoint 440m away from touchdown at 50m altitude, the final approach waypoint at 220m away and 25m altitude, giving a supposedly gentle glide slope of 6 degrees (which is a 1.7m/s descent at 15m/s airspeed). However, the actual result is 9 deg glide path since the switch to AUTO mode and the landing sequence was begun at the point shown at beginning of the yellow path, and the resulting overshoots at the two waypoints result in a steeper glide slope (9 degrees) between the final approach waypoint and the touchdown point. Spacing the waypoints a little further away would have allowed the approach to have settled by the final approach waypoint, and with the desired final glide slope. The faster the vehicle is flying, the wider the turn radii are, and the wider the waypoints should be spaced. Note

You can use QGroundControl to automatically setup your approach and landing waypoints, but it will use a slightly different approach. Using the “LAND” button on the Plan screen, QGroundControl will add a “LOITER_TO_ALT” waypoint (NAV_LOITER_TO_ALT) at a distance determined by its wizard’s glide slope parameter to bring the vehicle down (or up) to approach altitude, add a DO_LAND_START (See
How to Abort an Autolanding
) marker, and a NAV_LAND. Note

Very low drag vehicles will normally require a much shallower approach angle (glide slope) since they cannot lose altitude quickly while maintaining
AIRSPEED_CRUISE
(for vehicles with airspeed sensors) during the glide slope. Often a much steeper approach is required to clear obstacles. In those cases, there is an option (
TECS_OPTIONS
bit 1) that when set allows the speed in descents to exceed
AIRSPEED_CRUISE
up to
AIRSPEED_MAX
in order to get up the the
TECS_SINK_MAX
descent rate,if required. This would apply not only to autolandings but any TECS speed controlled flight stage. The key parameters that control automatic landing are:

LAND_FLARE_ALT

LAND_FLARE_SEC

LAND_PITCH_DEG

TECS_LAND_SINK

TECS_SINK_MAX

TECS_SINK_MIN

TECS_LAND_THR

Note

The TECS parameters are related to the glide slope and final flare sink control.

--- chunk_id: chunk-0048
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: 292a21ea82cbf9e6
prev_chunk_id: chunk-0047
next_chunk_id: chunk-0049
section_heading: Basic Autolanding
document_type: technical_reference

This would apply not only to autolandings but any TECS speed controlled flight stage. The key parameters that control automatic landing are:

LAND_FLARE_ALT

LAND_FLARE_SEC

LAND_PITCH_DEG

TECS_LAND_SINK

TECS_SINK_MAX

TECS_SINK_MIN

TECS_LAND_THR

Note

The TECS parameters are related to the glide slope and final flare sink control. As such, the
TECS speed/height controller
must be tuned correctly, and the vehicle must have good pitch tuning for TECS to operate properly (see
Tuning
)


The meaning and recommended value of each of these parameters is described below. ### Setting the Flare Point
### ¶
The “flare” is the final stage of the landing when the autopilot cuts the throttle and raises the pitch, increasing drag and slowing the aircraft to sink onto the ground. The appropriate time to flare depends on the type of aircraft, and is controlled by the
LAND_FLARE_ALT
and
LAND_FLARE_SEC
parameters. The first control of the flare is the
LAND_FLARE_SEC
parameter. This is the time in seconds before the aircraft would hit the ground if it continued with its current descent rate. So if the plane is descending at 2 meters/second and you set the
LAND_FLARE_SEC
to 3 then the aircraft would flare at an altitude of 6 meters above the ground. By using a time to impact to control the flare the aircraft is able to flare at a higher altitude if it is descending quickly, and at a lower altitude if it is descending slowly. That helps ensure the flare is able to produce a smooth touchdown. The second control is
LAND_FLARE_ALT
. That is an altitude above the ground in meters at which the aircraft will flare, regardless of its descent rate. It is important that this value be close to the altitude that will usually result from the
LAND_FLARE_SEC
, since it is used in later calculations. Changing the descent rate required from the last waypoint before the landing will impact the height at which
LAND_FLARE_SEC
would become active and should be adjusted accordingly. Whichever is reached first will force the beginning of the flare.The appropriate values for these two parameters depends on how the autopilot is estimating its altitude above the ground. If you are relying solely on a barometer for landing altitude then you will probably need higher values, to account for barometric errors (see
Improving the landing
below).

--- chunk_id: chunk-0049
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 64bade7258f7f82b
prev_chunk_id: chunk-0048
next_chunk_id: chunk-0050
section_heading: Basic Autolanding
document_type: technical_reference

Whichever is reached first will force the beginning of the flare.The appropriate values for these two parameters depends on how the autopilot is estimating its altitude above the ground. If you are relying solely on a barometer for landing altitude then you will probably need higher values, to account for barometric errors (see
Improving the landing
below). The defaults are usually appropriate as a starting point for 1-1.5 meter wingspan vehicles. With a very well tuned vehicle (both Attitude and TECS) and using a rangefinder, lower altitudes can be attempted to start the flare. ### Controlling the glide slope
### ¶
Another important factor in setting up the flare point is the glide slope. The glide slope is the ratio of the distance from the last waypoint to the landing point, and the height difference between the last waypoint and the landing point. For example, if the landing point is 300 meters from the last waypoint, and the last waypoint is 30 meters above the ground then the glide slope is 10%. If the glide slope is too steep then the aircraft will not be able to flare in time to avoid crashing, plus the autopilot may not be able to keep the plane on the approach slope accurately. It is recommended that you start with a glide slope of at most 10%. What glide slope your plane can handle will depend on how good your pitch controller tuning is, how good your TECS tuning is, and the landing speed you ask for. If you find your aircraft is not following the desired glide slope
accurately then you should first check your pitch tuning in your logs,
and ensure that the demanded and achieved pitch match within a couple of
degrees during landing. If they don’t then look at the documentation on
pitch tuning (or possibly re-run AUTOTUNE). If the demanded and achieved
pitch do match then you should check your TECS logs to ensure that the
demanded and achieved airspeed are matching during landing. Have a look
at the
TECS tuning page
for more information. You should also be aware that many model aircraft can glide for long
distances, and it may be that your requested glide slope and airspeed
combination just isn’t achievable.

--- chunk_id: chunk-0050
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 4b4fbfda10697ab6
prev_chunk_id: chunk-0049
next_chunk_id: chunk-0051
section_heading: Basic Autolanding
document_type: technical_reference

Have a look
at the
TECS tuning page
for more information. You should also be aware that many model aircraft can glide for long
distances, and it may be that your requested glide slope and airspeed
combination just isn’t achievable. ### Controlling the flare
### ¶
The final stage of the landing is called the “flare”. During the flare
the aircraft tries to retain a course along the line between the last
waypoint and the landing waypoint, and it controls its height solely
using a target descent rate. Once the flare is started the throttle is
“disabled” - set to some value between
THR_MIN
and
zero. The main job of the autopilot in the flare is to try to achieve
the descent rate specified in the
TECS_LAND_SINK
parameter. That defaults to 0.25 meters/second, which is a reasonable
touchdown vertical speed for most models. To achieve that speed the TECS controller uses pitch control only as the motor has been forced to zero. The primary parameters which affect the ability of the aircraft to
achieve the desired descent rate are
LAND_PITCH_DEG
,
TECS_LAND_DAMP
and the main pitch tuning parameters. Note

If the vehicle does not have good pitch tuning, the vehicle’s CG is significantly “nose heavy”, or the elevator is being increased by propeller slip-stream, then the ability of the vehicle to actually attain the desired sink rates and attitudes can be severely impacted. Symptoms are landing short, and/or with the nose/nose wheel touching down first. The landing controller sets a point before the touchdown as the expected flare start point. This “flare_aim” point is calculated from the
LAND_FLARE_ALT
and
TECS_LAND_SINK
for the expected duration of the flare before the actual touchdown. If consistently landing long or short, this point can be adjusted using the
LAND_FLARE_AIM
parameter. If landing too short, decrease the percentage from its default of 50%, conversely, increasing it if landing too long. The transition from the glide-slope sink rate to the flare sink rate is controlled by the
TECS_FLARE_HGT
parameter and should normally be set below
LAND_FLARE_ALT
.

--- chunk_id: chunk-0051
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: 48657078d7fcd3b2
prev_chunk_id: chunk-0050
next_chunk_id: chunk-0052
section_heading: Basic Autolanding
document_type: technical_reference

If landing too short, decrease the percentage from its default of 50%, conversely, increasing it if landing too long. The transition from the glide-slope sink rate to the flare sink rate is controlled by the
TECS_FLARE_HGT
parameter and should normally be set below
LAND_FLARE_ALT
. The start of the flare will occur at
LAND_FLARE_ALT
and the sink rate will be gradually adjusted to
TECS_LAND_SINK
at the
TECS_FLARE_HGT
to avoid a rapid pitch change at the beginning of the flare, which would tend to create a “ballooning” effect at the start of the flare. See note at the end of this section for a possible exception to having
TECS_FLARE_HGT
set lower than
LAND_FLARE_ALT
. The
LAND_PITCH_DEG
parameter sets the minimum pitch target at the very end of the
flare (in centi-degrees). This parameter is very airframe specific and
is designed to prevent the nose of the aircraft being too far down on
touchdown causing issues with damaging the landing gear or breaking a
propeller. For most aircraft this should be a small positive number
(such as 300, meaning 3 degrees), but for some belly landing aircraft a
small negative number can be good, to allow the nose to be kept down a
small amount to reduce the chance of stall if the flare happens too far
off the ground. Note that the actual pitch of the aircraft can be quite a bit above
LAND_PITCH_DEG
as the TECS controller tries to control the descent rate. The maximum pitch is controlled by the
TECS_PITCH_MAX
parameter if it is non-zero, otherwise by the
PTCH_LIM_MAX_DEG
parameter. However, if the vehicle cannot maintain the demanded pitch attitude in the later stages of the flare due to CG, tuning, etc. LAND_PITCH_DEG
may never be reached resulting in nose/nose wheel first touchdowns. In that case, set the
TECS_FLARE_HGT
ABOVE the
LAND_FLARE_ALT
parameter, effectively allowing the
LAND_PITCH_DEG
limit to take effect immediately, increasing the rate at which its demanded (i.e. at the beginning of the flare as opposed to the end)

The
TECS_LAND_DAMP
parameter is a damping constant for the pitch
control during flare. A larger number will cause the pitch demand to change
more slowly. This parameter can be used to reduce issues with sudden
pitch changes when the flare happens.

--- chunk_id: chunk-0052
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 461
content_hash: 54bf26d6dbedc0b0
prev_chunk_id: chunk-0051
next_chunk_id: chunk-0053
section_heading: Basic Autolanding
document_type: technical_reference

A larger number will cause the pitch demand to change
more slowly. This parameter can be used to reduce issues with sudden
pitch changes when the flare happens. Note

you can use
STICK_MIXING
to allow manual adjustments during the flare, if needed, while tuning the above parameters. Note

For most well tuned vehicles the default values for all the landing parameters should result in safe landings. Iteratively adjusting the altitude limits and the aim point parameter will usually lead to almost perfect, repeatable landings. Analyzing the logs for TECS.dh vs TECS.dhdem and ATT.Pitch vs ATT.DesPitch will show how well the vehicle is attaining the desired attitude and sink rates in the flare. ### After the Flare
### ¶
After the plane flares it continues to navigate, but with zero throttle. The navigation direction is a line extrapolated forward through the
landing point from the last waypoint. Note that the navigation roll will
be limited to
LEVEL_ROLL_LIMIT
(which defaults to 5 degrees) to prevent wing strike, so if there is a
significant cross-wind then it is likely that the aircraft will not be
able to maintain the exact path. If your aircraft is consistently landing long (which can happen for a
variety of reasons) then you can adjust
TECS_LAND_SRC
to
either force a stall (negative) or bring it down (positive). This value
will adjust your
TECS_LAND_SRC
proportional to the distance from
the LAND point. This helps ensure you land in a reasonable distance from
the LAND point. Note

Possible causes of landing long include ground effect giving the
aircraft more lift as it is close to the ground or simply the aircraft
traveling very fast. When the plane has stopped moving for
LAND_DISARMDELAY
seconds (default 20 seconds) it will disarm the motor. Optionally, you
can disable servo movement once LAND_DISARMDELAY has triggered by
setting
LAND_THEN_NEUTRL
. ### Rudder Control during Flare and Rollout
### ¶
If enabled, the ground steering controller will take over below
GROUND_STEER_ALT
to maintain vehicle compass heading below this altitude and during roll out. See
Tuning Ground Steering for a Plane
for details.

--- chunk_id: chunk-0053
source_document: automatic-landing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 474
content_hash: 98e98ea785c6fa30
prev_chunk_id: chunk-0052
next_chunk_id: chunk-0054
section_heading: Improving the landing
document_type: technical_reference

## Improving the landing
### ¶
The key to a good landing is the autopilot knowing how far off the
ground it is. With the default setup the only sensor available to detect
altitude is the barometer. Unfortunately barometers suffer from three
main types of error:

barometric drift due to changes in atmospheric pressure

barometric drift due to changes in the temperature of the autopilot
electronics

barometric error due to local pressure changes from airflow around
the barometer

The ideal setup for good automatic landing is to have a
Lidar
. A Lidar can measure
the distance to the ground very accurately, and doesn’t suffer from
drift. If you have a Lidar installed you can enable its use for landing
with
RNGFND_LANDING
bit 0 or 1 is set. If a Lidar isn’t fitted then there are a few things you can do to minimize barometric error problems with auto-land

perform a barometer calibration after the electronics have warmed up. The easiest way to do this is to disarm the plane with rudder-disarming, arm/disarm switch, or
the safety switch. When the plane is disarmed it assumes it is on the
ground and will zero the barometer to the current pressure. It will also reset the HOME position and altitude. try to prevent direct airflow over the autopilot that could cause
speed related pressure changes

fly shorter flights, allowing for less time for air pressure changes. Check your logs and see if the landing is happening at zero altitude
consistently

Alternatively, you can use a high precision GPS as the altitude source instead of the barometer. See

With planes that belly land it can also work well to setup the landing
with a shallow pitch (in
LAND_PITCH_DEG
) and set a slightly higher
altitude to flare at. That will only work if your stall speed is low
enough that gliding for a while will work reliably. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0054
source_document: autotune-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 370
content_hash: dfdcfab9984a04fb
prev_chunk_id: chunk-0053
next_chunk_id: chunk-0055
document_type: technical_reference

AUTOTUNE Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- AUTOTUNE Mode
Edit on GitHub

# AUTOTUNE Mode
# ¶
The AUTOTUNE mode flies in the same way as
FLY BY WIRE_A (FBWA)
, but it does automatic tuning of roll and pitch
control gains. Please read the
full documentation on AUTOTUNE
for more details. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0055
source_document: circle-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: fcd06234c8a4fe91
prev_chunk_id: chunk-0054
next_chunk_id: chunk-0056
document_type: technical_reference

CIRCLE Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- CIRCLE Mode
Edit on GitHub

# CIRCLE Mode
# ¶
Circle mode is similar to
LOITER
, but doesn’t attempt
to hold position. This is primarily meant to be used as an initial failsafe
mode to allow the vehicle to turn in order to hopefully regain radio control
signal and pilot control. See
failsafe documentation
for more information. Circle mode is deliberately a very conservative mode, and doesn’t rely
on GPS positioning as it is used when GPS fails. It will do a large
circle, The bank angle is set to the
ROLL_LIMIT_DEG
divided by 3, to
try to ensure the plane remains stable even without GPS velocity data
for accelerometer correction. That is why the circle radius is so large. Circle mode uses throttle and pitch control to maintain altitude at the
altitude where it started circling. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0056
source_document: common-accelerometer-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 338
content_hash: 5ebe3eb2149c6bf0
prev_chunk_id: chunk-0055
next_chunk_id: chunk-0057
document_type: technical_reference

Accelerometer Calibration — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Calibration steps
Simple Calibration
Video demonstration (Copter)
Compass Calibration
Flight Modes
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
- Accelerometer Calibration
Edit on GitHub

# Accelerometer Calibration
# ¶
This article shows how to perform basic accelerometer calibration (using
Mission Planner
). The accelerometers in the autopilot must be calibrated to correct for their bias offsets in all three axes, as well as any off-axis variations. Attention

Accelerometer calibration is mandatory in ArduPilot. Important

Accelerometer calibration cannot be performed while the vehicle is armed.

--- chunk_id: chunk-0057
source_document: common-accelerometer-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: e55593f8f472518e
prev_chunk_id: chunk-0056
next_chunk_id: chunk-0058
section_heading: Calibration steps
document_type: technical_reference

## Calibration steps
### ¶
Warning

If the board is mounted in a non-standard orientation (i.e. arrow is not pointing forward) then please ensure the
AHRS_ORIENTATION
is properly set before doing the accelerometer calibration. Tip

For very large vehicles, this may be done on the bench, after the orientation is set for how it will be mounted in the vehicle and the calibration orientations are done as fit in the vehicle. Then be sure to use the
Calibrate Level
step in the following instructions once mounted. Under
Setup | Mandatory Hardware
, select
Accel Calibration
from the left-side menu. Mission Planner: Calibrate Acceleration
¶


Click
Calibrate Accel
to start the full 3-axis calibration. Mission Planner
will prompt you to place the vehicle on each axis during the calibration. Press any key to indicate that the autopilot is in position and then proceed to the next orientation. The calibration positions are: level, right side, left side, nose down, nose up, and on its back. Accelerometer Calibration Positions (Copter)
¶

The vehicle must be kept still immediately after pressing the key for each step. This is more important than getting the angle exactly right, ie. left being 90deg to horizontal, etc. Except for the first “LEVEL”, the positions can be within 20 degrees of being exact. Being still in each position as you press the key is much more important. . Do not hold the vehicle when doing this step, find some way to pose the vehicle (e.g. lie on the ground or put it in a jig). You should calibrate the board mounted in the vehicle if possible. However, you may need to calibrate the board before it is mounted if the size/shape of the vehicle makes this difficult. The level position is the most important to get right as this will be the attitude that your controller considers level while flying. You can recalibrate this Level position using Mission Planner after you have installed the autopilot and are ready to fly. Place the vehicle in its level flying attitude and use the
Calibrate Level
button. Note

this
Calibrate Level
operation can only correct up to a 10 degree difference between the initial calibration and the final position in the vehicle, and only corrects pitch and roll differences, not yaw.

--- chunk_id: chunk-0058
source_document: common-accelerometer-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 337
content_hash: 8c896ea4c9843fa6
prev_chunk_id: chunk-0057
next_chunk_id: chunk-0059
section_heading: Calibration steps
document_type: technical_reference

Place the vehicle in its level flying attitude and use the
Calibrate Level
button. Note

this
Calibrate Level
operation can only correct up to a 10 degree difference between the initial calibration and the final position in the vehicle, and only corrects pitch and roll differences, not yaw. Tip

For planes, the “level” angle for pitch is important for steady altitude flight. See
Tuning Cruise Configuration
for more details. The
STAB_PITCH_DOWN
parameter will add “nose-down” trim when the throttle stick is lowered in pilot throttle controlled and stabilized modes, such as FBWA, to prevent the autopilot from holding the nose up as the plane slows down and potentially causing a stall. This can be tested, at altitude, in FBWA mode by moving the throttle to idle and checking that there is sufficient airspeed in a turn to avoid stalling. Be prepared to recover from a stall! Increase the value of
STAB_PITCH_DOWN
, if necessary. Tip

For small planes or gliders,
STAB_PITCH_DOWN
often needs to be set more than the default value of 2 degrees. Proceed through the required positions, using the
Click when Done
button once each position is reached and held still. When you have completed the calibration process, Mission Planner will display “Calibration Successful!” as shown below. Mission Planner: Calibration Successful
¶


Note

If your autopilot has a built-in IMU heater, then it is recommended that the
IMU Temperature Calibration
also be done. Some autopilots have this calibration done at the factory in which case, this calibration need not be done.

--- chunk_id: chunk-0059
source_document: common-accelerometer-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: 62107f05c930722d
prev_chunk_id: chunk-0058
next_chunk_id: chunk-0060
section_heading: Simple Calibration
document_type: technical_reference

## Simple Calibration
### ¶
Sometimes, for very large vehicles, it’s not easy to do the full 3-axis calibration. In this case, the
Simple Accel Cal
can be done with the vehicle held still and in a level attitude. This only calibrates the main offsets of the accelerometers, not the minor off-axis variations, so it’s not ideal in terms of optimal performance, but is sometimes an acceptable compromise. Note

This is
NOT
the same as the
Calibrate Level
function. To use that function, either a full 3-axis or simple calibration must be done first! ### Video demonstration (Copter)
### ¶
Video demonstration of accelerometer calibration. This is for an older
version of Copter/Mission Planner, but is useful as an example of how
you might hold a Copter. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0060
source_document: common-apm-navigation-extended-kalman-filter-overview.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 188
content_hash: 6dc3d7344b8d4567
prev_chunk_id: chunk-0059
next_chunk_id: chunk-0061
document_type: technical_reference

Extended Kalman Filter (EKF) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
EKF (Extended Kalman Filter)
Should the EKF2 or EKF3 be used?

--- chunk_id: chunk-0061
source_document: common-apm-navigation-extended-kalman-filter-overview.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: b7a402e1ab34849a
prev_chunk_id: chunk-0060
next_chunk_id: chunk-0062
document_type: technical_reference

Extended Kalman Filter (EKF) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
EKF (Extended Kalman Filter)
Should the EKF2 or EKF3 be used? Choosing the EKF and number of cores
Affinity and Lane Switching
GPS / Non-GPS Transitions
Commonly modified parameters
EKF3 Fallback to DCM
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- Extended Kalman Filter (EKF)
Edit on GitHub

# Extended Kalman Filter (EKF)
# ¶
An Extended Kalman Filter (EKF) algorithm is used to
estimate vehicle position, velocity and angular orientation based on
rate gyroscopes, accelerometer, compass, GPS, airspeed and barometric
pressure measurements.

--- chunk_id: chunk-0062
source_document: common-apm-navigation-extended-kalman-filter-overview.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 534
content_hash: c37fc7e0c11f275a
prev_chunk_id: chunk-0061
next_chunk_id: chunk-0063
document_type: technical_reference

Extended Kalman Filter (EKF) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
EKF (Extended Kalman Filter)
Should the EKF2 or EKF3 be used? Choosing the EKF and number of cores
Affinity and Lane Switching
GPS / Non-GPS Transitions
Commonly modified parameters
EKF3 Fallback to DCM
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- Extended Kalman Filter (EKF)
Edit on GitHub

# Extended Kalman Filter (EKF)
# ¶
An Extended Kalman Filter (EKF) algorithm is used to
estimate vehicle position, velocity and angular orientation based on
rate gyroscopes, accelerometer, compass, GPS, airspeed and barometric
pressure measurements. The advantage of the EKF over the simpler complementary filter
algorithms (i.e.

--- chunk_id: chunk-0063
source_document: common-apm-navigation-extended-kalman-filter-overview.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 486
content_hash: 043d2213ad4c140a
prev_chunk_id: chunk-0062
next_chunk_id: chunk-0064
document_type: technical_reference

Choosing the EKF and number of cores
Affinity and Lane Switching
GPS / Non-GPS Transitions
Commonly modified parameters
EKF3 Fallback to DCM
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- Extended Kalman Filter (EKF)
Edit on GitHub

# Extended Kalman Filter (EKF)
# ¶
An Extended Kalman Filter (EKF) algorithm is used to
estimate vehicle position, velocity and angular orientation based on
rate gyroscopes, accelerometer, compass, GPS, airspeed and barometric
pressure measurements. The advantage of the EKF over the simpler complementary filter
algorithms (i.e. “Inertial Nav” or DCM), is that by fusing all available measurements it is better
able to reject measurements with significant errors. This makes the
vehicle less susceptible to faults that affect a single sensor. An EKF also
enables measurements from optional sensors such as optical flow and
laser range finders to be used to assist navigation. Current stable versions of ArduPilot use EKF3 as their primary attitude and position estimation source with DCM running quietly in the background. If the autopilot has two (or more) IMUs available, two EKF “cores” (i.e. two instances of the EKF) will run in parallel, each using a different IMU.

--- chunk_id: chunk-0064
source_document: common-apm-navigation-extended-kalman-filter-overview.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 133
content_hash: 4c9068de23452ae2
prev_chunk_id: chunk-0063
next_chunk_id: chunk-0065
document_type: technical_reference

If the autopilot has two (or more) IMUs available, two EKF “cores” (i.e. two instances of the EKF) will run in parallel, each using a different IMU. At any one time, only the output from a single EKF core is ever used, that core being the one that reports the best health which is determined by the consistency of its sensor data. Most users should not need to modify any EKF parameters, but the information below provides some information on those parameters that are most commonly changed. More detailed information can be found on the
developer EKF wiki page
.

--- chunk_id: chunk-0065
source_document: common-apm-navigation-extended-kalman-filter-overview.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 24d9a923e5b77c4d
prev_chunk_id: chunk-0064
next_chunk_id: chunk-0066
section_heading: Should the EKF2 or EKF3 be used?
document_type: technical_reference

## Should the EKF2 or EKF3 be used? ### ¶
In general, we recommend users stick with the EKF3, which is now the default. In addition, 1MB autopilots only have this option due to space limitations. EKF2 can still be used but does not have many of the enhancements of EKF3 such as newer sensor sources including Beacons, Wheel Encoders and Visual Odometry. ### Choosing the EKF and number of cores
### ¶
AHRS_EKF_USE
: set to “1” to use the EKF, “0” to use DCM for attitude control and ahrs dead reckoning (Plane) for position control. In Copter this parameter is forced to “1” and cannot be changed. AHRS_EKF_TYPE
: set to “2” to use EKF2 for attitude and position estimation, “3” for EKF3. EK2_ENABLE
,
EK3_ENABLE
: set to “1” to enable the EKF2 and/or EKF3 respectively. EK2_IMU_MASK
,
EK3_IMU_MASK
: a bitmask specifying which IMUs (i.e. accelerometer/gyro) to use. An EKF “core” (i.e. a single EKF instance) will be started for each IMU specified. 1: starts a single EKF core using the first IMU

2: starts a single EKF core using only the second IMU

3: starts two separate EKF cores using the first and second IMUs respectively

EK3_PRIMARY
: selects which “core” or “lane” is used as the primary. A value of 0 selects the first IMU lane in the
EK3_IMU_MASK
, 1 the second, etc. Be sure that the selected primary lane exists. See Affinity and Lane Switching below. Note

Plane and Rover will fall back from EKF2 or EKF3 to DCM if the EKF becomes unhealthy or the EKF is not fusing GPS data despite the GPS having 3D Lock. There is no fallback from EKF3 to EKF2 (or EKF2 to EKF1)


Warning

Using the parameters above it is possible to run up to 5 AHRSs in parallel at the same time (DCMx1, EKF2x2, EKF3x2) but this can result in performance problems so if running EKF2 and EKF3 in parallel, set the IMU_MASK to reduce the total number of cores.

--- chunk_id: chunk-0066
source_document: common-apm-navigation-extended-kalman-filter-overview.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 320
content_hash: 2c7c0f20dca93cb7
prev_chunk_id: chunk-0065
next_chunk_id: chunk-0067
section_heading: Affinity and Lane Switching
document_type: technical_reference

## Affinity and Lane Switching
### ¶
EKF3 provides the feature of sensor affinity which allows the EKF cores to also use non-primary instances of sensors, specifically, Airspeed, Barometer, Compass (Magnetometer) and GPS. This allows the vehicle to better manage good quality sensors and be able to switch lanes accordingly to use the best-performing one for state estimation. For more details and configuration, refer
EKF3 Affinity and Lane Switching
. ### GPS / Non-GPS Transitions
### ¶
EKF3 supports in-flight switching of sensors which can be useful for transitioning between GPS and Non-GPS environments. See
GPS / Non-GPS Transitions
for more details. ### Commonly modified parameters
### ¶
EKF sensor sources, see
EKF Source Selection and Switching
. EK3_ALT_M_NSE
: Default is “1.0”. Lower number reduces reliance on accelerometers, increases reliance on barometer. EK3_GPS_TYPE
:
Controls how GPS is used. 0 : use 3D velocity & 2D position from GPS

1 : use 2D velocity & 2D position (GPS velocity does not contribute
to altitude estimate)

2: use 2D position

3 : no GPS (will use
optical flow
only if available)

EK3_YAW_M_NSE
: Controls the weighting between GPS and Compass when calculating the heading. Default is “0.5”, lower values will cause the compass to be trusted more (i.e. higher weighting to the compass)

As mentioned above, a more detailed overview of EKF theory and tuning parameters is available on the developer wiki’s
Extended Kalman Filter Navigation Overview and Tuning
.

--- chunk_id: chunk-0067
source_document: common-apm-navigation-extended-kalman-filter-overview.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 377
content_hash: 636589acb894c117
prev_chunk_id: chunk-0066
next_chunk_id: chunk-0068
section_heading: EKF3 Fallback to DCM
document_type: technical_reference

## EKF3 Fallback to DCM
### ¶
In ArduPlane, the older filter (DCM) is used as a fallback if the EKF3 stops using GPS (ie does not think that the GPS is providing accurate position and velocity) but the GPS is still reporting a 3D lock. In this case, ArduPlane switches to the DCM filter as its position, velocity, and attitude estimator. This is indicated by a GCS message that DCM has now become active. The reasons why EKF3 may start rejecting GPS are varied (but still have GPS 3D lock), but include GPS jamming, high vibrations making the EKF3 think it has moved to a different position inertially than GPS reports, etc. Using DCM (if GPS is indeed still accurate) as a fallback filter is not a real issue for fixed wing flight. It was the original ArduPlane inertial navigation algorithm. For VTOL QuadPlane hovering modes, it is more problematic, since DCM does not consider velocities in its estimator, so hovering is less accurate. If DCM fallback is observed, it would be worthwhile to determine the root cause and address it, since this is not a desired operating mode. However, in some situations where GPS lock is valid, but the GPS may give incorrect data leading to DCM being worse than just using EKF3 without GPS (for example, GPS jamming environments), you may wish to prevent fallback to DCM. This can be accomplished using the bits in the
AHRS_OPTIONS
parameter. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0068
source_document: common-autopilots.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 886
content_hash: 01165a0a99103f1e
prev_chunk_id: chunk-0067
next_chunk_id: chunk-0069
document_type: technical_reference

Choosing an Autopilot — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Open Hardware
AcctonGodwit GA1
ARKV6X DS-10 Pixhawk6
CUAV V5 Plus
CUAV V5 Nano
CUAV Nora
CUAV Pixhawk v6X
CUAV Pixhawk v6X V2
CUAV X7/X7Pro/X7+/X7+ Pro
CUAV-7-Nano
F4BY
CubePilot Cube Black
CubePilot Cube Orange/+
CubePilot Cube Purple
CubePilot Cube Yellow
CubePilot Cube Green
Holybro Durandal H7
Holybro Pix32 v5
Holybro Pixhawk 4
Holybro Pixhawk6X/6X Pro
Holybro Pixhawk6C/ 6C Mini
Holybro Pix32v6(Pixhawk6C variant)
mRo Pixhawk
mRo Pixracer
mRo X2.1
mRo X2.1-777
OpenPilot Revolution
SULIGH7
TauLabs Sparky2
ZeroOneX6/X6 Pro
ZeroOneX6-Air/Air+
Closed Hardware
3DR Control Zero H7 OEM
Aeromind6X
ACNS-CM4Pilot
AEDROX H7
AeroCogito H7Digital
AeroFox H7
Aerotenna Ocpoc-Zynq
AIRBRAINH743
Airvolute DroneCore
AET-H743-Basic
AnyleafH7
AocodaRC H743Dual
ARK FPV
ARK_PI6X
Atlas-Control
AtomRC F405-NAVI
AtomRC F405-NAVI-Deluxe
BCubeF745v2
BetaFPV F405 family
BrahmaF4
BOTWINGF405
brainFPV RADIX2 HD
Brother Hobby F405v3
Brother Hobby H743
CORVON743V1
CORVON743V2
CBUnmanned H743 Stamp
CORVONF405V2.1
CrazyF405
CSKY405
DAKEFPVH743Pro
DAKEFPVH743-SLIM
CUAV-X25-EVO
DAKEFPVF405
DroneerF405
Emlid NAVIO2 (Linux)
F4BY_H743
Flywoo F405 Pro
Flywoo F405HD 1-2S
Flywoo F745 AIO BL_32/ Nano
Flywoo H743
Foxeer F405v2
Foxeer H743 MPU600
Foxeer Reaper F745-AIO V2/V3/V4
Furious FPV F-35 Lightning and Wing FC-10
GEPRC Taker F745
GEPRC Taker H743 BT
GreenSightUltraBlue
HeeWing F405/F405V2
Holybro Kakute F4
Holybro Kakute F4 Mini
Holybro Kakute F7 AIO
Holybro Kakute F4 Wing
Holybro Kakute F7 Mini (only V1 and V2 are compatible)
Holybro Kakute H7 V1
Holybro Kakute H7 V2
Holybro Kakute H7 Wing
Holybro Pixhawk 4 Mini
Holybro Pixhawk5X
Horizon31 PixC4-Jetson
HWH7
iFlight Beast F7 45A AIO
iFlight BeastH7 AIO
iFlight Blitz F745/F745 Mini
iFlight Blitz Whoop F7 AIO
iFlight Blitz H743 Pro
iFlight Blitz Wing H743
iFlight Thunder H7
JAE JFB-110
JFB-100
JFB-110
JFB-200
JHEMCU F405Pro
JHEMCU F405WING
JHEMCU H743HD
KT-FMU-F1
LongBowF405WING
Lumineer LUXF765-NDAA
Mamba F405 MK2
Mamba MK4 F405Mini
Mamba Basic F405 mk3
Mamba H743 v4
MakeFlyEasy PixSurveyA1
MakeFlyEasy PixSurveyA1-IND
MakeFlyEasy PixPilot-C3
MakeFlyEasy PixPilot-V3
MakeFlyEasy PixPilot-V6
MakeFlyEasy PixPilot-V6PRO
Mateksys F405 TE Family
Mateksys H743-Wing/MINI/SLIM/WLITE
Mateksys H7A3-Slim
Mateksys H7A3-Wing
MFT-SEMA100
MicoAir405v2/Mini
MicoAir743
MicoAir743-AIO
MicoAir743-Lite
MicoAir743v2
ModalAI Flight core
Morakot
mRo ControlZero Classic
mRo ControlZero F7
mRo ControlZero H7
mRo COntrolZero H7 OEM
mRo Pixracer Pro (H7)
mRo Nexus
MUPilot
NarinFC-H7/H5
NarinFC-X3
NxtPX4v2
Omnibus F4 AIO/Pro
OmnibusNanoV6
Omnibus F7V2
OrbitH743
OrqaF405
Orqa H7 QuadCore
Parrot C.H.U.C.K
PixFlamingo- F767
PixSurveyA2-IND
RadioLink MiniPix
RadioLinkF405
RadioLinkPIX6
ResoluteH7
QioTek Zealot F427
QioTek Zealot H743
SDMODEL SDH7V1
SDMODEL H7 V2
SequreH743
SIYI N7
SkyDroid-S3
Sky-Drones AIRLink
SkyRukh Surge H7
SkystarsF405 V2
SkySakuraH743
SkystarsH7HD
SkystarsH7HDV2
SPRacing H7 Extreme
SPRacing H7 RF
Swan-K1
Spedix F405
Spedix H743
SpeedyBee F4 (this board currently is non-verified)
SpeedyBee F405 AIO
SpeedyBee F4 V3/V4
SpeedyBee F4 V5
SpeedyBee F405 Mini
SpeedyBeeF405WING/WING Mini
StellarF4
StellarF4V2
StellarH7V2
SVehicle E2
TBS Lucid H7
TBS Lucid H7 V3
TBS Lucid H7 OEM
TBS Lucid H7 Wing
TBS Lucid H7 Wing AIO
ThePeach FCC-K1
ThePeach FCC-R1
TmotorH7Mini
UAV-DEV H7 UM982
VR Brain 5
VR uBrain 5.1
X-MAV-AP-H743v2
X-MAV-AP-H743r1
YARIV6X
YJUAV A6SE
YJUAV A6SE H743
YJUAV-A6Ultra
VUAV-TINYV7
Linux Based Autopilots
BBBMini** (Linux)
Beagle Bone Blue (Linux)
Blue Robotics Navigator** (Linux)
Obal Board (Linux)
Pi PilotPi
PocketBeagle 2 DIY Cape** (Linux)
PocketPilot** (Linux)
T3 Gemstone O1 (Linux)
Firmware Limitations
Firmware Limitations
Discontinued Boards
CUAV V5
Emlid Edge
Erle PXFmini RPi Zero Shield
Erle ErleBrain
Holybro Kakute H7 Mini
Intel Aero
Intel Aero RTF vehicle
Mateksys F405-SE
Mateksys F405-STD and variants*
Mateksys F405-Wing
Mateksys F765-Wing
Mateksys F765-WSE
Drotek Pixhawk3
Schematics
TBS Lucid Pro
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
- Choosing an Autopilot
Edit on GitHub

# Choosing an Autopilot
# ¶
ArduPilot runs on many different autopilot boards.

--- chunk_id: chunk-0069
source_document: common-autopilots.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 916
content_hash: 6a2dd5145eba34de
prev_chunk_id: chunk-0068
next_chunk_id: chunk-0070
document_type: technical_reference

Choosing an Autopilot — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Open Hardware
AcctonGodwit GA1
ARKV6X DS-10 Pixhawk6
CUAV V5 Plus
CUAV V5 Nano
CUAV Nora
CUAV Pixhawk v6X
CUAV Pixhawk v6X V2
CUAV X7/X7Pro/X7+/X7+ Pro
CUAV-7-Nano
F4BY
CubePilot Cube Black
CubePilot Cube Orange/+
CubePilot Cube Purple
CubePilot Cube Yellow
CubePilot Cube Green
Holybro Durandal H7
Holybro Pix32 v5
Holybro Pixhawk 4
Holybro Pixhawk6X/6X Pro
Holybro Pixhawk6C/ 6C Mini
Holybro Pix32v6(Pixhawk6C variant)
mRo Pixhawk
mRo Pixracer
mRo X2.1
mRo X2.1-777
OpenPilot Revolution
SULIGH7
TauLabs Sparky2
ZeroOneX6/X6 Pro
ZeroOneX6-Air/Air+
Closed Hardware
3DR Control Zero H7 OEM
Aeromind6X
ACNS-CM4Pilot
AEDROX H7
AeroCogito H7Digital
AeroFox H7
Aerotenna Ocpoc-Zynq
AIRBRAINH743
Airvolute DroneCore
AET-H743-Basic
AnyleafH7
AocodaRC H743Dual
ARK FPV
ARK_PI6X
Atlas-Control
AtomRC F405-NAVI
AtomRC F405-NAVI-Deluxe
BCubeF745v2
BetaFPV F405 family
BrahmaF4
BOTWINGF405
brainFPV RADIX2 HD
Brother Hobby F405v3
Brother Hobby H743
CORVON743V1
CORVON743V2
CBUnmanned H743 Stamp
CORVONF405V2.1
CrazyF405
CSKY405
DAKEFPVH743Pro
DAKEFPVH743-SLIM
CUAV-X25-EVO
DAKEFPVF405
DroneerF405
Emlid NAVIO2 (Linux)
F4BY_H743
Flywoo F405 Pro
Flywoo F405HD 1-2S
Flywoo F745 AIO BL_32/ Nano
Flywoo H743
Foxeer F405v2
Foxeer H743 MPU600
Foxeer Reaper F745-AIO V2/V3/V4
Furious FPV F-35 Lightning and Wing FC-10
GEPRC Taker F745
GEPRC Taker H743 BT
GreenSightUltraBlue
HeeWing F405/F405V2
Holybro Kakute F4
Holybro Kakute F4 Mini
Holybro Kakute F7 AIO
Holybro Kakute F4 Wing
Holybro Kakute F7 Mini (only V1 and V2 are compatible)
Holybro Kakute H7 V1
Holybro Kakute H7 V2
Holybro Kakute H7 Wing
Holybro Pixhawk 4 Mini
Holybro Pixhawk5X
Horizon31 PixC4-Jetson
HWH7
iFlight Beast F7 45A AIO
iFlight BeastH7 AIO
iFlight Blitz F745/F745 Mini
iFlight Blitz Whoop F7 AIO
iFlight Blitz H743 Pro
iFlight Blitz Wing H743
iFlight Thunder H7
JAE JFB-110
JFB-100
JFB-110
JFB-200
JHEMCU F405Pro
JHEMCU F405WING
JHEMCU H743HD
KT-FMU-F1
LongBowF405WING
Lumineer LUXF765-NDAA
Mamba F405 MK2
Mamba MK4 F405Mini
Mamba Basic F405 mk3
Mamba H743 v4
MakeFlyEasy PixSurveyA1
MakeFlyEasy PixSurveyA1-IND
MakeFlyEasy PixPilot-C3
MakeFlyEasy PixPilot-V3
MakeFlyEasy PixPilot-V6
MakeFlyEasy PixPilot-V6PRO
Mateksys F405 TE Family
Mateksys H743-Wing/MINI/SLIM/WLITE
Mateksys H7A3-Slim
Mateksys H7A3-Wing
MFT-SEMA100
MicoAir405v2/Mini
MicoAir743
MicoAir743-AIO
MicoAir743-Lite
MicoAir743v2
ModalAI Flight core
Morakot
mRo ControlZero Classic
mRo ControlZero F7
mRo ControlZero H7
mRo COntrolZero H7 OEM
mRo Pixracer Pro (H7)
mRo Nexus
MUPilot
NarinFC-H7/H5
NarinFC-X3
NxtPX4v2
Omnibus F4 AIO/Pro
OmnibusNanoV6
Omnibus F7V2
OrbitH743
OrqaF405
Orqa H7 QuadCore
Parrot C.H.U.C.K
PixFlamingo- F767
PixSurveyA2-IND
RadioLink MiniPix
RadioLinkF405
RadioLinkPIX6
ResoluteH7
QioTek Zealot F427
QioTek Zealot H743
SDMODEL SDH7V1
SDMODEL H7 V2
SequreH743
SIYI N7
SkyDroid-S3
Sky-Drones AIRLink
SkyRukh Surge H7
SkystarsF405 V2
SkySakuraH743
SkystarsH7HD
SkystarsH7HDV2
SPRacing H7 Extreme
SPRacing H7 RF
Swan-K1
Spedix F405
Spedix H743
SpeedyBee F4 (this board currently is non-verified)
SpeedyBee F405 AIO
SpeedyBee F4 V3/V4
SpeedyBee F4 V5
SpeedyBee F405 Mini
SpeedyBeeF405WING/WING Mini
StellarF4
StellarF4V2
StellarH7V2
SVehicle E2
TBS Lucid H7
TBS Lucid H7 V3
TBS Lucid H7 OEM
TBS Lucid H7 Wing
TBS Lucid H7 Wing AIO
ThePeach FCC-K1
ThePeach FCC-R1
TmotorH7Mini
UAV-DEV H7 UM982
VR Brain 5
VR uBrain 5.1
X-MAV-AP-H743v2
X-MAV-AP-H743r1
YARIV6X
YJUAV A6SE
YJUAV A6SE H743
YJUAV-A6Ultra
VUAV-TINYV7
Linux Based Autopilots
BBBMini** (Linux)
Beagle Bone Blue (Linux)
Blue Robotics Navigator** (Linux)
Obal Board (Linux)
Pi PilotPi
PocketBeagle 2 DIY Cape** (Linux)
PocketPilot** (Linux)
T3 Gemstone O1 (Linux)
Firmware Limitations
Firmware Limitations
Discontinued Boards
CUAV V5
Emlid Edge
Erle PXFmini RPi Zero Shield
Erle ErleBrain
Holybro Kakute H7 Mini
Intel Aero
Intel Aero RTF vehicle
Mateksys F405-SE
Mateksys F405-STD and variants*
Mateksys F405-Wing
Mateksys F765-Wing
Mateksys F765-WSE
Drotek Pixhawk3
Schematics
TBS Lucid Pro
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
- Choosing an Autopilot
Edit on GitHub

# Choosing an Autopilot
# ¶
ArduPilot runs on many different autopilot boards. Selecting the right board depends on the physical constraints of the
vehicle, features desired, and the applications that you want to run.

--- chunk_id: chunk-0070
source_document: common-autopilots.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 932
content_hash: 02662aefad867d3c
prev_chunk_id: chunk-0069
next_chunk_id: chunk-0071
document_type: technical_reference

Choosing an Autopilot — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Open Hardware
AcctonGodwit GA1
ARKV6X DS-10 Pixhawk6
CUAV V5 Plus
CUAV V5 Nano
CUAV Nora
CUAV Pixhawk v6X
CUAV Pixhawk v6X V2
CUAV X7/X7Pro/X7+/X7+ Pro
CUAV-7-Nano
F4BY
CubePilot Cube Black
CubePilot Cube Orange/+
CubePilot Cube Purple
CubePilot Cube Yellow
CubePilot Cube Green
Holybro Durandal H7
Holybro Pix32 v5
Holybro Pixhawk 4
Holybro Pixhawk6X/6X Pro
Holybro Pixhawk6C/ 6C Mini
Holybro Pix32v6(Pixhawk6C variant)
mRo Pixhawk
mRo Pixracer
mRo X2.1
mRo X2.1-777
OpenPilot Revolution
SULIGH7
TauLabs Sparky2
ZeroOneX6/X6 Pro
ZeroOneX6-Air/Air+
Closed Hardware
3DR Control Zero H7 OEM
Aeromind6X
ACNS-CM4Pilot
AEDROX H7
AeroCogito H7Digital
AeroFox H7
Aerotenna Ocpoc-Zynq
AIRBRAINH743
Airvolute DroneCore
AET-H743-Basic
AnyleafH7
AocodaRC H743Dual
ARK FPV
ARK_PI6X
Atlas-Control
AtomRC F405-NAVI
AtomRC F405-NAVI-Deluxe
BCubeF745v2
BetaFPV F405 family
BrahmaF4
BOTWINGF405
brainFPV RADIX2 HD
Brother Hobby F405v3
Brother Hobby H743
CORVON743V1
CORVON743V2
CBUnmanned H743 Stamp
CORVONF405V2.1
CrazyF405
CSKY405
DAKEFPVH743Pro
DAKEFPVH743-SLIM
CUAV-X25-EVO
DAKEFPVF405
DroneerF405
Emlid NAVIO2 (Linux)
F4BY_H743
Flywoo F405 Pro
Flywoo F405HD 1-2S
Flywoo F745 AIO BL_32/ Nano
Flywoo H743
Foxeer F405v2
Foxeer H743 MPU600
Foxeer Reaper F745-AIO V2/V3/V4
Furious FPV F-35 Lightning and Wing FC-10
GEPRC Taker F745
GEPRC Taker H743 BT
GreenSightUltraBlue
HeeWing F405/F405V2
Holybro Kakute F4
Holybro Kakute F4 Mini
Holybro Kakute F7 AIO
Holybro Kakute F4 Wing
Holybro Kakute F7 Mini (only V1 and V2 are compatible)
Holybro Kakute H7 V1
Holybro Kakute H7 V2
Holybro Kakute H7 Wing
Holybro Pixhawk 4 Mini
Holybro Pixhawk5X
Horizon31 PixC4-Jetson
HWH7
iFlight Beast F7 45A AIO
iFlight BeastH7 AIO
iFlight Blitz F745/F745 Mini
iFlight Blitz Whoop F7 AIO
iFlight Blitz H743 Pro
iFlight Blitz Wing H743
iFlight Thunder H7
JAE JFB-110
JFB-100
JFB-110
JFB-200
JHEMCU F405Pro
JHEMCU F405WING
JHEMCU H743HD
KT-FMU-F1
LongBowF405WING
Lumineer LUXF765-NDAA
Mamba F405 MK2
Mamba MK4 F405Mini
Mamba Basic F405 mk3
Mamba H743 v4
MakeFlyEasy PixSurveyA1
MakeFlyEasy PixSurveyA1-IND
MakeFlyEasy PixPilot-C3
MakeFlyEasy PixPilot-V3
MakeFlyEasy PixPilot-V6
MakeFlyEasy PixPilot-V6PRO
Mateksys F405 TE Family
Mateksys H743-Wing/MINI/SLIM/WLITE
Mateksys H7A3-Slim
Mateksys H7A3-Wing
MFT-SEMA100
MicoAir405v2/Mini
MicoAir743
MicoAir743-AIO
MicoAir743-Lite
MicoAir743v2
ModalAI Flight core
Morakot
mRo ControlZero Classic
mRo ControlZero F7
mRo ControlZero H7
mRo COntrolZero H7 OEM
mRo Pixracer Pro (H7)
mRo Nexus
MUPilot
NarinFC-H7/H5
NarinFC-X3
NxtPX4v2
Omnibus F4 AIO/Pro
OmnibusNanoV6
Omnibus F7V2
OrbitH743
OrqaF405
Orqa H7 QuadCore
Parrot C.H.U.C.K
PixFlamingo- F767
PixSurveyA2-IND
RadioLink MiniPix
RadioLinkF405
RadioLinkPIX6
ResoluteH7
QioTek Zealot F427
QioTek Zealot H743
SDMODEL SDH7V1
SDMODEL H7 V2
SequreH743
SIYI N7
SkyDroid-S3
Sky-Drones AIRLink
SkyRukh Surge H7
SkystarsF405 V2
SkySakuraH743
SkystarsH7HD
SkystarsH7HDV2
SPRacing H7 Extreme
SPRacing H7 RF
Swan-K1
Spedix F405
Spedix H743
SpeedyBee F4 (this board currently is non-verified)
SpeedyBee F405 AIO
SpeedyBee F4 V3/V4
SpeedyBee F4 V5
SpeedyBee F405 Mini
SpeedyBeeF405WING/WING Mini
StellarF4
StellarF4V2
StellarH7V2
SVehicle E2
TBS Lucid H7
TBS Lucid H7 V3
TBS Lucid H7 OEM
TBS Lucid H7 Wing
TBS Lucid H7 Wing AIO
ThePeach FCC-K1
ThePeach FCC-R1
TmotorH7Mini
UAV-DEV H7 UM982
VR Brain 5
VR uBrain 5.1
X-MAV-AP-H743v2
X-MAV-AP-H743r1
YARIV6X
YJUAV A6SE
YJUAV A6SE H743
YJUAV-A6Ultra
VUAV-TINYV7
Linux Based Autopilots
BBBMini** (Linux)
Beagle Bone Blue (Linux)
Blue Robotics Navigator** (Linux)
Obal Board (Linux)
Pi PilotPi
PocketBeagle 2 DIY Cape** (Linux)
PocketPilot** (Linux)
T3 Gemstone O1 (Linux)
Firmware Limitations
Firmware Limitations
Discontinued Boards
CUAV V5
Emlid Edge
Erle PXFmini RPi Zero Shield
Erle ErleBrain
Holybro Kakute H7 Mini
Intel Aero
Intel Aero RTF vehicle
Mateksys F405-SE
Mateksys F405-STD and variants*
Mateksys F405-Wing
Mateksys F765-Wing
Mateksys F765-WSE
Drotek Pixhawk3
Schematics
TBS Lucid Pro
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
- Choosing an Autopilot
Edit on GitHub

# Choosing an Autopilot
# ¶
ArduPilot runs on many different autopilot boards. Selecting the right board depends on the physical constraints of the
vehicle, features desired, and the applications that you want to run. Factors to consider are:

Sensor Redundancy: ArduPilot supports redundant IMUS, GPS, etc.

--- chunk_id: chunk-0071
source_document: common-autopilots.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 480
content_hash: 4cebe53c5e94b7f6
prev_chunk_id: chunk-0070
next_chunk_id: chunk-0072
document_type: technical_reference

Selecting the right board depends on the physical constraints of the
vehicle, features desired, and the applications that you want to run. Factors to consider are:

Sensor Redundancy: ArduPilot supports redundant IMUS, GPS, etc. Many controllers have multiple IMUs integrated on board for applications requiring this level of reliability. Number of Servo/Motor Outputs. Number of UARTs: Telemetry radios, GPS’s, Companion Computers, etc can be attached via these ports. External Buses: I2C, CAN, etc. allow many types of devices, such as airspeed sensors, LED controllers, etc. to be attached to the autopilot. Number of Analog I/O: Some controllers have analog I/O available for such features as inputting receiver signal strength (RSSI) or battery voltage/current or other analog sensors. Integrated Features: Such as on-board OSD (On Screen Display), integrated battery monitoring sensors. Vibration Isolation: Internal mechanical vibration isolators for IMUs for high vibration applications. IMU Heaters: On board temperature control of IMUs for applications in harsh environments or widely varying temperatures during a flight to provide the highest possible precision. Size: Many vehicles have limited space for the autopilot. Expense: Controller prices range from ~$25 to much more, depending on feature set. The sections below provide information about ArduPilot autopilot hardware options. The list below is sorted by manufacturer and product name. Tip

There are also numerous clones and minor variants of the boards linked below. Many of these may be perfectly capable replacements. Help in selecting an autopilot can also be obtained in the user forums (
ArduPilot Discuss
or
RC Groups
). Note

The APM2.6 board is no longer supported for Copter or Plane. The
last firmware builds that can be installed on these boards are AC v3.2.1 and Plane
3.3.0. Note

Not all of these autopilots have been directly tested by ArduPilot development team members and while firmware  is provided by ArduPilot, it does not constitute an endorsement by ArduPilot. However, most boards developed by ArduPilot Partners have been provided to the ArduPilot development team to aid in any possible support issues that might arise. Note

Due to flash memory limitations, most F4 based, and some other boards, do not include all ArduPilot features. See
Firmware Limitations
for details.

--- chunk_id: chunk-0072
source_document: common-autopilots.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 626
content_hash: a1f6f8665b29192c
prev_chunk_id: chunk-0071
next_chunk_id: chunk-0073
section_heading: Open Hardware
document_type: technical_reference

## Open Hardware
### ¶
AcctonGodwit GA1
ARKV6X DS-10 Pixhawk6
CUAV V5 Plus
CUAV V5 Nano
CUAV Nora
CUAV Pixhawk v6X
CUAV Pixhawk v6X V2
CUAV X7/X7Pro/X7+/X7+ Pro
CUAV-7-Nano
F4BY
CubePilot Cube Black
CubePilot Cube Orange/+
CubePilot Cube Purple
CubePilot Cube Yellow
CubePilot Cube Green
Holybro Durandal H7
Holybro Pix32 v5
Holybro Pixhawk 4
Holybro Pixhawk6X/6X Pro
Holybro Pixhawk6C/ 6C Mini
Holybro Pix32v6(Pixhawk6C variant)
mRo Pixhawk
mRo Pixracer
mRo X2.1
mRo X2.1-777
OpenPilot Revolution
SULIGH7
TauLabs Sparky2
ZeroOneX6/X6 Pro
ZeroOneX6-Air/Air+

### Closed Hardware
### ¶
3DR Control Zero H7 OEM
Aeromind6X
ACNS-CM4Pilot
AEDROX H7
AeroCogito H7Digital
AeroFox H7
Aerotenna Ocpoc-Zynq
AIRBRAINH743
Airvolute DroneCore
AET-H743-Basic
AnyleafH7
AocodaRC H743Dual
ARK FPV
ARK_PI6X
Atlas-Control
AtomRC F405-NAVI
AtomRC F405-NAVI-Deluxe
BCubeF745v2
BetaFPV F405 family
BrahmaF4
BOTWINGF405
brainFPV RADIX2 HD
Brother Hobby F405v3
Brother Hobby H743
CORVON743V1
CORVON743V2
CBUnmanned H743 Stamp
CORVONF405V2.1
CrazyF405
CSKY405
DAKEFPVH743Pro
DAKEFPVH743-SLIM
CUAV-X25-EVO
DAKEFPVF405
DroneerF405
Emlid NAVIO2 (Linux)
F4BY_H743
Flywoo F405 Pro
Flywoo F405HD 1-2S
Flywoo F745 AIO BL_32/ Nano
Flywoo H743
Foxeer F405v2
Foxeer H743 MPU600
Foxeer Reaper F745-AIO V2/V3/V4
Furious FPV F-35 Lightning and Wing FC-10
GEPRC Taker F745
GEPRC Taker H743 BT
GreenSightUltraBlue
HeeWing F405/F405V2
Holybro Kakute F4
Holybro Kakute F4 Mini
Holybro Kakute F7 AIO
Holybro Kakute F4 Wing
Holybro Kakute F7 Mini (only V1 and V2 are compatible)
Holybro Kakute H7 V1
Holybro Kakute H7 V2
Holybro Kakute H7 Wing
Holybro Pixhawk 4 Mini
Holybro Pixhawk5X
Horizon31 PixC4-Jetson
HWH7
iFlight Beast F7 45A AIO
iFlight BeastH7 AIO
iFlight Blitz F745/F745 Mini
iFlight Blitz Whoop F7 AIO
iFlight Blitz H743 Pro
iFlight Blitz Wing H743
iFlight Thunder H7
JAE JFB-110
JFB-100
JFB-110
JFB-200
JHEMCU F405Pro
JHEMCU F405WING
JHEMCU H743HD
KT-FMU-F1
LongBowF405WING
Lumineer LUXF765-NDAA
Mamba F405 MK2
Mamba MK4 F405Mini
Mamba Basic F405 mk3
Mamba H743 v4
MakeFlyEasy PixSurveyA1
MakeFlyEasy PixSurveyA1-IND
MakeFlyEasy PixPilot-C3
MakeFlyEasy PixPilot-V3
MakeFlyEasy PixPilot-V6
MakeFlyEasy PixPilot-V6PRO
Mateksys F405 TE Family
Mateksys H743-Wing/MINI/SLIM/WLITE
Mateksys H7A3-Slim
Mateksys H7A3-Wing
MFT-SEMA100
MicoAir405v2/Mini
MicoAir743
MicoAir743-AIO
MicoAir743-Lite
MicoAir743v2
ModalAI Flight core
Morakot
mRo ControlZero Classic
mRo ControlZero F7
mRo ControlZero H7
mRo COntrolZero H7 OEM
mRo Pixracer Pro (H7)
mRo Nexus
MUPilot
NarinFC-H7/H5
NarinFC-X3
NxtPX4v2
Omnibus F4 AIO/Pro
OmnibusNanoV6
Omnibus F7V2
OrbitH743
OrqaF405
Orqa H7 QuadCore
Parrot C.H.U.C.K
PixFlamingo- F767
PixSurveyA2-IND
RadioLink MiniPix
RadioLinkF405
RadioLinkPIX6
ResoluteH7
QioTek Zealot F427
QioTek Zealot H743
SDMODEL SDH7V1
SDMODEL H7 V2
SequreH743
SIYI N7
SkyDroid-S3
Sky-Drones AIRLink
SkyRukh Surge H7
SkystarsF405 V2
SkySakuraH743
SkystarsH7HD
SkystarsH7HDV2
SPRacing H7 Extreme
SPRacing H7 RF
Swan-K1
Spedix F405
Spedix H743
SpeedyBee F4 (this board currently is non-verified)
SpeedyBee F405 AIO
SpeedyBee F4 V3/V4
SpeedyBee F4 V5
SpeedyBee F405 Mini
SpeedyBeeF405WING/WING Mini
StellarF4
StellarF4V2
StellarH7V2
SVehicle E2
TBS Lucid H7
TBS Lucid H7 V3
TBS Lucid H7 OEM
TBS Lucid H7 Wing
TBS Lucid H7 Wing AIO
ThePeach FCC-K1
ThePeach FCC-R1
TmotorH7Mini
UAV-DEV H7 UM982
VR Brain 5
VR uBrain 5.1
X-MAV-AP-H743v2
X-MAV-AP-H743r1
YARIV6X
YJUAV A6SE
YJUAV A6SE H743
YJUAV-A6Ultra
VUAV-TINYV7

--- chunk_id: chunk-0073
source_document: common-autopilots.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 172
content_hash: 4baca50defdf37c1
prev_chunk_id: chunk-0072
next_chunk_id: chunk-0074
section_heading: Linux Based Autopilots
document_type: technical_reference

## Linux Based Autopilots
### ¶
These autopilots use an underlying Linux OS. Linux boards usually have more CPU power and memory many of the other boards listed on this page, but do not support DShot, Bi-Directional DShot, BLHeli ESC passthrough, many of the ArduPilot GPIO based features, and easy upload from the ground stations. They do allow experimentation and development of advanced control and navigation algorithms (see also
Companion Computers
). BBBMini** (Linux)
Beagle Bone Blue (Linux)
Blue Robotics Navigator** (Linux)
Obal Board (Linux)
Pi PilotPi
PocketBeagle 2 DIY Cape** (Linux)
PocketPilot** (Linux)
T3 Gemstone O1 (Linux)

** these devices are sensor add-on boards for a Linux-based microcomputer. See board links for details. Note

For more information on using ArduPilot on Linux based boards, see
Building the code

--- chunk_id: chunk-0074
source_document: common-autopilots.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 276
content_hash: bc05eb7156522e62
prev_chunk_id: chunk-0073
next_chunk_id: chunk-0075
section_heading: Firmware Limitations
document_type: technical_reference

## Firmware Limitations
### ¶
Some boards have features removed in order to fit the firmware into their memory capacity. See the section below:

Firmware Limitations

Note

If a board has a missing feature that is required by the user, building a custom firmware using the
ArduPilot Custom Firmware Build Server
can be used to create firmware which drops features not needed and adding desired features back into the firmware in that freed space. ### Discontinued Boards
### ¶
The following boards are no longer produced, however, documentation is still available in the wiki or online, and recent builds are still expected to work. These boards are not recommended for new projects. CUAV V5
Emlid Edge
Erle PXFmini RPi Zero Shield
Erle ErleBrain
Holybro Kakute H7 Mini
Intel Aero
Intel Aero RTF vehicle
Mateksys F405-SE
Mateksys F405-STD and variants*
Mateksys F405-Wing
Mateksys F765-Wing
Mateksys F765-WSE
Drotek Pixhawk3

The following boards are no longer supported. The documentation is
archived
, but
available if you’re still working on those platforms:

APM 2.x (APM 2.6 and later) are no longer supported for Copter, Plane or Rover. The last firmware builds that fit on this board are Copter 3.2.1, and Plane 3.4.0, and Rover 2.5.1. NAVIO+

PX4FMU

Qualcomm Snapdragon Flight Kit

--- chunk_id: chunk-0075
source_document: common-autopilots.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 77
content_hash: d0cb10643e1c7990
prev_chunk_id: chunk-0074
next_chunk_id: chunk-0076
section_heading: Schematics
document_type: technical_reference

## Schematics
### ¶
Schematics for some of the “Open Hardware” autopilots
can be found here






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0076
source_document: common-canbus-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: 3fc1df988fab0d35
prev_chunk_id: chunk-0075
next_chunk_id: chunk-0077
document_type: technical_reference

CAN Bus Setup — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Overview
Configuration settings
Enabling CAN interfaces
Configuration of CAN interfaces
Configuration of CAN driver
CAN Logging
CAN ESCs
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
EKF (Extended Kalman Filter)
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- CAN Bus Setup
Edit on GitHub

# CAN Bus Setup
# ¶
This article shows how to setup CAN bus and what options users have
to accomplish the setup suitable for their specific needs. Tip

The
DroneCAN setup page is here
.

--- chunk_id: chunk-0077
source_document: common-canbus-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 522
content_hash: 3bf00c2c3b949c8a
prev_chunk_id: chunk-0076
next_chunk_id: chunk-0078
document_type: technical_reference

CAN Bus Setup — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Overview
Configuration settings
Enabling CAN interfaces
Configuration of CAN interfaces
Configuration of CAN driver
CAN Logging
CAN ESCs
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
EKF (Extended Kalman Filter)
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- CAN Bus Setup
Edit on GitHub

# CAN Bus Setup
# ¶
This article shows how to setup CAN bus and what options users have
to accomplish the setup suitable for their specific needs. Tip

The
DroneCAN setup page is here
. But the parameters below must be configured correctly in order to use the DroneCAN driver.

--- chunk_id: chunk-0078
source_document: common-canbus-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 40
content_hash: 9fd7dc6e5fa59a3f
prev_chunk_id: chunk-0077
next_chunk_id: chunk-0079
document_type: technical_reference

Tip

The
DroneCAN setup page is here
. But the parameters below must be configured correctly in order to use the DroneCAN driver. Note

DroneCAN was formerly known as UAVCAN.

--- chunk_id: chunk-0079
source_document: common-canbus-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 296
content_hash: 80861374b8701ab1
prev_chunk_id: chunk-0078
next_chunk_id: chunk-0080
section_heading: Overview
document_type: technical_reference

## Overview
### ¶
A Controller Area Network (CAN bus) is a robust vehicle bus standard designed
to allow microcontrollers and devices to communicate with each other in
applications without a host computer. It is a message-based protocol, designed
originally for multiplex electrical wiring within automobiles to save on copper,
but is also used in many other contexts. All nodes are connected to each other through a two wire bus. The wires are
120 Ω nominal twisted pair. Most autopilots that run ArduPilot have either one or two CAN interfaces
for connection of different devices. ArduPilot can support up to 3 CAN interfaces. The setup of the interfaces can be made in a way that will provide redundancy or
maximum throughput or a mix of both. This is accomplished with a three layer approach, where apart from the physical
interface there exists a driver layer that represents a specific protocol and a
software layer (ArduPilot) that communicates on CAN bus through these drivers. Each physical interface can be virtually connected to one of up to three drivers that
represent the protocols to be used. For example, the most common scenario will be with all
interfaces connected to a DroneCAN driver. Such setup will provide redundancy for devices with
up to three CAN interfaces and full functionality for devices with one CAN interface.

--- chunk_id: chunk-0080
source_document: common-canbus-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 482
content_hash: 0e3c0336d0e659ad
prev_chunk_id: chunk-0079
next_chunk_id: chunk-0081
section_heading: Configuration settings
document_type: technical_reference

## Configuration settings
### ¶
### Enabling CAN interfaces
### ¶
Each physical port can be turned off or connected to corresponding driver with
parameter
CAN_Px_DRIVER
, where x is the number of the CAN port. The value of this parameter is the id of driver that will be associated with this
port (interface). Each enabled bus/driver will use a block of RAM memory (not Flash) depending on the type of driver and if CANFD is enabled. For example, DroneCAN will allocate 12KB for its driver (24K if CANFD) by default, but can vary from board to board depending on its defaults, if set by its hardware definition file. The
CAN_Dx_UC_POOL
parameter can be used to change the pool size. Required pool size depends on bus traffic required by the attached DroneCAN peripheral and can sometimes be reduced for peripherals such as GPS or Compass, whereas peripherals such as ESCs require more bus traffic and therefore a larger pool size. For example, the most common setup will have one driver and all interfaces will be connected
to it. The
CAN_P1_DRIVER
and
CAN_P2_DRIVER
parameters in this configuration should be set to 1 (first
driver). And that driver (
CAN_D1_PROTOCOL
) be set to 1 (DroneCAN). After change of any
CAN_Px_DRIVER
or
CAN_Dx_PROTOCOL
the autopilot has to be rebooted for the changes to take place. ### Configuration of CAN interfaces
### ¶
After enabling the interface and reboot two more parameters can be set for each
of the enabled interfaces. These are:

CAN_Px_BITRATE
- sets the desired rate of transfer on this interface

CAN_Px_DEBUG
- allows output of debug messages

Usually the bitrate used by default is 1 Mbit. Debug level can also be set on user’s preference and needs. When any of the interfaces are associated with any driver, that driver will be
loaded with specified protocol. ### Configuration of CAN driver
### ¶
The driver should be set to use some protocol. Currently there is support for DroneCAN devices,
which is numbered 1, and numerous CAN ESCs and other devices. The parameter
CAN_Dx_PROTOCOL
, where x is the number of driver, should be filled
with the number of protocol for this driver.

--- chunk_id: chunk-0081
source_document: common-canbus-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: 8beb6764d8918f42
prev_chunk_id: chunk-0080
next_chunk_id: chunk-0082
section_heading: Configuration settings
document_type: technical_reference

Currently there is support for DroneCAN devices,
which is numbered 1, and numerous CAN ESCs and other devices. The parameter
CAN_Dx_PROTOCOL
, where x is the number of driver, should be filled
with the number of protocol for this driver. CAN_Dx_PROTOCOL

Protocol Type

0

Disabled

1

DroneCAN

4

PiccoloCAN

6

EFI_NWPMU

7

USD1 (RangeFinder)

8

KDECAN

10

Scripting based CAN driver

11

Benewake (RangeFinder)

12

Scripting2 (allows two drivers)

13

NoopLoop TOFSenseP (RangeFinder)

14

RadarCAN (NanoRadar/Hexsoon RangeFinders)

After the change to protocol the autopilot has to be rebooted for the changes to take place. Note

only devices matching the selected protocol can be connected to a given CAN bus. Mixing of different protocol devices on a single CAN bus is not allowed. However, if the Protocol is set to DroneCAN, certain devices with different protocols can be attached. See
Mixed Protocols on a DroneCAN CAN bus
. ### CAN Logging
### ¶
Logging of all CAN frames can be enabled using the
CAN_P1_OPTIONS
and/or
CAN_P2_OPTIONS
parameters.

--- chunk_id: chunk-0082
source_document: common-canbus-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 105
content_hash: 4e2b8e14e2ed0a7e
prev_chunk_id: chunk-0081
next_chunk_id: chunk-0083
section_heading: CAN ESCs
document_type: technical_reference

## CAN ESCs
### ¶
Several types of CAN based ESCs are supported: DroneCAN, KDECAN, ToshibaCAN, UAVCAN, and PiccoloCAN. For these ESCs, each type use several parameters for configuration. See the ESC’s individual description page
here
. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0083
source_document: common-compass-calibration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 482
content_hash: 86714fa93abc2987
prev_chunk_id: chunk-0082
next_chunk_id: chunk-0084
document_type: technical_reference

Compass Calibration — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Calibration first steps
Onboard Calibration
Onboard Calibration using RC Switch
Large Vehicle MagCal
Compass Ordering
Additional information
Video demonstration
Flight Modes
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
- Compass Calibration
Edit on GitHub

# Compass Calibration
# ¶
Note

Operation of fixed wing Planes and some Rovers is possible without the use of a compass (See
Compass-less Operation
), but utilizing a compass is recommended for all other vehicles unless yaw is provided by some other means (
GPS for Yaw (aka Moving Baseline)
or
Non-GPS Navigation
or
External AHRS Systems
)


This article explains how to perform basic compass calibration. It assumes that you have at least one compass, either internally or externally in the system, and it has been enabled. See
Advanced Compass Setup
for more information and to setup other compass related features. Warning

It is important that when compass calibration is done, the vehicle have a good 3D gps lock, in order to assure the best setup. If necessary, move outdoors in order to get a good 3D gps lock before doing the compass calibration. Note

Compass calibration cannot be performed while vehicle is armed.

--- chunk_id: chunk-0084
source_document: common-compass-calibration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 108
content_hash: 9f39985edb486575
prev_chunk_id: chunk-0083
next_chunk_id: chunk-0085
document_type: technical_reference

If necessary, move outdoors in order to get a good 3D gps lock before doing the compass calibration. Note

Compass calibration cannot be performed while vehicle is armed. Tip

It is not necessary to recalibrate the compass when the vehicle is flown at a new location because ArduPilot includes a “world magnetic model” which allows converting the location’s magnetic North to true North without recalibrating . In addition the location’s “inclination” is calibrated at startup and then again soon after takeoff.

--- chunk_id: chunk-0085
source_document: common-compass-calibration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: 302538546ec41877
prev_chunk_id: chunk-0084
next_chunk_id: chunk-0086
section_heading: Calibration first steps
document_type: technical_reference

## Calibration first steps
### ¶
Warning

Do not calibrate the compasses near any metallic or magnetic field producing object (computers, cell phones, metal desks, power supplies, etc.) or incorrect calibration will occur. Under
SETUP| Mandatory Hardware
select
Compass
. Mission Planner: Compass Calibration
¶

You may wish to disable any internal compasses if you are consistently seeing the “inconsistent compasses” pre-arm message often and you are sure that the external compass is calibrated. ### Onboard Calibration
### ¶
“Onboard Calibration” is a calibration routine that runs on the autopilot. This method is more accurate than the older “Offboard Calibration” (aka “Live Calibration”) which runs on the ground station because in addition to offsets, scaling and orientation are also automatically determined. Note

Calibration could fail for the compasses integrated into the autopilot, if any,  if the
autopilot board orientation
parameter is not correct. To perform the onboard calibration of all compasses:

click the “Onboard Mag Calibration” section’s “Start” button

if your autopilot has a buzzer attached you should hear a single tone followed by short beep once per second

hold the vehicle in the air and rotate it so that each side (front, back, left, right, top and bottom) points down towards the earth for a few seconds in turn. Consider a full 360-degree turn with each turn pointing a different direction of the vehicle to the ground. It will result in 6 full turns plus possibly some additional time and turns to confirm the calibration or retry if it initially does not pass. as the vehicle is rotated the green bars should extend further and further to the right until the calibration completes

upon successful completion three rising tones will be emitted and a “Please reboot the autopilot” window will appear and you will need to reboot the autopilot before it is possible to arm the vehicle. If calibration fails:

you will hear an “unhappy” failure tone, the green bars may reset to the left, and the calibration routine may restart (depending upon the ground station). Mission Planner will automatically retry, so continue to rotate the vehicle as instructed above. if a compass is not calibrating, consider moving to a different area away from magnetic disturbances, and remove electronics from your pockets.

--- chunk_id: chunk-0086
source_document: common-compass-calibration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 129
content_hash: 35d07ba10973cd5a
prev_chunk_id: chunk-0085
next_chunk_id: chunk-0087
section_heading: Calibration first steps
document_type: technical_reference

Mission Planner will automatically retry, so continue to rotate the vehicle as instructed above. if a compass is not calibrating, consider moving to a different area away from magnetic disturbances, and remove electronics from your pockets. if, after multiple attempts, the compass has not passed the calibration, Press the “Cancel” button and change the “Fitness” drop-down to a more relaxed setting and try again. if compass calibration still fails it may help to raise
COMPASS_OFFS_MAX
from 850 to 2000 or even 3000

finally, if a single compass is not calibrating and you trust the others, disable it.

--- chunk_id: chunk-0087
source_document: common-compass-calibration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 298
content_hash: 16c4cadc66221fb8
prev_chunk_id: chunk-0086
next_chunk_id: chunk-0088
section_heading: Onboard Calibration using RC Switch
document_type: technical_reference

## Onboard Calibration using RC Switch
### ¶
Onboard Calibration can be started using an RC switch instead using the Mission Planner technique above. This allows calibrating without the tangle of the USB cable. Setup an RC channel to start the calibration by setting its
RCx_OPTION
to be “171”. A high value on the channel will start calibrating all compasses and you would move the vehicle as above. A low value will cancel the calibration. The tones for success or failure above will be emitted. ### Large Vehicle MagCal
### ¶
Large or heavy vehicles are impractical to rotate on all axis. This feature allows a fairly accurate calibration if GPS lock is active on the autopilot and the vehicles actual heading is known, either using a landmark reference on the Mission Planner map, or using another compass (eg cell phone) and entering the vehicles heading. Warning

The proper orientation of the compass must also be set in order for this method to give a good result. If orientation is incorrect this procedure will appear to succeed while leaving the compass calibration in a very bad state. Note

the heading entered should be TRUE, not MAGNETIC. Using a phone’s compass app will usually required adding the local declination value to the reading in order to obtain the TRUE geographic heading which should be entered.

--- chunk_id: chunk-0088
source_document: common-compass-calibration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: 90871b0a9211cf5c
prev_chunk_id: chunk-0087
next_chunk_id: chunk-0089
section_heading: Compass Ordering
document_type: technical_reference

## Compass Ordering
### ¶
At the top of the page, you can change the priority of the attached compasses, if desired. ### Additional information
### ¶
More information about compass configuration can be found in
Advanced Compass Setup
. This includes instructions for how to set up additional compasses,
automatic setting of offsets
, non-standard compass alignments,
compassmot
, etc. General discussion on magnetic interference and ways to reduce it can be
found in
Magnetic Interference
. ### Video demonstration
### ¶
Video demonstrations of compass calibration. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0089
source_document: common-connect-mission-planner-autopilot.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 294
content_hash: 8e174e162035cf52
prev_chunk_id: chunk-0088
next_chunk_id: chunk-0090
document_type: technical_reference

Connect Mission Planner to AutoPilot — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Setting up the connection
Connecting to multiple vehicles
Troubleshooting
Troubleshooting Composite Connections
Related topics
Configuration
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
- Connect Mission Planner to AutoPilot
Edit on GitHub

# Connect Mission Planner to AutoPilot
# ¶
This article explains how to connect
Mission Planner
to an autopilot
in order to receive telemetry and control the vehicle. Note

There are separate instructions for connecting in order to
Load Firmware
for existing ArduPilot firmware installations, or for boards
without existing ArduPilot firmware
.

--- chunk_id: chunk-0090
source_document: common-connect-mission-planner-autopilot.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 468
content_hash: 2160ad010ef744fa
prev_chunk_id: chunk-0089
next_chunk_id: chunk-0091
section_heading: Setting up the connection
document_type: technical_reference

## Setting up the connection
### ¶
To establish a connection you must first choose the communication
method/channel you want to use, and then set up the physical hardware
and Windows device drivers. You can connect the PC and autopilot using
USB cables,
Telemetry Radios
,
Bluetooth
,
IP connections etc. Note

The driver for your connection hardware must be present on Windows
as this makes your connection’s COM port and default data rate available
to
Mission Planner
. Pixhawk USB Connection
¶

Connection using SiK Radio
¶

On
Mission Planner
, the connection and data rate are set up using the
drop down boxes in the upper right portion of the screen. Once you’ve attached the USB or Telemetry Radio, Windows will
automatically assign your autopilot a COM port number, and that will
show in the drop-down menu (the actual number does not matter). The
appropriate data rate for the connection is also set (typically the USB
connection data rate is 115200 and the radio connection rate is 57600). Select the desired port and data rate and then press the
CONNECT
button to connect to the autopilot. After connecting
Mission Planner
will download parameters from the autopilot and the button will change
to
DISCONNECT
as shown:

Tip

The “select port” dropdown also contains TCP or UDP port options
that can be used to connect to an autopilot over a network. The “Stats…” hotlink beneath the port selection box, if clicked, will give information about the connection, such as if
Signing security
is active, link stats, etc. Sometimes this window pops up beneath the current screen and will have to be brought to the front to be seen. ### Connecting to multiple vehicles
### ¶
Additional connections can be made by right-clicking the
CONNECT
button and selecting
Connection Options
from the drop-down list. A file with a pre-written list of connections can be loaded with the
Connection List
drop-down option. This is an example format of the file:

tcp
:
//
127.0.0.1
:
5670
udp
:
//
127.0.0.1
:
14550
udpcl
:
//
192.168.1.255
:
14550
serial
:
com4
:
115200

--- chunk_id: chunk-0091
source_document: common-connect-mission-planner-autopilot.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 341
content_hash: 9c9ad5c23e7c8ce3
prev_chunk_id: chunk-0090
next_chunk_id: chunk-0092
section_heading: Troubleshooting
document_type: technical_reference

## Troubleshooting
### ¶
If Mission Planner is unable to connect:

Check that the correct baud rate is used for the selected method
(115200 on USB or 57600 on Radio/Telemetry)

If attaching via USB, be sure that a few seconds after power up have passed before attempting to connect. If you attempted to connect during the bootloader initialization time, Windows may get the wrong USB information. Connection attempts after this may require that the USB connection be  unplugged and re-plugged,then wait for bootloader to enter the main code ( few seconds), then attempt the connection. Occasionally, MP must be restarted if an attempt to connect is made while in the bootloader initialization period. If using a COM port on Windows, check that the connection’s COM port
exists in the Windows Device Manager’s list of serial ports. If your autopilot has an F7 or H7 processor and has CAN ports, then see the section below,
Troubleshooting Composite Connections

If using a USB port, try a different physical USB port

If using a UDP or TCP connection, check that your firewall is not blocking IP traffic

You should also ensure that the autopilot controller board has
appropriate ArduPilot firmware installed and has booted correctly (on
Pixhawk there are useful
LEDs
and
Sounds
which can tell you the state of the autopilot). If using a remote link (not USB) and Mission Planner connects, but does not download parameters or you cannot get commands, like mode changes acted upon,then the autopilot probably has Signing turned on. See
MAVLink2 Signing
.

--- chunk_id: chunk-0092
source_document: common-connect-mission-planner-autopilot.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 474
content_hash: ef87316af5dbf041
prev_chunk_id: chunk-0091
next_chunk_id: chunk-0093
section_heading: Troubleshooting Composite Connections
document_type: technical_reference

## Troubleshooting Composite Connections
### ¶
Autopilots with F7 or H7 processors and having CAN interfaces use firmware that presents two USB interfaces: One for the normal MAVLink connection, and one for SLCAN serial connections to the CAN interface for configuration and firmware updates.This is called a composite USB device. By default, the MAVLink USB interface is SERIAL0 and the SLCAN USB interface is the highest SERIALx port the board presents. The Windows driver currently installed with Mission Planner may select to use either one, and since both are set by default in ArduPilot firmware for MAVLINK protocol, it will work fine, whichever one it chooses as the COM port. However, there is a situation where the user will find that it will not connect to the obvious COM port in the Mission Planner dropdown box.This occurs when the user accidentally changes the protocol of whichever SERIALx port the Windows driver is using as the MAVLink COM port to something other than MAVLink. This can easily happen if the user takes an existing parameter file from a vehicle configuration used with a different autopilot that has the protocol changed. For example, the user has a plane with non F7/H7 CAN capable autopilot and upgrades it to one that is, then loads his existing parameter file while setting up the plane with the new autopilot. As soon as the parameter file is loaded and the autopilot is rebooted, communication is lost and cannot be re-established. What has occurred, is that the protocol for the SERIALx port that Windows was using has been changed. Almost always, this is the highest numbered SERIALx port since that is commonly set to -1 on non-CAN capable autopilots, and the Windows COM port driver has selected this interface as the COM port instead of SERIAL0. The procedure to recover is as follows:

Go to Windows Device Manager and find the COM port being used by the autopilot in the Ports listings. It will have the COM Port # you used to connect initially to Mission Planner. Right click and it will present “Update driver software” as one of the options. Click it.

--- chunk_id: chunk-0093
source_document: common-connect-mission-planner-autopilot.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 276
content_hash: fadceef37d70c116
prev_chunk_id: chunk-0092
next_chunk_id: chunk-0094
section_heading: Troubleshooting Composite Connections
document_type: technical_reference

Right click and it will present “Update driver software” as one of the options. Click it. Click the “Browse my computer……” option and then click the “Choose from a list…” option and you will see this screen:

Scroll down the top list until “Composite USB” option appears and click it. Now reconnect your autopilot to the PC and two COM ports will be presented. One will connect (the remaining one with MAVLink Protocol) and the other will not. If you do not connect to one, try the other. But DO NOT disconnect the autopilot from the PC or the composite driver will unload and you will have to start over. Now that you are connected to Mission Planner, change back the protocol of the Serialx port protocol to 2 (MAVLink2). You can now disconnect and reconnect the autopilot and it will present only one COM port and you should be able to connect from now on. Do not change this protocol from now on unless trying to utilize the SLCAN interface. It may be a bit unfamiliar since the Mission Planner SERIALx port being used is no longer the normal SERIAL0 but rather,the highest port, but this does not affect anything in the autopilot’s configuration and operation.

--- chunk_id: chunk-0094
source_document: common-connect-mission-planner-autopilot.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 68
content_hash: b83a5793a73d2cf1
prev_chunk_id: chunk-0093
next_chunk_id: chunk-0095
section_heading: Related topics
document_type: technical_reference

## Related topics
### ¶
Mission Planner Bluetooth Connectivity





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0095
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 264
content_hash: 8e7e01e1471f43ca
prev_chunk_id: chunk-0094
next_chunk_id: chunk-0096
document_type: technical_reference

Diagnosing some common problems using Logs — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Logs
Log Types (Dataflash vs Tlogs)
Topics related to logging and analysis
Tools for Log Analysis
What to do if you have an issue
Vehicle Will Not Arm
Interference issues on Electric Vehicles
Free RAM issues
H7 AutoPilot Will Not Initialize
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
When Problems Arise
Logs
- Diagnosing some common problems using Logs
Edit on GitHub

# Diagnosing some common problems using Logs
# ¶
This page show how to diagnose the six most common problems affecting Copter in particular but to some extent Plane and Rover as well.

--- chunk_id: chunk-0096
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: 3da9235a98c7ddb6
prev_chunk_id: chunk-0095
next_chunk_id: chunk-0097
section_heading: Mechanical Failures
document_type: technical_reference

## Mechanical Failures
### ¶
Common mechanical failures include a motor or ESC failure (
including ESC sync failures
), the propeller breaking or coming off, etc. These appear in the log as a sudden divergence in the desired roll and pitch vs the vehicle’s actual roll and pitch. This divergence is visible by graphing the ATT message’s DesRoll vs Roll, DesPitch vs Pitch and to a lesser extent DesYaw vs Yaw. In the example above the vehicle’s actual roll (“Roll”) closely follows the desired roll (“DesRoll”) for the first part of the log but then suddenly diverges. The autopilot wanted the roll to remain level (“Roll” = 0) but it was unable to likely meaning there was a mechanical failure. This is very different from a software failure in which the autopilot freaked out and for some strange reason suddenly wanted the copter up-side-down because in such cases the DesRoll would be also be crazy and actual Roll would follow. Tlogs contain the same data. Compare NAV_CONTROLLER_OUTPUT’s nav_roll (desired roll) and nav_pitch (desired pitch) to ATTITUDE.roll (actual roll) and pitch (actual pitch).

--- chunk_id: chunk-0097
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 194
content_hash: c1c22c74651c047d
prev_chunk_id: chunk-0096
next_chunk_id: chunk-0098
section_heading: Vibrations
document_type: technical_reference

## Vibrations
### ¶
High vibrations can cause the Copter’s accelerometer based altitude and horizontal position estimates to drift far off from reality which leads to problems with altitude hold (the vehicle may rocket into the sky) or position control in modes like Loiter, PosHold, Auto, etc. As covered on the
Measuring Vibration
page, vibrations are best viewed by graphing the
VIBE
message’s
VibeX
,
VibeY
and
VibeZ
values. Vibration levels below 30m/s/s are normally acceptable. Levels above 30m/s/s may have problems and levels above 60m/s/s nearly always have problems with position or altitude hold. The below graph shows acceptable vibration levels which are consistently below 30m/s/s

The graph below is from a vehicle that had position estimation problems due to high vibrations

Tlog’s VIBRATION
vibration_x
,
vibration_y
and
vibration_z
can also be used and show the same information as is stored to the dataflash log

--- chunk_id: chunk-0098
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 445
content_hash: 1fa039850df88d29
prev_chunk_id: chunk-0097
next_chunk_id: chunk-0099
section_heading: Compass interference
document_type: technical_reference

## Compass interference
### ¶
Interference from the power distribution board, motors, battery, ESCs and other electrical devices near the autopilot can throw off the compass heading which can lead to circling (aka “toilet bowling”) or even the copter flying off in completely the wrong direction. Graphing the tlog’s mag_field (found under “CUSTOM”) and throttle (found under VFR_HUD) is the easiest way to quickly see the amount of interference. The graph below shows an acceptable amount of magnetic interference with mag_field fluctuations of only 10% to 20% when the throttle is raised. Below 30% interference is acceptable. Between 30% ~ 60% is in the grey zone where it might be OK (some users are OK, some are not) and really bad magnetic interference will show up as jumps of over 60% when the throttle is raised. Extra Notes:

The length of the mag_field can be anywhere from 120 ~ 550 depending upon where in the world the vehicle is but it is normally around 330

The magnetic interference as a percentage of the total mag field is also displayed at the end of the compassmot set-up procedure. Search for “CompassMot” on the
Advanced Compass Setup page
page to learn more about compassmot

Dataflash log’s COMPASS message hold the compass’s raw x, y and z axis values (called MagX, MagY, MagZ) which are equivalent to the tlog’s RAW_IMU xmag, ymag and zmag fields. It is possible to calculate the mag-field length by first loading the dataflash log file into excel, filtering by the COMPASS message and then calculating the mag-field using the formula mag_field = sqrt(MagX^2, MagY^2, MagZ^2). Note that the COMPASS message is not enabled by default in the dataflash logs because it runs at 50hz and does affect CPU performance a bit. The image above it shows a short spike at the beginning of the graph but this can be ignored because it is before the throttle is raised so it is probably just as the user plugged in some other electrical device

--- chunk_id: chunk-0099
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 228
content_hash: 1d597af73d5b13f5
prev_chunk_id: chunk-0098
next_chunk_id: chunk-0100
section_heading: GPS glitches
document_type: technical_reference

## GPS glitches
### ¶
When in autonomous modes (Loiter, RTL, Auto, etc) position errors from the GPS can cause the vehicle to think that it is suddenly in the wrong place and lead to aggressive flying to correct the perceived error. These “glitches” show up in both the tlogs and dataflash logs as a decrease in the number of satellites visible and an increase in the
hdop
. Graph the Dataflash log’s GPS message’s “HDop” and “NSats” values. Hdop values below 1.5 are very good, values over 2.0 could indicate the GPS positions are not good. The number of satellites falling below 12 is also bad. A significant change in these two values often accompanies a GPS position change. If using tlogs graph the GPS_RAW_IT group’s “eph” and “satellites_visible” values. Hdop values below 150 are good, values over 200 could indicate a bad position. See the
EKF failsafe
wiki page for more details on how the vehicle may switch to non-autonomous modes in the case of very bad GPS glitches

--- chunk_id: chunk-0100
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 284
content_hash: 263250780cbd877b
prev_chunk_id: chunk-0099
next_chunk_id: chunk-0101
section_heading: Power Problems (BrownOuts, etc)
document_type: technical_reference

## Power Problems (BrownOuts, etc)
### ¶
Power Modules
provide a reliable power supply to the autopilot but brown-outs do still occasionally occur. They can normally be recognised by the logs suddenly ending while the vehicle is still in the air (i.e. barometer or EKF altitude is still reporting the vehicle’s altitude is well above zero). Try graphing the:

Dataflash log’s CTUN Alt (altitude above home) or BAlt (Barometer altitude)

Dataflash log’s GPS Alt (altitude above sea level)

Tlog’s VFR_HUD alt (the combined accelerometer + barometer altitude estimate)

Tlog’s GLOBAL_POSITION relative_alt (altitude above home)

Changes in the board voltage can also be a sign of a power problem. Variations of 0.10 to 0.15 volts are normal. Beyond that could be a sign that other devices sharing the power source with the autopilot are causing ripples in the power supply that could lead to a brown-out. The board voltage can be graphed using:

Dataflash POWR message’s VCC

Tlog HWSTATUS’s Vcc

In the image directly below shows the board voltage sinking by 0.15V when the throttle is raised. This is generally not a good thing but because it’s only 0.15V it’s probably OK. The 2nd graph below (a dataflash graph from a different user’s log) shows a very stable voltage with ripples less than 0.1V.

--- chunk_id: chunk-0101
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 02cc1b9148d0b3da
prev_chunk_id: chunk-0100
next_chunk_id: chunk-0102
section_heading: Unexpected ERRORS including Failsafes
document_type: technical_reference

## Unexpected ERRORS including Failsafes
### ¶
When unexpected behaviour from the autopilot occurs (especially when the user complains that the copter no longer responded to their input) it is often caused by one of the
failsafes
being triggered. The easiest way to find these is to look in the dataflash logs and filter the first column by “ERR”. If using the Mission Planner, the errors will also appear in red markers at the top of the graphing area. The Subsys (aka Sub-system) gives the area that generated the error and the ECode (aka Error Code) tells you what the error was specifically. The list of subsystems and error codes can be found in the AP_Logger library
AP_Logger.h file
. Subsys
ECode and Description
2 = Radio
0 = Errors Resolved

2 = Late Frame : no updates received from receiver for two seconds

3 = Compass
0 = Errors Resolved

1 = Failed to initialise (probably a hardware issue)

4 = Unhealthy : failed to read from the sensor

5 = Radio Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

6 = Battery Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

8 = GCS Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

9 = Fence Failsafe
0 = Failsafe Resolved

1 = Altitude fence breach, Failsafe Triggered

2 = Circular fence breach, Failsafe Triggered

3 = Both Alt and Circular fence breached, Failsafe Triggered

4 = Polygon fence breached, Failsafe Triggered

10 = Flight mode Change failure
Vehicle was unable to enter the desired flight mode normally because of a bad position estimate

See
flight mode numbers here
for Copter,
Plane modes here
, and
Rover modes here

11 = GPS
0 = Glitch cleared

2 = GPS Glitch occurred

12 = Crash Check
1 = Crash into ground detected. Normally vehicle is disarmed soon after

2 = Loss of control detected.

--- chunk_id: chunk-0102
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 680
content_hash: 3fa4dc1a7cacc313
prev_chunk_id: chunk-0101
next_chunk_id: chunk-0103
section_heading: Unexpected ERRORS including Failsafes
document_type: technical_reference

Subsys
ECode and Description
2 = Radio
0 = Errors Resolved

2 = Late Frame : no updates received from receiver for two seconds

3 = Compass
0 = Errors Resolved

1 = Failed to initialise (probably a hardware issue)

4 = Unhealthy : failed to read from the sensor

5 = Radio Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

6 = Battery Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

8 = GCS Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

9 = Fence Failsafe
0 = Failsafe Resolved

1 = Altitude fence breach, Failsafe Triggered

2 = Circular fence breach, Failsafe Triggered

3 = Both Alt and Circular fence breached, Failsafe Triggered

4 = Polygon fence breached, Failsafe Triggered

10 = Flight mode Change failure
Vehicle was unable to enter the desired flight mode normally because of a bad position estimate

See
flight mode numbers here
for Copter,
Plane modes here
, and
Rover modes here

11 = GPS
0 = Glitch cleared

2 = GPS Glitch occurred

12 = Crash Check
1 = Crash into ground detected. Normally vehicle is disarmed soon after

2 = Loss of control detected. Normally parachute is released soon after

13 = Flip mode
2 = Flip abandoned (not armed, pilot input or timeout)
15 = Parachute
2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check
0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer
0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe
0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data
2 = missing terrain data
22 = Navigation
2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed
0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check
0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub)
0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub)
0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only)
0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe
0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
.

--- chunk_id: chunk-0103
source_document: common-diagnosing-problems-using-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 469
content_hash: 487f33d2c4543669
prev_chunk_id: chunk-0102
next_chunk_id: chunk-0104
section_heading: Unexpected ERRORS including Failsafes
document_type: technical_reference

Normally vehicle is disarmed soon after

2 = Loss of control detected. Normally parachute is released soon after

13 = Flip mode
2 = Flip abandoned (not armed, pilot input or timeout)
15 = Parachute
2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check
0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer
0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe
0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data
2 = missing terrain data
22 = Navigation
2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed
0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check
0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub)
0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub)
0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only)
0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe
0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0104
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 465
content_hash: c16f4eea10bf602e
prev_chunk_id: chunk-0103
next_chunk_id: chunk-0105
document_type: technical_reference

Downloading and Analyzing Data Logs in Mission Planner — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Logs
Log Types (Dataflash vs Tlogs)
Topics related to logging and analysis
Tools for Log Analysis
What to do if you have an issue
Vehicle Will Not Arm
Interference issues on Electric Vehicles
Free RAM issues
H7 AutoPilot Will Not Initialize
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
When Problems Arise
Logs
- Downloading and Analyzing Data Logs in Mission Planner
Edit on GitHub

# Downloading and Analyzing Data Logs in Mission Planner
# ¶
Dataflash logs are stored on the autopilot
and can be downloaded after a flight. By default, they are created after you first
arm the vehicle. This topic explains how to configure and access
Dataflash logs. Depending on the autopilot type and configuration, the dataflash logs may be saved on a SD card, dataflash chip or streamed over MAVLink telemetry ports. The MAVLink option does require a high-speed telemetry port, typically 921600 baud. Note

In addition to using Mission Planner, many other tools are available to users for log analysis:
MAVExplorer(part of MAVProxy installation)
and
Web-based tools
. Note

Telemetry logs
(also known as “tlogs”) collect similar information to dataflash logs (see
Diagnosing problems using Logs
for more information). Note

If your vehicle is having trouble producing dataflash logs - including the infamous “No IO heartbeat” diagnostic message - try a different SD card. You may also choose to test the card using a dedicated tool, such as
H2testw
. Low board voltages are also known to cause logging issues.

--- chunk_id: chunk-0105
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: c452a832f31d36b3
prev_chunk_id: chunk-0104
next_chunk_id: chunk-0106
section_heading: Logging Parameters
document_type: technical_reference

## Logging Parameters
### ¶
Some commonly used parameters are:

LOG_BACKEND_TYPE
: Bitmask for where to save logs to. Common values are “0” to disable logging, “1” (bit 0 set) to log to SD card file, “2”(bit 1 set) to stream over MAVLink and “4”(bit 2 set) to log to board dataflash memory, if equipped. LOG_BITMASK
: Bitmask for what items are logged. Normally, use default value, or “0” to disable logging. LOG_DISARMED
: Setting to 1 will start logging when power is applied, rather than at the first arming of the vehicle. Useful when debugging pre-arm failures. Setting to 2 will only log on power application other than USB power to prevent logging while setting up on the bench. Setting to 3 will also erase any log in which the vehicle does not proceed to the armed stated. This prevents accumulating numerous logs while configuring on the bench or at the field. See
LOG_DARM_RATEMAX
also for managing log file sizes while logging disarmed. LOG_FILE_DSRMROT
: Setting this bit will force the creation of a new log file after disarming, waiting 15 seconds, and then re-arming. Normally, a log will be one file for every power cycle of the autopilot, beginning upon first arm. LOG_FILE_MB_FREE
: This parameter sets the minimum free space on the logging media before logging begins. If this is not available, then older logs will be deleted to provide it during initialization. Default is 500MB. LOG_FILE_RATEMAX
: This sets the maximum rate that streaming log messages will be logged to the file backend to limit file sizes. A value of zero(default) means no limit is applied to normal logging, which depends on the
SCHED_LOOP_RATE
value ( 50Hz: Plane, 300Hz: QuadPlane/Rover, 400Hz: Copter, normally). Note that similarly,
LOG_BLK_RATEMAX
and
LOG_MAV_RATEMAX
perform the same optional limiting for the BLOCK logging and MAVLink logging streams, respectively. LOG_MAX_FILES
: The maximum number of log file that will be written on dataflash or SD card before starting to rotate log number. Limit is a maximum of 500 logs. Note

If you suspect that you are missing logging entries due to excessive logging speed, you can check the DSF.Dp log message for the amount of missed entries. Note

Logging of the continuously streaming log messages, such as attitude, sensors, etc.

--- chunk_id: chunk-0106
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 158
content_hash: 9ad9d3df4d39b80d
prev_chunk_id: chunk-0105
next_chunk_id: chunk-0107
section_heading: Logging Parameters
document_type: technical_reference

Note

If you suspect that you are missing logging entries due to excessive logging speed, you can check the DSF.Dp log message for the amount of missed entries. Note

Logging of the continuously streaming log messages, such as attitude, sensors, etc. can be paused by using the
RCx_OPTION
auxiliary function “164” on a transmitter channel. Switching this channel high will pause these messages, but not events, mode changes, warnings, etc. This allows autopilots with limited logging capabilities (ie using Block logging to chip memory and no SD card) to log only when desired during the flight, as during tuning phases or determination of TECs parameters, etc. You can also eliminate unneeded log messages using
LOG_BITMASK
to reduce log size

--- chunk_id: chunk-0107
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 273
content_hash: 23d468e964b5e380
prev_chunk_id: chunk-0106
next_chunk_id: chunk-0108
section_heading: Replay Logging
document_type: technical_reference

## Replay Logging
### ¶
ArduPilot has the ability to log in a fashion that solutions to EKF/AHRS issues can be more easily verified by actually re-playing a log against code changes to see if the solution results in the desired, corrected behavior. This requires that the logs showing the issue to be worked on be made with logging active during disarmed periods (with
LOG_DISARMED
set to a non-zero value, preferably 3) and
LOG_REPLAY
=1 , thereby logging more sensor data than normal. ### SD Card Logging Issues
### ¶
If you are running into problems with bad logging errors on SD cards, here are some things you can try. Format the card to FAT32 or vFAT (newer formats can work with new versions of Ardupilot and better hardware). Perform a full format to check for bad sectors. Check that the card is not write protected. Check card contacts. Some cards are problematic, try using a different one. Ensure that the card is fast enough to keep up with logging demands (Class 10 works for many, but lower speeds can work too). Reduce the amount of data included with the logs in LOG_BITMASK. Incrementally increase BRD_SD_SLOWDOWN up to a maximum of 32 (default is 0).

--- chunk_id: chunk-0108
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 342
content_hash: 8c454dafc3a118cb
prev_chunk_id: chunk-0107
next_chunk_id: chunk-0109
section_heading: On-Board DataFlash Logging
document_type: technical_reference

## On-Board DataFlash Logging
### ¶
Some boards do not have SD card interfaces for logging, but rather a limited amount of dataflash, typically 16MB. This saves log files in a manner like a circular buffer. Once the flash is filled, the oldest log file is overwritten with the current logging data. If there is only one file on the flash when space runs out, logging is stopped instead. A new log file will be started after boot, upon arming, or, immediately if
LOG_DISARMED
is 1. If
LOG_FILE_DSRMROT
is enabled, any disarm will stop logging and a new file started upon the next arm or immediately if
LOG_DISARMED
is 1. Otherwise, logging to the current file will resume on a re-arm. Any reboot stops logging to the current file. In order to maximize the utility of the limited flash space several things can be done:

Reduce the things logged using
LOG_BITMASK
. Eliminate logging the EKF3 messages which are voluminous and usually needed only for problem diagnosis using the
EK3_LOG_LEVEL
parameter. Only log when needed during the flight, ie tuning, gathering data for TECS tuning, etc. using an RC Aux switch set to “164” to start and stop log writes. Reduce the logging rate to a slower rate (below 10Hz) by setting
LOG_BLK_RATEMAX
which is by default unrestricted. Download and erase the logs each flight and only log one file for a flight

Note

some dataflash chips are particularly slow, leading to gaps in the logs. Setting
LOG_BLK_RATEMAX
to a lower value can help eliminate these gaps.

--- chunk_id: chunk-0109
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: 666106066cd73688
prev_chunk_id: chunk-0108
next_chunk_id: chunk-0110
section_heading: Downloading logs via MAVLink
document_type: technical_reference

## Downloading logs via MAVLink
### ¶
Connect your vehicle to the ground station using the micro USB cable

Open the Mission Planner’s Flight Data screen

On the bottom left, select the “DataFlash Logs” tab and push the
“Download DataFlash Log Via Mavlink” button

Then, select the log you want to download. This will save that log to
your MissionPlanner/logs directory, in a folder named after the vehicle
type, such as QUADCOPTER. ### Review a log
### ¶
For more detailed analysis, click on “Review a Log” and select a log
that you’ve already saved to the MissionPlanner/logs directory. Once
again, they will be in folders named after the vehicle type, such as
QUADCOPTER or ROVER. ### Steps to review a log downloaded from the internet, or your vehicle
### ¶
For DataFlash logs, with a .bin or .log extension:

Download the log file. Note the place on your computer to which it is downloaded. (For example, it might be C:\Downloads)

Open Mission Planner

Navigate to the “Flight Data” page (top left)

Select the “Dataflash Logs” tab (mid-screen, left side)

Select the “Review a Log” button. A standard Windows “select a file” box will let you go find the .bin file that you downloaded, at the place that you downloaded it. (Per the example above, it is in C:\Downloads) Choose that file. After reading the log, a Manual Log Review window will be open, which allows you to plot data from the log for inspection. (see below)


### Reviewing the log data
### ¶
Once you pick the log you want, you will get charts
such as the below. The basic format of the dataflash is:

Line numbers appear on the very left side of the viewer

Software version and board type appear at the top

FMT messages are next which tell the mission planner the column
headers for each message type

PARM rows which show each parameter (in the order in which they
appear in the eeprom) along with their value at the beginning of the
flight

Flight data messages including GPS, IMU, etc. Graph any flight data by first clicking on the appropriate row, you
should see the column headers update appropriately. Next find the column
you wish to graph, click on it and then push the “Graph this data”
button.

--- chunk_id: chunk-0110
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 205
content_hash: d91faf41ab191506
prev_chunk_id: chunk-0109
next_chunk_id: chunk-0111
section_heading: Downloading logs via MAVLink
document_type: technical_reference

Graph any flight data by first clicking on the appropriate row, you
should see the column headers update appropriately. Next find the column
you wish to graph, click on it and then push the “Graph this data”
button. In the example above the ATT’s Roll-In and Roll data have been
graphed. The mouse’s scroll wheel can be used to zoom in or out. You may
also select an area of the graph to zoom in on it. Zoom out by
right-mouse-button clicking and selecting “Set Scale to Default”. Here’s
a mini tutorial on using this feature. You may also filter on just the
first column (the flight data message type) by clicking on the first
column and selecting the message type from the drop-down. This is very
useful especially for viewing the different flight modes (called “MODE”
messages) used during the mission. Click the first column again but
press “Cancel” to clear the filter.

--- chunk_id: chunk-0111
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 221
content_hash: c491a438ee6e1b2a
prev_chunk_id: chunk-0110
next_chunk_id: chunk-0112
section_heading: Setting what data you want recorded
document_type: technical_reference

## Setting what data you want recorded
### ¶
The
LOG_BITMASK
parameter controls what messages are recorded in the logs. The bits differ between vehicles. The image above is for Copter. ### Bitmask Table (Plane)
### ¶
Bit

BitMask Name

What is logged if bit is set

0

Fast Attitude

Attitude @ 25Hz

1

Medium Attitude

Attitude @ 10Hz

2

GPS

GPS

3

System Performance

CPU,etc. Performance monitoring

4

Control Tuning

Control Data

5

Navigation Tuning

Navigation Data

7

IMU

IMU (ACC/Gyro) Data

8

Mission Commands

Mission/GCS Commands

9

Battery Monitor

Battery Monitors data

10

Compass

Compasses Data

11

TECS

Speed/Height Controller Data

12

Camera

Camera Data (if present)

13

RC Input & Output

RC input/Servo output data

14

Rangefinder

Rangefinder Data (if present)

19

Raw IMU

Raw IMU data, unprocessed

20

Full Rate Attitude

Attitude at
SCHED_LOOP_RATE

21

Video Stabilization

GyroFlow Data logs

ATTITUDE logging will occur at highest rate of the selections. Note

the logging of EKF3 data is controlled by the
EK3_LOG_LEVEL
parameter.

--- chunk_id: chunk-0112
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: a4878fad4e6b18be
prev_chunk_id: chunk-0111
next_chunk_id: chunk-0113
section_heading: Message Details (Copter specific)
document_type: technical_reference

## Message Details (Copter specific)
### ¶
Note

Many messages are detailed in the
Onboard Message Log Messages
page in each vehicle’s wiki section. ATT (attitude information):

DesRoll

The pilot’s desired roll angle in degrees (roll left is negative, right is positive)

Roll

The vehicle’s actual roll in degrees (roll left is negative, right is positive)

DesPitch

The pilot’s desired pitch angle in degrees (pitch forward is negative, pitch back is positive)

Pitch

The vehicle’s actual pitch angle in degrees (pitch forward is negative, pitch back is positive)

DesYaw

The pilot’s desired heading in degrees with 0 = north

Yaw

The vehicle’s actual heading in degrees with 0 = north

ErrRP

The average size of the roll/pitch error estimate (values between 0 and 1)

ErrYaw

The average size of the yaw error estimate (values between 0 and 1)

ATUN (auto tune overview):

Axis: 0 = Roll, 1 = Pitch

TuneStep

0 = Returning towards Level (before
or after a test), 1 = Testing (i.e.

--- chunk_id: chunk-0113
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 542
content_hash: 27a6ed1e81229573
prev_chunk_id: chunk-0112
next_chunk_id: chunk-0114
section_heading: Message Details (Copter specific)
document_type: technical_reference

## Message Details (Copter specific)
### ¶
Note

Many messages are detailed in the
Onboard Message Log Messages
page in each vehicle’s wiki section. ATT (attitude information):

DesRoll

The pilot’s desired roll angle in degrees (roll left is negative, right is positive)

Roll

The vehicle’s actual roll in degrees (roll left is negative, right is positive)

DesPitch

The pilot’s desired pitch angle in degrees (pitch forward is negative, pitch back is positive)

Pitch

The vehicle’s actual pitch angle in degrees (pitch forward is negative, pitch back is positive)

DesYaw

The pilot’s desired heading in degrees with 0 = north

Yaw

The vehicle’s actual heading in degrees with 0 = north

ErrRP

The average size of the roll/pitch error estimate (values between 0 and 1)

ErrYaw

The average size of the yaw error estimate (values between 0 and 1)

ATUN (auto tune overview):

Axis: 0 = Roll, 1 = Pitch

TuneStep

0 = Returning towards Level (before
or after a test), 1 = Testing (i.e. performing a twitch to test
response), 2 = Updating gains
(twitch completed and gains
adjusted)

RateMin

Minimum recorded rate during this
test

RateMax

Maximum recorded rate during this
test

RPGain

Rate P gain value being tested

RDGain

Rate D gain value being tested

SPGain

Stabilize P gain being tested

ATDE (auto tune step details):

Angle

Angle of the copter in centi-degrees for the axis being testedx

Rate

Rate of rotation of the copter for the axis being tested

CAM (time and position when camera shutter was activated):

GPSTime

The GPS reported time since epoch in milliseconds

Lat

The accelerometer + GPS latitude estimate

Lng

The accelerometer + GPS longitude estimate

Alt

The accelerometer + barometer estimated altitude in cm above ground

Roll

The vehicle roll angle in centi-degrees

Pitch

The vehicle pitch angle in centi-degrees

Yaw

The vehicle’s heading in centi-degrees

CMD (commands received from the ground station or executed as part of
a mission):

CTot

The total number of commands in the mission

CNum

This command’s number in the mission (0 is always home, 1 is the first command, etc)

CId

The
MAVLink message id

Copt

The option parameter (used for many different purposes)

Prm1

The command’s parameter (used for many different purposes)

Alt

The command’s altitude in meters

Lat

The command’s latitude position

Lng

The command’s longitude position

COMPASS (raw compass, offset and compassmot compensation values):

Field

Description

MagX, MagY, MagZ

Raw magnetic field values for x, y, and z axis.

--- chunk_id: chunk-0114
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 525
content_hash: 3d1005bf52c3bf8f
prev_chunk_id: chunk-0113
next_chunk_id: chunk-0115
section_heading: Message Details (Copter specific)
document_type: technical_reference

ATT (attitude information):

DesRoll

The pilot’s desired roll angle in degrees (roll left is negative, right is positive)

Roll

The vehicle’s actual roll in degrees (roll left is negative, right is positive)

DesPitch

The pilot’s desired pitch angle in degrees (pitch forward is negative, pitch back is positive)

Pitch

The vehicle’s actual pitch angle in degrees (pitch forward is negative, pitch back is positive)

DesYaw

The pilot’s desired heading in degrees with 0 = north

Yaw

The vehicle’s actual heading in degrees with 0 = north

ErrRP

The average size of the roll/pitch error estimate (values between 0 and 1)

ErrYaw

The average size of the yaw error estimate (values between 0 and 1)

ATUN (auto tune overview):

Axis: 0 = Roll, 1 = Pitch

TuneStep

0 = Returning towards Level (before
or after a test), 1 = Testing (i.e. performing a twitch to test
response), 2 = Updating gains
(twitch completed and gains
adjusted)

RateMin

Minimum recorded rate during this
test

RateMax

Maximum recorded rate during this
test

RPGain

Rate P gain value being tested

RDGain

Rate D gain value being tested

SPGain

Stabilize P gain being tested

ATDE (auto tune step details):

Angle

Angle of the copter in centi-degrees for the axis being testedx

Rate

Rate of rotation of the copter for the axis being tested

CAM (time and position when camera shutter was activated):

GPSTime

The GPS reported time since epoch in milliseconds

Lat

The accelerometer + GPS latitude estimate

Lng

The accelerometer + GPS longitude estimate

Alt

The accelerometer + barometer estimated altitude in cm above ground

Roll

The vehicle roll angle in centi-degrees

Pitch

The vehicle pitch angle in centi-degrees

Yaw

The vehicle’s heading in centi-degrees

CMD (commands received from the ground station or executed as part of
a mission):

CTot

The total number of commands in the mission

CNum

This command’s number in the mission (0 is always home, 1 is the first command, etc)

CId

The
MAVLink message id

Copt

The option parameter (used for many different purposes)

Prm1

The command’s parameter (used for many different purposes)

Alt

The command’s altitude in meters

Lat

The command’s latitude position

Lng

The command’s longitude position

COMPASS (raw compass, offset and compassmot compensation values):

Field

Description

MagX, MagY, MagZ

Raw magnetic field values for x, y, and z axis. These are magnetometer readings with
calibration applied, not raw magnetometer readings.

--- chunk_id: chunk-0115
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 398
content_hash: 9e7d4c37cee4674c
prev_chunk_id: chunk-0114
next_chunk_id: chunk-0116
section_heading: Message Details (Copter specific)
document_type: technical_reference

performing a twitch to test
response), 2 = Updating gains
(twitch completed and gains
adjusted)

RateMin

Minimum recorded rate during this
test

RateMax

Maximum recorded rate during this
test

RPGain

Rate P gain value being tested

RDGain

Rate D gain value being tested

SPGain

Stabilize P gain being tested

ATDE (auto tune step details):

Angle

Angle of the copter in centi-degrees for the axis being testedx

Rate

Rate of rotation of the copter for the axis being tested

CAM (time and position when camera shutter was activated):

GPSTime

The GPS reported time since epoch in milliseconds

Lat

The accelerometer + GPS latitude estimate

Lng

The accelerometer + GPS longitude estimate

Alt

The accelerometer + barometer estimated altitude in cm above ground

Roll

The vehicle roll angle in centi-degrees

Pitch

The vehicle pitch angle in centi-degrees

Yaw

The vehicle’s heading in centi-degrees

CMD (commands received from the ground station or executed as part of
a mission):

CTot

The total number of commands in the mission

CNum

This command’s number in the mission (0 is always home, 1 is the first command, etc)

CId

The
MAVLink message id

Copt

The option parameter (used for many different purposes)

Prm1

The command’s parameter (used for many different purposes)

Alt

The command’s altitude in meters

Lat

The command’s latitude position

Lng

The command’s longitude position

COMPASS (raw compass, offset and compassmot compensation values):

Field

Description

MagX, MagY, MagZ

Raw magnetic field values for x, y, and z axis. These are magnetometer readings with
calibration applied, not raw magnetometer readings. OfsX, OfsY, OfsZ

Raw magnetic offsets (will only change if COMPASS_LEARN parameter is 1)

MOfsX, MOfsY, MOfsZ

Compassmot compensation for throttle or current

CURRENT (battery voltage, current and board voltage information):

FIELD

DESCRIPTION

Thr

Pilot input throttle from 0 ~ 1000

ThrInt

Integrated throttle (i.e.

--- chunk_id: chunk-0116
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: d89083c19724b4b4
prev_chunk_id: chunk-0115
next_chunk_id: chunk-0117
section_heading: Message Details (Copter specific)
document_type: technical_reference

These are magnetometer readings with
calibration applied, not raw magnetometer readings. OfsX, OfsY, OfsZ

Raw magnetic offsets (will only change if COMPASS_LEARN parameter is 1)

MOfsX, MOfsY, MOfsZ

Compassmot compensation for throttle or current

CURRENT (battery voltage, current and board voltage information):

FIELD

DESCRIPTION

Thr

Pilot input throttle from 0 ~ 1000

ThrInt

Integrated throttle (i.e. sum of total throttle output for this flight)

Volt

Battery voltage in volts * 100

Curr

Current drawn from the battery in amps * 100

Vcc

Board voltage

CurrTot

Total current drawn from battery

CTUN (Control, Throttle and altitude information):

FIELD

DESCRIPTION

TimeUS

Time stamp for messages in microseconds (can be ignored)

ThI

The pilot’s throttle in as a number from 0 to 1000

ABst

Angle Boost: throttle increase (from 0 ~ 1000) as a result of the copter leaning over
(automatically added to all pilot and autopilot throttle to reduce altitude loss while leaning)

ThO

Final throttle output sent to the motors (from 0 ~ 1000). Normally equal to ThrI+ABst while
in stabilize mode. ThH

Estimated throttle required to hover throttle in the range 0 ~ 1

DAlt

The Desired Altitude while in AltHold, Loiter, RTL or Auto flight modes. It is influenced by EKF origin, which in 3.5.X is corrected by GPS altitude. This behaviour is
turned off in 3.6.X and can be turned on with EKF_OGN_HGT_MASK. Alt

The current EKF Altitude

BAlt

Barometer Altitude: The altitude above ground according to the barometer

DSAlt

Desired distance in cm from ground or ceiling (only visible if Sonar is available)

SAlt

Sonar Altitude: the altitude above ground according to the sonar
(Only visible of Sonar is available)

TAlt

Terrain altitude (not used by default)

DCRt

Desired Climb Rate in cm/s

CRt

Climb Rate in cm/s

N

Harmonic notch current center frequency for gyro in Hz

D32, DU32 (single data values which are either signed 32bit integers
or unsigned 32bit integers):

FIELD

DESCRIPTION

id

Identification number for the variable. There are only two possible values:

7 = bit mask of internal state (The meaning of individual bits can be found in the def’n of the
ap structure

9 = simple mode’s initial heading in centi-degrees

EKF (Extended Kalman Filter
):

Log information here
(Dev Wiki). Overview
here
.

--- chunk_id: chunk-0117
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 326
content_hash: 63766849b3c5679b
prev_chunk_id: chunk-0116
next_chunk_id: chunk-0118
section_heading: Message Details (Copter specific)
document_type: technical_reference

There are only two possible values:

7 = bit mask of internal state (The meaning of individual bits can be found in the def’n of the
ap structure

9 = simple mode’s initial heading in centi-degrees

EKF (Extended Kalman Filter
):

Log information here
(Dev Wiki). Overview
here
. ERR (an error message):

SubSystem and Error codes listed below

Subsys
ECode and Description
2 = Radio
0 = Errors Resolved

2 = Late Frame : no updates received from receiver for two seconds

3 = Compass
0 = Errors Resolved

1 = Failed to initialise (probably a hardware issue)

4 = Unhealthy : failed to read from the sensor

5 = Radio Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

6 = Battery Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

8 = GCS Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

9 = Fence Failsafe
0 = Failsafe Resolved

1 = Altitude fence breach, Failsafe Triggered

2 = Circular fence breach, Failsafe Triggered

3 = Both Alt and Circular fence breached, Failsafe Triggered

4 = Polygon fence breached, Failsafe Triggered

10 = Flight mode Change failure
Vehicle was unable to enter the desired flight mode normally because of a bad position estimate

See
flight mode numbers here

11 = GPS
0 = Glitch cleared

2 = GPS Glitch occurred

12 = Crash Check
1 = Crash into ground detected. Normally vehicle is disarmed soon after

2 = Loss of control detected.

--- chunk_id: chunk-0118
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 665
content_hash: c200e8c53e7e5edb
prev_chunk_id: chunk-0117
next_chunk_id: chunk-0119
section_heading: Message Details (Copter specific)
document_type: technical_reference

ERR (an error message):

SubSystem and Error codes listed below

Subsys
ECode and Description
2 = Radio
0 = Errors Resolved

2 = Late Frame : no updates received from receiver for two seconds

3 = Compass
0 = Errors Resolved

1 = Failed to initialise (probably a hardware issue)

4 = Unhealthy : failed to read from the sensor

5 = Radio Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

6 = Battery Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

8 = GCS Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

9 = Fence Failsafe
0 = Failsafe Resolved

1 = Altitude fence breach, Failsafe Triggered

2 = Circular fence breach, Failsafe Triggered

3 = Both Alt and Circular fence breached, Failsafe Triggered

4 = Polygon fence breached, Failsafe Triggered

10 = Flight mode Change failure
Vehicle was unable to enter the desired flight mode normally because of a bad position estimate

See
flight mode numbers here

11 = GPS
0 = Glitch cleared

2 = GPS Glitch occurred

12 = Crash Check
1 = Crash into ground detected. Normally vehicle is disarmed soon after

2 = Loss of control detected. Normally parachute is released soon after

13 = Flip mode
2 = Flip abandoned (not armed, pilot input or timeout)
15 = Parachute
2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check
0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer
0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe
0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data
2 = missing terrain data
22 = Navigation
2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed
0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check
0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub)
0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub)
0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only)
0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe
0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated

EV: (an event number)
.

--- chunk_id: chunk-0119
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 612
content_hash: 4a5becef01a4213e
prev_chunk_id: chunk-0118
next_chunk_id: chunk-0120
section_heading: Message Details (Copter specific)
document_type: technical_reference

Normally vehicle is disarmed soon after

2 = Loss of control detected. Normally parachute is released soon after

13 = Flip mode
2 = Flip abandoned (not armed, pilot input or timeout)
15 = Parachute
2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check
0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer
0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe
0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data
2 = missing terrain data
22 = Navigation
2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed
0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check
0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub)
0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub)
0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only)
0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe
0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated

EV: (an event number)
. The full list of possible events can be found
in
AP_Logger.h
but the most common are:

Event No

DESCRIPTION

10

Armed

11

Disarmed

15

Auto Armed (pilot has raised throttle above zero and autopilot is free to take control of throttle)

18

Land Complete

25

Set Home (home location coordinates have been capture)

28

Not Landed (aka Takeoff complete)

GPA: (Global Position Accuracy)

FIELD

DESCRIPTION

VDop

Vertical dilution of precision, a unitless measure of precision
https://en.wikipedia.org/wiki/Dilution_of_precision

HAcc

Horizontal Accuracy as reported by the GPS module, in meters

VAcc

Vertical Accuracy as reported by the GPS module, in meters

SAcc

Speed accuracy as reported by the GPS, in m/s/s

VV

Flag to indicate if the GPS is reporting vertical velocity
0 No vertical velocity data
1 GPS has vertical velocity data

SMS

The autopilot time in milliseconds that the accuracy/GPS position data is associated with.

--- chunk_id: chunk-0120
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 810
content_hash: 06e37170d3f49115
prev_chunk_id: chunk-0119
next_chunk_id: chunk-0121
section_heading: Message Details (Copter specific)
document_type: technical_reference

Normally parachute is released soon after

13 = Flip mode
2 = Flip abandoned (not armed, pilot input or timeout)
15 = Parachute
2 = Not Deployed, vehicle too low

3 = Not Deployed, vehicle landed

16 = EKF Check
0 = Variance cleared (position estimate OK)

2 = Bad Variance (position estimate bad)

17 = EKF Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered

18 = Barometer
0 = Errors Resolved

4 = Unhealthy : failed to read from the sensor

19 = CPU Load Watchdog
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle disarms)

20 = ADSB Failsafe
0 = Failsafe Resolved

1 = No action just report to Pilot

2 = Vehicle avoids by climbing or descending

3 = Vehicle avoids by moving horizontally

4 = Vehicle avoids by moving perpendicular to other vehicle

5 = RTL invoked

21 = Terrain Data
2 = missing terrain data
22 = Navigation
2 = Failed to set destination

3 = RTL restarted

4 = Circle initialisation failed

5 = Destination outside fence

23 = Terrain Failsafe
0 = Failsafe Resolved

1 = Failsafe Triggered (normally vehicle RTLs)

24 = EKF Primary changed
0 = 1st EKF has become primary

1 = 2nd EKF has become primary

25 = Thrust Loss Check
0 = Thrust Restored

1 = Thrust Loss Detected (altitude may be prioritised over yaw control)

26 = Sensor Failsafe (Sub)
0 = Sensor Failsafe Cleared

1 = Sensor Failsafe Triggered

27 = Leak Failsafe (Sub)
0 = Leak Failsafe Cleared

1 = Leak Detector Failsafe Triggered

28 = Pilot Input Timeout Failsafe (Sub only)
0 = Pilot Input Failsafe Cleared

1 = Pilot Input Failsafe Triggered

29 = Vibration Failsafe
0 = Excessive Vibration Compensation De-activated

1 = Excessive Vibration Compenstaion Activated

EV: (an event number)
. The full list of possible events can be found
in
AP_Logger.h
but the most common are:

Event No

DESCRIPTION

10

Armed

11

Disarmed

15

Auto Armed (pilot has raised throttle above zero and autopilot is free to take control of throttle)

18

Land Complete

25

Set Home (home location coordinates have been capture)

28

Not Landed (aka Takeoff complete)

GPA: (Global Position Accuracy)

FIELD

DESCRIPTION

VDop

Vertical dilution of precision, a unitless measure of precision
https://en.wikipedia.org/wiki/Dilution_of_precision

HAcc

Horizontal Accuracy as reported by the GPS module, in meters

VAcc

Vertical Accuracy as reported by the GPS module, in meters

SAcc

Speed accuracy as reported by the GPS, in m/s/s

VV

Flag to indicate if the GPS is reporting vertical velocity
0 No vertical velocity data
1 GPS has vertical velocity data

SMS

The autopilot time in milliseconds that the accuracy/GPS position data is associated with. Delta

The time between when the previous GPS message and the current GPS message was parsed by the
autopilot, in milliseconds

GPS:

FIELD

DESCRIPTION

Status

0 = no GPS, 1 = GPS but no fix, 2 = GPS with 2D fix, 3 = GPS with 3D fix

Time

The GPS reported time since epoch in milliseconds

NSats

The number of satellites current being used

HDop

A measure of gps precision (1.5 is good, >2.0 is not so good)
https://en.wikipedia.org/wiki/Dilution_of_precision

Lat

Latitude according to the GPS

Lng

Longitude according to the GPS

RelAlt

Accelerometer + Baro altitude in meters

Alt

GPS reported altitude (not used by the autopilot)

SPD

Horizontal ground speed in m/s

GCrs

Ground course in degrees (0 = north)

IMU (accelerometer and gyro information):

FIELD

DESCRIPTION

GyrX, GyrY, GyrZ

The raw gyro rotation rates in radians/second

AccX, AccY, AccZ

The raw accelerometer values in m/s/s

Mode (flight mode):

FIELD

DESCRIPTION

Mode

The flight mode displayed as a string (i.e.

--- chunk_id: chunk-0121
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 9f91d5d3a38676ce
prev_chunk_id: chunk-0120
next_chunk_id: chunk-0122
section_heading: Message Details (Copter specific)
document_type: technical_reference

The full list of possible events can be found
in
AP_Logger.h
but the most common are:

Event No

DESCRIPTION

10

Armed

11

Disarmed

15

Auto Armed (pilot has raised throttle above zero and autopilot is free to take control of throttle)

18

Land Complete

25

Set Home (home location coordinates have been capture)

28

Not Landed (aka Takeoff complete)

GPA: (Global Position Accuracy)

FIELD

DESCRIPTION

VDop

Vertical dilution of precision, a unitless measure of precision
https://en.wikipedia.org/wiki/Dilution_of_precision

HAcc

Horizontal Accuracy as reported by the GPS module, in meters

VAcc

Vertical Accuracy as reported by the GPS module, in meters

SAcc

Speed accuracy as reported by the GPS, in m/s/s

VV

Flag to indicate if the GPS is reporting vertical velocity
0 No vertical velocity data
1 GPS has vertical velocity data

SMS

The autopilot time in milliseconds that the accuracy/GPS position data is associated with. Delta

The time between when the previous GPS message and the current GPS message was parsed by the
autopilot, in milliseconds

GPS:

FIELD

DESCRIPTION

Status

0 = no GPS, 1 = GPS but no fix, 2 = GPS with 2D fix, 3 = GPS with 3D fix

Time

The GPS reported time since epoch in milliseconds

NSats

The number of satellites current being used

HDop

A measure of gps precision (1.5 is good, >2.0 is not so good)
https://en.wikipedia.org/wiki/Dilution_of_precision

Lat

Latitude according to the GPS

Lng

Longitude according to the GPS

RelAlt

Accelerometer + Baro altitude in meters

Alt

GPS reported altitude (not used by the autopilot)

SPD

Horizontal ground speed in m/s

GCrs

Ground course in degrees (0 = north)

IMU (accelerometer and gyro information):

FIELD

DESCRIPTION

GyrX, GyrY, GyrZ

The raw gyro rotation rates in radians/second

AccX, AccY, AccZ

The raw accelerometer values in m/s/s

Mode (flight mode):

FIELD

DESCRIPTION

Mode

The flight mode displayed as a string (i.e. STABILIZE, LOITER, etc)

ThrCrs

Throttle cruise (from 0 ~ 1000) which is the autopilot’s best guess as to what throttle
is required to maintain a stable hover

Rsn

Reason for mode change (TX command, failsafe, etc) . The meaning of code values can be found in
ModeReason

NTUN (navigation information):

FIELD

DESCRIPTION

WPDst

Distance to the next waypoint (or loiter target) in cm. Only updated while in Loiter, RTL, Auto.

--- chunk_id: chunk-0122
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: 98b5cef64b949baa
prev_chunk_id: chunk-0121
next_chunk_id: chunk-0123
section_heading: Message Details (Copter specific)
document_type: technical_reference

The meaning of code values can be found in
ModeReason

NTUN (navigation information):

FIELD

DESCRIPTION

WPDst

Distance to the next waypoint (or loiter target) in cm. Only updated while in Loiter, RTL, Auto. WPBrg

Bearing to the next waypoint in degrees

PErX

Distance to intermediate target between copter and the next waypoint in the latitude direction

PErY

Distance to intermediate target between copter and the next waypoint in the longitude direction

DVelX

Desired velocity in cm/s in the latitude direction

DVelY

Desired velocity in cm/s in the longitude direction

VelX

Actual accelerometer + gps velocity estimate in the latitude direction

VelY

Actual accelerometer + gps velocity estimate in the longitude direction

DAcX

Desired acceleration in cm/s/s in the latitude direction

DAcY

Desired acceleration in cm/s/s in the longitude direction

DRol

Desired roll angle in centi-degrees

DPit

Desired pitch angle in centi-degrees

PM (performance monitoring):

FIELD

DESCRIPTION

NLon

Number of long running main loops (i.e. loops that take more than 20% longer
than they should according to
SCHED_LOOP_RATE
- ex. 3ms for 400Hz rate)

NLoop

The total number of loops since the last PM message was displayed. This allows you to calculate
the percentage of slow running loops (which should never be higher than 15%). Note that the
value will depend on the autopilot clock speed

MaxT

The maximum time that any loop took since the last PM message. This shouldn’t exceed 120% of
scheduler loop period, but will be much higher during the interval where the motors are armed

Mem

Available memory, in bytes

Load

Percentage (times 10) of the scheduler loop period when CPU is used

RCOUT (pwm output to individual RC outputs):

RC1, RC2, etc : pwm command sent from autopilot to the
esc/motor/RC output

--- chunk_id: chunk-0123
source_document: common-downloading-and-analyzing-data-logs-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 141
content_hash: 2d6f801aef6f65e3
prev_chunk_id: chunk-0122
next_chunk_id: chunk-0124
section_heading: Viewing KMZ FILES
document_type: technical_reference

## Viewing KMZ FILES
### ¶
When you download the dataflash log files from the autopilot it will
automatically create a KMZ file (file with extension .kmz). This file
can be opened with Google Earth (just double click the file) to view
your flight in Google Earth. Please see the instructions on the
Telemetry Logs Page
for additional details. ### Video tutorials
### ¶
Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0124
source_document: common-geofencing-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: 4c7057d30ab8843b
prev_chunk_id: chunk-0123
next_chunk_id: chunk-0125
document_type: technical_reference

GeoFencing — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Introducing Plane
Flight Features
Automatic Takeoff
Automatic Landing
Inverted Flight
Stall Prevention
Geo-Fencing in Plane
General Setup
Types of Fences
Fence Breach Actions
Enabling the Fence with an RC Channel Auxiliary Switch
Automatic Altitude Breach Avoidance
Enabling Fences in Mission Planner
Use for R/C Training
Stick-mixing on fence breach
MAVLink support
Terrain Following
Soaring
Automated Aerobatics (prior to 4.4)
Automated Aerobatics (4.4 and later)
Moving Vehicle/Ship Takeoff/Landing
High Altitude Glider Drop Pullup
Fixed Wing FAQ
Ready to Fly vehicles
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Plane Introduction
Flight Features
- GeoFencing
Edit on GitHub

# GeoFencing
# ¶
ArduPilot supports a home based Cylindrical (“TinCan”) and Polygonal and/or Cylindrical, Inclusion and/or Exclusion regions. Inclusion and Exclusion Fences are defined easily in Mission Planner under the PLAN screen and loaded to the autopilot, using the FENCES item in the drop down box, just like Missions or Rally Points are planned. Some vehicles can also have maximum and/or minimum altitude limits. Some flight modes will try to prevent exceeding these limits automatically, a fence breach will be declared in all modes if exceeded. Upon Fence breach, selectable actions are taken.

--- chunk_id: chunk-0125
source_document: common-geofencing-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 6f67ff7b3e49c5a6
prev_chunk_id: chunk-0124
next_chunk_id: chunk-0126
section_heading: General Setup
document_type: technical_reference

## General Setup
### ¶
Set
FENCE_ENABLE
= 1 to enable fences. This enables any fences that are setup, except the ALT_MIN fence, which must be enabled by using any fence enable means (GCS message, AUTOENABLE in plane, RC switch)

Set
FENCE_ACTION
= to whatever you wish for a breach action. These will vary depending on vehicle type. See
Fence Breach Actions
above. Set
FENCE_OPTIONS
Set bit 1 to prevent mode changes after a fence breach until the vehicle returns within the fence boundary (Plane only, Copter/Rover do not allow mode changes while in breach). Set bit 2 to use the Union of inclusion areas instead of just Intersects. Set bit 3 to provide GCS warning when vehicle is less than
FENCE_MARGIN
from a breach. This parameter is also used in avoidance and path planning. Set
FENCE_ALT_MAX
= to the altitude limit you want (in meters). This is unavailable in Rover. Set
FENCE_MARGIN
= to the distance from the fence horizontal boundary the vehicle must maintain in order to prevent a breach. Set the
FENCE_ALT_MIN
as a minimum altitude breach boundary. Set
FENCE_AUTOENABLE
= (Plane Only)to allow automatic enabling of the fence (different than
FENCE_ENABLE
) under certain vehicle conditions, such as upon arming or takeoff. A value of 0 disables this feature. FENCE_ENABLE
is ignored if this feature is enabled. Using
FENCE_AUTOENABLE
= 3 (enable on ARM) is the only recommended use. “1” or “2” functions are being deprecated shortly since they can produce undesirable results in terms of containment. FENCE_RET_RALLY
allows returning to the nearest RALLY point (See:
Rally Points
), if loaded, instead of HOME. Set
FENCE_TYPE
= is a bitmap set to enable the various fence types: MIN or MAX altitude, simple CIRCLE tin can around HOME, or POLYGON fences. The POLYGON fences must also have been loaded via a fence list from a ground control station in order to be active. See below for detailed setup of
Cylindrical Fence
and
Inclusion and Exclusion Fences
. Note

Polygon fence type includes the circular fences specified in the Inclusion/Exclusion fence list. The simple home centered CIRCLE fence is a separate fence. Rover ignores altitudes, if set. Defaults for
FENCE_TYPE
are:

Rover: CIRCLE and POLYGON

Copter: ALT MAX, CIRCLE, and POLYGON

Plane: POLYGON

### Detailed Setup
### ¶
Cylindrical Fence Failsafe
Inclusion/Exclusion Fence Failsafe

--- chunk_id: chunk-0126
source_document: common-geofencing-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 489
content_hash: 215d1d96f1f31323
prev_chunk_id: chunk-0125
next_chunk_id: chunk-0127
section_heading: Types of Fences
document_type: technical_reference

## Types of Fences
### ¶
TYPE OF FENCE

FENCE_TYPE
bit

PLANE

COPTER

ROVER

Global Maximum Altitude
FENCE_ALT_MAX defines max altitude

0

X

X

Cylindrical (“TinCan”)
Circle Centered on Home

Parameters for radius, height

1

X

X

X

Inclusion/Exclusion Zones
Arbitrary Locations

Polygonal or Circular

Inclusion or Exclusion

Defined by list, like missions

No height/altitude restriction

2

X

X

X

Global Minimum Altitude
FENCE_ALT_MIN defines min altitude

3

X

Note

if
FENCE_TYPE
=2 inclusion zones overlap, a fence breach will occur when crossing a boundary, even if within another inclusion zone, UNLESS
FENCE_OPTIONS
bit 1 is set to make all inclusions zones a union set. ### Fence Breach Actions
### ¶
If enabled, and  the fence boundaries or altitudes(
FENCE_ALT_MAX
and
FENCE_ALT_MIN
), if non-zero,  are exceeded, Plane will execute the
FENCE_ACTION
below:

FENCE_ACTION

Plane

0

Report Only

1

RTL

6

Guided to return
point

7

Guided to return
point with pilot
throttle control

8

AUTOLAND mode, or
RTL

The return (and loiter) point, unless
FENCE_RET_RALLY
is enabled, is the geometric center of the breached fence boundary. If
FENCE_ACTION
is set to a guided return mode (6 or 7), the altitude at which it returns is determined by
FENCE_RET_ALT
or if
FENCE_RET_ALT
is zero, midway between the altitude limits, if non-zero. If both altitude limits are zero, then it will return at current altitude. The return point can also be replaced by the nearest rally point (See:
Rally Points
) as a destination, if
FENCE_RET_RALLY
is enabled. Note

while executing any action that requires a mode change (ie. all except Report Only), any additional fence breaches are recorded but ignored. For example, RTL that has an AutoLand will breach a MIN_ALT fence, if enabled, but take no action and finish the landing. Modes changes cannot be executed after the fence breach unless the
FENCE_OPTIONS
bit 0 is set to “0”. By default it is set to “1” to prevent mode changes. When set, the vehicle must return to within the fence boundary in order to change modes. If mode changes are allowed, you can also return to the mode that was active upon breach by using an RC auxiliary switch set to option “96” (Re-read mode switch).

--- chunk_id: chunk-0127
source_document: common-geofencing-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 248
content_hash: 03e66b52fd83d2b3
prev_chunk_id: chunk-0126
next_chunk_id: chunk-0128
section_heading: Enabling the Fence with an RC Channel Auxiliary Switch
document_type: technical_reference

## Enabling the Fence with an RC Channel Auxiliary Switch
### ¶
It is not necessary to set-up a switch to enable or disable the fence
but if you wish to control the fence with a switch follow these
steps:

An
RCx_OPTION
can be set via the Config/Tuning > Full Parameter List screen, for example using RC channel 7:

Set
RC7_OPTION
= 11 (Fence Enable)

setting the switch high (i.e. PWM > 1800) will enable all configured fences, low
(under 1800) will disable all fences. Note

if the Minimum Altitude fence is enabled by the switch while on the ground and disarmed, a pre-arm failure will occur preventing arming. ### Automatic Altitude Breach Avoidance
### ¶
For landing modes (NAV_LAND,QLAND,LAND,etc.) in Copter and Plane, the
FENCE_ALT_MIN
limit is automatically disabled. When in Mode FBWB or CRUISE, Plane will attempt to limit altitude target changes by the pilot (ie using Pitch stick for climb/descent rate demand inputs) to avoid breaching a maximum or minimum altitude fence. Note

altitude control imperfections can still result in a breach unless the
FENCE_MARGIN
param is loose enough to accommodate these imperfections.

--- chunk_id: chunk-0128
source_document: common-geofencing-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 213
content_hash: 0dee686655d0e1f3
prev_chunk_id: chunk-0127
next_chunk_id: chunk-0129
section_heading: Enabling Fences in Mission Planner
document_type: technical_reference

## Enabling Fences in Mission Planner
### ¶
To enable Fences, go to the Mission Planner full parameter list (CONFIG->Full Parameter Tree), search for items with
FENCE_
:

### Use for R/C Training
### ¶
One of the main uses of geo-fencing is to teach yourself (or someone
else) to fly radio controlled vehicles. When you have a properly
configured geo-fence it is very hard to crash, and you can try
manoeuvres that would normally be too likely to end in a crash, trusting
the autopilot to ‘bounce’ the vehicle off the geo-fence before the flight ends
in disaster. Geo-fencing can be combined with any flight mode. So for a raw
beginner, you would combine it with one of the stabilised flight modes
. Once the pilot has gained some confidence you could combine it with ACRO mode in Copter or MANUAL mode in Plane, which gives direct control of the vehicle and allows for the most interesting aerobatic manoeuvres.

--- chunk_id: chunk-0129
source_document: common-geofencing-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 184
content_hash: 8e5a37a9ddfe6f11
prev_chunk_id: chunk-0128
next_chunk_id: chunk-0130
section_heading: Stick-mixing on fence breach
document_type: technical_reference

## Stick-mixing on fence breach
### ¶
ArduPilot enables ‘stick mixing’ by default when in auto modes. This means
that you can change the path of a loiter, for example, by using your
transmitter sticks. When you are using geo-fencing, stick mixing will be disabled on fence
breach until your plane is back inside the fenced region. This is to
ensure that the bad control inputs that caused you to breach the fence
don’t prevent it from recovering to the return point. As soon as you are back inside the fence stick mixing will be
re-enabled, allowing you to control the GUIDED mode that the plane will
be in. If by using stick mixing you manage to take the plane outside the
fence again then stick mixing will again be disabled until you are back
inside the fence.

--- chunk_id: chunk-0130
source_document: common-geofencing-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 372
content_hash: 7389641d2885324b
prev_chunk_id: chunk-0129
next_chunk_id: chunk-0131
section_heading: MAVLink support
document_type: technical_reference

## MAVLink support
### ¶
ArduPilot will report the fence status via the MAVLink GCS protocol. The
key status packet is called FENCE_STATUS, and is defined in
“ardupilotmega.xml”. A typical FENCE_STATUS packet looks like this:

2011
-
12
-
20
16
:
36
:
35.60
:
FENCE_STATUS
breach_status
:
1
,
breach_count
:
15
,
breach_type
:
1
,
breach_time
:
1706506


The breach_status field is 0 if inside the fence, and 1 if outside. The
breach_count is how many fence breaches you have had on this flight. The breach_type is the type of the last breach (see the FENCE_BREACH
enum in ardupilotmega.xml). The breach_time is the time in milliseconds
of the breach since APM was booted. The MAV_SYS_STATUS_GEOFENCE bit of the MAV_SYS_STATUS_SENSOR
portion of the SYS_STATUS message indicates whether or not the
geo-fence is breached. As of this writing only the MAVProxy GCS
recognizes this status bit and reports the status of the geo-fence. In
the future the Mission Planner, APM Planner, and other GCS applications
should get support for announcing geo-fence status during the flight. The MAV_CMD_DO_FENCE_ENABLE MAVLink command message allows a GCS to
enable or disable a fence interactively. As of this writing only
MAVProxy supports this message using the “fence enable” or “fence
disable” commands. In the future Mission Planner, APM Planner, and
other GCS applications may get support for interactively enabling and
disabling the geo-fence without needing to use a manual transmitter. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0131
source_document: common-gps-blending.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: 705ad163eb12f8d5
prev_chunk_id: chunk-0130
next_chunk_id: chunk-0132
document_type: technical_reference

GPS Blending (aka Dual GPS) — Copter  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Copter


Introduction to Copter
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Traditional Helicopters
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
GPS/Compass
RTK GPS
Moving Baseline (GPS for Yaw) Capable
GPS Auto Configuration
GPS Driver Options
GPS Auto Switch
GPS Jamming Mediation
Advanced Uses
Fixed Baseline RTK GPS Correction
GPS Blending (aka Dual GPS)
GPS for Yaw (aka Moving Baseline)
GPS – How it Works
U-Blox F9P Firmware Update Procedure
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
Non-GPS navigation
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Tether
PPM Encoder
Precision Landing and Loiter
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Copter
Peripheral Hardware
GPS/Compass (landing page)
- GPS Blending (aka Dual GPS)
Edit on GitHub

# GPS Blending (aka Dual GPS)
# ¶
GPS Blending combines the readings from two gpses. Using two GPSes reduces the chance of glitches affecting the vehicle. Only GPSs that report position and speed accuracy can be used for blending. All UBlox GPSs provide this extra information while GPSs using the NMEA protocol generally do not. Normally blending should be done with two GPSs from the same manufacturer because the scaling of the accuracy numbers varies and will lead to favouring one GPS over the other.

--- chunk_id: chunk-0132
source_document: common-gps-blending.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 237
content_hash: eb7eac5c32f51d93
prev_chunk_id: chunk-0131
next_chunk_id: chunk-0133
section_heading: Setup through the Ground Station
document_type: technical_reference

## Setup through the Ground Station
### ¶
SERIAL4_PROTOCOL
= 5 / “GPS”. Alternatively telemetry port 1 or 2 can be used by setting
SERIAL1_PROTOCOL
or
SERIAL2_PROTOCOL
to 5. GPS2_TYPE
= 1 / “AUTO” or the specific number corresponding to the type of GPS

GPS_AUTO_SWITCH
= 2 / “Blend”. Alternatively set to 1 / “UseBest” to only use the better GPS. The better GPS is decided based on the GPS’s self reported accuracy. After rebooting the board, the status, hdop and satellite count of both GPSs should be visible. ### Dataflash logging
### ¶
The first GPS’s data appears with an instance number of 0 in the GPS and GPA messages. (ie GPS[0].x, GPA[0].x messages)
The second GPS’s data appears with an instance number of 1 in the GPS and GPA messages. The blended GPS data appears with an instance number of 2 in the GPS and GPA messages. If using the Mission Planner, opening a dataflash log and clicking on “Show Map” will show both GPSs, the blended position and the EKF’s final estimate (shown as “POS”)

--- chunk_id: chunk-0133
source_document: common-gps-blending.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 82
content_hash: e33398a13940d3ff
prev_chunk_id: chunk-0132
next_chunk_id: chunk-0134
section_heading: Video
document_type: technical_reference

## Video
### ¶
Video of a heavily loaded IRIS using Blended GPS, optical flow and a lidar range finder






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0134
source_document: common-gps-how-it-works.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: 7eee472c32c4730a
prev_chunk_id: chunk-0133
next_chunk_id: chunk-0135
document_type: technical_reference

GPS - How it Works — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
Drive Calculator Motor/Propeller Analyzer
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
GPS/Compass
RTK GPS
Moving Baseline (GPS for Yaw) Capable
GPS Auto Configuration
GPS Driver Options
GPS Auto Switch
GPS Jamming Mediation
Advanced Uses
Fixed Baseline RTK GPS Correction
GPS Blending (aka Dual GPS)
GPS for Yaw (aka Moving Baseline)
GPS – How it Works
U-Blox F9P Firmware Update Procedure
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Tether
PPM Encoder
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Peripheral Hardware
GPS/Compass (landing page)
- GPS - How it Works
Edit on GitHub

# GPS - How it Works
# ¶
GPS system is a Global Navigation Satellite System (GNSS). Most civil GPS receivers are using pseudorange data (C/A code) available
on GPS L1 channel (1575.42 MHz) and optionally they can receive SBAS
DGPS corrections giving meter precision. Advanced and expensive civil GPS receivers can use the previous method
plus carrier phase smoothing, carrier phase corrections (RTK) as well as
L2 channel P(Y) code semi-codeless tracking (1227.60 MHz) for realtime
local ionospheric corrections giving centimeter or even millimeter
precision.

--- chunk_id: chunk-0135
source_document: common-gps-how-it-works.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 188
content_hash: f127b8fb9903e6e8
prev_chunk_id: chunk-0134
next_chunk_id: chunk-0136
document_type: technical_reference

Most civil GPS receivers are using pseudorange data (C/A code) available
on GPS L1 channel (1575.42 MHz) and optionally they can receive SBAS
DGPS corrections giving meter precision. Advanced and expensive civil GPS receivers can use the previous method
plus carrier phase smoothing, carrier phase corrections (RTK) as well as
L2 channel P(Y) code semi-codeless tracking (1227.60 MHz) for realtime
local ionospheric corrections giving centimeter or even millimeter
precision. Some even more advanced GNSS receivers can combine DGPS and RTK
corrections and can receive other GNSS satellite constellations (GLONASS, GALILEO, SBAS, Galileo, Beidou, IMES, QZSS, and/or NAVIC) and other channels (L2C, L5…) at the same time to enhance
precision and fix reliability. Military GPS receivers are able to decode the P(Y) code available on L1
and L2 channels giving ten times more precision in realtime compared to
a pseudorange basic solution.

--- chunk_id: chunk-0136
source_document: common-gps-how-it-works.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 286
content_hash: e7ea8e71f14245f2
prev_chunk_id: chunk-0135
next_chunk_id: chunk-0137
section_heading: GPS multipathing
document_type: technical_reference

## GPS multipathing
### ¶
Multipathing is causing GPS position errors that are difficult to detect
and compensate for. Multiple GNSS receivers are better suited to filter
out multipathing thanks to a higher number of visible satellites at the
same time. ### GPS disturbed signal propagation
### ¶
Ionospheric perturbations and magnetic storms (solar activity) can cause
signal delays. This can be partially compensated using SBAS and L1 / L2
decoding. Decoding L1 and L2 channels at the same time do allow realtime
ionospheric corrections through a differential technique. Unlike SBAS
broadcasted ionospheric corrections, this method gives a better match to
local ionospheric conditions. New channels (L2C, L5) for civil use will enhance signal acquisition and
position precision as soon as new satellites constellations will be
complete ( 2015 - 2020 ). ### GPS performance data for different scenarios
### ¶
Those values can be thought as a basis to understand GPS limitations. As a general rule only clear sky view is safe enough for Auto missions ! GPS 3D precision :

Free Horizon (clear sky view): 2.5 m

Extreme Multipath (Backyards or between buildings flights): 26 m

Indoor: 55 m

GPS Availability :

Free Horizon (clear sky view) : 99%

Extreme Multipath (Backyards or between buildings flights) : 83 %

Indoor : 14 %

--- chunk_id: chunk-0137
source_document: common-gps-how-it-works.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: 48e3ee62da035413
prev_chunk_id: chunk-0136
next_chunk_id: chunk-0138
section_heading: DGPS corrections
document_type: technical_reference

## DGPS corrections
### ¶
DGPS corrections are using pseudorange data only. SBAS is a form of DGPS
correction freely available from one or more geostationary satellites. Each region of the world has a localized SBAS system : WAAS for America,
EGNOS for Europe, MSAS for Japan. DGPS corrections give meter precision (free services) or decimeter
precision (paying services)

### RTK corrections
### ¶
RTK corrections are using carrier phase information and needs costly
advanced GPS as well as a RTK base station or a Network of RTK base
stations broadcasting corrections over a modem or Internet through the
RTCM protocol. RTK is easier to use with slow motion or static applications (like
surveying or farming) and give centimeter or millimeter precision. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0138
source_document: common-imu-batchsampling.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 484
content_hash: 2bc9c66a46337d40
prev_chunk_id: chunk-0137
next_chunk_id: chunk-0139
document_type: technical_reference

Measuring Vibration with IMU Batch Sampler — Copter  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Copter


Introduction to Copter
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Traditional Helicopters
Mission Planning
If A Problem Arises
Logs
Log Types (Dataflash vs Tlogs)
Topics related to logging and analysis
Tools for Log Analysis
What to do if you have an issue
Vehicle Will Not Arm
Interference issues on Electric Vehicles
Copter Common Problems
Free RAM issues
H7 AutoPilot Will Not Initialize
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Copter
When Problems Arise
Logs
- Measuring Vibration with IMU Batch Sampler
Edit on GitHub

# Measuring Vibration with IMU Batch Sampler
# ¶
The IMU BatchSampler can be used to record high-frequency data from the IMU sensors to the dataflash log on the autopilot. This data can be analysed post-flight to diagnose vibration issues using graphs created from Fast Fourier Transforms (FFT) of the data. FFT transforms data from the time domain into the frequency domain. Put another way, accelerometer data recorded over time (i.e. a flight) can be converted into a graph showing the frequencies of the vibration. A frequent feature of these graphs is a spike at the propeller’s “blade passage frequency” (the frequency at which the blade crosses over the arms) which causes an acceleration in the aircraft body. FFT has the following limitations:

FFT cannot show you frequencies above half your sensor’s sampling rate

The smallest frequency that can be shown is half your sample size divided by your sample rate

Samples are typically taken at the same rate as gyro updates provided to the autopilot. For example if you are using
INS_FAST_SAMPLE
on an MPU9250 sensor (fairly typical on modern Pixhawk class autopilots) then samples will be take at 8KHz, but averaged and downsampled to 1KHz.

--- chunk_id: chunk-0139
source_document: common-imu-batchsampling.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 416
content_hash: 828eaab006db4bea
prev_chunk_id: chunk-0138
next_chunk_id: chunk-0140
document_type: technical_reference

FFT has the following limitations:

FFT cannot show you frequencies above half your sensor’s sampling rate

The smallest frequency that can be shown is half your sample size divided by your sample rate

Samples are typically taken at the same rate as gyro updates provided to the autopilot. For example if you are using
INS_FAST_SAMPLE
on an MPU9250 sensor (fairly typical on modern Pixhawk class autopilots) then samples will be take at 8KHz, but averaged and downsampled to 1KHz. If you are not using an autopilot with fast sampling capability, then the sample rate is 1KHz

This 1KHz “backend” rate is the rate at which gyro filtering takes place, i.e. low-pass and notch filters, and on smaller copters 1Khz is not high enough to avoid aliasing from noise at higher frequencies. For example, a 3” copter might have a full throttle motor frequency of 600Hz. Since filters can only apply at half the sample frequency (the Nyquist limit)it is not possible to filter 600Hz noise when sampling at 1Khz and the noise will be aliased down to lower frequencies. The backend rate has been made configurable for IMUs that support fast sampling (i.e. Invensense sensors) so that higher rates can be supported. The backend rate can be configured by setting
INS_GYRO_RATE
. The default 0 gives the same behaviour as previous firmware versions. A rate of N gives a backend rate of 2^N Khz, so for instance a value of 1 gives a backend rate of 2Khz ,etc. Note

This raises the rate at which all gyro filters are run and can be computationally expensive depending on the number of notches configured. Values above 0 are only recommend on F7 or H7 platforms and values above 1 should only be used with careful tuning. This is automatically done for those platforms. This allows capturing frequencies at 1KHz and below on these autopilots.

--- chunk_id: chunk-0140
source_document: common-imu-batchsampling.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: b0297928ad0ea78c
prev_chunk_id: chunk-0139
next_chunk_id: chunk-0141
section_heading: Pre-Flight Setup
document_type: technical_reference

## Pre-Flight Setup
### ¶
Set
INS_LOG_BAT_OPT
= 4 to do pre and post-filter 1KHz sampling

Set
INS_LOG_BAT_MASK
= 1 to collect data from the first IMU

INS_LOG_BAT_LGIN
is the gap between batch samples and normally does not need to be changed. It can be lowered to increase accuracy of resulting FFT, but may be ineffective depending on the systems logging speed. LOG_BITMASK
’s IMU_RAW bit must
not
be checked. The default
LOG_BITMASK
value is fine. If it is checked the results can be confusing as you will get no samples if using post-filter or regular logging, you will however get samples if using sensor rate logging and your SD card is able to cope. ### Flight and Post-Flight Analysis
### ¶
Perform a regular flight (not just a gentle hover) of at least 1 minute and
download the dataflash logs

Open Mission Planner, under SETUP/ADVANCED, press the FFT button, press “IMU Batch Sample” and select the .bin log file downloaded above

On the graph it should be possible to identify a significant peak in noise that corresponds to the motor rotational frequency. On a smaller Copter this is likely to be around 200Hz and on a larger Copter/QuadPlane 100Hz or so. There will usually be harmonics of the motor rotational frequency (2x,3x that frequency) also.Here is an example from a 5” quad with no notches setup and a 20Hz lowpass setting for the gyro filter:

Four graphs are shown: ACC0- Accelerometer spectrum before filtering, ACC1- Accelerometer spectrum after filtering, GYR0 -Gyro spectrum before filtering, and GYR1- Gyro spectrum after filtering. Vibration at frequencies above 100Hz may lead to attitude or position control problems. A pronounced noise peak at 180Hz is evident from the motors in hover, with a smaller second harmonic showing. Notice that the noise has been dramatically reduced by the lowpass filters on the sensors, but at the cost of significant phase lag that will have reduced how tight the tune was made. It should be possible to “notch” out that 180Hz motor noise spike and increase the gyro low pass filter to 60 or 80Hz to allow a tighter tune to be done. The accelerometer path is not as critical since it forms an outer loop around the gyro based rate PID controllers.

--- chunk_id: chunk-0141
source_document: common-imu-batchsampling.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 138
content_hash: 2016705d0f91c802
prev_chunk_id: chunk-0140
next_chunk_id: chunk-0142
section_heading: Pre-Flight Setup
document_type: technical_reference

It should be possible to “notch” out that 180Hz motor noise spike and increase the gyro low pass filter to 60 or 80Hz to allow a tighter tune to be done. The accelerometer path is not as critical since it forms an outer loop around the gyro based rate PID controllers. Leaving its lowpass filter at 10Hz does not affect the ability of the vehicle to reject disturbances quickly, which is the rate controller’s main task. If we just increase the gyro lowpass filter to 60Hz from 20HZ , without adding notch filters to decrease the motor noise, this results, which is not acceptable:

--- chunk_id: chunk-0142
source_document: common-imu-batchsampling.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 253
content_hash: 49cecfadaae7040a
prev_chunk_id: chunk-0141
next_chunk_id: chunk-0143
section_heading: Harmonic Notch Filter Setup
document_type: technical_reference

## Harmonic Notch Filter Setup
### ¶
It is possible to filter some of this noise to increase performance and allow better tuning by activating the harmonic notch filter(s). See
Managing Gyro Noise with the Dynamic Harmonic Notch Filters
for details. For Throttle Based Dynamic Harmonic Notch(s) you will need some additional information from the logs if using a
Throttle Based Dynamic Notch Setup
:
- With the same log, open it in the regular way in mission planner and graph the throttle value: CTUN.ThO (Copter) or QTUN.ThO (QuadPlane). . From this identify an average hover throttle value which will be used for
INS_HNTCH_REF
. - It’s also possible to use
MOT_HOVER_LEARN
= 2 in Copter and read off the value of
MOT_THST_HOVER
, or
Q_M_HOVER_LEARN
= 2 in QuadPlane and read off the value of
Q_M_THST_HOVER
- This gives you a hover motor frequency
hover_freq
and thrust value
hover_thrust
. Note that learning of hover thrust only occurs while in an altitude controlled mode with no pitch or roll angle. Therefore, it should be done in calm wind conditions with no pilot stick input for at least 10 seconds.

--- chunk_id: chunk-0143
source_document: common-imu-batchsampling.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 228
content_hash: d810c67513b3850a
prev_chunk_id: chunk-0142
next_chunk_id: chunk-0144
section_heading: Post Configuration Confirmation Flight and Post-Flight Analysis
document_type: technical_reference

## Post Configuration Confirmation Flight and Post-Flight Analysis
### ¶
With
INS_LOG_BAT_MASK
still set to = 1 to collect data from the first IMU:

Set
INS_LOG_BAT_OPT
= 2 to capture post-filter gyro data

Perform a similar hover flight and analyze the dataflash logs in the same way. This time you should see significantly less noise and, more significantly, attenuation of the motor noise peak. If the peak does not seem well attenuated then you can experiment with increasing the bandwidth and attenuation of the notch. However, the wider the notch the more delay it will introduce into the control of the aircraft so doing this can be counter-productive. Here is an example from the same 5” quad with the harmonic notch configured and 60Hz gyro lowpass filter:

Note

be sure to reset the
INS_LOG_BAT_MASK
to “0” when finished with analysis flights to free up the RAM consumed by this feature. In some autopilots, you cannot do other memory intensive tasks like Compass Calibration or MAVftp if this batch logging is enabled.

--- chunk_id: chunk-0144
source_document: common-imu-batchsampling.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 449
content_hash: 5991c30476731065
prev_chunk_id: chunk-0143
next_chunk_id: chunk-0145
section_heading: Advanced Configuration and Analysis
document_type: technical_reference

## Advanced Configuration and Analysis
### ¶
Set
INS_LOG_BAT_OPT
= 1 to enable batch sampling at the sensor’s highest rate which allows analysis above 500hz for very fast IMUs from InvenseSense

INS_LOG_BAT_MASK
can be used to sample just a single sensor. This will increase the number of samples retrieved from a single sensor (e.g. the best on the platform), which may provide better data for analysis

INS_LOG_BAT_CNT
specifies the number of samples which will be collected. Increasing this will yield a more representative idea of problem frequencies. When divided by the sample rate will give the lowest frequency which can be detected, so 1024 samples at 1024kHz sampling will (poorly) pick up 0.5Hz frequencies

INS_LOG_BAT_LGIN
interval between pushing samples to the dataflash log, in ms. Increase this to reduce the time taken to flush data to the dataflash log, reducing cycle time. This will be at the expense of increased system load and possibly choking up the dataflash log for other messages

INS_LOG_BAT_LGCT
Number of samples to push to count every
INS_LOG_BAT_LGIN
ms. Increase this to push more samples each time they are sent to the dataflash log. Increasing this may cause timing jitter, and possibly choke up the dataflash log for other messages

Note

On an H7 based autopilot such as the CubeOrange or Zealot H743, raw IMU logging can be used and will provide better data for analysis. Set
INS_LOG_BAT_MASK
= 0, set the raw IMU bit (bit 19) in
LOG_BITMASK
, set
INS_LOG_BAT_OPT
= 0. Raw logging is very helpful when doing filter tuning, but will give you really large logs which generally means you don’t want to leave it on. The web based
Notch Filter Review tool
on the ArduPilot Firmware “Web Tools” page can be used to analyze notch filter logs generated with either batch sampling or raw IMU logging. The following two graphs are from the same flight on a PixRacer autopilot. Accel[0] on the right is the InvenseSense IMU and shows higher frequencies than the slower IMU on the left

--- chunk_id: chunk-0145
source_document: common-imu-batchsampling.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 261
content_hash: 2d9eae6f76ab2734
prev_chunk_id: chunk-0144
next_chunk_id: chunk-0146
section_heading: Log Message Contents
document_type: technical_reference

## Log Message Contents
### ¶
There are two types of dataflash log messages involved in batch sampling,
ISBH
and
ISBD
. ISBH
is a batch header; it includes a batch number and metadata about the batch. ISBD
messages contain the actual data for the batch, and reference a header by batch number. ### Analysis with pymavlink
### ¶
pymavlink
is a developer focussed tool which supports graph FFT’d data

pbarker@bluebottle:~/rc/ardupilot(fastest-sampling)$ ~/rc/pymavlink/tools/mavfft_isb.py /tmp/000003.BIN
Processing log /tmp/000003.BIN
Skipping ISBD outside ISBH (fftnum=0)

Skipping ISBD outside ISBH (fftnum=0)

Skipping ISBD outside ISBH (fftnum=0)

Skipping ISBD outside ISBH (fftnum=0)

Skipping ISBD outside ISBH (fftnum=0)

Skipping ISBD outside ISBH (fftnum=0)

............................... 32560s messages  48433 messages/second  1904039 kB/second
Extracted 10 fft data sets
Sensor: Gyro[0]
Sensor: Accel[0]


This output shows
mavfft_isb.py
extracting data from a single-IMU multicopter log. This multicopter frame clearly shows vibrations in the 80Hz range. This multicopter frame clearly shows rotational vibrations in the 80Hz range. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0146
source_document: common-loading-firmware-onto-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 338
content_hash: bfc87894e7007037
prev_chunk_id: chunk-0145
next_chunk_id: chunk-0147
document_type: technical_reference

Loading Firmware — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Installation Steps
Connect autopilot to computer
Select the COM port
Install firmware
Using Beta, Developer, and Customized Versions
Beta
Latest Developer Version
Custom Firmware Build Server
Firmware Limitations
Loading Firmware via SD Card
Testing
Loading Firmware via SD Card
ArduPilot Custom Firmware Builder
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
- Loading Firmware
Edit on GitHub

# Loading Firmware
# ¶
These instructions will show you how to download the latest firmware onto the autopilot hardware that already has ArduPilot firmware installed. This process will use the Mission Planner ground control station. See
Loading Firmware onto boards without existing ArduPilot firmware
. Note

for some autopilots, it may be possible to update the firmware by
flashing from SD card

--- chunk_id: chunk-0147
source_document: common-loading-firmware-onto-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: d865c23fc1256a75
prev_chunk_id: chunk-0146
next_chunk_id: chunk-0148
section_heading: Installation Steps
document_type: technical_reference

## Installation Steps
### ¶
### Connect autopilot to computer
### ¶
Once you have
installed a ground station
on your computer, connect
the autopilot using a USB cable as shown
below. Use a direct USB port on your computer (not a USB hub). Pixhawk USB Connection
¶

Windows should automatically detect and install the correct driver
software. ### Select the COM port
### ¶
If using
Mission Planner
as the GCS, select the COM port drop-down in the upper-right corner of the window near the
Connect
button. Select
AUTO
or the specific port for your board. Set the Baud rate to
115200
as shown. Do not hit
Connect
just yet. ### Install firmware
### ¶
In Mission Planner’s
SETUP | Install Firmware
screen
select the appropriate icon that matches your vehicle or frame type(i.e. Quad, Hexa). Answer
Yes
when it asks you “Are you sure?”. Mission Planner: Install FirmwareScreen
¶

Note

some boards are specifically targeted to a particular vehicle type and firmware is not automatically built for other vehicles. However, ArduPilot could still be built for those other vehicles using the
Custom Firmware Server
. Mission Planner will try to detect which board you are using. It may ask you to unplug the board, press OK, and plug it back in to detect the board type. Mission Planner: Install Firmware Prompt
¶

Often you will be presented with a dropdown box of firmware variants for the board, which you can select from (such as bi-directional DShot variants, if available). For boards which share the Pixhawk board id, the list will be extensive, as shown below:

Select the appropriate firmware for your board. For boards marked “Pixhawk”, Pixhawk1 firmware is usually the best choice. Warning

some boards labeled as Pixhawk 2.4.x may have sensor substitutions which may lead to pre-arm checks or no secondary IMU. Please see the BARO_OPTIONS parameter for a workaround for a known sensor substitution on some boards of a MS5607 barometer where a MS5611 should be used. IMUs may also be substituted. Where possible, please source autopilots from ArduPilot partners. If all goes well, you will see a status appear on the bottom right including the words: “erase…”, “program…”, “verify..”, and “Upload Done”. The firmware has been successfully uploaded to the board.

--- chunk_id: chunk-0148
source_document: common-loading-firmware-onto-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 204
content_hash: 6799bd6227657b91
prev_chunk_id: chunk-0147
next_chunk_id: chunk-0149
section_heading: Installation Steps
document_type: technical_reference

If all goes well, you will see a status appear on the bottom right including the words: “erase…”, “program…”, “verify..”, and “Upload Done”. The firmware has been successfully uploaded to the board. It usually takes a few seconds for the bootloader to exit and enter the main code after programming or a power-up. Wait to press CONNECT until this occurs. Note

Updating the firmware to a newer version does not alter existing parameters unless the firmware is for a different vehicle, in which case parameters are reset to their default values for that vehicle. However, it is always a good idea to save your parameters to a file using the “Save to File” button on the Mission Planner’s
CONFIG/Full Parameter Tree
tab before any firmware updates, just in case of any issues while updating. Do not apply all parameters after upgrading to a new version as some parameters might have a different meaning.

--- chunk_id: chunk-0149
source_document: common-loading-firmware-onto-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 289
content_hash: d3a860b41f1f6b4d
prev_chunk_id: chunk-0148
next_chunk_id: chunk-0150
section_heading: Using Beta, Developer, and Customized Versions
document_type: technical_reference

## Using Beta, Developer, and Customized Versions
### ¶
### Beta
### ¶
Prior to
Stable
releases,
Beta
versions are released. These may be used if you wish to try newer features or help the developers flight test new code. Since these are “beta” versions, there may still be bugs. This is possible even in Stable release firmware. However, a Beta release has been tested by the development team, and already flight tested. This release allows a wider user base to final test the firmware before releasing as
Stable
. Experienced ArduPilot users are encouraged to test fly this firmware and provide feedback. Mission Planner has an option on the
Install Firmware
page to upload this release, but later
Stable
releases may already be available. Be sure to check the normal vehicle upload option first. ### Latest Developer Version
### ¶
This reflects the current state of the development branch of the ArduPilot code. It has been reviewed by the development team, passed all automated test suites, and in most cases test flown. This code gets built daily and is available for testing by experienced users. This corresponds to an “alpha” release, and may have bugs, although very rarely “crash inducing”. Very shortly after an addition that changes or introduces a feature is added, the
Upcoming Features

--- chunk_id: chunk-0150
source_document: common-loading-firmware-onto-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 432
content_hash: 4e2ebe361fa5d454
prev_chunk_id: chunk-0149
next_chunk_id: chunk-0151
section_heading: section of the Wiki is updated with information about the addition or change.
document_type: technical_reference

section of the Wiki is updated with information about the addition or change. This code must be manually downloaded from the
Firmware Downloads
page as
latest
for your particular board, and then uploaded using Mission Planner’s “Load Custom Firmware” option on its
Install Firmware Page


### Custom Firmware Build Server
### ¶
ArduPilot is currently experimentally testing a custom firmware build server that will allow users to generate firmware builds for their autopilots with selectable features. Since all 1MB flash sized boards now have feature restrictions to allow the code to fit, this will give a path to enable a user to select which features will or will not be included, giving some flexibility to users of 1MB autopilots. The server is located
HERE
and instructions for its use are
on this page HERE
. It allows creating a custom build, which can be downloaded, and flashed to the autopilot using Mission Planner’s “Load Custom Firmware” option on its
Install Firmware Page
. connect the ground station PC to the autopilot using a USB cable

select the COM port and baud rate (normally 115200, but you can choose higher if your hardware allows) for the board. These are selected on the top right of the screen. Do
not
press the Connect button

go to MP firmware install screen (select “Setup >> Install Firmware”)

click the “Load custom firmware” link and select the .apj file you downloaded (do not select the .hex files, which are only meant to be used with DFU/JTAG/SWD methods). If the “Load custom firmware” link is not visible select “Config >> Planner” and set the “Layout” drop-down to “Advanced”. you may need to click on “Force bootloader” before the step above (assuming the board has been previously flashed with Ardupilot’s bootloader)

follow any instructions displayed regarding plugging/unplugging the board

if all goes well some status should be displayed at the bottom of the screen. i.e. “erase…”, “program…”, “verify..” and “Upload Done”.

--- chunk_id: chunk-0151
source_document: common-loading-firmware-onto-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 230
content_hash: 8b590304b875e687
prev_chunk_id: chunk-0150
next_chunk_id: chunk-0152
section_heading: Firmware Limitations
document_type: technical_reference

## Firmware Limitations
### ¶
For a list of what features are
not
included in the current “latest” firmware for any given autopilot, see
this page
. All the feature options currently
not
included in the 1MB autopilots, by default, are on the list of options on the Custom Firmware Build Server. There are also many features still included in the 1MB autopilots that may not be required for your application. So it is possible to create a build that includes some of the currently excluded features while removing some of the unneeded features. The list of feature options will be continuously expanded, allowing other large features to be dropped and more restricted features added to the custom build. For example, not including QuadPlane features will save space for Planes not requiring it. Drivers and peripheral support may be individually selected, allowing only those used to be in the code thus allowing other features to be included in the custom firmware. Current build is from the daily master branch, Stable and Beta branches.

--- chunk_id: chunk-0152
source_document: common-loading-firmware-onto-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 186
content_hash: 1ea8a4b0ca5d7446
prev_chunk_id: chunk-0151
next_chunk_id: chunk-0153
section_heading: Loading Firmware via SD Card
document_type: technical_reference

## Loading Firmware via SD Card
### ¶
The firmware on some autopilots may be uploaded by copying an ‘ardupilot.abin’ firmware file to the SD card and then power cycling the board. Details on how to
update the firmware via SD Card can be found here
. ### Testing
### ¶
You can test the firmware is working on a basic level by switching to the
Mission Planner Flight Data
screen and pressing the
Connect
button. The HUD should update as you tilt the board. Connect Mission Planner to AutoPilot
has more
information on connecting to Mission Planner. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0153
source_document: common-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 210
content_hash: 1960ef393bb42cf4
prev_chunk_id: chunk-0152
next_chunk_id: chunk-0154
document_type: technical_reference

Logs — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Logs
Log Types (Dataflash vs Tlogs)
Topics related to logging and analysis
Tools for Log Analysis
What to do if you have an issue
Vehicle Will Not Arm
Interference issues on Electric Vehicles
Free RAM issues
H7 AutoPilot Will Not Initialize
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
When Problems Arise
- Logs
Edit on GitHub

# Logs
# ¶

--- chunk_id: chunk-0154
source_document: common-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 296
content_hash: 945aa018afae4df0
prev_chunk_id: chunk-0153
next_chunk_id: chunk-0155
section_heading: Log Types (Dataflash vs Tlogs)
document_type: technical_reference

## Log Types (Dataflash vs Tlogs)
### ¶
There are two ways to record your flight data. With some exceptions, the
two methods record very similar data but in different ways:

Dataflash logs
are recorded on the autopilot (often to the SD card) so they must be downloaded from the autopilot after a flight

Telemetry logs
(also known as “Tlogs”) are recorded by the ground station (i.e. Mission Planner) on the local PC when the autopilot is connected via a
telemetry link

If you are not yet familiar with the basics of these log files, first review the introductory pages to understand where these logs are stored and how you can download and view the information held within them. ### Topics related to logging and analysis
### ¶
Dataflash Logs
Telemetry Logs
Diagnosing problems using Logs
Plane Log Messages
Log Analysis Case Study: Fly-by-Wire
Log Analysis Case Study: Turn Rate Adjustment
Measuring Vibration
Measuring Vibration with "Batch Sampling"
Measuring Vibration with "Raw IMU Logging" (Preferred)


### Tools for Log Analysis
### ¶
MAVExplorer
ArduPilot WebTools
MissionPLanner
QGroundControl
Dronee Plotter
PlotJuggler






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0155
source_document: common-magnetic-interference.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 489
content_hash: e12cee0fae3aa96a
prev_chunk_id: chunk-0154
next_chunk_id: chunk-0156
document_type: technical_reference

Magnetic Interference — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
EKF (Extended Kalman Filter)
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Overview
Hardware changes to reduce magnetic interference on the compass
Maxwell’s Equations - The Magnetic Field on the Axis of a Current Loop
Natural and Artificial Magnetic Anomalies Warning
GPS for yaw
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- Magnetic Interference
Edit on GitHub

# Magnetic Interference
# ¶
This article covers general information related to magnetic
interference.

--- chunk_id: chunk-0156
source_document: common-magnetic-interference.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 305
content_hash: 4b4cd387a5e8e3bc
prev_chunk_id: chunk-0155
next_chunk_id: chunk-0157
section_heading: Overview
document_type: technical_reference

## Overview
### ¶
Magnet Interference on a compass can have a serious impact on navigation
on all vehicle types. This article explains what hardware changes you can make to reduce
magnetic interference on the compass, along with supporting theoretical
discussion. Information on how to set-up your compass can be found on
Advanced Compass Setup
. See also
Magnetic Declination
(wikipedia)

### Hardware changes to reduce magnetic interference on the compass
### ¶
The best way method is to use an
external compass
or
GPS+Compass
module mounted on a mast up and away from magnetic source of
interference including the power distribution board (PDB). Keep the wires between the PDB, ESCs and battery as short as
possible. The wires from the ESCs to the motors are less important
because they are AC and produce less interference. Twist the wires between the PDB, ESC and battery and use grounded
shielding where possible. Replace the PDB and ESCs with a 4-in-1 ESC because they tend to
produce less interference probably because their wires are shorter
and closer together and they also have an aluminum plate on top which
may help reduce the interference. Add aluminum shielding (even gutter tape) around the wires from the
ESC to the motors may reduce the AC interference. Aluminum will not
help reduce the primary DC interference from the PDB, ESCs and the
wires connecting them.

--- chunk_id: chunk-0157
source_document: common-magnetic-interference.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 78b657a4d0f16dec
prev_chunk_id: chunk-0156
next_chunk_id: chunk-0158
section_heading: Maxwell’s Equations - The Magnetic Field on the Axis of a Current Loop
document_type: technical_reference

## Maxwell’s Equations - The Magnetic Field on the Axis of a Current Loop
### ¶
Geometric details (from
this web
page. )


The application of
the
Biot-Savart
law
on the centerline of a
current
loop
involves
integrating the z-component. The symmetry is such that all the
terms in this element are constant
except the distance element dL,
which when integrated just gives the
circumference of the circle. The
magnetic field is then:


There are 3 things to get from this drawing and the equation for the
magnetic field B as you move away from a current loop along the Z axis:

The magnetic field increases as a function of the enclosed loop area
Pi R^2

Big loop = big magnetic field

Reduce the magnetic field by twisting the loop to close it. aka
twist the wires together and keep your return path close to the
source

In the case where you have a PDB and 4 ESCs you have 4 loops that
start at the Deans connector on the PDB, go out to the ESC and
return back to the Deans connector. In the case of the 4 in 1 ESC
the current flow is much more concentrated in one area and you
don’t have the big loops so consequently you decrease the magnetic
field. The magnetic field increases as a function of current

Where there is the option, you can deliver the same power and
decrease the magnetic field by increasing the voltage and
decreasing the current. The magnetic field decreases as a function of the cube of the
distance

It is more complicated when you are close to the loop but when z
>> R the denominator goes to z^3

There is one more thing and that is that the direction of the magnetic
field depends on the direction that the current flows so when you rotate
a battery it changes the magnetic field produced by the current flowing
in the battery. It can’t be stated enough that minimizing the enclosed loop areas and
moving the compass away from the current will help things work better
and “yes”, power distribution boards with big circular thick high
current PC traces on them produce significant semi-spherical fields as
large or larger than their diameter.

--- chunk_id: chunk-0158
source_document: common-magnetic-interference.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 276
content_hash: 91a87b6bb0748522
prev_chunk_id: chunk-0157
next_chunk_id: chunk-0159
section_heading: Natural and Artificial Magnetic Anomalies Warning
document_type: technical_reference

## Natural and Artificial Magnetic Anomalies Warning
### ¶
Note

The following information has not been objectively tested to
determine its impact on a vehicle’s compass accuracy in flight. Many things can distort the earth’s magnetic field in the area you
are flying:

Steel framed or reinforced concrete buildings, bridges and
roadways, iron pipes and culverts, high power electric lines,
heavy equipment, trucks and automobiles, steel tanks, electric
motors and even computers. Flying between steel framed or reinforced high rise buildings will
distort the magnetic field in addition to causing GPS
multi-pathing. Safe distances for compass calibration

6” (15 cm) minimum: Metal rim glasses, pen/pencil, metal watch
band, pocket knife, metal zipper/buttons, belt buckle, batteries,
binoculars, cell phone, keys, camera, camcorder, survey nails,
metal tape measure. 18” (50 cm) minimum: Clipboard, data collector, computer, GPS
antenna, 2-way radio, hand gun, hatchet, cell phone case with
magnetic closure. 6 ft (2 m) minimum: Bicycle, fire hydrant, road signs, sewer cap
or drain, steel pole, ATV, guy wire, magnets, chain-link fence,
bar-wire fence, data collectors

that use a magnet to hold the stylus. 15 ft (5 m) minimum: Electrical box, small car/truck, powerline,
building with concrete & steel. 30 ft (10 m) minimum: Large truck, metal building, heavy
machinery.

--- chunk_id: chunk-0159
source_document: common-magnetic-interference.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 97
content_hash: 422b0e6b46c0bca9
prev_chunk_id: chunk-0158
next_chunk_id: chunk-0160
section_heading: GPS for yaw
document_type: technical_reference

## GPS for yaw
### ¶
ArduPilot supports the use of GPS heading information to reduce malfunctions caused by changes in the magnetic field in certain environments. Configure GPS for yaw






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0160
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: 856f9d59fb01578e
prev_chunk_id: chunk-0159
next_chunk_id: chunk-0161
document_type: technical_reference

Mission Commands — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
Choosing a Ground Station
Mission Planning
Planning a Mission with Waypoints and Events
Mission Command List
Overview
Commands supported by Plane
Navigation commands
Conditional commands
DO commands
Camera Control in Auto Missions
Rally Points
DO_LAND_START
DO_RETURN_PATH_START
Geotagging Images with Mission Planner
Terrain Following
Rewind-on-resume
Continue Mission After Landing
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
Planning a Mission with Waypoints and Events
Mission Command List
Overview
Types of commands
Frames of reference
How accurate is the information? How to interpret the command parameters
Using this information with a GCS
Commands supported by Plane
Navigation commands
MAV_CMD_NAV_WAYPOINT
MAV_CMD_NAV_TAKEOFF
MAV_CMD_NAV_VTOL_TAKEOFF
MAV_CMD_NAV_LOITER_UNLIM
MAV_CMD_NAV_LOITER_TURNS
MAV_CMD_NAV_LOITER_TIME
MAV_CMD_NAV_RETURN_TO_LAUNCH
MAV_CMD_NAV_LAND
MAV_CMD_NAV_VTOL_LAND
MAV_CMD_NAV_CONTINUE_AND_CHANGE_ALT
MAV_CMD_NAV_ALTITUDE_WAIT
MAV_CMD_NAV_LOITER_TO_ALT
MAV_CMD_NAV_DELAY
MAV_CMD_NAV_PAYLOAD_PLACE
MAV_CMD_DO_JUMP
MAV_CMD_JUMP_TAG
MAV_CMD_DO_JUMP_TAG
Conditional commands
MAV_CMD_CONDITION_DELAY
MAV_CMD_CONDITION_DISTANCE
DO commands
MAV_CMD_DO_CHANGE_SPEED
MAV_CMD_DO_SET_HOME
MAV_CMD_DO_SET_RELAY
MAV_CMD_DO_REPEAT_RELAY
MAV_CMD_DO_SET_SERVO
MAV_CMD_DO_REPEAT_SERVO
MAV_CMD_DO_LAND_START
MAV_CMD_DO_VTOL_TRANSITION
MAV_CMD_DO_SET_ROI, MAV_CMD_DOE_SET_ROI_LOOCATION, MAV_CMD_DO_SET_ROI_NONE
MAV_CMD_DO_DIGICAM_CONFIGURE
MAV_CMD_DO_DIGICAM_CONTROL
MAV_CMD_DO_MOUNT_CONTROL
MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW
MAV_CMD_DO_SET_CAM_TRIGG_DIST
MAV_CMD_DO_FENCE_ENABLE
MAV_CMD_DO_AUX_FUNCTION
MAV_CMD_DO_INVERTED_FLIGHT
MAV_CMD_DO_AUTOTUNE_ENABLE
MAV_CMD_DO_ENGINE_CONTROL
MAV_CMD_DO_SET_RESUME_REPEAT_DIST
MAV_CMD_STORAGE_FORMAT
Camera Control in Auto Missions
Rally Points
DO_LAND_START
DO_RETURN_PATH_START
Geotagging Images with Mission Planner
Terrain Following
Rewind-on-resume
Continue Mission After Landing
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Ground Control Stations
Mission Planning
- Mission Commands
Edit on GitHub

# Mission Commands
# ¶
This article describes the mission commands that are supported by Copter, Plane, Sub and Rover when switched into Auto mode. Note

there are many other MAVLink commands that a GCS or other device can send to the autopilot. See the ArduPilot/navlink repository, or the documentation for your GCS.

--- chunk_id: chunk-0161
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: 47a95fe584d5372e
prev_chunk_id: chunk-0160
next_chunk_id: chunk-0162
section_heading: Overview
document_type: technical_reference

## Overview
### ¶
The MAVLink protocol defines a large number of
MAV_CMD
waypoint command types (sent in a
MAVLink_mission_item_message
). ArduPilot implements handling for the subset of these commands and
command parameters that are
most relevant
and meaningful for each of
the vehicles. Unsupported commands that are sent to a particular
autopilot will simply be dropped. This article lists and describes the commands and command-parameters
that are supported on each of the vehicle types. Any parameter that is
“grey” is not supported by the autopilot and will be ignored. They are
still documented to make it clear which properties are supported by
the
MAV_CMD protocol
are not implemented by the vehicle. Some commands and command parameters are not implemented because they
are not relevant for particular vehicle types (for example
“MAV_CMD_NAV_TAKEOFF” command makes sense for Plane and Copter but
not Rover and the pitch parameter only makes sense for Plane). There
are also some potentially useful command parameters that are not handled
because there is a limit to the message size, and a decision has been
made to prioritize some parameters over others. Note

There is additional information about the supported commands on
Copter (from a Mission Planner perspective) in the
Copter Mission Command List
. ### Types of commands
### ¶
There are several different types of commands that can be used within
missions:

Navigation commands are used to control the movement of the vehicle,
including takeoff, moving to and around waypoints, changing altitude,
and landing. DO commands are for auxiliary functions and do not affect the
vehicle’s position (for example, setting the camera trigger distance,
or setting a servo value). Condition commands are used to delay DO commands until some condition
is met, for example, the UAV reaches a certain altitude or distance
from the waypoint. During a mission at most one “Navigation” command and one “Do” or
“Condition” command can be running at one time. A typical mission might
set a waypoint (NAV command), add a CONDITION command that doesn’t
complete until a certain distance from the destination
(
MAV_CMD_CONDITION_DISTANCE
), and
then add a number of DO commands that are executed sequentially (for
example
MAV_CMD_DO_SET_CAM_TRIGG_DIST
to take pictures at regular intervals) when the condition completes.

--- chunk_id: chunk-0162
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 473
content_hash: 06f1209f5b79b23e
prev_chunk_id: chunk-0161
next_chunk_id: chunk-0163
section_heading: Overview
document_type: technical_reference

During a mission at most one “Navigation” command and one “Do” or
“Condition” command can be running at one time. A typical mission might
set a waypoint (NAV command), add a CONDITION command that doesn’t
complete until a certain distance from the destination
(
MAV_CMD_CONDITION_DISTANCE
), and
then add a number of DO commands that are executed sequentially (for
example
MAV_CMD_DO_SET_CAM_TRIGG_DIST
to take pictures at regular intervals) when the condition completes. Note

CONDITION and DO commands are associated with the preceding NAV
command: if the UAV reaches the next waypoint before these commands are
executed, the next NAV command is loaded and they will be
skipped. ### Frames of reference
### ¶
Many of the commands (in particular the
NAV_ commands
) include position/location
information. The information is provided relative to a particular “frame
of reference”, which is specified in the message’s
Frames of reference
field. Copter and Rover Mission use
MAV_CMD_DO_SET_HOME
command to set the
“home position” in the global coordinate frame (MAV_FRAME_GLOBAL),
WGS84 coordinate system
, where
the altitude is relative to mean sea level. All other commands use the
MAV_FRAME_GLOBAL_RELATIVE_ALT frame, which uses the same latitude
and longitude, but sets altitude as relative to the
home position
(home altitude = 0). Plane commands can additionally use MAV_FRAME_GLOBAL_TERRAIN_ALT
frame of reference. This again has the same WGS84 frame of reference for
latitude/longitude, but specifies altitude relative to ground height (as
defined in a terrain database). Note

The other frame types are defined in the MAVLink protocol (see
MAV_FRAME
)
are not supported for mission commands. ### How accurate is the information? ### ¶
If a command or parameter is marked as supported then it is likely (but
not guaranteed) that it will behave as indicated. If a command or
parameter is not listed (or marked as not supported) then it is
extremely likely that it is not supported on ArduPilot. The reason for this is that the information was predominantly inferred
by inspecting the command handlers for messages:

The switch statement in
AP_Mission::mavlink_to_mission_cmd
was inspected to determine which commands are handled by
all
vehicle platforms, and which parameters from the message are stored.

--- chunk_id: chunk-0163
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 488
content_hash: 2b09b4ce5af07b22
prev_chunk_id: chunk-0162
next_chunk_id: chunk-0164
section_heading: Overview
document_type: technical_reference

If a command or
parameter is not listed (or marked as not supported) then it is
extremely likely that it is not supported on ArduPilot. The reason for this is that the information was predominantly inferred
by inspecting the command handlers for messages:

The switch statement in
AP_Mission::mavlink_to_mission_cmd
was inspected to determine which commands are handled by
all
vehicle platforms, and which parameters from the message are stored. The command handler switch for each vehicle type
(
Plane
,
Copter
,
Rover
)
tells us which commands are likely to be supported in each vehicle
and which parameters are passed to the handler. The above checks give a very accurate picture of what commands and
parameters are not supported. They give a fairly accurate picture of
what commands/parameters are
likely to be supported
. However, this
indication is not guaranteed to be accurate because a command handler
could just throw away all the information (and we have not fully checked
all of these). In addition to the above checks, we have also merged information from
the
Copter Mission Command List
. ### How to interpret the command parameters
### ¶
The parameters for each command are listed in a table. The parameters
that are “greyed out” are not supported. The command field column (param
name) uses “bold” text to indicate those parameters that are defined in
the protocol (normal text is used for “empty” parameters). This allows users/developers to see both what is supported, and what
protocol fields are not supported in ArduPilot. ### Using this information with a GCS
### ¶
Mission Planner
(MP) exposes the full subset of commands and
parameters supported by ArduPilot, filtered to display just those
relevant to the currently connected vehicle. Mapping the MP commands to
this documentation is easy, because it simply names commands using a
cut-down version of the full command name (e.g. DO_SET_SERVO
rather
than the full command name:
MAV_CMD_DO_SET_SERVO
). In addition, this
document conveniently lists the column label used by Mission Planner
alongside each of the parameters. Other GCSs (APM Planner 2, Tower etc.) may support some other subset of
commands/parameters and use alternative names/labels for them. In most
cases, the mapping should be obvious.

--- chunk_id: chunk-0164
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: 55a80bbf36c307aa
prev_chunk_id: chunk-0163
next_chunk_id: chunk-0165
section_heading: Commands supported by Plane
document_type: technical_reference

## Commands supported by Plane
### ¶
This list of commands was inferred from the command handler in
/ArduPlane/commands_logic.cpp
. MAV_CMD_NAV_WAYPOINT

MAV_CMD_NAV_RETURN_TO_LAUNCH

MAV_CMD_NAV_TAKEOFF

MAV_CMD_NAV_LAND

MAV_CMD_NAV_LOITER_UNLIM

MAV_CMD_NAV_LOITER_TURNS

MAV_CMD_NAV_LOITER_TIME

MAV_CMD_NAV_ALTITUDE_WAIT

MAV_CMD_NAV_LOITER_TO_ALT

MAV_CMD_NAV_CONTINUE_AND_CHANGE_ALT

MAV_CMD_NAV_VTOL_TAKEOFF

MAV_CMD_NAV_VTOL_LAND

MAV_CMD_NAV_DELAY

MAV_CMD_NAV_PAYLOAD_PLACE

MAV_CMD_CONDITION_DELAY

MAV_CMD_CONDITION_DISTANCE

MAV_CMD_DO_AUX_FUNCTION

MAV_CMD_DO_CHANGE_SPEED

MAV_CMD_DO_ENGINE_CONTROL

MAV_CMD_DO_VTOL_TRANSITION

MAV_CMD_DO_SET_HOME

MAV_CMD_DO_SET_SERVO

MAV_CMD_DO_SET_RELAY

MAV_CMD_DO_REPEAT_SERVO

MAV_CMD_DO_REPEAT_RELAY

MAV_CMD_DO_DIGICAM_CONFIGURE
(Camera enabled only)

MAV_CMD_DO_DIGICAM_CONTROL
(Camera enabled only)

MAV_CMD_DO_SET_CAM_TRIGG_DIST
(Camera enabled only)

MAV_CMD_DO_SET_ROI
(Gimbal/mount enabled only)

MAV_CMD_DO_SET_ROI_LOCATION
(Gimbal/mount enabled only)

MAV_CMD_DO_SET_ROI_NONE
(Gimbal/mount enabled only)

MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW
(Gimbal/mount enabled only)

MAV_CMD_DO_JUMP

MAV_CMD_JUMP_TAG

MAV_CMD_DO_JUMP_TAG

MAV_CMD_DO_MOUNT_CONTROL

MAV_CMD_DO_INVERTED_FLIGHT

MAV_CMD_DO_LAND_START

MAV_CMD_DO_FENCE_ENABLE

MAV_CMD_DO_AUTOTUNE_ENABLE

MAV_CMD_DO_SET_RESUME_REPEAT_DIST

MAV_CMD_STORAGE_FORMAT

### Navigation commands
### ¶
Navigation commands are used to control the movement of the vehicle,
including takeoff, moving to and around waypoints, and landing. NAV commands have the highest priority. Any DO_ and CONDITION_
commands that have not executed when a NAV command is loaded are skipped
(for example, if a waypoint completes and the NAV command for another
waypoint is loaded, and unexecuted DO/CONDITION commands associated with
the first waypoint are dropped. ### MAV_CMD_NAV_WAYPOINT
### ¶
Supported by: All vehicles. Navigate to the specified position. The vehicle will fly to the specified latitude, longitude and altitude. The waypoint is considered “complete” when Plane is within the specified
radius of the target location, at which point Plane processes the next
command. The protocol additionally provides for the plane to circle the waypoint
with a specified radius and direction for a specified time (Delay). These parameters are not supported by Copter. Command parameters

Command Field
Mission Planner Field
Description
param1
param2
Acc radius
Acceptance radius in meters (waypoint is complete when the plane is this close to the waypoint location
param3
Pass by
0 to pass through the WP, if > 0 radius in meters to pass by WP. Positive value for clockwise orbit, negative value for counter-clockwise
orbit. Allows trajectory control. param4
param5
Lat
Target latitude
param6
Lon
Target longitude
param7
Alt
Target altitude

### MAV_CMD_NAV_TAKEOFF
### ¶
Supported by: Copter, Plane (not Rover). Takeoff (either from the ground or by hand-launch). It should be the first
command of nearly all Plane and Copter missions. The plane climbs to the specified altitude (at the specified pitch/climb
angle) before proceeding to the next waypoint. The plane is
only
attempting to climb at this point and can be pushed
off its heading by wind.

--- chunk_id: chunk-0165
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: 240e3d455147e9cb
prev_chunk_id: chunk-0164
next_chunk_id: chunk-0166
section_heading: Commands supported by Plane
document_type: technical_reference

The plane climbs to the specified altitude (at the specified pitch/climb
angle) before proceeding to the next waypoint. The plane is
only
attempting to climb at this point and can be pushed
off its heading by wind. The pitch value is the
minimum
climb angle
when using an airspeed sensor, and
maximum
angle when
not
using an airspeed sensor. Command Field
Mission Planner Field
Description
param1
Pitch Angle
Pitch/climb angle in degrees
param2
Empty
param3
Empty
param4
Yaw angle (ignored if compass not present). param5
Lat
Latitude
param6
Lon
Longitude
param7
Alt
Altitude

### MAV_CMD_NAV_VTOL_TAKEOFF
### ¶
Supported by:  Plane  (not Copter or Rover). Specifically QuadPlanes. Takeoff while in VTOL mode. The vehicle will climb straight up from it’s current location to the
specified altitude as a delta above its current altitude. However, if
Q_OPTIONS
bit 3 is set (use altitude reference frames for VTOL takeoff), then the altitude value (in the specified reference frame) will be used for the target altitude, instead of a delta above the current altitude. If the command is begun while the vehicle is already flying, the vehicle will climb straight up to the specified altitude, if
the vehicle is already above the altitude the command will be ignored
and the mission will move on to the next command immediately. Command parameters

Command Field
Mission Planner Field
Description
param1
Empty
param2
Empty
param3
Empty
param4
param5
Lat
Latitude
param6
Lon
Longitude
param7
Alt
Altitude

### MAV_CMD_NAV_LOITER_UNLIM
### ¶
Supported by: All vehicles. Loiter at the specified location for an unlimited amount of time. Fly to the specified location and then loiter there indefinitely — where
loiter means “circle the waypoint”. If zero is specified for a
latitude/longitude/altitude parameter then the current location value
for the parameter will be used. You can also specify the radius and
direction for the loiter. The mission will not proceed past this command while in AUTO mode. In
order to break out of this command you need to change the mode (i.e. to
MANUAL). If there are subsequent commands then you can continue the
mission at the next command, if the Copter
MIS_RESTART
parameter is
set to resume, by switching back to AUTO mode (otherwise the mission
will restart). Command parameters

Command Field
Mission Planner Field
Description
param1
Empty
param2
Empty
param3
Dir 1=CW
Radius around waypoint, in meters.

--- chunk_id: chunk-0166
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 521
content_hash: ef7764ea0443b476
prev_chunk_id: chunk-0165
next_chunk_id: chunk-0167
section_heading: Commands supported by Plane
document_type: technical_reference

If there are subsequent commands then you can continue the
mission at the next command, if the Copter
MIS_RESTART
parameter is
set to resume, by switching back to AUTO mode (otherwise the mission
will restart). Command parameters

Command Field
Mission Planner Field
Description
param1
Empty
param2
Empty
param3
Dir 1=CW
Radius around waypoint, in meters. Specify as a positive value to loiter clockwise, as a negative to move counter-clockwise. param4
Desired yaw angle. param5
Lat
Target latitude. If zero, the vehicle will loiter at the current latitude. param6
Lon
Target longitude. If zero, the vehicle will loiter at the current longitude. param7
Alt
Target altitude. If zero, the vehicle will loiter at the current altitude. ### MAV_CMD_NAV_LOITER_TURNS
### ¶
Supported by: Copter, Plane (not Rover). Loiter (circle) the specified location for at least the specified number of complete turns,
and then proceed to the next command upon intersection of the course to it with the circle’s perimeter. If zero is specified for a latitude/longitude/altitude parameter then the current location value
for the parameter will be used. Fractional turns between 0 and 1 are supported, while turns greater than 1 must be integers. The radius of the circle is controlled by the
command parameter. A radius of 0 will result in
WP_LOITER_RAD
being used as the radius. Negative radius values result in counter-clockwise turns instead of clockwise turns. Radius values over 255 meters will be rounded down to the nearest 10 meter mark. Once the number of turns is completed, continue to loiter until heading
points to next nav waypoint. If XTrack Tangent param =1, proceed directly to next waypoint, otherwise, track to
the path in a line between the waypoint centers. =1. Command parameters

Command Field
Mission Planner Field
Description
param1
Turns
Number of turns (N x 360°)
param2
Empty
param3
Radius
Loiter radius around the waypoint. Units are in meters. Values over 255 will be rounded to units of 10 meters. and values greater than 2550 will be clamped to 2550 m. Negative values indicate counter-clockwise turns. A value of zero will use WP_LOITER_RAD
param4
XTrack Tangent
Determines which line the aircraft will track after exiting the loiter. If 0, track the line from the center of the circle to the next waypoint. If 1, track the line tangent to the circle to the next waypoint. param5
Lat
Target latitude.

--- chunk_id: chunk-0167
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: 4f250f89ef096945
prev_chunk_id: chunk-0166
next_chunk_id: chunk-0168
section_heading: Commands supported by Plane
document_type: technical_reference

If 1, track the line tangent to the circle to the next waypoint. param5
Lat
Target latitude. If zero, the vehicle will loiter at the current latitude. param6
Lon
Target longitude. If zero, the vehicle will loiter at the current longitude. param7
Alt
Target altitude. If zero, the vehicle will loiter at the current altitude. ### MAV_CMD_NAV_LOITER_TIME
### ¶
Supported by: Copter, Plane, Rover. Fly to the specified location and then loiter there for the specified
number of seconds — where loiter means “circle the waypoint”. The timer
starts when the waypoint is reached; when it expires the waypoint is
complete. If zero is specified for a latitude/longitude/altitude
parameter then the current location value for the parameter will be
used. You can also specify the radius and direction for the loiter. Once
time has elapsed, continue to loiter until heading
points to next nav waypoint. If XTrack Tangent param = gb1, proceed directly to next waypoint, otherwise, track to
the path in a line between the waypoint centers. The radius of the loiter is set in the
WP_LOITER_RAD
parameter. Command parameters

Command Field
Mission Planner Field
Description
param1
Time (s)
Time to loiter at waypoint (seconds - decimal)
param2
Empty
param3
Dir 1=CW
Radius around waypoint, in meters. Specify as a positive value to loiter clockwise, as a negative to move counter-clockwise. param4
XTrack Tangent
Determines which line the aircraft will track after exiting the loiter. If 0, track the line from the center of the circle to the next waypoint. If 1, track the line tangent to the circle to the next waypoint. param5
Lat
Target latitude. If zero, the vehicle will loiter at the current latitude. param6
Lon
Target longitude. If zero, the vehicle will loiter at the current longitude. param7
Alt
Target altitude. If zero, the vehicle will loiter at the current altitude. ### MAV_CMD_NAV_RETURN_TO_LAUNCH
### ¶
Supported by: All vehicles. Return to the
home location
or the nearest
Rally
Point
, if closer. The home location is where
the vehicle was last armed (or when it first gets GPS lock after arming
if the vehicle configuration allows this). Return to the
home location
(or the nearest
Rally Point
if closer) and then “Loiter” (circle the
point).

--- chunk_id: chunk-0168
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: 9c54664be02564aa
prev_chunk_id: chunk-0167
next_chunk_id: chunk-0169
section_heading: Commands supported by Plane
document_type: technical_reference

The home location is where
the vehicle was last armed (or when it first gets GPS lock after arming
if the vehicle configuration allows this). Return to the
home location
(or the nearest
Rally Point
if closer) and then “Loiter” (circle the
point). The home location is where the vehicle was last armed (or when
it first gets GPS lock after arming if the vehicle configuration allows
this). If the return is to a rally point, the plane will loiter at the position
and altitude set in the rally point. If the return is to the home
location, then the parameter
RTL_ALTITUDE
is used for the loiter height (default 100m). The radius of the loiter
is defined in the parameter
WP_LOITER_RAD
. This command takes no parameters and generally should be the last
command in the mission. Command parameters

Command Field
Mission Planner Field
Description
param1
Empty
param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_NAV_LAND
### ¶
Supported by: Copter, Plane (not Rover). The plane will land at its current location or proceed to the (non-zero)
lat/lon coordinates provided beginning with current altitude. Information on the parameters used to
control the landing is provided in
LAND flight mode
. Command parameters

Command Field
Mission Planner Field
Description
param1
Abort Alt
param2
Empty
param3
Empty
param4
Desired yaw angle. param5
Lat
Latitude
param6
Long
Longitude
param7
Alt
Altitude to target for the landing. Unless you are landing at a location different than home, this should be zero

### MAV_CMD_NAV_VTOL_LAND
### ¶
Supported by: Plane (not Copter or Rover). Specifically QuadPlanes. Land the vehicle at the current or a specified location. If the
Q_OPTIONS
bit 4 is not set (default),the vehicle will land at its current location or proceed at the current altitude to the lat/lon
coordinates provided (if non-zero) and land. The ALT parameter is used to determine final landing phase initiation rather than
Q_LAND_FINAL_ALT
. This is the mission equivalent of the
QLAND flight mode
. If the
Q_OPTIONS
bit 4 is set (Use a fixed wind spiral approach), the it will fly in plane mode to the lat/lon coordinates provided (if non-zero), climbing or descending to the altitude set in the NAV_VTOL_LAND waypoint.

--- chunk_id: chunk-0169
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 520
content_hash: 79d691d71a7e44f9
prev_chunk_id: chunk-0168
next_chunk_id: chunk-0170
section_heading: Commands supported by Plane
document_type: technical_reference

This is the mission equivalent of the
QLAND flight mode
. If the
Q_OPTIONS
bit 4 is set (Use a fixed wind spiral approach), the it will fly in plane mode to the lat/lon coordinates provided (if non-zero), climbing or descending to the altitude set in the NAV_VTOL_LAND waypoint. When it reaches within
Q_FW_LND_APR_RAD
of the landing location, it will perform a LOITER_TO_ALT to finish the climb or descent to that ALT set in the waypoint, then, turning into the wind, transition to VTOL mode and proceed to the landing location and land. The motors will disarm on their own once landed

Note

param1 of the command acts just like
Q_OPTIONS
bit 4 above, if that option bit is not set. This allows the use of different approaches for different VTOL_LAND commands within the same mission. Command parameters

Command Field
Mission Planner Field
Description
param1
Option:if set to 1,forces FW spiral approach
param2
Empty
param3
Empty
param4
Desired yaw angle. param5
Lat
Target latitude. If zero, the QuadPlane will land at the current latitude. param6
Lon
Longitude
param7
Alt
additional altitude above Q_LAND_FINAL_ALT to switch to final landing phase

### MAV_CMD_NAV_CONTINUE_AND_CHANGE_ALT
### ¶
Supported by: Plane (not Copter, Rover). Continue on the current course and climb/descend to a specified altitude. Move to the next command when the desired altitude is reached. Note

The
param1
value sets how close the
vehicle altitude must be to target altitude for command
completion. Command parameters

Command Field
Mission Planner Field
Description
param1
TBD
Climb or Descend (0 = Neutral, command completes when within 5m of this
command's altitude, 1 = Climbing, command completes when at or above
this command's altitude, 2 = Descending, command completes when at or
below this command's altitude. param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Alt
Target altitude

### MAV_CMD_NAV_ALTITUDE_WAIT
### ¶
Supported by: Plane (not Copter or Rover). Mission command to wait for an altitude or downward vertical speed. This is meant for high-altitude balloon launches, allowing the aircraft
to be idle until either an altitude is reached or a negative vertical
speed is reached (indicating early balloon burst). The wiggle time is
how often to wiggle the control surfaces to prevent them from seizing up. Command parameters

Command Field
Mission Planner Field
Description
param1
? Altitude (m)
param2
? Descent speed (m/s)
param3
?

--- chunk_id: chunk-0170
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 460
content_hash: e39e4bffebb11b75
prev_chunk_id: chunk-0169
next_chunk_id: chunk-0171
section_heading: Commands supported by Plane
document_type: technical_reference

Altitude (m)
param2
? Descent speed (m/s)
param3
? Wiggle Time (s)
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_NAV_LOITER_TO_ALT
### ¶
Supported by: Plane (not Copter or Rover). Loiter while climbing/descending to an altitude. Begin loitering at the specified Latitude and Longitude. If Lat=Lon=0, then
loiter at the current position. Don’t consider the navigation command
complete (don’t leave loiter) until the altitude has been reached. Continue to loiter until heading
points to next nav waypoint. If XTrack Tangent param =1, proceed directly to next waypoint, otherwise, track to
the path in a line between the waypoint centers. Command parameters

Command Field
Mission Planner Field
Description
param1
Empty
param2
Radius
Radius in meters. If positive loiter clockwise, negative counter-clockwise, 0 means no change to standard loiter. param3
Empty
param4
XTrack Tangent
Determines which line the aircraft will track after exiting the loiter. If 0, track the line from the center of the circle to the next waypoint. If 1, track the line tangent to the circle to the next waypoint. param5
Lat
Latitude. param6
Long
Longitude
param7
Alt
Altitude

### MAV_CMD_NAV_DELAY
### ¶
Supported by: Copter, Rover, Plane. After reaching this waypoint, if disarmed, delay the execution of the next mission command
until the time in seconds has elapsed. This is used in a mission to allow a vehicle to land, disarm for a period (for a payload change for example), and then re-arm, and takeoff to resume the mission. If not disarmed, this mission item is skipped. Command parameters

Command Field
Mission Planner Field
Description
param1
Time (sec)
Delay in seconds (decimal). param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_NAV_PAYLOAD_PLACE
### ¶
Supported by: Copter and Plane. QUADPLANE ONLY, fixed wing planes will skip this command
After reaching this waypoint, the vehicle will have transitioned to VTOL and will descend up to the maximum descent value. If the vehicle has not touched the ground before this limit is reached, the vehicle will climb back up to the waypoint altitude and continue to the next mission item.

--- chunk_id: chunk-0171
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 465
content_hash: 3ffdfeb9c153ae99
prev_chunk_id: chunk-0170
next_chunk_id: chunk-0172
section_heading: Commands supported by Plane
document_type: technical_reference

QUADPLANE ONLY, fixed wing planes will skip this command
After reaching this waypoint, the vehicle will have transitioned to VTOL and will descend up to the maximum descent value. If the vehicle has not touched the ground before this limit is reached, the vehicle will climb back up to the waypoint altitude and continue to the next mission item. If it reaches the ground, it will stop its motors and wait for a LUA script command (see
Package Place LUA applet
) to send an abort_landing command to ascend back to the waypoint altitude and continue to the next mission item, be sent a disarm command, or the pilot uses the
RCx_OPTION
= 173 to send the abort_landing command, instead of via a LUA script. This allows the gripper to be commanded to be released, packages replaced, etc. [wiki site=”copter,plane”]
Command parameters

Command Field
Mission Planner Field
Description
param1
Maximum Descent
meters
param2
Empty
param3
Empty
param4
Empty
param5
Lat
Latitude. param6
Long
Longitude
param7
Alt
Altitude
[/site]


### MAV_CMD_DO_JUMP
### ¶
Supported by: All vehicles. Jump to the specified command in the mission list. The jump command can
be repeated either a specified number of times before continuing the
mission, or it can be repeated indefinitely. Tip

Despite the name, this command is really a “NAV_” command rather
than a “DO_” command. Conditional commands like CONDITION_DELAY don’t
affect DO_JUMP (it will always perform the jump as soon as it reaches
the command). Note

There can be a maximum of 15 jump commands in a mission after which new DO_JUMP commands are ignored. Command parameters

Command Field
Mission Planner Field
Description
param1
WP#
The command index/sequence number of the command to jump to. param2
Repeat#
Number of times that the DO_JUMP command will execute before moving to
the next sequential command. However, if MIS_OPTIONS bit 2 is not set, then the repeat count will be used again if the command is encountered again after the last repeat. If the value is zero the next command will
execute immediately. A value of -1 will cause the command to repeat
indefinitely.

--- chunk_id: chunk-0172
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 476
content_hash: 21ed4e12329b9e1c
prev_chunk_id: chunk-0171
next_chunk_id: chunk-0173
section_heading: Commands supported by Plane
document_type: technical_reference

If the value is zero the next command will
execute immediately. A value of -1 will cause the command to repeat
indefinitely. param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission Planner Settings for DO_JUMP command
¶

In the example above the vehicle would fly back-and-forth between
waypoints #1 and #2 a total of 3 times before flying on to waypoint #4. ### MAV_CMD_JUMP_TAG
### ¶
Supported by: Copter, Plane, Rover. This is a location marker in the mission command sequence that can be used as a “jump to” location for the
MAV_CMD_DO_JUMP_TAG
command. The tag id in its parameter field can be any arbitrary number between 1 and 65535. Command parameters

Command Field
Mission Planner Field
Description
param1
Tag#
The tag number for the DO_JUMP_TAG command. param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_JUMP_TAG
### ¶
Supported by: Copter, Plane, Rover. Jump to the specified
MAV_CMD_JUMP_TAG
item in the mission list. The jump tag command can be repeated, either a specified number of times before continuing the
mission, or it can be repeated indefinitely. Tip

Despite the name, this command is really a “NAV_” command rather
than a “DO_” command. Conditional commands like CONDITION_DELAY don’t
affect DO_JUMP (it will always perform the jump as soon as it reaches
the command). Note

There can be a maximum of 15 jump_tag commands in a mission after which new DO_JUMP_TAG commands are ignored. Command parameters

Command Field
Mission Planner Field
Description
param1
WP#
The tag number of the JUMP_TAG item to jump to. param2
Repeat#
Number of times that the DO_JUMP_TAG command will execute before moving to
the next sequential command. If the value is zero the next command will
execute immediately. A value of -1 will cause the command to repeat
indefinitely. param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission Planner Settings for DO_JUMP_TAG command
¶

In the example above, the vehicle would fly back-and-forth between waypoints #3 and #4 a total of 3 times before completing the mission. This is because the DO_JUMP_TAG redirects the vehicle to JUMP_TAG #565 twice.

--- chunk_id: chunk-0173
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: 760aa98b9be4dbc7
prev_chunk_id: chunk-0172
next_chunk_id: chunk-0174
section_heading: Conditional commands
document_type: technical_reference

## Conditional commands
### ¶
Conditional commands control the execution of _DO_ commands. For
example, a conditional command can prevent DO commands from executing based
on a time delay, until the vehicle is at a certain altitude, or at a
specified distance from the next target position. A conditional command may not be complete before reaching the next
waypoint. In this case, any unexecuted _DO_ commands associated with
the last waypoint will be skipped. ### MAV_CMD_CONDITION_DELAY
### ¶
Supported by: All vehicles. After reaching a waypoint, delay the execution of the next conditional
“_DO_” command for the specified number of seconds (e.g. MAV_CMD_DO_SET_ROI
). Note

This command does not stop the vehicle. If the vehicle reaches the
next waypoint before the delay timer completes, the delayed “_DO_”
commands will never trigger. Command parameters

Command Field
Mission Planner Field
Description
param1
Time (sec)
Delay in seconds (decimal). param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission Planner Settings for CONDITION_DELAY command
¶

In the example above, Command #4 (
DO_SET_ROI
) is delayed so that it
starts 5 seconds after the vehicle has passed Waypoint #2. ### MAV_CMD_CONDITION_DISTANCE
### ¶
Supported by: All vehicles. Delays the start of the next “
_DO_
” command until the vehicle is
within the specified number of meters of the next waypoint. Note

This command does not stop the vehicle: it only affects DO
commands. Command parameters

Command Field
Mission Planner Field
Description
param1
Dist (m)
Distance from the next waypoint before DO commands are executed (meters). param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission PlannerSettings for CONDITION_DISTANCE command
¶

In the example above, Command #4 (
DO_SET_ROI
) is delayed so that it
only starts once the vehicle is within 50m of waypoint #5.

--- chunk_id: chunk-0174
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 456
content_hash: a711df3306f9e13d
prev_chunk_id: chunk-0173
next_chunk_id: chunk-0175
section_heading: DO commands
document_type: technical_reference

## DO commands
### ¶
The “DO” or “Now” commands are executed once to perform some action. All
the DO commands associated with a waypoint are executed immediately. ### MAV_CMD_DO_CHANGE_SPEED
### ¶
Supported by: Copter, Plane, Rover. Change the target horizontal speed (airspeed or groundspeed) and/or the
vehicle’s throttle. If the airspeed option is selected, this changes the
AIRSPEED_CRUISE
parameter during the flight until reboot or mode is changed to CRUISE or FBWB. If the groundspeed option is used, then
MIN_GROUNDSPEED
parameter is changed to this value until rebooted or changed by this command again. If the throttle field is non-zero and equal to or below 100, then the
TRIM_THROTTLE
parameter is changed  until reboot or changed by this command again. Note

Speed changes only have an effect if an airspeed sensor is present, healthy, and in use. TRIM_THROTTLE
changes impacts only flight with airspeed sensor not in use. Command parameters

Command Field
Mission Planner Field
Description
param1
Type
Speed type (0=Airspeed, 1=Ground Speed). param2
Speed (m/s)
Target speed (m/s). If airspeed, a value below or above min/max airspeed limits results in no change. a value of -2 uses :ref:`AIRSPEED_CRUISE
`
param3
Throttle(%)
Throttle as a percentage (0-100%). A value of 0 or negative indicates no change. param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_SET_HOME
### ¶
Supported by: All vehicles. Sets the home location either as the current location or at the location
specified in the command. For SITL work, altitude input here needs to be with reference to absolute altitude, taking into account SRTM elevation. Note

For Plane and Rover, if a good GPS fix cannot be obtained the
location specified in the command is used. For Copter, the command will also try to use the current position if
all the location parameters are set to 0. The location information in
the command is only used if it is close to the EKF origin. Command parameters

Command Field
Mission Planner Field
Description
param1
Current
Set home location:

1=Set home as current location. 0=Use location specified in message parameters.

--- chunk_id: chunk-0175
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 472
content_hash: d029ae217fb857e0
prev_chunk_id: chunk-0174
next_chunk_id: chunk-0176
section_heading: DO commands
document_type: technical_reference

Command parameters

Command Field
Mission Planner Field
Description
param1
Current
Set home location:

1=Set home as current location. 0=Use location specified in message parameters. param2
Empty
param3
Empty
param4
Empty
param5
Lat
Target home latitude (if
param1=0
)
param6
Lon
Target home longitude (if
param1=0
)
param7
Alt
Target home altitude (if
param1=0
)
Mission planner screenshots

Mission Planner Settings for DO_SET_HOME command
¶


### MAV_CMD_DO_SET_RELAY
### ¶
Supported by: All vehicles. Set a
Relay
pin’s voltage high (on) or low (off). Command parameters

Command Field
Mission Planner Field
Description
param1
Relay No
Relay number. param2
off(0)/on(1)
Set relay state:

1: Set relay high/on (3.3V on Pixhawk, 5V on APM). 0: Set relay low/off (0v)
any other value toggles the relay
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

MissionPlanner Settings for DO_SET_RELAY command
¶


### MAV_CMD_DO_REPEAT_RELAY
### ¶
Supported by: All vehicles. Toggle the
Relay
pin’s voltage/state a specified
number of times with a given period. Toggling the Relay will turn an off
relay on and vice versa

Command parameters

Command Field
Mission Planner Field
Description
param1
Relay No
Relay number. param2
Repeat #
Cycle count - the number of times the relay should be toggled
param3
Delay(s)
Cycle time (seconds, decimal) - time between each toggle. param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission Planner Settings for DO_RELAY_REPEAT command
¶

In the example above, assuming the relay was off to begin with, it would
be set high and then after 3 seconds, it would be toggled low again. ### MAV_CMD_DO_SET_SERVO
### ¶
Supported by: All vehicles. Set a given
servo pin
output to a specific PWM value. Command parameters

Command Field
Mission Planner Field
Description
param1
Ser No
Servo number - target servo output pin/channel number. param2
PWM
PWM value to output, in microseconds (typically 1000 to 2000). param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission Planner Settingsfor DO_SET_SERVO command
¶

In the example above, the servo attached to output channel 8 would be
moved to PWM 1700 (servos generally accept PWM values between 1000 and
2000).

--- chunk_id: chunk-0176
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: aa0fa9509d93e473
prev_chunk_id: chunk-0175
next_chunk_id: chunk-0177
section_heading: DO commands
document_type: technical_reference

param2
PWM
PWM value to output, in microseconds (typically 1000 to 2000). param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission Planner Settingsfor DO_SET_SERVO command
¶

In the example above, the servo attached to output channel 8 would be
moved to PWM 1700 (servos generally accept PWM values between 1000 and
2000). Note

as of firmware versions 4.0 and later, this command can be used on any output configured by its
SERVOx_FUNCTION
command as 0,1, or 51-66  (disabled or RC pass-throughs)



### MAV_CMD_DO_REPEAT_SERVO
### ¶
Supported by: All vehicles. Cycle a
servo
PWM output pin between its mid-position
value and a specified PWM value, for a given number of cycles and with a
set period. The mid-position value is specified in the
RCn_TRIM
parameter for
the channel (
RC8_TRIM
in the screenshot below). The default value is
1500.. Command parameters

Command Field
Mission Planner Field
Description
param1
Ser No
Servo number - target servo output pin/channel. param2
PWM
PWM value to output, in microseconds (typically 1000 to 2000). param3
Repeat #
Cycle count - number of times to move the servo to the specified PWM value
param4
Delay (s)
Cycle time (seconds) - the delay in seconds between each servo movement. param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission Planner Settingsfor DO_REPEAT_SERVO command
¶

In the example above, the servo attached to output channel 8 would be
moved to PWM 1700, then after 4 second, back to mid, after another 4
seconds it would be moved to 1700 again, then finally after 4 more
seconds it would be moved back to mid. ### MAV_CMD_DO_LAND_START
### ¶
Supported by: Plane (not Copter, Rover). Mission command to prepare for a landing. This is used as a marker in a mission to tell the autopilot where a
sequence of mission items that represents a landing starts. It may also
be sent via a
COMMAND_LONG
to trigger a landing, in which case the
nearest (geographically) landing sequence in the mission will be used. If
RTL_AUTOLAND
is set to 2, the plane will jump to the nearest
DO_LAND_START
in the mission table when RTL is initialized. Note

General information on landing a plane is provided in the topic
Automatic Landing
.

--- chunk_id: chunk-0177
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: 226169bba8ca2696
prev_chunk_id: chunk-0176
next_chunk_id: chunk-0178
section_heading: DO commands
document_type: technical_reference

If
RTL_AUTOLAND
is set to 2, the plane will jump to the nearest
DO_LAND_START
in the mission table when RTL is initialized. Note

General information on landing a plane is provided in the topic
Automatic Landing
. Command parameters

Command Field
Mission Planner Field
Description
param1
Empty
param2
Empty
param3
Empty
param4
Empty
param5
Lat
Latitude used to help find the closest landing sequence, or zero if not needed. param6
Long
Longitude used to help find the closest landing sequence, or zero if not needed. param7
Empty

### MAV_CMD_DO_VTOL_TRANSITION
### ¶
Supported by: Plane (not Copter or Rover).Specifically QuadPlanes. Mission command to change to/from VTOL and fixed wing mode of flight. The mode is changed based on the first parameter: 3 = change to VTOL flight, 4 = change to fixed wing flight. Command parameters

Command Field
Mission Planner Field
Description
param1
Mode
3=VTOL,4=Fixed-Wing
param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_SET_ROI, MAV_CMD_DOE_SET_ROI_LOOCATION, MAV_CMD_DO_SET_ROI_NONE
### ¶
Supported by: Copter, Plane, Rover,Sub. Currently, the DO_SET_ROI,DO_SET_ROI_LOCATION, and DO_SET_ROI_NONE commands all behave the same with DO_SET_ROI_NONE removing the ROI target, the same as setting the location to 0,0 in the other commands. Points the
camera gimbal
at the “region
of interest”. After setting the ROI, the camera will continue to follow it until the
end of the mission, unless it is changed or cleared by setting another
ROI. Clearing the ROI is achieved by setting a later DO_SET_ROI
command with all zeros for
param5
-
param7
(Lat, Lon and Alt). Command parameters

Command Field
Mission Planner Field
Description
param1
Region of interest mode. (see MAV_ROI enum) // 0 = no roi, 1 = next
waypoint, 2 = waypoint number, 3 = fixed location, 4 = given target (not supported)
param2
MISSION index/ target ID. (see MAV_ROI enum)
param3
ROI index (allows a vehicle to manage multiple ROI's)
param4
Empty
param5
Lat
Latitude (x) of the fixed ROI
param6
Long
Longitude (y) of the fixed ROI
param7
Alt
Altitude of the fixed ROI

### MAV_CMD_DO_DIGICAM_CONFIGURE
### ¶
Supported by: All vehicles. Configure an on-board camera controller system. The parameters are forwarded to an on-board camera controller system
(like the
3DR Camera Control Board
),
if one is present.

--- chunk_id: chunk-0178
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: f7e5be7d62b51910
prev_chunk_id: chunk-0177
next_chunk_id: chunk-0179
section_heading: DO commands
document_type: technical_reference

Configure an on-board camera controller system. The parameters are forwarded to an on-board camera controller system
(like the
3DR Camera Control Board
),
if one is present. Command parameters

Command Field
Mission Planner Field
Description
param1
Mode
Set camera mode:
1: ProgramAuto

2: Aperture Priority

3: Shutter Priority

4: Manual

5: IntelligentAuto

6: SuperiorAuto
param2
Shutter Speed
Shutter speed (seconds divisor). So if the speed is 1/60 seconds, the
value entered would be 60. Slowest shutter trigger supported is 1 second. param3
Aperture
Aperture: F stop number
param4
ISO
ISO number e.g. 80, 100, 200, etc. param5
ExposureMode
Exposure type enumerator
param6
CommandID
Command Identity
param7
Engine Cut-Off
Main engine cut-off time before camera trigger in seconds/10 (0 means no cut-off). ### MAV_CMD_DO_DIGICAM_CONTROL
### ¶
Supported by: All vehicles. Trigger the
camera shutter
once. This command takes no additional arguments. Command parameters

In general, if a command field is set to 0 it is ignored. Command Field
Mission Planner Field
Description
param1
On/Off
Session control (on/off or show/hide lens):

0: Turn off the camera / hide the lens

1: Turn on the camera /Show the lens
param2
Zoom Position
Zoom's absolute position. 2x, 3x, 10x, etc. param3
Zoom Step
Zooming step value to offset zoom from the current position
param4
Focus Lock
Focus Locking, Unlocking or Re-locking:
0: Ignore

1: Unlock

2: Lock
param5
Shutter Cmd
Shooting Command. Any non-zero value triggers the camera. param6
CommandID
Command Identity
param7
Empty
Mission planner screenshots

Mission PlannerSettings for DO_DIGICAM_CONTROL command. ¶


### MAV_CMD_DO_MOUNT_CONTROL
### ¶
Supported by: All vehicles. Mission command to control a camera or antenna mount. This command allows you to specify a roll, pitch and yaw angle which
will be sent to the
camera gimbal
. This
can be used to point the camera in specific directions at various times
in the mission. Command parameters

Command Field
Mission Planner Field
Description
param1
Pitch, in degrees. param2
Roll, in degrees. param3
Yaw, in degrees. param4
reserved
param5
reserved
param6
reserved
param7
`MAV_MOUNT_MODE
`__ enum value. Mission planner screenshots

Mission Planner Settings for DO_MOUNT_CONTROL command
¶


### MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW
### ¶
Supported by: All vehicles. Mission command to move the gimbal to the desired pitch and yaw angles (in degrees). This command allows you to specify a pitch and yaw angle which
will be sent to the
camera gimbal
.

--- chunk_id: chunk-0179
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: ab20ce656b056fd3
prev_chunk_id: chunk-0178
next_chunk_id: chunk-0180
section_heading: DO commands
document_type: technical_reference

Mission command to move the gimbal to the desired pitch and yaw angles (in degrees). This command allows you to specify a pitch and yaw angle which
will be sent to the
camera gimbal
. This
can be used to point the camera in specific directions at various times
in the mission. Positive pitch angles are up, Negative are down. Positive yaw angles are clockwise, negative are counter clockwise. Command parameters

Command Field
Mission Planner Field
Description
param1
Pitch, in degrees. param2
Yaw, in degrees. param3
PitchRate, in deg/s. param4
YawRate, in deg/s
param5
Flags: 0=boddyframe, 16=earthframe
param6
reserved
param7
Gimbal instance ID
Mission planner screenshots

Mission PlannerSettings for DO_GIMBAL_MANAGE_PITCHYAW command
¶


### MAV_CMD_DO_SET_CAM_TRIGG_DIST
### ¶
Supported by: All vehicles. Trigger the
camera shutter
at
regular distance intervals. This command is useful in
camera survey missions
. To trigger the camera once, immediately after passing the DO command, set param3 to 1. Note

Providing a distance of zero will stop the camera shutter from being triggered. Command parameters

Command Field
Mission Planner Field
Description
param1
Dist (m)
Camera trigger distance interval (meters). Zero to turn off distance triggering. param2
Empty
param3
? Trigger once instantly. One is on, zero is off. param4
Empty
param5
Empty
param6
Empty
param7
Empty
Mission planner screenshots

Mission PlannerSettings for DO_SET_CAM_TRIGG_DIST command
¶

The above configuration will cause the camera shutter to trigger
after every 5m that the vehicle travels. ### MAV_CMD_DO_FENCE_ENABLE
### ¶
Supported by: All vehicles. Mission commands to enable the Plane
GeoFence
, Copter/Rover
Cylindrical Fence
and/or
Inclusion and Exclusion Fences
. Command parameters

Command Field
Mission Planner Field
Description
param1
Set GeoFence enable state (0=disable, 1=enable, 2= disable only floor (Plane only)). param2
bitmask
The target fence is specified by the bitmask value of FENCE_TYPE. 0 is ALL configured fences. param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_AUX_FUNCTION
### ¶
Supported by: All vehicles. Mission command to control an
Auxiliary Function
in the same manner as an RC channel switch. Command parameters

Command Field
Mission Planner Field
Description
param1
Aux Function
Auxiliary Function code,same as RCx_OPTIONS
param2
Switch Position
0:Low, 1:Mid, 2:High
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_INVERTED_FLIGHT
### ¶
Supported by: Plane (not Copter or Rover). Change between normal and
inverted flight
.

--- chunk_id: chunk-0180
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 59ec63ef031f11b4
prev_chunk_id: chunk-0179
next_chunk_id: chunk-0181
section_heading: DO commands
document_type: technical_reference

Command parameters

Command Field
Mission Planner Field
Description
param1
Aux Function
Auxiliary Function code,same as RCx_OPTIONS
param2
Switch Position
0:Low, 1:Mid, 2:High
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_INVERTED_FLIGHT
### ¶
Supported by: Plane (not Copter or Rover). Change between normal and
inverted flight
. Command parameters

Command Field
Mission Planner Field
Description
param1
0=normal, 1=inverted
Set flight type:

0: normal
1: inverted
param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_AUTOTUNE_ENABLE
### ¶
Supported by: Plane (not Copter or Rover). Enable/disable
AUTOTUNE
mode. Command parameters

Command Field
Mission Planner Field
Description
param1
na
Enable/disable autotune (1: enable, 0:disable)
param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_ENGINE_CONTROL
### ¶
Supported by: Plane (not Copter or Rover). Stop or start the internal combustion engine (ICE)

This command can be used to start or stop the ICE before a NAV_VTOL_LAND or after a NAV_VTOL_TAKEOFF command for a QuadPlane to avoid potential prop strikes in the wind. It should be placed before either of those commands.Also can be used to allow a single engine start while disarmed if otherwise prohibited by
ICE_OPTIONS
bit 3 being set,

Command parameters

Command Field
Mission Planner Field
Description
param1
? Start/Stop ICE (1: start, 0:stop)
param2
Cold Start (1: enables choke, currently not implemented)
param3
Altitude in meters. Altitude at which action is taken. param4
Flags: 1 = allow a single start while disarmed even if :ref:`ICE_OPTIONS
` bit 3 is set
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_DO_SET_RESUME_REPEAT_DIST
### ¶
Supported by: All vehicles. Set the distance that the mission will be rewound when resuming after an interrupt (switching modes). A full explanation of this feature can be found on the
Mission Rewind on Resume Page
. After setting a rewind distance in a mission, setting the distance to zero will switch off the rewind feature from that point on the mission. Command parameters

Command Field
Mission Planner Field
Description
param1
? Rewind distance in meters
param2
Empty
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty

### MAV_CMD_STORAGE_FORMAT
### ¶
Supported by: All vehicles. Format SD Card. Useful for vehicles where SD card is inaccessible. Param1 and Param2 must be set to 1. Command parameters

Command Field
Mission Planner Field
Description
param1
?

--- chunk_id: chunk-0181
source_document: common-mavlink-mission-command-messages-mav_cmd.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 104
content_hash: 66f66a8d172bc65d
prev_chunk_id: chunk-0180
next_chunk_id: chunk-0182
section_heading: DO commands
document_type: technical_reference

Param1 and Param2 must be set to 1. Command parameters

Command Field
Mission Planner Field
Description
param1
? Must be 1
param2
? Must be 1
param3
Empty
param4
Empty
param5
Empty
param6
Empty
param7
Empty





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0182
source_document: common-measuring-vibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 346
content_hash: c27079adf4da2da3
prev_chunk_id: chunk-0181
next_chunk_id: chunk-0183
document_type: technical_reference

Measuring Vibration — Copter  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Copter


Introduction to Copter
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Pre-arm Safety Check
Arming and Disarming
Pre-Flight Checklist
Getting Off the Ground – Tips for New Operators
Tuning
Measuring Vibration
Real-Time view in Ground Station
Vibe Dataflash Log message
Looking for “The Leans”
Advanced Analysis with FFT
IMU Dataflash Log message
Setting Hover Throttle
Save Trim & Auto Trim
Thrust Loss and Yaw Imbalance Warnings
Indoor Flying
Aerobatic Multicopters
Traditional Helicopters
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Copter
First Flight with Copter
- Measuring Vibration
Edit on GitHub

# Measuring Vibration
# ¶
Autopilots have accelerometers that are sensitive to vibrations. These accelerometer values are combined with barometer and
GPS data to estimate the vehicle’s position. With excessive
vibrations, the estimate can be thrown off and lead to very bad
performance in modes that rely on accurate positioning (e.g. on Copter:
AltHold, Loiter, RTL, Guided, Position and Auto flight modes). These instructions explain how to measure the vibration levels. If you
find they are out-of-tolerance then follow the advice found on the
Vibration Damping
page.

--- chunk_id: chunk-0183
source_document: common-measuring-vibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: f367cdec4e856c45
prev_chunk_id: chunk-0182
next_chunk_id: chunk-0184
section_heading: Real-Time view in Ground Station
document_type: technical_reference

## Real-Time view in Ground Station
### ¶
Ground Stations can display a real-time view of vibration and clipping. If using the Mission Planner click on “Vibe” on the HUD to display the current vibration levels. Vibration levels below 30m/s/s are normally acceptable. Levels above 30m/s/s
may
have problems and levels above 60m/s/s nearly always have problems with position or altitude hold. ### Vibe Dataflash Log message
### ¶
Check the recorded Vibe levels are mostly below 30m/s/s

Perform a regular flight (i.e. not just a gentle hover) of at least a
few minutes and
download the dataflash logs
. Using the Mission Planner or other ground station graph the VIBE message’s
VibeX, VibeY and VibeZ values. These show the standard deviation of
the primary accelerometer’s output in m/s/s. The image below, taken
from a 3DR IRIS, shows normal levels which are below 15m/s/s but
occasionally peak to 30m/s/s. Maximum acceptable values appear to be
below 30m/s/s (see second picture below). Graph the Clip0, Clip1 and Clip2 values which increase each time one
of the accelerometers reaches its maximum limit (16G). Ideally
these should be zero for the whole flight but low numbers (<100) are
likely ok especially if they occur during hard landings. A regularly
increasing number through the log indicates a serious vibration
problem that
should be fixed
. This is an example of a vehicle that had position estimate problems due
to high vibrations. The algorithm for calculating the vibration levels can be seen in the
AP_InertialSensor.cpp’s calc_vibration_and_clipping()
method but in short it involves calculating the standard deviation of
the accelerometer readings like this:

Capture the raw x, y and z accelerometer values from the primary IMU

High-pass filter the raw values at 5hz to remove the vehicle’s
movement and create a “accel_vibe_floor” for x,y and z axis. Calculate the difference between the latest accel values and the
accel_vibe_floor. Square the above differences, filter at 2hz and then calculate the
square root (for x, y and z). These final three values are what
appear in the VIBE msg’s VibeX, Y and Z fields. When looking at vibrations in a log the first thing to look at is the clipping. If the clipping is 0 that’s good. That means the vibrations that are being detected aren’t overwhelming the IMU.

--- chunk_id: chunk-0184
source_document: common-measuring-vibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 222
content_hash: 6af48f5be83c8816
prev_chunk_id: chunk-0183
next_chunk_id: chunk-0185
section_heading: Real-Time view in Ground Station
document_type: technical_reference

If the clipping is 0 that’s good. That means the vibrations that are being detected aren’t overwhelming the IMU. When troubleshooting the vibration, consider the axis of the vibration as a staring point to find the problem:

If X AND Y are both high, then you may have an issue with a motor bearing or prop balance. Or you may need more/better overall vibration damping for your FC. If X OR Y is high then you may have an issue with your FC mounting. Maybe a wire is bouncing on the FC or restraining it. Or maybe your vibration damping works better in one axis than the other. If you have a Z vibration then you may have a track issue with propeller (bent blade) or vertical play in a motor. Also consider that some flight conditions/airframes will have different natural vibrations. If the vibrations look good in a hover, but they increase with speed, perhaps there is an aerodynamic issue with the airframe, or in wind,

--- chunk_id: chunk-0185
source_document: common-measuring-vibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 154
content_hash: bec48570ea7bbb10
prev_chunk_id: chunk-0184
next_chunk_id: chunk-0186
section_heading: Looking for “The Leans”
document_type: technical_reference

## Looking for “The Leans”
### ¶
The Leans
occurs when the vehicle’s attitude estimate becomes incorrect causing it to lean significantly even though the pilot is commanding level flight. The cause of the problem is often accelerometer aliasing which can be confirmed by comparing the Roll and Pitch attitude estimates from each of the estimation systems (i.e. each AHRSs or EKFs). The attitude estimates should be within a few degrees of each other

Download the dataflash log and open in the ground station’s log viewer

Compare the AHRS2.Roll, NKF1[0].Roll and NKF1[1].Roll if using EKF2, or AHRS2.Roll, XKF1[0].Roll and XKF1[1].Roll, if using EKF3

The image below shows a typical log in which the attitudes match well

--- chunk_id: chunk-0186
source_document: common-measuring-vibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 466
content_hash: 6bbe1d35f8807385
prev_chunk_id: chunk-0185
next_chunk_id: chunk-0187
section_heading: Advanced Analysis with FFT
document_type: technical_reference

## Advanced Analysis with FFT
### ¶
Refer to the
Measuring Vibration with “Raw IMU Logging”
page for instructions on how to collect large amounts of IMU data and perform an FFT analysis to determine the frequencies with the most vibration. ### IMU Dataflash Log message
### ¶
For very old versions of ArduPilot that do not include the Vibe message the IMU values can be checked directly

Ensure the
LOG_BITMASK
parameter is set to include IMU data so accelerometer values are recorded to the dataflash logs

Fly your copter in Stabilize mode and try to maintain a level hover (it doesn’t need to be perfectly stable or level)

Download the dataflash logs and
after the download has completed, use the Mission Planner’s “Review a
Log” button to open the latest file in the log directory (it’s last
digit will be the Log number you downloaded so in the example above
we downloaded Log #1 so the filename will end in 1.log)

When the Log Browser appears, scroll down until you find any IMU
message. Click on the row’s AccX and push
Graph this data
Left
button. Repeat for the AccY and AccZ columns to produce a graph like
below. Check the scale on the left and ensure that your vibration levels for
the AccX and AccY are between -3 and +3. For AccZ the acceptable
range is -15 to -5. If it is very close or over these limits you
should refer back to the
Vibration Damping
page for possible solutions. After all the above is complete, go to the Mission Planner’s standard
parameters page (you may need to press the
Connect
button again)
and set the Log Bitmask back to “Default”. This is important because
especially on the APM logging requires significant CPU resources and
it’s a waste to log these if they’re not really needed. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0187
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: b0f1f588b30e2a82
prev_chunk_id: chunk-0186
next_chunk_id: chunk-0188
document_type: technical_reference

Power Monitor/Module Configuration in Mission Planner — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
Drive Calculator Motor/Propeller Analyzer
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Monitor Configuration
Mission Planner Setup
Connecting power monitor to alternative pins
Power Monitors Connecting to AutoPilot Power Monitor Port
CAN/DroneCAN Power Monitors and Batteries
DroneCAN Battery Tag
I2C Power Monitor
Power Monitoring Via Telemetry Equipped AM32/BLHeli32/S ESCs
EFI Fuel Monitoring
Liquid Fuel Monitors
Substituting  a Battery Monitor’s Data into an ESC’s telemetry stream
Power Tether
PPM Encoder
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Peripheral Hardware
Battery Monitors (aka Power Monitors/Modules)
- Power Monitor/Module Configuration in Mission Planner
Edit on GitHub

# Power Monitor/Module Configuration in Mission Planner
# ¶
Note

Up to 16 battery monitors may be used in ArduPilot, with parameter groups named BATT_ through BATT9_ for the first 10, and BATTA_ thru BATTF_ for the last 6 monitors. For this article all parameter name references will be shown for the first monitor, BATT_


A power monitor can be used to measure the battery voltage and current for use in the battery failsafe and a power module can also provide a stable power supply to the autopilot.

--- chunk_id: chunk-0188
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 522
content_hash: 3305ef8ee000fc5f
prev_chunk_id: chunk-0187
next_chunk_id: chunk-0189
document_type: technical_reference

Power Monitor/Module Configuration in Mission Planner — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
Drive Calculator Motor/Propeller Analyzer
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Monitor Configuration
Mission Planner Setup
Connecting power monitor to alternative pins
Power Monitors Connecting to AutoPilot Power Monitor Port
CAN/DroneCAN Power Monitors and Batteries
DroneCAN Battery Tag
I2C Power Monitor
Power Monitoring Via Telemetry Equipped AM32/BLHeli32/S ESCs
EFI Fuel Monitoring
Liquid Fuel Monitors
Substituting  a Battery Monitor’s Data into an ESC’s telemetry stream
Power Tether
PPM Encoder
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Peripheral Hardware
Battery Monitors (aka Power Monitors/Modules)
- Power Monitor/Module Configuration in Mission Planner
Edit on GitHub

# Power Monitor/Module Configuration in Mission Planner
# ¶
Note

Up to 16 battery monitors may be used in ArduPilot, with parameter groups named BATT_ through BATT9_ for the first 10, and BATTA_ thru BATTF_ for the last 6 monitors. For this article all parameter name references will be shown for the first monitor, BATT_


A power monitor can be used to measure the battery voltage and current for use in the battery failsafe and a power module can also provide a stable power supply to the autopilot. ArduPilot is
compatible with a number of power modules/monitors
.

--- chunk_id: chunk-0189
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 93
content_hash: d491e417a61bc122
prev_chunk_id: chunk-0188
next_chunk_id: chunk-0190
document_type: technical_reference

For this article all parameter name references will be shown for the first monitor, BATT_


A power monitor can be used to measure the battery voltage and current for use in the battery failsafe and a power module can also provide a stable power supply to the autopilot. ArduPilot is
compatible with a number of power modules/monitors
. Note

Boards with integrated power monitors have their parameters setup by default.

--- chunk_id: chunk-0190
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 30
content_hash: d05905cf3fb37817
prev_chunk_id: chunk-0189
next_chunk_id: chunk-0191
section_heading: Mission Planner Setup
document_type: technical_reference

## Mission Planner Setup
### ¶
Battery measurement is primarily set up in the
Mission Planner
’s
INITIAL SETUP | Optional Hardware |

--- chunk_id: chunk-0191
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 1076
content_hash: 0047719cccdafdb7
prev_chunk_id: chunk-0190
next_chunk_id: chunk-0192
section_heading: Mission Planner Setup
document_type: technical_reference

Battery Monitor
screen. Note that currently Mission Planner only supports the first two Battery Monitors in the system (a total of 10 are available in firmware versions 4.0 and later). More would need to be configured directly by directly setting their parameters in the
CONFIG/TUNING|Full Parameter List
screen.

MissionPlanner: Battery Monitor Configuration
¶

### Enable voltage and current sensing
### ¶
Enter the properties your monitor can measure, the type of monitor, the
type of autopilot, and the battery capacity:

Monitor:
Voltage and Current
or
Battery Volts

Sensor:
Supported power module, or “Other”

APM ver:
Autopilot (e.g. Pixhawk )

Battery Capacity:
Battery capacity in mAh

The
Sensor
selection list offers a number of analog Power Modules
(including popular models from 3DR and AttoPilot) which you can select
to automatically configure your module. If your PM is not on the list
then you can select
Other
, enter its recommended values, or
perform a manual calibration
as described below.


### Other Types of Power Modules/Smart Batteries
### ¶
In addition to normal analog voltage and current sensing modules, ArduPilot supports a wide range of SMBus, DroneCAN/CAN power modules and Smart Batteries. (In the following, the first monitor’s parameters are shown. Each of the other monitors have their own parameters.)

These are selected via the
BATTx_MONITOR
parameter for each battery monitor. These can be set directly via the CONFIG/Parameter Tree tab for each battery monitor. Here are the monitor types supported:

BATT_MONITOR

TYPE

0

Disabled

3

Analog Voltage Only

4

Analog Voltage and Current

5

Solo

6

Bebop

7

SMBus-Generic

8

DroneCAN-BatteryInfo

9

ESC

10

Sum Of Selected Monitors, see BATTx_SUM_MASK parameter

11

FuelFlow

12

FuelLevelPWM

13

SMBUS-SUI3

14

SMBUS-SUI6

15

NeoDesign

16

SMBus-Maxell

17

Generator-Elec

18

Generator-Fuel

19

Rotoye

20

MPPT

21

INA2XX

22

LTC2946

23

Torqeedo Motor Controller

24

FuelLevelAnalog

Note

Once a specific monitor type is selected, parameters associated with that type of monitor will be revealed once parameters are refreshed. Scales and offsets, bus addresses, etc. will be displayed, as appropriate, for that monitor.



### Other Parameters
### ¶
BATT_OPTIONS
bit 0, if set, will ignore the State Of Charge field in DroneCAN monitors, since some do not populate this field with meaningful data. Also various options for MPPT type monitors are provided. Bit 6 allows the resting voltage to be sent in place of battery voltage, which is sometime more useful. Bit 7 allows the Battery Auxiliary info from another DroneCAN monitor with the same
BATT_SERIAL_NUM
to be used for this monitor instance. For Bit 9 if set, the Sum monitor type measures minimum voltage instead of average. Bit 10 allows telemetry to conttinue if a DroneCAN battery with a different id is hotswapped.

BATT_SUM_MASK
is used if the monitor is type “10” (Sum Of Selected Monitors) to select which monitors’ reported voltages will be averaged, and current values will be summed, and reported for this monitor. Selecting this monitor’s own instance number has no effect. If no bits are set, it will average all higher numbered instance’s reports.

BATT_ARM_VOLT
is the minimum voltage reported from this monitor that will allow arming to occur.

BATT_ARM_MAH
is the minimum capacity remaining reported from this monitor that will allow arming to occur.

BATT_CURR_MULT
allows adjusting the current scale for DroneCAN(UAVCAN) monitors which do not have a CAN parameter exposed for adjustment.

BATT_SERIAL_NUM
is used to designate which battery an SMBUS or DroneCAN monitor is associated, since multiple instances of these monitors are possible.

BATT_MAX_AMPS
applies only to INA2xx sensors. Controls the maximum current which can be reported. This sensor is usually integrated onto the autopilot board and this value preset appropriately in the firmware. Normally, the user would only adjust this if the power monitor OEM suggest that it be set to a certain value.


### Failsafe
### ¶
Failsafes can be implemented for low battery/fuel conditions. For Plane see
Plane Failsafe Function
, for Copter see
Battery Failsafe
, or for Rover see
Failsafes


### Analog Monitor Calibration
### ¶
The bottom section of the
Battery Monitor
screen allows you to
calibrate the voltage/current measurement in order to verify that the
measured voltage of the battery is correct. You can also set the
Sensor
selection list to
Other
and use the calibration process
to configure an “unknown” power monitor/module.

To calibrate the voltage reading:

Check the voltage of your LiPo battery with a hand-held volt meter or
a
power analyzer

Connect your Pixhawk-series to your computer and plug in the LiPo battery

Check the voltage through the
Mission Planner
’s
INITIAL SETUP |
Optional Hardware | Battery Monitor
screen or on the Flight Data
screen’s HUD or
Status
tab.

If you find the voltage is not correct (i.e. if off from the hand-held
volt meter’s reading by more than perhaps 0.2V) you can calibrate it by doing the following:

On
Mission Planner
’s
INITIAL SETUP

--- chunk_id: chunk-0192
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 1081
content_hash: 3fb4d4dbc6e59d65
prev_chunk_id: chunk-0191
next_chunk_id: chunk-0193
section_heading: Mission Planner Setup
document_type: technical_reference

Battery Monitor
screen. Note that currently Mission Planner only supports the first two Battery Monitors in the system (a total of 10 are available in firmware versions 4.0 and later). More would need to be configured directly by directly setting their parameters in the
CONFIG/TUNING|Full Parameter List
screen.

MissionPlanner: Battery Monitor Configuration
¶

### Enable voltage and current sensing
### ¶
Enter the properties your monitor can measure, the type of monitor, the
type of autopilot, and the battery capacity:

Monitor:
Voltage and Current
or
Battery Volts

Sensor:
Supported power module, or “Other”

APM ver:
Autopilot (e.g. Pixhawk )

Battery Capacity:
Battery capacity in mAh

The
Sensor
selection list offers a number of analog Power Modules
(including popular models from 3DR and AttoPilot) which you can select
to automatically configure your module. If your PM is not on the list
then you can select
Other
, enter its recommended values, or
perform a manual calibration
as described below.


### Other Types of Power Modules/Smart Batteries
### ¶
In addition to normal analog voltage and current sensing modules, ArduPilot supports a wide range of SMBus, DroneCAN/CAN power modules and Smart Batteries. (In the following, the first monitor’s parameters are shown. Each of the other monitors have their own parameters.)

These are selected via the
BATTx_MONITOR
parameter for each battery monitor. These can be set directly via the CONFIG/Parameter Tree tab for each battery monitor. Here are the monitor types supported:

BATT_MONITOR

TYPE

0

Disabled

3

Analog Voltage Only

4

Analog Voltage and Current

5

Solo

6

Bebop

7

SMBus-Generic

8

DroneCAN-BatteryInfo

9

ESC

10

Sum Of Selected Monitors, see BATTx_SUM_MASK parameter

11

FuelFlow

12

FuelLevelPWM

13

SMBUS-SUI3

14

SMBUS-SUI6

15

NeoDesign

16

SMBus-Maxell

17

Generator-Elec

18

Generator-Fuel

19

Rotoye

20

MPPT

21

INA2XX

22

LTC2946

23

Torqeedo Motor Controller

24

FuelLevelAnalog

Note

Once a specific monitor type is selected, parameters associated with that type of monitor will be revealed once parameters are refreshed. Scales and offsets, bus addresses, etc. will be displayed, as appropriate, for that monitor.



### Other Parameters
### ¶
BATT_OPTIONS
bit 0, if set, will ignore the State Of Charge field in DroneCAN monitors, since some do not populate this field with meaningful data. Also various options for MPPT type monitors are provided. Bit 6 allows the resting voltage to be sent in place of battery voltage, which is sometime more useful. Bit 7 allows the Battery Auxiliary info from another DroneCAN monitor with the same
BATT_SERIAL_NUM
to be used for this monitor instance. For Bit 9 if set, the Sum monitor type measures minimum voltage instead of average. Bit 10 allows telemetry to conttinue if a DroneCAN battery with a different id is hotswapped.

BATT_SUM_MASK
is used if the monitor is type “10” (Sum Of Selected Monitors) to select which monitors’ reported voltages will be averaged, and current values will be summed, and reported for this monitor. Selecting this monitor’s own instance number has no effect. If no bits are set, it will average all higher numbered instance’s reports.

BATT_ARM_VOLT
is the minimum voltage reported from this monitor that will allow arming to occur.

BATT_ARM_MAH
is the minimum capacity remaining reported from this monitor that will allow arming to occur.

BATT_CURR_MULT
allows adjusting the current scale for DroneCAN(UAVCAN) monitors which do not have a CAN parameter exposed for adjustment.

BATT_SERIAL_NUM
is used to designate which battery an SMBUS or DroneCAN monitor is associated, since multiple instances of these monitors are possible.

BATT_MAX_AMPS
applies only to INA2xx sensors. Controls the maximum current which can be reported. This sensor is usually integrated onto the autopilot board and this value preset appropriately in the firmware. Normally, the user would only adjust this if the power monitor OEM suggest that it be set to a certain value.


### Failsafe
### ¶
Failsafes can be implemented for low battery/fuel conditions. For Plane see
Plane Failsafe Function
, for Copter see
Battery Failsafe
, or for Rover see
Failsafes


### Analog Monitor Calibration
### ¶
The bottom section of the
Battery Monitor
screen allows you to
calibrate the voltage/current measurement in order to verify that the
measured voltage of the battery is correct. You can also set the
Sensor
selection list to
Other
and use the calibration process
to configure an “unknown” power monitor/module.

To calibrate the voltage reading:

Check the voltage of your LiPo battery with a hand-held volt meter or
a
power analyzer

Connect your Pixhawk-series to your computer and plug in the LiPo battery

Check the voltage through the
Mission Planner
’s
INITIAL SETUP |
Optional Hardware | Battery Monitor
screen or on the Flight Data
screen’s HUD or
Status
tab.

If you find the voltage is not correct (i.e. if off from the hand-held
volt meter’s reading by more than perhaps 0.2V) you can calibrate it by doing the following:

On
Mission Planner
’s
INITIAL SETUP | Optional Hardware |

--- chunk_id: chunk-0193
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 1092
content_hash: 0404728f9fdc5a1f
prev_chunk_id: chunk-0192
next_chunk_id: chunk-0194
section_heading: Mission Planner Setup
document_type: technical_reference

Battery Monitor
screen. Note that currently Mission Planner only supports the first two Battery Monitors in the system (a total of 10 are available in firmware versions 4.0 and later). More would need to be configured directly by directly setting their parameters in the
CONFIG/TUNING|Full Parameter List
screen.

MissionPlanner: Battery Monitor Configuration
¶

### Enable voltage and current sensing
### ¶
Enter the properties your monitor can measure, the type of monitor, the
type of autopilot, and the battery capacity:

Monitor:
Voltage and Current
or
Battery Volts

Sensor:
Supported power module, or “Other”

APM ver:
Autopilot (e.g. Pixhawk )

Battery Capacity:
Battery capacity in mAh

The
Sensor
selection list offers a number of analog Power Modules
(including popular models from 3DR and AttoPilot) which you can select
to automatically configure your module. If your PM is not on the list
then you can select
Other
, enter its recommended values, or
perform a manual calibration
as described below.


### Other Types of Power Modules/Smart Batteries
### ¶
In addition to normal analog voltage and current sensing modules, ArduPilot supports a wide range of SMBus, DroneCAN/CAN power modules and Smart Batteries. (In the following, the first monitor’s parameters are shown. Each of the other monitors have their own parameters.)

These are selected via the
BATTx_MONITOR
parameter for each battery monitor. These can be set directly via the CONFIG/Parameter Tree tab for each battery monitor. Here are the monitor types supported:

BATT_MONITOR

TYPE

0

Disabled

3

Analog Voltage Only

4

Analog Voltage and Current

5

Solo

6

Bebop

7

SMBus-Generic

8

DroneCAN-BatteryInfo

9

ESC

10

Sum Of Selected Monitors, see BATTx_SUM_MASK parameter

11

FuelFlow

12

FuelLevelPWM

13

SMBUS-SUI3

14

SMBUS-SUI6

15

NeoDesign

16

SMBus-Maxell

17

Generator-Elec

18

Generator-Fuel

19

Rotoye

20

MPPT

21

INA2XX

22

LTC2946

23

Torqeedo Motor Controller

24

FuelLevelAnalog

Note

Once a specific monitor type is selected, parameters associated with that type of monitor will be revealed once parameters are refreshed. Scales and offsets, bus addresses, etc. will be displayed, as appropriate, for that monitor.



### Other Parameters
### ¶
BATT_OPTIONS
bit 0, if set, will ignore the State Of Charge field in DroneCAN monitors, since some do not populate this field with meaningful data. Also various options for MPPT type monitors are provided. Bit 6 allows the resting voltage to be sent in place of battery voltage, which is sometime more useful. Bit 7 allows the Battery Auxiliary info from another DroneCAN monitor with the same
BATT_SERIAL_NUM
to be used for this monitor instance. For Bit 9 if set, the Sum monitor type measures minimum voltage instead of average. Bit 10 allows telemetry to conttinue if a DroneCAN battery with a different id is hotswapped.

BATT_SUM_MASK
is used if the monitor is type “10” (Sum Of Selected Monitors) to select which monitors’ reported voltages will be averaged, and current values will be summed, and reported for this monitor. Selecting this monitor’s own instance number has no effect. If no bits are set, it will average all higher numbered instance’s reports.

BATT_ARM_VOLT
is the minimum voltage reported from this monitor that will allow arming to occur.

BATT_ARM_MAH
is the minimum capacity remaining reported from this monitor that will allow arming to occur.

BATT_CURR_MULT
allows adjusting the current scale for DroneCAN(UAVCAN) monitors which do not have a CAN parameter exposed for adjustment.

BATT_SERIAL_NUM
is used to designate which battery an SMBUS or DroneCAN monitor is associated, since multiple instances of these monitors are possible.

BATT_MAX_AMPS
applies only to INA2xx sensors. Controls the maximum current which can be reported. This sensor is usually integrated onto the autopilot board and this value preset appropriately in the firmware. Normally, the user would only adjust this if the power monitor OEM suggest that it be set to a certain value.


### Failsafe
### ¶
Failsafes can be implemented for low battery/fuel conditions. For Plane see
Plane Failsafe Function
, for Copter see
Battery Failsafe
, or for Rover see
Failsafes


### Analog Monitor Calibration
### ¶
The bottom section of the
Battery Monitor
screen allows you to
calibrate the voltage/current measurement in order to verify that the
measured voltage of the battery is correct. You can also set the
Sensor
selection list to
Other
and use the calibration process
to configure an “unknown” power monitor/module.

To calibrate the voltage reading:

Check the voltage of your LiPo battery with a hand-held volt meter or
a
power analyzer

Connect your Pixhawk-series to your computer and plug in the LiPo battery

Check the voltage through the
Mission Planner
’s
INITIAL SETUP |
Optional Hardware | Battery Monitor
screen or on the Flight Data
screen’s HUD or
Status
tab.

If you find the voltage is not correct (i.e. if off from the hand-held
volt meter’s reading by more than perhaps 0.2V) you can calibrate it by doing the following:

On
Mission Planner
’s
INITIAL SETUP | Optional Hardware | Battery Monitor
screen set the “Sensor” to “Other”.

--- chunk_id: chunk-0194
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 260
content_hash: 31b01cb11bcab4d3
prev_chunk_id: chunk-0193
next_chunk_id: chunk-0195
section_heading: Mission Planner Setup
document_type: technical_reference

| Optional Hardware | Battery Monitor
screen set the “Sensor” to “Other”. Enter the voltage according to the hand-held volt meter in the
“Measured Battery Voltage” field

Press tab or click out of the field and the “Voltage Divider
(Calced)” value will update and the “Battery voltage (Calced)” should
now equal the measured voltage

Using the power analyser you can also measure the current and compare to
results displayed in the Mission Planner. You can also empirically adjust the current scale and offset parameters as explained in
Analog Current Monitor Calibration
. Note

Most current sensors are not very accurate at low currents (less
than 3 Amps). Typically you should perform current calibration at around
10A. The exception is PMs that use hall-effect sensors, like
those from Mauch
. This video shows the voltage and current calibration process using a
Turnigy Power Analyser. ### Enable Low Battery Alert
### ¶
You can set
Mission Planner
to alert you verbally when your battery is
low (using a computerized voice). Simply check the
MP Alert on Low Battery
checkbox and enter the
warning you wish to hear, the voltage level and finally the percentage
of remaining current.

--- chunk_id: chunk-0195
source_document: common-power-module-configuration-in-mission-planner.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 166
content_hash: a59680e67d6a51c3
prev_chunk_id: chunk-0194
next_chunk_id: chunk-0196
section_heading: Connecting power monitor to alternative pins
document_type: technical_reference

## Connecting power monitor to alternative pins
### ¶
The power monitor is generally plugged into the default port on the
autopilot (ie. Pixhawk). If you wish to change where the power
monitor is plugged into the controller, the pins used can be modified
using the
BATT_VOLT_PIN
and
BATT_CURR_PIN
parameters. The list of available analog input pins that can be used are listed on
the Hardware Options page for the
Pixhawk
board or its board description linked from the
Choosing an Autopilot
page






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0196
source_document: common-powering-the-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 269
content_hash: e40ad203d92cd81d
prev_chunk_id: chunk-0195
next_chunk_id: chunk-0197
document_type: technical_reference

Powering the Pixhawk — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Mounting the Autopilot
Autopilot Wiring
GPS/Compass
RC input
Motor/Servo Connections
NAVIO2 (Linux based) Wiring QuickStart
Installing GPS + Compass Module
Detailed Vehicle Builds
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Autopilot System Assembly Instructions for Plane
Typical Autopilot Wiring Connections
Pixhawk Wiring Quick Start
- Powering the Pixhawk
Edit on GitHub

# Powering the Pixhawk
# ¶
This article explains how to power the
Pixhawk
.

--- chunk_id: chunk-0197
source_document: common-powering-the-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 425
content_hash: 66574fc8f53576fb
prev_chunk_id: chunk-0196
next_chunk_id: chunk-0198
section_heading: Overview
document_type: technical_reference

## Overview
### ¶
For most users powering the Pixhawk is as simple as connecting a 6-pin
DF13 cable from one of the
supported power modules
into the Pixhawk’s “Power”
port as shown below. Pixhawk Power Port
¶

The module will provide a steady ~5V to Pixhawk and allow the Pixhawk to
measure the current and/or voltage of the main battery. Depending on the
power module you may also have connections to provide backup power and
power to supply the servo rail. The type of power module also determines what size batteries can be used
(most multicopters draw less than 20amps when hovering and rarely
consume more than 90amps at full throttle). Warning

Pixhawk does
not
supply
power to the servo rail. Powering
the servo rails is normally done by an ESC or alternatively a separate
source such as a BEC (as shown in the
wiring overview below
). Tip

Some power modules explicitly provide support for powering the
servo rail, backup power and support for larger batteries. Using this
sort of module means that you don’t need to think about most of the
wiring issues discussed in the rest of this article. Warning

Pixhawk supplies power for an RC receiver if that receiver is connected via a 3-conductor servo cable to the RC connector on the Pixhawk. If that receiver is also connected to the SBus port on the
Pixhawk to communicate an analog RSSI signal via a 3-conductor cable, there is an opportunity to inadvertently power the servo bus from the primary PixHawk power input thru the radio. Some radios (e.g., FRSky) will pass power received on their RC output cable out on their analog RSSI port. And the PixHawk servo-rail power bus includes the SBus +5v pin. Removing the center conductor from the RSSI monitoring cable will avoid powering the Pixhawk servo bus from the wrong (or from multiple) voltage sources thru the RC radio receiver.

--- chunk_id: chunk-0198
source_document: common-powering-the-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 156
content_hash: 001d69637facc3c8
prev_chunk_id: chunk-0197
next_chunk_id: chunk-0199
section_heading: Powering/backup off the servo rail
document_type: technical_reference

## Powering/backup off the servo rail
### ¶
Pixhawk can be powered off the servo rail instead of from a power
module. This is achieved by connecting a 5V BEC (with or without a
servo) to a power (+) pin and a ground (-) pin of the “MAIN OUT” or “AUX
OUT” pins. You
must
also add a Zener diode (part number 1N5339) to
condition the power across the rail and restrict it to less than 5.7V. This method can also be used as backup power for Pixhawk when using a
power module. If the voltage provided by the power module falls too low
(4V?), Pixhawk will take power from the output rail. See the
voltage
ratings

--- chunk_id: chunk-0199
source_document: common-powering-the-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 66
content_hash: 9093350cb97bae17
prev_chunk_id: chunk-0198
next_chunk_id: chunk-0200
section_heading: section below for more information on powering Pixhawk.
document_type: technical_reference

section below for more information on powering Pixhawk. Warning

The servo rail can supply servos requiring up to 10.5V (but not also power the Pixhawk). Voltages above 5V cannot be used to power the Pixhawk via the servo rail. In this case the Zener diode
must not be used
.

--- chunk_id: chunk-0200
source_document: common-powering-the-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 196
content_hash: bcb9ffea6b029882
prev_chunk_id: chunk-0199
next_chunk_id: chunk-0201
section_heading: Pixhawk Power/ESC Wiring Overview
document_type: technical_reference

## Pixhawk Power/ESC Wiring Overview
### ¶
The block diagram below synthesizes an overview of Pixhawk’s power and
ESC wiring. In this diagram, a 3DR power module (or equivalent device)
powers Pixhawk through its power port (primary source). One power source
is enough but obviously not redundant if the power module fails to power
this primary source. Therefore the diagram adds a second backup power
source via a 5V BEC that wires to Pixhawk’s output servo rail. If the
primary source fails, Pixhawk will automatically switch to this second
power source. Pixhawk Power/ESC Wiring Overview
¶

Diagram acronyms:

PDB = Power Distribution Board. PM = pixhawk power port. PM/Atto = optional power module from 3DR or Attopilot alternative
for higher than 4S battery voltages. Note

Looking for a detailed explanation of power wiring with Pixhawk? Click here for more information about connecting ESCs and servos to Pixhawk.

--- chunk_id: chunk-0201
source_document: common-powering-the-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 432
content_hash: 091ad914ecdcca3c
prev_chunk_id: chunk-0200
next_chunk_id: chunk-0202
section_heading: General wiring recommendations
document_type: technical_reference

## General wiring recommendations
### ¶
Always connect a ground reference wire with your ESC’s signal wires
on the Pixhawk servo rail (output ports 1-8). Indeed an ESC’s signal
wire should never be left floating without its ground reference
(THERE IS NO SETUP WHICH WOULDN’T REQUIRE SIGNAL GROUND TO BE
CONNECTED). It is dangerous to power the Pixhawk
only
from the servo rail,
especially with digital servos. Servos may cause voltage spikes (as
shown on illustration below that shows the servo rail voltage on an
oscilloscope when a single digital servo attached to a Pixhawk is
moved rapidly ). The key thing is that the digital servo causes the
voltage on the rail to rise above the critical 5.7V level. Above that
level the Pixhawk power management will cut power to the FMU and the
Pixhawk will reboot. If that happens when flying you will lose your aircraft. It is up to the user to provide a clean source of power for the cases
when it is powered off the servo rail. Servos by themselves are not
quiet enough. Do not connect a BEC power source to the RC IN port (black ground,
red power and white signal wires from the receiver’s PPM output are
connected to these RC pins)

Adding an external Zener is a recommendation specifically for systems
that are using 5V servos and have the servo rail configured for back
up power. Connect the recommended Zener diode with its polarity as
indicated on the diagram. Use as short wires as possible or even
better, use a standard 3 position JR servo connector with the diode
legs directly inserted (and soldered) in the servo female pins. To
complement the diode, it is also useful to add a capacitor in parallel
to the diode. The capacitor will smooth out eventual voltage ripples. As advised for the diode, the capacitor should be connected with as
short wires as possible. Do not oversize the capacitor.

--- chunk_id: chunk-0202
source_document: common-powering-the-pixhawk.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 352
content_hash: 5b903451f9a76077
prev_chunk_id: chunk-0201
next_chunk_id: chunk-0203
section_heading: Advanced power supply configuration
document_type: technical_reference

## Advanced power supply configuration
### ¶
This section explains how to set up triple redundant power sources
(power module as primary, with two backup BECs). In this scheme, a simple MBR1545CT integrated circuit is used. This
circuit takes two BECs on its inputs, and outputs only off the BEC with
the highest voltage (i.e. if BEC1 outputs 5.25V and BEC2 outputs 5.45V,
MBR1545CT will pass BEC2 and blocks BEC1). Here is a tie bus circuit
wiring diagram and example realisation with the MBR1545CT integrated
circuit and a 6 pin JST connector:

### Voltage ratings
### ¶
Pixhawk can be triple-redundant on the power supply if three power
sources are supplied. The three rails are: Power module input, servo
rail input, USB input. Normal Operation Maximum Ratings

Under these conditions all power sources will be used in this order to
power the system. Power module input (4.1V to 5.7V) [refers to the voltage coming into
Pixhawk from the power module]

Servo rail input (4.1V to 5.7V)

USB power input (4.1V to 5.7V)

Absolute Maximum Ratings

Under these conditions the system will not draw any power (will not be
operational), but will remain intact. Power module input (0V to 20V) [refers to the voltage coming into
Pixhawk from the power module]

Servo rail input (0V to 20V)

USB power input (0V to 6V)





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0203
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 385
content_hash: a5397d4ecda4e18c
prev_chunk_id: chunk-0202
next_chunk_id: chunk-0204
document_type: technical_reference

Pre-Arm Safety Checks — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Center of Gravity
Starting up and calibrating Plane
Pre-Arm Safety Checks
Recognising which Pre-Arm Check has failed using the GCS
Other Failure messages
Failsafes:
Barometer failures:
Compass failures:
GPS related failures:
INS checks (i.e. Accelerometer and Gyro checks):
Board Voltage checks:
Parameter checks:
Battery/Power Monitor:
Airspeed:
Logging:
Safety Switch:
System:
Mission:
Rangefinder:
Disabling the Pre-arm Safety Check
Arming Plane
Takeoff
Tuning Quickstart
Automatic Tuning
Tuning in Detail
Tuning Configuration Values for Common Airframes
Measuring Vibration
Transmitter based tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
First Flight
- Pre-Arm Safety Checks
Edit on GitHub

# Pre-Arm Safety Checks
# ¶
ArduPilot includes a suite of Pre-arm Safety Checks which will prevent the
vehicle from arming its propulsion system if any of a fairly large number of issues are
discovered before movement including missed calibration, configuration
or bad sensor data. These checks help prevent crashes or fly-aways but
some can also be disabled if necessary. Warning

Never disable arming checks (ie
ARMING_SKIPCHK
not = “0”, except for bench testing. Always resolve any prearm or arming failures BEFORE attempting to fly. Doing otherwise may result in the loss of the vehicle.

--- chunk_id: chunk-0204
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: d97edabb7174a8f9
prev_chunk_id: chunk-0203
next_chunk_id: chunk-0205
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

## Recognising which Pre-Arm Check has failed using the GCS
### ¶
The pilot will notice a pre-arm check failure because he/she will be
unable to arm the vehicle and the notification LED, if available, will be flashing yellow. To
determine exactly which check has failed:

Connect the Autopilot to the ground station using a USB cable
or
Telemetry
. Ensure the GCS is connected to the vehicle (i.e. on Mission
Planner and push the “Connect” button on the upper right). Turn on your radio transmitter and attempt to arm the vehicle
(regular procedure is using throttle down, yaw right or via an RCx_OPTION switch)

The first cause of the Pre-Arm Check failure will be displayed in red
on the HUD window

Pre-arm checks that are failing will also be sent as messages to the GCS while disarmed, about every 30 seconds. If you wish to disable this and have them sent only when an attempt arm fails, then set the
ARMING_OPTIONS
bit 1 (value 1). Pre-Arm Failure Messages (All vehicle types)
¶
Message

Cause

Solution

3D Accel calibration needed

Accelerometer calibration has not been done

Complete the
accel calibration

Accels calibrated requires reboot

Autopilot must be rebooted after accel calibration

Reboot autopilot

Accels inconsistent

Two accelerometers are inconsistent by 0.75 m/s/s

Re-do the
accel calibration
. Allow autopilot to warm-up and reboot. If failure continues replace autopilot. If ICE engine runs before arming, see
ARMING_OPTIONS
bit 2 as a possible solution. ADSB out of memory

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

Accels not healthy

At least one accelerometer is not providing data

Reboot autopilot. If failure continues replace autopilot

AHRS: not using configured AHRS type

EKF3 is not ready yet and vehicle is using DCM

If indoors, go outside. Ensure good GPS lock. Check for misconfiguration of EKF (see
AHRS_EKF_TYPE
)

AHRS: waiting for home

GPS has not gotten a fix

If indoors, go outside. Ensure compass and accelerometer calibrations have been completed. Eliminate radio-frequency sources that could interfere with the GPS

Airspeed 1 not healthy

Autopilot is unable to retrieve data from sensor

Check the physical connection and
configuration

AP_Relay not available

Parachute misconfigured

Parachute is controlled via Relay but the relay feature is missing.

--- chunk_id: chunk-0205
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 5768c80995624f01
prev_chunk_id: chunk-0204
next_chunk_id: chunk-0206
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Ensure compass and accelerometer calibrations have been completed. Eliminate radio-frequency sources that could interfere with the GPS

Airspeed 1 not healthy

Autopilot is unable to retrieve data from sensor

Check the physical connection and
configuration

AP_Relay not available

Parachute misconfigured

Parachute is controlled via Relay but the relay feature is missing. Custom build server
was probably used, rebuild with relay enabled

Auxiliary authorisation refused

External system has disallowed authorisation

Check external authorisation system

Batch sampling requires reboot

Batch sampling feature requires Autopilot reboot

Reboot autopilot or check
Batch sampling
configuration

Battery below minimum arming capacity

Battery capacity is below BATT_ARM_MAH

Replace battery or adjust
BATT_ARM_MAH

Battery below minimum arming voltage

Battery voltage is below BATT_ARM_VOLT

Replace battery or adjust
BATT_ARM_VOLT

Battery capacity failsafe critical >= low

Battery failsafe misconfiguration

Check
BATT_LOW_MAH
is higher than
BATT_CRT_MAH

Battery critical capacity failsafe

Battery capacity is below BATT_CRT_MAH

Replace battery or adjust
BATT_CRT_MAH

Battery critical voltage failsafe

Battery voltage is below BATT_CRT_VOLT

Replace battery or adjust
BATT_CRT_VOLT

Battery low capacity failsafe

Battery capacity is below BATT_LOW_MAH

Replace battery or adjust
BATT_LOW_MAH

Battery low voltage failsafe

Battery voltage is below BATT_LOW_VOLT

Replace battery or adjust
BATT_LOW_VOLT

Battery unhealthy

Battery is not providing data

Check battery monitors physical connect and
configuration

Battery voltage failsafe critical >= low

Battery failsafe misconfiguration

Check
BATT_LOW_VOLT
is higher than
BATT_CRT_VOLT

BendyRuler OA requires reboot

Object avoidance config change requires reboot

Reboot autopilot. See
Object Avoidance configuration

Board (Xv) out of range 4.3-5.8v

Board voltage below BRD_VBUS_MIN or too high

Check power supply. If powering via USB plug in a battery or replace USB cable

BTN_PINx=y invalid

Button misconfigured

BTNx_PIN is set to an invalid value. Check
Button setup instructions

BTN_PINx=y, set SERVOz_FUNCTION=-1

Button misconfigured

Set SERVOz_FUNCTION to -1

Can’t check rally without position

EKF does not have a position estimate yet

Wait or move to location with better GPS reception

Check fence

Fence feature has failed to be initialised

Reboot autopilot

Check mag field (xy diff:x>875)

Compass horiz field strength is too large or small

Relocate vehicle away from metal in the environment. Move compass away from metal in the frame. repeat
compass calibration
. Disable internal compass. Check mag field (z diff:x>875)

Compass vert field strength is too large or small

Relocate vehicle away from metal in the environment. Move compass away from metal in the frame.

--- chunk_id: chunk-0206
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: 1882d0c214252c48
prev_chunk_id: chunk-0205
next_chunk_id: chunk-0207
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Check mag field (z diff:x>875)

Compass vert field strength is too large or small

Relocate vehicle away from metal in the environment. Move compass away from metal in the frame. repeat
compass calibration
. Disable internal compass. Check mag field: x, max y, min z

Compass field strength is too large or small

Relocate vehicle away from metal in the environment. Move compass away from metal in the frame. repeat
compass calibration
. Disable internal compass. Chute has no channel

Parachute misconfigured

Parachute is controlled using PWM but no servo output function has been configured (e.g. need SERVOx_FUNCTION = 27). see
Parachute setup instructions

Chute has no relay

Parachute misconfigured

Parachute is controlled via Relay but no relay output has been configured. see
Parachute setup instructions

Chute is released

Parachute has been released

Reboot autopilot

Compass calibrated requires reboot

Autopilot must be rebooted after compass cal

Reboot autopilot

Compass calibration running

Compass calibration is running

Complete or cancel the
compass calibration

Compass X not healthy

Compass X is not providing data

Check the connection between compass X and the autopilot, and review the
configuration

Compass offsets too high

Compass offset params are too large

Relocate compass away from metal in the frame and repeat
compass calibration
. Disable internal compass. Increase
COMPASS_OFFS_MAX
. Compasses inconsistent

Two compasses angles or field strength disagree

Check compass orientations (e.g. COMPASS_ORIENT
). Move compass away from metal in the frame. repeat
compass calibration
. Disable internal compass. CrashDump data detected

Crash Dump data has been logged

A CPU crash has occurred and data logged. Plane is probably unsafe to fly! See
Reporting a Watchdog / Crash Dump

Dijkstra OA requires reboot

Object avoidance config change requires reboot

Reboot autopilot. See
Object Avoidance configuration

Disarm Switch on

Disarm auxiliary switch is in the high position

Move Disarm switch to the low position or check
auxiliary functions
setup

Downloading logs

Vehicle cannot be armed while logs are downloading

Wait until logs are downloaded, cancel download or reboot autopilot

DroneCAN: Duplicate Node x../y! DroneCAN sees same node ids used by two devices

Clear DroneCAN DNS server by setting
CAN_D1_UC_OPTION
= 1 and reboot

DroneCAN: Failed to access storage! Possible hardware issue

Reboot autopilot

DroneCAN: Failed to add Node x!

--- chunk_id: chunk-0207
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 345
content_hash: d8bb2e6557656645
prev_chunk_id: chunk-0206
next_chunk_id: chunk-0208
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

DroneCAN sees same node ids used by two devices

Clear DroneCAN DNS server by setting
CAN_D1_UC_OPTION
= 1 and reboot

DroneCAN: Failed to access storage! Possible hardware issue

Reboot autopilot

DroneCAN: Failed to add Node x! DroneCAN could not init connection to a device

Check sensor’s physical connection and power supply

DroneCAN: Node x unhealthy! A DroneCAN device is not providing data

Check sensor’s physical connection and power supply

Duplicate Aux Switch Options

Two auxiliary function switches for same feature

Check
auxiliary function
setup. Check for
RCx_OPTION
parameters with same values

EKF3 Roll/Pitch inconsistent by x degs

Roll or Pitch lean angle estimates are inconsistent

Normally due to EKF3 not getting good enough GPS accuracy, but could be due to other sensors producing errors. Go outdoors, wait or reboot autopilot. EKF3x vel error y

EKF3 has velocity innovation of “y”

EKF3 getting high position velocity innovations. Check GPS, wait or reboot. EKF3 waiting for GPS config data

automatic GPS configuration has not completed

Check GPS connection and configuration especially if using DroneCAN GPS

EKF3 Yaw inconsistent by x degs

Yaw angle estimates are inconsistent

Wait or reboot autopilot

Failed to open mission.stg

Failed to load mission from SD Card

Check SD card. Try to re-save mission to SD card

Failed to create log directory /APM/LOGS : ENOMEM

Failed to create log directory on SD card

Decrease
LOG_FILE_BUFSIZE
or disable other features to reduce memory usage

Fence requires position

If fences are enabled, position estimate required

Wait or move vehicle to a location with a clear view of the sky.

--- chunk_id: chunk-0208
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 592
content_hash: a5f0fd7581117044
prev_chunk_id: chunk-0207
next_chunk_id: chunk-0209
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

EKF3 waiting for GPS config data

automatic GPS configuration has not completed

Check GPS connection and configuration especially if using DroneCAN GPS

EKF3 Yaw inconsistent by x degs

Yaw angle estimates are inconsistent

Wait or reboot autopilot

Failed to open mission.stg

Failed to load mission from SD Card

Check SD card. Try to re-save mission to SD card

Failed to create log directory /APM/LOGS : ENOMEM

Failed to create log directory on SD card

Decrease
LOG_FILE_BUFSIZE
or disable other features to reduce memory usage

Fence requires position

If fences are enabled, position estimate required

Wait or move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

FENCE_ALT_MAX < FENCE_ALT_MIN

FENCE_ALT_MAX must be greater than FENCE_ALT_MIN

Increase
FENCE_ALT_MAX
or lower
FENCE_ALT_MIN

FENCE_MARGIN is less than FENCE_RADIUS

FENCE_MARGIN must be larger than FENCE_RADIUS

Increase
FENCE_RADIUS
or reduce
FENCE_MARGIN

FENCE_MARGIN too big

FENCE_ALT_MAX - FENCE_ALT_MIN < 2x FENCE_MARGIN

Decrease
FENCE_MARGIN
or increase difference between
FENCE_ALT_MAX
and
FENCE_ALT_MIN

Fences enabled, but none selected

Fences are enabled but none are defined

Disable some or all fences using
FENCE_ENABLE
or
FENCE_TYPE
or define the missing fences

Fences invalid

Polygon fence is invalid

Check polygon fence does not have overlapping lines

FETtec: Invalid motor mask

FETtec misconfiguration

See
FETtec configuration

FETtec: Invalid pole count x

FETtec misconfiguration

See
FETtec configuration

FETtec: No uart

FETtec misconfiguration

See
FETtec configuration

FETtec: Not initialised

FETtec ESCs are not communicating with autopilot

See
FETtec configuration

FETtec: x of y ESCs are not running

FETtec ESCs are not spinning

See
FETtec configuration

FETtec: x of y ESCs are not sending telem

FETtec ESCs are not communicating with autopilot

See
FETtec configuration

FFT calibrating noise

FFT Harmonic Notch analysis has not completed

Wait until
In-Flight FFT analysis
completes

FFT config MAXHZ xHz > yHz

FFT Harmonic Notch misconfiguration

See
In-Flight FFT Harmonic Notch Setup
completes

FFT self-test failed, max error Hz

FFT Harmonic Notch failed

See
In-Flight FFT Harmonic Notch Setup
completes

FFT still analyzing

FFT Harmonic Notch analysis has not completed

Wait until
In-Flight FFT analysis
completes

FFT: calibrated xHz/xHz/xHz

FFT Harmonic Notch issue

See
In-Flight FFT Harmonic Notch Setup
completes

FFT: resolution is xHz, increase length

FFT Harmonic Notch misconfiguration

See
In-Flight FFT Harmonic Notch Setup
completes

Generator: Not healthy

Generator is not communicating with autopilot

Check
generator configuration

Generator: No backend driver

Firmware does not include selected generator

Build version of firmware with desired generator using custom.ardupilot.org

GPS alt error xm (see BARO_ALTERR_MAX)

GPS and BARO alt disagree by a large amount

Read the
BARO_ALTERR_MAX
parameter description

GPS and AHRS differ by Xm

GPS and EKF positions differ by at least 10m

Wait until GPS quality improves.

--- chunk_id: chunk-0209
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 540
content_hash: d02dbcf61a3b0102
prev_chunk_id: chunk-0208
next_chunk_id: chunk-0210
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Try to re-save mission to SD card

Failed to create log directory /APM/LOGS : ENOMEM

Failed to create log directory on SD card

Decrease
LOG_FILE_BUFSIZE
or disable other features to reduce memory usage

Fence requires position

If fences are enabled, position estimate required

Wait or move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

FENCE_ALT_MAX < FENCE_ALT_MIN

FENCE_ALT_MAX must be greater than FENCE_ALT_MIN

Increase
FENCE_ALT_MAX
or lower
FENCE_ALT_MIN

FENCE_MARGIN is less than FENCE_RADIUS

FENCE_MARGIN must be larger than FENCE_RADIUS

Increase
FENCE_RADIUS
or reduce
FENCE_MARGIN

FENCE_MARGIN too big

FENCE_ALT_MAX - FENCE_ALT_MIN < 2x FENCE_MARGIN

Decrease
FENCE_MARGIN
or increase difference between
FENCE_ALT_MAX
and
FENCE_ALT_MIN

Fences enabled, but none selected

Fences are enabled but none are defined

Disable some or all fences using
FENCE_ENABLE
or
FENCE_TYPE
or define the missing fences

Fences invalid

Polygon fence is invalid

Check polygon fence does not have overlapping lines

FETtec: Invalid motor mask

FETtec misconfiguration

See
FETtec configuration

FETtec: Invalid pole count x

FETtec misconfiguration

See
FETtec configuration

FETtec: No uart

FETtec misconfiguration

See
FETtec configuration

FETtec: Not initialised

FETtec ESCs are not communicating with autopilot

See
FETtec configuration

FETtec: x of y ESCs are not running

FETtec ESCs are not spinning

See
FETtec configuration

FETtec: x of y ESCs are not sending telem

FETtec ESCs are not communicating with autopilot

See
FETtec configuration

FFT calibrating noise

FFT Harmonic Notch analysis has not completed

Wait until
In-Flight FFT analysis
completes

FFT config MAXHZ xHz > yHz

FFT Harmonic Notch misconfiguration

See
In-Flight FFT Harmonic Notch Setup
completes

FFT self-test failed, max error Hz

FFT Harmonic Notch failed

See
In-Flight FFT Harmonic Notch Setup
completes

FFT still analyzing

FFT Harmonic Notch analysis has not completed

Wait until
In-Flight FFT analysis
completes

FFT: calibrated xHz/xHz/xHz

FFT Harmonic Notch issue

See
In-Flight FFT Harmonic Notch Setup
completes

FFT: resolution is xHz, increase length

FFT Harmonic Notch misconfiguration

See
In-Flight FFT Harmonic Notch Setup
completes

Generator: Not healthy

Generator is not communicating with autopilot

Check
generator configuration

Generator: No backend driver

Firmware does not include selected generator

Build version of firmware with desired generator using custom.ardupilot.org

GPS alt error xm (see BARO_ALTERR_MAX)

GPS and BARO alt disagree by a large amount

Read the
BARO_ALTERR_MAX
parameter description

GPS and AHRS differ by Xm

GPS and EKF positions differ by at least 10m

Wait until GPS quality improves. Move vehicle to a location with a clear view of the sky.

--- chunk_id: chunk-0210
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: 565594be4ebc8790
prev_chunk_id: chunk-0209
next_chunk_id: chunk-0211
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Reduce sources of radio-frequency interference

FENCE_ALT_MAX < FENCE_ALT_MIN

FENCE_ALT_MAX must be greater than FENCE_ALT_MIN

Increase
FENCE_ALT_MAX
or lower
FENCE_ALT_MIN

FENCE_MARGIN is less than FENCE_RADIUS

FENCE_MARGIN must be larger than FENCE_RADIUS

Increase
FENCE_RADIUS
or reduce
FENCE_MARGIN

FENCE_MARGIN too big

FENCE_ALT_MAX - FENCE_ALT_MIN < 2x FENCE_MARGIN

Decrease
FENCE_MARGIN
or increase difference between
FENCE_ALT_MAX
and
FENCE_ALT_MIN

Fences enabled, but none selected

Fences are enabled but none are defined

Disable some or all fences using
FENCE_ENABLE
or
FENCE_TYPE
or define the missing fences

Fences invalid

Polygon fence is invalid

Check polygon fence does not have overlapping lines

FETtec: Invalid motor mask

FETtec misconfiguration

See
FETtec configuration

FETtec: Invalid pole count x

FETtec misconfiguration

See
FETtec configuration

FETtec: No uart

FETtec misconfiguration

See
FETtec configuration

FETtec: Not initialised

FETtec ESCs are not communicating with autopilot

See
FETtec configuration

FETtec: x of y ESCs are not running

FETtec ESCs are not spinning

See
FETtec configuration

FETtec: x of y ESCs are not sending telem

FETtec ESCs are not communicating with autopilot

See
FETtec configuration

FFT calibrating noise

FFT Harmonic Notch analysis has not completed

Wait until
In-Flight FFT analysis
completes

FFT config MAXHZ xHz > yHz

FFT Harmonic Notch misconfiguration

See
In-Flight FFT Harmonic Notch Setup
completes

FFT self-test failed, max error Hz

FFT Harmonic Notch failed

See
In-Flight FFT Harmonic Notch Setup
completes

FFT still analyzing

FFT Harmonic Notch analysis has not completed

Wait until
In-Flight FFT analysis
completes

FFT: calibrated xHz/xHz/xHz

FFT Harmonic Notch issue

See
In-Flight FFT Harmonic Notch Setup
completes

FFT: resolution is xHz, increase length

FFT Harmonic Notch misconfiguration

See
In-Flight FFT Harmonic Notch Setup
completes

Generator: Not healthy

Generator is not communicating with autopilot

Check
generator configuration

Generator: No backend driver

Firmware does not include selected generator

Build version of firmware with desired generator using custom.ardupilot.org

GPS alt error xm (see BARO_ALTERR_MAX)

GPS and BARO alt disagree by a large amount

Read the
BARO_ALTERR_MAX
parameter description

GPS and AHRS differ by Xm

GPS and EKF positions differ by at least 10m

Wait until GPS quality improves. Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

GPS blending unhealthy

At least one GPS is not providing good data

Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference.

--- chunk_id: chunk-0211
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: 9ae9ee0d470ccf3f
prev_chunk_id: chunk-0210
next_chunk_id: chunk-0212
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Reduce sources of radio-frequency interference

GPS blending unhealthy

At least one GPS is not providing good data

Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference. Check
GPS blending configuration

GPS Node x not set as instance y

DroneCan GPS configuration error

Check
GPS1_CAN_NODEID
and
GPS2_CAN_NODEID

GPS positions differ by Xm

Two GPSs reported positions differ by 50m or more

Wait until GPS quality improves. Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

GPS x still configuring this GPS

Automatic GPS configuration has not completed

Wait until configuration completes. Check GPS connection and configuration especially if using DroneCAN GPS

GPS x: Bad fix

GPS does not have a good lock

Move vehicle to a location with a clear view of the sky. Reduce sources of radio-frequency interference

GPS x: not healthy

GPS is not providing data

Check GPSs physical connection to autopilot and
configuration

GPS x: primary but TYPE 0

Primary GPS has not been configured

Check
GPS_PRIMARY
and confirm corresponding
GPS1_TYPE
or
GPS2_TYPE
matches type of GPS used

GPS x: was not found

GPS disconnected or incorrectly configured

Check GPSs physical connection to autopilot and
configuration

GPSx yaw not available

GPS-for-yaw configured but not working

Move to location with better GPS reception. Check
GPS-for-yaw
configuration

Gyro x rate yHz < loop rate z Hz

Loop rate is faster than Gyro data

Lower
SCHED_LOOP_RATE

Gyros inconsistent

Two gyros are inconsistent by at least 5 deg/sec

Reboot autopilot and hold vehicle still until gyro calibration completes. Allow autopilot to warm-up and reboot. If failure continues replace autopilot. If ICE engine runs before arming, see
ARMING_OPTIONS
bit 2 as a possible solution. Gyros not calibrated

Gyro calibration normally run at startup failed

Reboot autopilot and hold vehicle still until gyro calibration completes

Gyros not healthy

At least one gyro is not providing data

Reboot autopilot. If failure continues replace autopilot

Hardware safety switch

Hardware safety switch has not been pushed

Push safety switch (normally on top of GPS) or disable by setting
BRD_SAFETY_DEFLT
to zero and reboot autopilot

heater temp low (x < 45)

Board heater temp is below BRD_HEAT_TARG

Wait for board to heat up.

--- chunk_id: chunk-0212
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 289
content_hash: 56a3058508975c1e
prev_chunk_id: chunk-0211
next_chunk_id: chunk-0213
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Gyros not calibrated

Gyro calibration normally run at startup failed

Reboot autopilot and hold vehicle still until gyro calibration completes

Gyros not healthy

At least one gyro is not providing data

Reboot autopilot. If failure continues replace autopilot

Hardware safety switch

Hardware safety switch has not been pushed

Push safety switch (normally on top of GPS) or disable by setting
BRD_SAFETY_DEFLT
to zero and reboot autopilot

heater temp low (x < 45)

Board heater temp is below BRD_HEAT_TARG

Wait for board to heat up. Target temperature can be adjust using
BRD_HEAT_TARG

In OSD menu

OSD is being configured

Complete OSD configuration. Check
OSD configuration

Internal errors 0x%x l:%u %s

An internal error has occurred

Reboot the autopilot. Report error to the development team

Invalid FENCE_ALT_MAX value

FENCE_ALT_MAX must be positive

Increase
FENCE_ALT_MAX

Invalid FENCE_ALT_MIN value

FENCE_ALT_MIN must be higher than -100

Increase
FENCE_ALT_MIN

Invalid FENCE_MARGIN value

FENCE_MARGIN must be positive

Increase
FENCE_MARGIN

Invalid FENCE_RADIUS value

FENCE_RADIUS must be positive

Increase
FENCE_RADIUS

Logging failed

Logs could not be written. Maybe hardware failure

Reboot autopilot. Replace autopilot

Logging not started

Logs could not be written. Maybe hardware failure

Reboot autopilot. Replace autopilot

Main loop slow (xHz < 400Hz)

Autopilot’s CPU is overloaded

Wait to see if the error is temporary. Disable features or replace with a higher powered autopilot.

--- chunk_id: chunk-0213
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 498
content_hash: ac43999534aafbcf
prev_chunk_id: chunk-0212
next_chunk_id: chunk-0214
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Replace autopilot

Main loop slow (xHz < 400Hz)

Autopilot’s CPU is overloaded

Wait to see if the error is temporary. Disable features or replace with a higher powered autopilot. Reduce
SCHED_LOOP_RATE

Margin is less than inclusion circle radius

A circular fence has radius below FENCE_MARGIN

Increase the size of the circular fence involved or decrease
FENCE_MARGIN

memory low for auxiliary authorisation

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

Missing mission item: do land start

Auto mission needs a DO_LAND_START command

Add a DO_LAND_START command to the mission or adjust the
ARMING_MIS_ITEMS
parameter

Missing mission item: land

Auto mission needs a LAND command

Add a LAND command to the mission or adjust the
ARMING_MIS_ITEMS
parameter

Missing mission item: RTL

Auto mission needs an RTL command

Add an RTL command to the mission or adjust the
ARMING_MIS_ITEMS
parameter

Missing mission item: takeoff

Auto mission needs a TAKEOFF command

Add a TAKEOFF command to the mission or adjust the
ARMING_MIS_ITEMS
parameter

Missing mission item: vtol land

Auto mission needs a VTOL_LAND command

Add a VTOL_LAND command to the mission or adjust the
ARMING_MIS_ITEMS
parameter

Missing mission item: vtol takeoff

Auto mission needs a VTOL_TAKEOFF command

Add a VTOL_TAKEOFF command to the mission or adjust the
ARMING_MIS_ITEMS
parameter

Mode channel and RCx_OPTION conflict

RC flight mode switch also used for an aux function

Change FLTMODE_CH (or MODE_CH for Rover) or RCx_OPTION to remove conflict

Mode requires mission

Attempting to arm in Auto mode but no mission

Arm in an other mode or create and upload an Auto mission

Motors Emergency Stopped

Motors emergency stopped

Release emergency stop. See
auxiliary functions

Mount: check TYPE

Mount (aka camera gimbal) misconfiguration

Check
MNT1_TYPE
is valid. Check
Gimbal configuration

Mount: not healthy

Mount is not communicating with autopilot

Check physical connection between autopilot and gimbal and check
Gimbal configuration

Multiple SERIAL ports configured for RC input

RC misconfiguration

see
Multiple Radio Control Receivers

No mission library present

Auto mission feature has been disabled

Custom build server
was probably used to produce the firmware without auto missions. Rebuild with auto missions enabled

No rally library present

Rally point feature has been disabled

Custom build server
was probably used to produce the firmware without rally point.

--- chunk_id: chunk-0214
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 320
content_hash: 44ec79c569c0fbb7
prev_chunk_id: chunk-0213
next_chunk_id: chunk-0215
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Check
Gimbal configuration

Mount: not healthy

Mount is not communicating with autopilot

Check physical connection between autopilot and gimbal and check
Gimbal configuration

Multiple SERIAL ports configured for RC input

RC misconfiguration

see
Multiple Radio Control Receivers

No mission library present

Auto mission feature has been disabled

Custom build server
was probably used to produce the firmware without auto missions. Rebuild with auto missions enabled

No rally library present

Rally point feature has been disabled

Custom build server
was probably used to produce the firmware without rally point. Rebuild with Rally points included

No SD card

SD card is corrupted or missing

Format or replace SD card

No sufficiently close rally point located

Rally points are further than RALLY_LIMIT_KM

Move
rally points
closer to vehicle’s current location or increase
RALLY_LIMIT_KM

OA requires reboot

Object avoidance config change requires reboot

Reboot autopilot. See
Object Avoidance configuration

OpenDroneID: ARM_STATUS not available

OpenDroneID misconfiguration

see
Remote ID configuration

OpenDroneID: operator location must be set

Operator location is not available

see
Remote ID configuration

OpenDroneID: SYSTEM not available

OpenDroneID misconfiguration

see
Remote ID configuration

OpenDroneID: UA_TYPE required in BasicID

OpenDroneID misconfiguration

see
Remote ID configuration

OSD_TYPE2 not compatible with first OSD

OSD1 and OSD2 configurations are incompatible

Disable 2nd OSD (set
OSD_TYPE2
to zero) or check
OSD configuration

Param storage failed

Eeprom hardware failure

Check power supply or replace autopilot

parameter storage full

Eeprom storage full

Save params. Reset to defaults. Reload saved parameters.

--- chunk_id: chunk-0215
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: ed08f6b481b365e4
prev_chunk_id: chunk-0214
next_chunk_id: chunk-0216
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Reset to defaults. Reload saved parameters. PiccoloCAN: Servo x not detected

PiccoloCAN misconfiguration or servo issue

Check
Currawong Velocity ESC setup instructions

Pin x disabled (ISR flood)

Sensor connected to GPIO pin is rapidly changing

Check sensor attached to specified pin

Pitch (RCx) is not neutral

RC transmitter’s pitch stick is not centered

Move RC pitch stick to center or repeat
radio calibration

Pitch radio max too low

RC pitch channel max below 1700

Repeat the
radio calibration
procedure or increase
RC2_MAX
above 1700

Pitch radio min too high

RC pitch channel min above 1300

Repeat the
radio calibration
procedure or reduce
RC2_MIN
below 1300

PRXx: No Data

Proximity sensor is not providing data

Check proximity sensor physical connection and
configuration

PRXx: Not Connected

Proximity sensor is not providing data

Check proximity sensor physical connection and
configuration

Radio failsafe on

RC failsafe has triggered

Turn on RC transmitter or check RC failsafe configuration

Rangefinder x: Not Connected

Rangefinder is not providing data

Check rangefinder’s physical connection to autopilot and
configuration
. Also check that the rangefinder is actually included in the firmware, many are not and require addition via the
custom firmware server

RC calibrating

RC calibration is in progress

Complete the
radio calibration
procedure

RC not calibrated

RC calibration has not been done

Complete the
radio calibration
. RC3_MIN
and
RC3_MAX
must have been changed from their default values (1100 and 1900), and for channels 1 to 4, MIN value must be 1300 or less, and MAX value 1700 or more. RC not found

RC failsafe enabled but no RC signal

Turn on RC transmitter or check RC transmitters connection to autopilot. If operating with only a GCS, see
Operation Using Only a Ground Control Station (GCS)

RCx_MAX is less than RCx_TRIM

RC misconfiguration

Adjust RCx_TRIM to be lower than RCx_MAX or repeat
radio calibration

RCx_MIN is greater than RCx_TRIM

RC misconfiguration

Adjust RCx_TRIM to be higher than RCx_MIN or repeat
radio calibration

RELAYx_PIN=y invalid

Relay misconfigured

RELAYx_PIN is set to an invalid value. Check
Relay setup instructions

RELAYx_PIN=y, set SERVx_FUNCTION=-1

Relay misconfigured

Set SERVOx_FUNCTION to -1

RNGFNDx_PIN not set

Rangefinder misconfigured

Set RNGFNDx_PIN to a non-zero value. See
rangefinder configuration

RNGFNDx_PIN=y invalid

Rangefinder misconfigured

RNGFNDx_PIN is set to an invalid value.

--- chunk_id: chunk-0216
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: a17bba10d82954ee
prev_chunk_id: chunk-0215
next_chunk_id: chunk-0217
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Check
Relay setup instructions

RELAYx_PIN=y, set SERVx_FUNCTION=-1

Relay misconfigured

Set SERVOx_FUNCTION to -1

RNGFNDx_PIN not set

Rangefinder misconfigured

Set RNGFNDx_PIN to a non-zero value. See
rangefinder configuration

RNGFNDx_PIN=y invalid

Rangefinder misconfigured

RNGFNDx_PIN is set to an invalid value. Check
rangefinder configuration

RNGFNDx_PIN=y, set SERVOx_FUNCTION=-1

Rangefinder misconfigured

Set SERVOx_FUNCTION to -1

Roll (RCx) is not neutral

RC transmitter’s roll stick is not centered

Move RC roll stick to center or repeat
radio calibration

Roll radio max too low

RC roll channel max below 1700

Repeat the
radio calibration
procedure or increase
RC1_MAX
above 1700

Roll radio min too high

RC roll channel min above 1300

Repeat the
radio calibration
procedure or reduce
RC1_MIN
below 1300

RPMx_PIN not set

RPM sensor misconfigured

Check RPMx_PIN value. Check
RPM setup instructions

RPMx_PIN=y invalid

RPM sensor misconfigured

RPMx_PIN is set to an invalid value. Check
RPM setup instructions

RPMx_PIN=y, set SERVOx_FUNCTION=-1

RPM sensor misconfigured

Set SERVOz_FUNCTION to -1

Same Node Id x set for multiple GPS

DroneCan GPS configuration error

Check
GPS1_CAN_NODEID
and
GPS2_CAN_NODEID
are different. Set one to zero and reboot autopilot

Same rfnd on different CAN ports

Two rangefinders appearing on different CAN ports

Check USD1, TOFSensP, NanoRadar or Benewake setup instructions

Scripting: loaded CRC incorrect want: x

Script has incorrect CRC

Replace Lua script with expected version

Scripting: running CRC incorrect want: x

Script has incorrect CRC

Replace Lua script with expected version

Scripting: xxx failed to start

A Lua script failed to start

Autopilot out of memory or Lua script misconfiguration. See
Lua scripts

Scripting: xxx out of memory

A Lua script ran out of memory

Increase
SCR_HEAP_SIZE
or check
Lua script configuration

Servo voltage to low (Xv < 4.3v)

Servo rail voltage below 4.3V

Check power supply to rear servo rail

SERVOx_FUNCTION=y on disabled channel

PWM output misconfigured

SERVOx_FUNCTION is set for a servo output that has been disabled.

--- chunk_id: chunk-0217
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 416
content_hash: c69b0dd9076faa96
prev_chunk_id: chunk-0216
next_chunk_id: chunk-0218
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Set one to zero and reboot autopilot

Same rfnd on different CAN ports

Two rangefinders appearing on different CAN ports

Check USD1, TOFSensP, NanoRadar or Benewake setup instructions

Scripting: loaded CRC incorrect want: x

Script has incorrect CRC

Replace Lua script with expected version

Scripting: running CRC incorrect want: x

Script has incorrect CRC

Replace Lua script with expected version

Scripting: xxx failed to start

A Lua script failed to start

Autopilot out of memory or Lua script misconfiguration. See
Lua scripts

Scripting: xxx out of memory

A Lua script ran out of memory

Increase
SCR_HEAP_SIZE
or check
Lua script configuration

Servo voltage to low (Xv < 4.3v)

Servo rail voltage below 4.3V

Check power supply to rear servo rail

SERVOx_FUNCTION=y on disabled channel

PWM output misconfigured

SERVOx_FUNCTION is set for a servo output that has been disabled. See
BLHeli setup

SERVOx_MAX is less than SERVOx_TRIM

PWM output misconfigured

Set SERVOx_TRIM to be lower than SERVOx_MAX

SERVOx_MIN is greater than SERVOx_TRIM

PWM output misconfigured

Set SERVOx_TRIM to be higher than SERVOx_MIN

System not Initialized

System still booting up

Wait, if not resolved shortly there may be a sensor problem not caught by other diagnostics

temperature cal running

Temperature calibration is running

Wait until
temp calibration
completes or reboot autopilot

terrain data expired, possible errors

Old terrain data that might have errors

Update terrain data on SD card

terrain disabled

Auto mission uses terrain but terrain disabled

Enable the terrain database (set
TERRAIN_ENABLE
= 1) or remove auto mission items that use terrain altitudes. For Copters also check RTL_ALT_TYPE. Terrain out of memory

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

terrain required but disabled

Auto mission uses terrain but not in firmware

Use custom build server and include the terrain database or remove auto mission items that use terrain altitudes. For Copters also check RTL_ALT_TYPE.

--- chunk_id: chunk-0218
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: ce1a0e54bde688b9
prev_chunk_id: chunk-0217
next_chunk_id: chunk-0219
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

Terrain out of memory

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

terrain required but disabled

Auto mission uses terrain but not in firmware

Use custom build server and include the terrain database or remove auto mission items that use terrain altitudes. For Copters also check RTL_ALT_TYPE. Throttle (RCx) is not neutral

RC transmitter’s throttle stick is too high

Lower throttle stick or repeat
radio calibration

Throttle radio max too low

RC throttle channel max below 1700

Repeat the
radio calibration
procedure or increase
RC2_MAX
above 1700

Throttle radio min too high

RC throttle channel min above 1300

Repeat the
radio calibration
procedure or reduce
RC1_MIN
below 1300

Too many auxiliary authorisers

More than 3 external systems controlling arming

Check external authorisation system

vehicle outside fence

Vehicle is outside the fence

Move vehicle within the fence

VisOdom: not healthy

VisualOdometry sensor is not providing data

Check visual odometry physical connection and
configuration

VisOdom: out of memory

Autopilot has run out of memory

Disable features or replace with a higher powered autopilot

VTOL Fwd Throttle iz not zero

RC transmitter’s VTOL Fwd throttle stick is high

Lower VTOL Fwd throttle stick or repeat
radio calibration

waiting for terrain data

Waiting for GCS to provide required terrain data

Wait or move to location with better GPS reception;check
TERRAIN_OPTIONS
is correctly set. Yaw (RCx) is not neutral

RC transmitter’s yaw stick is not centered

Move RC yaw stick to center or repeat
radio calibration

Yaw radio max too low

RC yaw channel max below 1700

Repeat the
radio calibration
procedure or increase
RC2_MAX
above 1700

Yaw radio min too high

RC yaw channel min above 1300

Repeat the
radio calibration
procedure or reduce
RC1_MIN
below 1300

Pre-Arm Failure Messages (Plane Only)
¶
Message

Cause

Solution

ADSB threat detected

ADSB failsafe. Manned vehicles nearby

See
ADSB configuration

AHRS not healthy

AHRS/EKF is not yet ready

Wait. Reboot autopilot. AIRSPEED_MIN too low x<5 m/s

Parameter set too low, under 5m/s

Raise to at least 20% above stall speed

Bad parameter: ATC_ANG_PIT_P must be > 0

Attitude controller misconfiguration

Increase specified parameter value to be above zero. See
Tuning Process Instructions

Bad parameter: PSC_POSXY_P must be > 0

Position controller misconfiguration

Increase specified parameter value to be above zero.

--- chunk_id: chunk-0219
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: 427790acda8dfe40
prev_chunk_id: chunk-0218
next_chunk_id: chunk-0220
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

AIRSPEED_MIN too low x<5 m/s

Parameter set too low, under 5m/s

Raise to at least 20% above stall speed

Bad parameter: ATC_ANG_PIT_P must be > 0

Attitude controller misconfiguration

Increase specified parameter value to be above zero. See
Tuning Process Instructions

Bad parameter: PSC_POSXY_P must be > 0

Position controller misconfiguration

Increase specified parameter value to be above zero. See
Tuning Process Instructions

Check Q_ANGLE_MAX

Set above 80 degrees

Reduce
Q_A_ANGLE_MAX
below 80; 30 degrees is typical

In landing sequence

Trying to arm while still in landing sequence

Reset mission;change to mission item not in a landing sequence

Invalid THR_FS_VALUE for reversed throttle input

THR_FS_VALUE pwm is not ABOVE the max throttle

Set
THR_FS_VALUE
above throttle maximum pwm

ROLL_LIMIT_DEG too small x

Parameter set under 3 degrees

Increase, 45 deg recommended minimum for adequate control

PTCH_LIM_MAX_DEG too small x

Parameter set under 3 degrees

Increase, 45 deg recommended minimum for adequate control

PTCH_LIM_MIN_DEG too large x

Parameter set over 3 degrees

Increase, 45 deg recommended minimum for adequate control

Mode not armable

Cannot arm from this mode

Change Mode

Mode not QMODE

Q_OPTION set to prevent arming except in QMODE/AUTO

Change Mode or reset
Q_OPTIONS
bit 18

Motors: Check frame class and type

Unknown or misconfigured frame class or type

Enter valid frame class and/or type

Motors: Check MOT_PWM_MIN and MOT_PWM_MAX

MOT_PWM_MIN or MOT_PWM_MAX misconfigured

Set
MOT_PWM_MIN
= 1000 and
MOT_PWM_MAX
= 2000 and repeat the
ESC calibration

Motors: MOT_SPIN_ARM > MOT_SPIN_MIN

MOT_SPIN_ARM is too high or MOT_SPIN_MIN is too low

Reducse
MOT_SPIN_ARM
to below
MOT_SPIN_MIN
. See
Setting motor range

Motors: MOT_SPIN_MIN too high x > 0.3

MOT_SPIN_MIN parameter value is too high

Reduce
MOT_SPIN_MIN
to below 0.3. See
Setting motor range

Motors: no SERVOx_FUNCTION set to MotorX

At least one motor output has not been configured

Check SERVOx_FUNCTION values for “Motor1”, “Motor2”, etc.

--- chunk_id: chunk-0220
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 340
content_hash: 70897e1e6a66341e
prev_chunk_id: chunk-0219
next_chunk_id: chunk-0221
section_heading: Recognising which Pre-Arm Check has failed using the GCS
document_type: technical_reference

See
Setting motor range

Motors: MOT_SPIN_MIN too high x > 0.3

MOT_SPIN_MIN parameter value is too high

Reduce
MOT_SPIN_MIN
to below 0.3. See
Setting motor range

Motors: no SERVOx_FUNCTION set to MotorX

At least one motor output has not been configured

Check SERVOx_FUNCTION values for “Motor1”, “Motor2”, etc. Check
ESC and motor configuration

Q_ASSIST_SPEED is not set

Q_ASSIST_SPEED has not been set

Set
Q_ASSIST_SPEED
, See
Assisted Fixed-Wing Flight

Quadplane enabled but not running

Q_ENABLE is set, but QuadPlane code has not started

Reboot

quadplane needs SCHED_LOOP_RATE >= 100

Quadplane needs faster loop times for performance

Increase
SCHED_LOOP_RATE
; 300 is typical

set Q_FWD_THR_USE to 0

Trying to use FWD Throttle on Tailsitter

Set
Q_FWD_THR_USE
= 0 on tailsitters

set TAILSIT_ENABLE 0 or TILT_ENABLE 0

Cannot have simultaneous tiltrotor and tailsitter

Pick one to match your vehicle configuration and reboot

tailsitter setup not complete, reboot

Enabled tiltrotor but have not rebooted yet

Reboot

tiltrotor setup not complete, reboot

Enabled tailsitter but have not rebooted yet

Reboot

Throttle trim not near center stick %x

RC trim for centered throttle stick use incorrect

Set throttle channels RC trim to center position (idle) if
FLIGHT_OPTIONS
bit 10 is set. unset one of RTL_AUTOLAND or Q_RTL_MODE

Have both parameters set

Only use one or the other parameter to set RTL behavior in VTOLs

Waiting for RC

RC failsafe enabled but no RC signal

Turn on RC transmitter or check RC transmitters connection to autopilot. If operating with only a GCS, see
Operation Using Only a Ground Control Station (GCS)

--- chunk_id: chunk-0221
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: 678612e4bf5ea5a0
prev_chunk_id: chunk-0220
next_chunk_id: chunk-0222
section_heading: Other Failure messages
document_type: technical_reference

## Other Failure messages
### ¶
### Failsafes:
### ¶
Any failsafe (RC, Battery, GCS,etc.) will display a message and prevent arming. ### Barometer failures:
### ¶
Baro not healthy
: the barometer sensor is reporting that it is
unhealthy which is normally a sign of a hardware failure. Alt disparity
: the barometer altitude disagrees with the inertial
navigation (i.e. Baro + Accelerometer) altitude estimate by more than 1
meters. This message is normally short-lived and can occur when the
autopilot is first plugged in or if it receives a hard jolt
(i.e. dropped suddenly). If it does not clear the
accelerometers may need to be calibrated
or there may
be a barometer hardware issue. ### Compass failures:
### ¶
Compass X not healthy
: the compass X sensor is reporting that it is
unhealthy, which is a sign of a possible hardware failure. Compass not calibrated
: the
compass(es) has not been calibrated
. the
COMPASS_OFS_X,
_Y,
_Z
parameters are zero or the number or type of
compasses connected has been changed since the last compass calibration
was performed. Compass offsets too high
: the primary compass’s offsets length
(i.e. sqrt(x^2+y^2+z^2)) are larger than 500. This can be caused by
metal objects being placed too close to the compass. If only an
internal compass is being used (not recommended), it may simply be the
metal in the board that is causing the large offsets and this may not
actually be a problem in which case you may wish to disable the compass
check. Check mag field
: This can result from failing two different checks. First, the sensed magnetic field in the area is 35%
higher or  lower than the expected value. The expected length is 530 so
it’s > 874 or < 185. Also, besides this rough check, when the vehicle’s position has been obtained (GPS lock), another check against the field strength predicted using the internal World Magnetic Field database is done with much tighter limits. If you are failing this, either the
compass calibration
has not calculated good offsets and calibration should be repeated, or your vehicle is near a large metallic or magnetic disturbance and will need to be relocated. Compasses inconsistent
: the internal and external compasses are
pointing in different directions (off by >45 degrees).

--- chunk_id: chunk-0222
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: c782f8b244f9c022
prev_chunk_id: chunk-0221
next_chunk_id: chunk-0223
section_heading: Other Failure messages
document_type: technical_reference

If you are failing this, either the
compass calibration
has not calculated good offsets and calibration should be repeated, or your vehicle is near a large metallic or magnetic disturbance and will need to be relocated. Compasses inconsistent
: the internal and external compasses are
pointing in different directions (off by >45 degrees). This is normally
caused by the external compasses orientation (i.e. COMPASS_ORIENT
parameter) being set incorrectly. ### GPS related failures:
### ¶
GPS Glitch
: the
GPS is glitching
and the vehicle
is in a flight mode that requires GPS (i.e. Loiter, PosHold, etc) and/or
the
cylindrical fence
is enabled. Need 3D Fix
: the GPS does not have a 3D fix and the vehicle is in a
flight mode that requires the GPS and/or the
cylindrical fence
is enabled. Bad Velocity
: the vehicle’s velocity (according to inertial
navigation system) is above 50cm/s. Issues that could lead to this
include the vehicle actually moving or being dropped, bad accelerometer
calibration, GPS updating at below the expected 5hz. High GPS HDOP
: the GPS’s HDOP value (a measure of the position
accuracy) is above 2.0 and the vehicle is in a flight mode that requires
GPS and/or the
cylindrical fence
is enabled. This may be resolved by simply waiting a few minutes, moving to a
location with a better view of the sky or checking sources of GPS
interference (i.e. FPV equipment) are moved further from the GPS. Alternatively the check can be relaxed by increasing the
GPS_HDOP_GOOD
parameter to 2.2 or 2.5. Worst case the pilot may disable the fence and
take-off in a mode that does not require the GPS (i.e. Stabilize,
AltHold) and switch into Loiter after arming but this is not
recommended. Note: the GPS HDOP can be readily viewed through the Mission Planner’s
Quick tab as shown below. ### INS checks (i.e. Accelerometer and Gyro checks):
### ¶
INS not calibrated
: some or all of the accelerometer’s offsets are
zero. The
accelerometers need to be calibrated
. Accels not healthy
: one of the accelerometers is reporting it is not
healthy which could be a hardware issue. This can also occur
immediately after a firmware update before the board has been restarted. Accels inconsistent
: the accelerometers are reporting accelerations
which are different by at least 1m/s/s.

--- chunk_id: chunk-0223
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: bfbecd9de3092f5e
prev_chunk_id: chunk-0222
next_chunk_id: chunk-0224
section_heading: Other Failure messages
document_type: technical_reference

This can also occur
immediately after a firmware update before the board has been restarted. Accels inconsistent
: the accelerometers are reporting accelerations
which are different by at least 1m/s/s. The
accelerometers need to be re-calibrated
or there is a
hardware issue. Gyros not healthy
: one of the gyroscopes is reporting it is
unhealthy which is likely a hardware issue. This can also occur
immediately after a firmware update before the board has been restarted. Gyro cal failed
: the gyro calibration failed to capture offsets. This is most often caused by the vehicle being moved during the gyro
calibration (when red and blue lights are flashing) in which case
unplugging the battery and plugging it in again while being careful not
to jostle the vehicle will likely resolve the issue. Sensors hardware
failures (i.e. spikes) can also cause this failure. Gyros inconsistent
: two gyroscopes are reporting vehicle rotation
rates that differ by more than 20deg/sec. This is likely a hardware
failure or caused by a bad gyro calibration. ### Board Voltage checks:
### ¶
Check Board Voltage
: the board’s internal voltage is below 4.3 Volts
or above 5.8 Volts. If powered through a USB cable (i.e. while on the bench) this can be
caused by the desktop computer being unable to provide sufficient
current to the autopilot - try replacing the USB cable. If powered from a battery this is a serious problem and the power system
(i.e. Power Module, battery, etc) should be carefully checked before
flying. ### Parameter checks:
### ¶
Ch7&Ch8 Opt cannot be same
:
Auxiliary Function Switches
are set to the same option which is not permitted because it could lead to confusion. Check FS_THR_VALUE
: the
radio failsafe pwm value
has been set too close to the throttle channels (i.e. ch3) minimum. Check ANGLE_MAX
: the
ATC_ANGLE_MAX
parameter which controls the
vehicle’s maximum lean angle has been set below 10 degrees (i.e. 10)
or above 80 degrees (i.e. 80). ACRO_BAL_ROLL/PITCH
: the
ACRO_BAL_ROLL
parameter is higher than
the Stabilize Roll P and/or
ACRO_BAL_PITCH
parameter is higher than
the Stabilize Pitch P value. This could lead to the pilot being unable
to control the lean angle in ACRO mode because the
Acro Trainer stabilization
would overpower the pilot’s
input.

--- chunk_id: chunk-0224
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 466
content_hash: 2af83bcdf8d7ee0e
prev_chunk_id: chunk-0223
next_chunk_id: chunk-0225
section_heading: Other Failure messages
document_type: technical_reference

ACRO_BAL_ROLL/PITCH
: the
ACRO_BAL_ROLL
parameter is higher than
the Stabilize Roll P and/or
ACRO_BAL_PITCH
parameter is higher than
the Stabilize Pitch P value. This could lead to the pilot being unable
to control the lean angle in ACRO mode because the
Acro Trainer stabilization
would overpower the pilot’s
input. ### Battery/Power Monitor:
### ¶
If a power monitor voltage is below its failsafe low or critical voltages or failsafe remaining capacity low or critical set points, this check will fail and indicate which set point it is below. It will also fail if these set points are inverted, ie critical point is higher than low point. See
Battery Failsafe
for Copter,
Plane Failsafe Function
for Plane, or
Failsafes
for Rover for more information on these. In addition, minimum arming voltage and remaining capacity parameters for each battery/power monitor can be set, for example
BATT_ARM_VOLT
and
BATT_ARM_MAH
for the first battery, to provide a check that the battery is not only above failsafe levels, but also has enough capacity for operation. ### Airspeed:
### ¶
If an airspeed sensor is configured, and it is not providing a reading or failed to calibrate, this check will fail. Airspeed not healthy


### Logging:
### ¶
Logging failed
: Logging pre-armed was enabled but failed to write to the log. No SD Card
: Logging is enabled, but no SD card is detected. ### Safety Switch:
### ¶
Hardware safety switch
: Hardware safety switch has not been pushed. ### System:
### ¶
Param storage failed
: A check of reading the parameter storage area failed. Internal errors (0xx)
: An internal error has occurred. Report to ArduPilot development team
here

KDECAN Failed
: KDECAN system failure. DroneCAN Failed
: DroneCAN system failure. ### Mission:
### ¶
See
ARMING_MIS_ITEMS

No mission library present
: Mission checking is enabled, but no mission is loaded. No rally library present
: Rally point checking is enabled, but no rally points loaded. Missing mission item: xxxx
: A required mission items is missing. ### Rangefinder:
### ¶
IF a rangefinder has been configured, a reporting error has occurred.

--- chunk_id: chunk-0225
source_document: common-prearm-safety-checks.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 202
content_hash: b1966cd0037d206f
prev_chunk_id: chunk-0224
next_chunk_id: chunk-0226
section_heading: Disabling the Pre-arm Safety Check
document_type: technical_reference

## Disabling the Pre-arm Safety Check
### ¶
Warning

Disabling pre-arm safety checks is not recommended. The cause of the pre-arm failure should be corrected before operation of the vehicle if at all possible. If you are confident that the pre-arm check failure is not a real problem, it is possible to skip a failing check. Arming checks can be individually skipped by setting the
ARMING_SKIPCHK
parameter to something other than 0. For example, setting to 4 skips the checks that the GPS has lock. In extremely unusual circumstances, setting the parameter to -1 can be used to skip all current and future pre-arm checks (though mandatory checks still remain). Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0226
source_document: common-radio-control-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 277
content_hash: 7b5b186d14a0cd52
prev_chunk_id: chunk-0225
next_chunk_id: chunk-0227
document_type: technical_reference

Radio Control Calibration — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Overview
Accelerometer Calibration
Compass Calibration
Flight Modes
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
- Radio Control Calibration
Edit on GitHub

# Radio Control Calibration
# ¶
This article shows how to perform radio control calibration using Mission Planner

--- chunk_id: chunk-0227
source_document: common-radio-control-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 489
content_hash: 895cfa98da77a96f
prev_chunk_id: chunk-0226
next_chunk_id: chunk-0228
section_heading: Overview
document_type: technical_reference

## Overview
### ¶
RC transmitters allow the pilot to set the flight mode, control the vehicle’s movement and orientation and also turn on/off auxiliary functions (i.e. raising and lowering landing gear, etc). RC Calibration involves capturing each RC input channel’s minimum, maximum and “trim” values so that ArduPilot can correctly interpret the input. ### Check the Transmitter’s Setup
### ¶
Ensure the battery is disconnected (this is important because it is possible to accidentally arm the vehicle during the RC calibration process)

Ensure the RC receiver is connected to the autopilot

Turn on your RC transmitter and if it has “trim tabs” ensure they are in the middle

Connect the autopilot to the PC using a USB cable

On the Mission Planner press the “Connect” button and open Mission Planner’s
INITIAL SETUP | Mandatory Hardware | Radio Calibration
screen

Some green bars should appear showing the ArduPilot is receiving input from the Transmitter/Receiver. If no bars appear check the receiver’s LED:

No lights may indicate that it is incorrectly wired to the autopilot. Look for connectors that may have been inserted upside down

A Red or flashing LED may indicate that your RC transmitter/receiver need be bound. See the manual that came with your RC equipment for instructions


Check the channel mapping in the transmitter (ie. check which inputs channels are controlled by the transmitter’s sticks, switches and knobs) by moving the sticks, knobs and switches and observing which (if any) green bars move. If this is the first time the transmitter is being used with ArduPilot it is likely that the transmitter’s channel mapping will need to be changed and normally this is done on the transmitter itself using its built-in configuration menu

Determine if your transmitter is Mode1 or Mode2 (see below)

Roll stick should control channel 1

Pitch stick should control channel 2

Throttle stick should control channel 3

Yaw stick should control channel 4

A 3 or 6 position switch (to control the flight mode) should be setup to control Channel 5 (default,if using Copter) or Channel 8 (default, if using Rover or Plane). This channel can be moved by setting the
FLTMODE_CH
parameter in Plane or Copter, or
MODE_CH
in Rover.

--- chunk_id: chunk-0228
source_document: common-radio-control-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 1c9752e2b97afe2d
prev_chunk_id: chunk-0227
next_chunk_id: chunk-0229
section_heading: Overview
document_type: technical_reference

If this is the first time the transmitter is being used with ArduPilot it is likely that the transmitter’s channel mapping will need to be changed and normally this is done on the transmitter itself using its built-in configuration menu

Determine if your transmitter is Mode1 or Mode2 (see below)

Roll stick should control channel 1

Pitch stick should control channel 2

Throttle stick should control channel 3

Yaw stick should control channel 4

A 3 or 6 position switch (to control the flight mode) should be setup to control Channel 5 (default,if using Copter) or Channel 8 (default, if using Rover or Plane). This channel can be moved by setting the
FLTMODE_CH
parameter in Plane or Copter, or
MODE_CH
in Rover. On Copter, a tuning knob should control Channel 6

On Copter and Rover, any remaining two or three position switches can be setup to control auxiliary functions by mapping them to channels 7 to 12

Note that for reversing motor controls on Plane and Rover, the throttle range is range is normally divided into two parts:
- Reverse throttle control: From
RCx_TRIM
(typically 1500us) to
RCx_MIN
, where x is usually “3” for normal RC throttle input channel. This corresponds to motor outputs from
SERVOx_TRIM
to
SERVOx_MIN
, where “x” is the output controlling the motor, and assumes the
SERVOx_REVERSE
bit is not set. - Forward throttle control: From
RCx_TRIM
(typically 1500us) to
RCx_MAX
, where x is usually “3” for normal RC throttle input channel. This corresponds to motor outputs from
SERVOx_TRIM
to
SERVOx_MAX
, where “x” is the output controlling the motor, and assumes the
SERVOx_REVERSE
bit is not set. Using a spring-loaded stick may be most convenient, as it naturally returns to the neutral (stopped) position at
RCx_TRIM
. Note

For Plane, it is possible to use an AUX RC switch to provide easie reverse thrust control using the entire throttle stick range on non-sprung throttle sticks. Also, many set up a switch controlled mix in their RC transmitter to map throttle low stick position to output
RCx_TRIM
after calibration and either output RC as the stick is raised for reverse or forward operation depending on the TX switch position, giving full throttle stick range to forward or reverse operation.

--- chunk_id: chunk-0229
source_document: common-radio-control-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: b19099824fe749f8
prev_chunk_id: chunk-0228
next_chunk_id: chunk-0230
section_heading: Overview
document_type: technical_reference

Note

For Plane, it is possible to use an AUX RC switch to provide easie reverse thrust control using the entire throttle stick range on non-sprung throttle sticks. Also, many set up a switch controlled mix in their RC transmitter to map throttle low stick position to output
RCx_TRIM
after calibration and either output RC as the stick is raised for reverse or forward operation depending on the TX switch position, giving full throttle stick range to forward or reverse operation. Move the transmitter’s roll, pitch, throttle, and yaw sticks and ensure the green bars move in the correct direction:

For roll, throttle and yaw channels, the green bars should move in the same direction as the transmitter’s physical sticks. For pitch, the green bar should move in the
opposite
direction to the transmitter’s physical stick. This is not the default for many transmitters. If one of the green bars moves in the incorrect direction, reverse the channel in the transmitter itself so that logging and outputs etc. are consistent. You may instead reverse the channel in ArduPilot by checking the “Reversed” checkbox (if shown), or directly changing the
RCx_REVERSED
parameter (where “x” is the input channel from 1 to 4). ### Calibration
### ¶
Open Mission Planner’s
INITIAL SETUP | Mandatory Hardware | Radio Calibration
screen

Click on the green “Calibrate Radio” button on the bottom right

Press “OK” when prompted to check the radio control equipment is on, battery is not connected, and propellers are not attached


Move the transmitter’s control sticks, knobs and switches to their limits. Red lines will appear across the calibration bars to show minimum and maximum values seen so far


Select
Click when Done

A window will appear with the prompt, “Ensure all your sticks are centered and throttle is down and click ok to continue”. Move the throttle to zero and press “OK”. Mission Planner will show a summary of the calibration data. Normal values are around 1100 for minimums and 1900 for maximums. If when testing your throttle stick you notice that the motor turns in a single direction, check in the full parameters list that
RCx_TRIM
for the throttle channel is set to the motor controller’s neutral value (usually about 1500 us).

--- chunk_id: chunk-0230
source_document: common-radio-control-calibration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 444
content_hash: f9699e448e82eff2
prev_chunk_id: chunk-0229
next_chunk_id: chunk-0231
section_heading: Overview
document_type: technical_reference

Normal values are around 1100 for minimums and 1900 for maximums. If when testing your throttle stick you notice that the motor turns in a single direction, check in the full parameters list that
RCx_TRIM
for the throttle channel is set to the motor controller’s neutral value (usually about 1500 us). This should be detected and set automatically during calibration if you followed the procedure without forgetting to
center
your throttle in the last calibration step instead of the normal
low
position. ### Mode1 and Mode2 Transmitters
### ¶
There are two main transmitter configurations:

Mode 1
: left stick controls pitch and yaw, the right stick will
control throttle and roll. Mode 2
: left stick controls throttle and yaw; the right stick will
control pitch and roll. There are two alternative configurations:

Mode 3
: left stick controls pitch and roll, the right stick will
control throttle and yaw. Mode 4
: left stick controls throttle and roll; the right stick will
control pitch and yaw. Mode 3 is the opposite of Mode 2 and Mode 4 is the opposite of Mode 1, giving complete right handed/left handed user options. ### Channel mappings
### ¶
Plane default channel mappings are:

Channel 1
: Roll

Channel 2
: Pitch

Channel 3
: Throttle

Channel 4
: Yaw

Channel 8
(default): Flight modes. Mode selection can be mapped to any RC channel using the
FLTMODE_CH
parameter

Unused channels can be mapped to control additional peripherals. ### Further Reading
### ¶
Roll, pitch, throttle and yaw channel mappings can be changed using
RCMAP Input Channel Mapping

Flight mode switch setup to specify which vehicle modes are enabled by each switch position can be found on the
RC Transmitter Flight Mode Configuration
page






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0231
source_document: common-rc-transmitter-flight-mode-configuration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 344
content_hash: 51fbe89c021c93a3
prev_chunk_id: chunk-0230
next_chunk_id: chunk-0232
document_type: technical_reference

RC Transmitter Flight Mode Configuration — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
RC Transmitter Mode Setup
Flight modes configuration
Setting the flight mode channel
Transmitter configuration
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
- RC Transmitter Flight Mode Configuration
Edit on GitHub

# RC Transmitter Flight Mode Configuration
# ¶
This article shows how you can enable up to 6 autopilot control/flight modes to be set from your RC transmitter via the flight mode channel (
FLTMODE_CH
for plane/copter/sub,
MODE_CH
for rover). Flight mode changes can also be made via RC channels setup as
Auxiliary Functions
.

--- chunk_id: chunk-0232
source_document: common-rc-transmitter-flight-mode-configuration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 197
content_hash: bb97c008d8c516c8
prev_chunk_id: chunk-0231
next_chunk_id: chunk-0233
section_heading: Flight modes configuration
document_type: technical_reference

## Flight modes configuration
### ¶
The mapping between switch position and flight mode is set in the
Mission Planner Flight Mode
screen. Mission Planner: Flight Mode Screen(Plane)
¶

You can set up the flight modes available on the transmitter by doing
the following:

Turn on your RC transmitter

Connect the Pixhawk (or other autopilot) to the
Mission Planner

Go to the
Initial Setup | Mandatory Hardware | Flight Modes
screen

Note

As you move your transmitter’s flight mode switch the green
highlight bar will move to a different position. Use the drop-down on each line to select the flight mode for that
switch position. When finished press the
Save Modes
button. ### Setting the flight mode channel
### ¶
The flight mode channel is the input radio channel that ArduPilot
monitors for mode changes. On Plane this is configurable using the
FLTMODE_CH
parameter. DEfault is channel 8.

--- chunk_id: chunk-0233
source_document: common-rc-transmitter-flight-mode-configuration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: b1c050a20e054830
prev_chunk_id: chunk-0232
next_chunk_id: chunk-0234
section_heading: Transmitter configuration
document_type: technical_reference

## Transmitter configuration
### ¶
The transmitter must emit PWM signals in the correct range to allow us
to map a mode to a switch position. Note

Generally the range is between 1000 to 2000 us (1.0 to 2.0 ms). ms = millisecond

us = microsecond


The correct PWM ranges for selectable modes are shown alongside
each mode selection dropdown in the
Mission Planner Flight Mode
screen
(see
screenshot above
). If you want to just support three modes (using a three position switch)
then you would configure the transmitter to produce PWM pulse widths of
1165, 1425, and 1815 us for the respective switch positions. If you want to support 6 modes then the transmitter will need to emit
PWM widths of around 1165, 1295, 1425, 1555, 1685, and 1815
us. Typically this is achieved by configuring the transmitter
to mix a two position switch and a three position switch (giving 6 modes
in total). You can also do this with an analog dial if one is available,
but it’s hard to reliably turn a dial to just the right position for six
distinct settings. The sections below provide links showing how to configure transmitters
from different manufactures, and how to test (in Mission Planner) that
each switch setting is emitting the appropriate PWM signal. ### Test transmitter switch settings
### ¶
You can use the
Mission Planner Radio Calibration
screen to test the
PWM pulse widths for each mode setting. Simply toggle through the modes on your transmitter and confirm that the
PWM for the selected channel matches the required PWM values. The
screenshot below assumes that the flight mode channel is set to Radio 5. ### Tutorials for specific RC hardware
### ¶
Here are some user-contributed tutorials for doing this (or adding more
modes to RC units with just a two-position toggle) with various RC
systems:

Any OpenTX based transmitter:

Simply select two switches (one must be three position) and add these mixes on the appropriate flight mode channel used for your vehicle. The example below shows it for a plane using Channel 8 for flight mode (default) and using switch SB selecting three flight modes with SA switch up , and selecting an additional three flight modes via SB when SA is not in the up position.

--- chunk_id: chunk-0234
source_document: common-rc-transmitter-flight-mode-configuration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 469
content_hash: 11b1512498b96496
prev_chunk_id: chunk-0233
next_chunk_id: chunk-0235
section_heading: Transmitter configuration
document_type: technical_reference

### Tutorials for specific RC hardware
### ¶
Here are some user-contributed tutorials for doing this (or adding more
modes to RC units with just a two-position toggle) with various RC
systems:

Any OpenTX based transmitter:

Simply select two switches (one must be three position) and add these mixes on the appropriate flight mode channel used for your vehicle. The example below shows it for a plane using Channel 8 for flight mode (default) and using switch SB selecting three flight modes with SA switch up , and selecting an additional three flight modes via SB when SA is not in the up position. TX16 style transmitters with 6 position switch

Setup your flight mode channel using “6P’, the six position switch, as its source, but with a weighted curve to move each position to be centered in ArduPilot’s required PWM values for each mode selection as shown below:

JR XG8 DMSS

JR9303

JR X2720

FlySky FS-I6

Futaba T8FG

Futaba T8J

Futaba T7CP

Futaba T6EX

Futaba 9ZAP/ZHP

Futaba T10CAG

Futaba T14

Futaba T14SG

Futaba 9C Super

Graupner MX-16

Turnigy 9x
(or
an even easier way)
(Here!)
-
Turnigy 9x with ER9x firmware

Turnigy 9XR

Turnigy TGY-I6

Hitech Aurora 9

Spektrum DX8
(alternate method below)

Spektrum DX7s

Spektrum DX7 Version 6

Or
build your own six-position switch! ### Spektrum DX8 (alternate method)
### ¶
This section describes an alternative way to set 6 modes with the
Spektrum DX8. This method uses the Gear switch and the Flight mode
switch. All the other switches can be assigned as preferred. This method
also allows each mode to be set in the middle of each mode’s pulse width
range so small changes will not change modes. Use Mission Planner Flight
Modes setup to monitor the Current PWM for these adjustments. Setup the switches (required for the 6 modes)

Hold roller bar down, turn on DX8, scroll down to Switch Select,
Click roller bar. Set switches as follows:

Gear = Gear (Channel 5)

FMode = Inh  Not assigned to a channel – Used to mix with Gear Sw (Channel 5) for 6 modes

Others anyway you want.

--- chunk_id: chunk-0235
source_document: common-rc-transmitter-flight-mode-configuration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: 00997439cac70ef8
prev_chunk_id: chunk-0234
next_chunk_id: chunk-0236
section_heading: Transmitter configuration
document_type: technical_reference

Setup the switches (required for the 6 modes)

Hold roller bar down, turn on DX8, scroll down to Switch Select,
Click roller bar. Set switches as follows:

Gear = Gear (Channel 5)

FMode = Inh  Not assigned to a channel – Used to mix with Gear Sw (Channel 5) for 6 modes

Others anyway you want. One method is as follows:

Knob to aux1 = channel 6 for camera tilt / tuning

Mix = aux2 = channel 7 to save Way Point or RTL, auto trim or
other settings in APM configuration. Flap to aux3 = channel 8 for other uses

Click BACK until the normal screen appears, or turn off power,
then turn power back on. Set up the non-mixed servo setting for channel 5 (Gear channel
controlled by the Gear Switch)

This will be the values with no mixing - F Mode switch in the 0
position and sets the lowest pulse width to 1165 us (mode 1) and
highest to 1815 us (mode 6)

Click the roller bar, scroll down to Servo Setup, Select the Gear
channel, Select Sub Trim. Set sub trim to 0

Select Travel. Set travel (left, position 0) for 1165 us pulse  (~90%). Set travel (right, position 1 for 1815 us pulse (~74%). Set up Mix 1 to change the Gear Pulse width when F Mode is in
position 1

Click roller, scroll down to Mixing, click roller, scroll to first
line under Mix (has xxx > xxx, AIL > RUD, or some other mix
set),click roller, Select Mix 1, Click roller. Set Mix: Gear > Gear. Gear changes Gear depending on Switch F Mode
setting

Set Offset = 0, Trim = Inh. Set SW = FM 1

Set the F Mode switch on the transmitter to position 1. Set the Gear switch on the transmitter to position 0. Set top Rate for pulse width of 1290 us for mode 2  (~-35%)

(change = 400 us * -90% * -35% = 126 us. Result = 1165 us + 126
us = 1251 us = mode 2)

Set the Gear switch on the transmitter to position 1. Set bottom Rate for pulse width of 1685 us for mode 5  (~– 45%)

(change = 400 us * +73% *- 45% = -131 us.

--- chunk_id: chunk-0236
source_document: common-rc-transmitter-flight-mode-configuration.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 336
content_hash: 8d56e90af822827e
prev_chunk_id: chunk-0235
next_chunk_id: chunk-0237
section_heading: Transmitter configuration
document_type: technical_reference

Result = 1165 us + 126
us = 1251 us = mode 2)

Set the Gear switch on the transmitter to position 1. Set bottom Rate for pulse width of 1685 us for mode 5  (~– 45%)

(change = 400 us * +73% *- 45% = -131 us. Result = 1815 us - 131
us = 1684 us = mode 5)

Set up a mix 2 to change the Gear Pulse width when F Mode is in
position 2

Mix: Gear > Gear. Gear changes Gear depending on Switch F Mode
setting. Set Offset = 0, Trim = Inh

Set SW = FM2

Set the F Mode switch on the transmitter to position 2

Set the Gear switch on the transmitter to position 0. Rate top Rate for pulse width of 1425 us for mode 3  (~–72%)
(change = 400 us * –90% * – 72% = 259 us. Result = 1165 us +
259 us = 1424 us = mode 3)

Set the Gear switch on the transmitter to position 1. Set bottom Rate for pulse width of 1550 us for mode 4  (~–89%)
(change = 400 us * +73% * – 89% = -262 us. Result = 1815 us -
262 us = 1553 us = mode 4)






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0237
source_document: common-serial-options.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: 155297f053ec3b67
prev_chunk_id: chunk-0236
next_chunk_id: chunk-0238
document_type: technical_reference

Serial Port Configuration Options — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
EKF (Extended Kalman Filter)
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Logical Serial Port to Physical UART Assignment
SERIALx_PROTOCOL
SERIALx_OPTIONS Parameter
Bitmask Options
MAVLINK PROTOCOL OPTIONS
MAV_OPTIONS
Individual MAVLink Channel Options
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- Serial Port Configuration Options
Edit on GitHub

# Serial Port Configuration Options
# ¶
This page describes the configuration options for the serial ports. Currently, some of these options are supported only on specific autopilots.

--- chunk_id: chunk-0238
source_document: common-serial-options.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 232
content_hash: 15333d5e0012a03f
prev_chunk_id: chunk-0237
next_chunk_id: chunk-0239
section_heading: Logical Serial Port to Physical UART Assignment
document_type: technical_reference

## Logical Serial Port to Physical UART Assignment
### ¶
ArduPilot Serialx Port numbering is logical, rather than physical. Which UART or USART port is assigned to a Serial Port is determined by the autopilot’s hardware definition file. Serial Port 0 is always assigned to the USB port, but others can vary. Check its
description page

Note

more serial ports may be shown in the parameters than exist on a given controller. Check its
description page


By default (for most autopilots) the protocols/expected peripheral for each port is shown below:

Note

any supported protocol/peripheral can be used by any port by changing its
SERIALx_PROTOCOL
parameter


Serial 0

USB port, MAVLink2 protocol

Serial 1

Telemetry port 1, MAVLink1 protocol

Serial 2

Telemetry port 2, MAVLink1 protocol

Serial 3

GPS1 port

Serial 4

GPS2 port

Serial 5

USER port, disabled

Serial 6

USER port, disabled

Serial 7

USER port, disabled

Often cased autopilots will have the designation “TELEM1”, “GPS”, etc. marked on the case, otherwise, the autopilot
description page
should provide the mapping to SERIALx Port

--- chunk_id: chunk-0239
source_document: common-serial-options.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 376
content_hash: 463980cf18755b03
prev_chunk_id: chunk-0238
next_chunk_id: chunk-0240
section_heading: SERIALx_PROTOCOL
document_type: technical_reference

## SERIALx_PROTOCOL
### ¶
The serial ports support many different kinds of interfaces and peripheral. The
SERIALx_PROTOCOL
parameter determines what type of device/interface is expected. Value
Protocol
-1
Disabled
1
MAVLink1, see
Telemetry Setup

2
MAVLink2, see
Telemetry Setup

3
FrSky D, see
FrSky Telemetry

4
FrSky SPort, see
FrSky Telemetry

5
GPS, see
GPS
and
Devices

7
Alexmos Gimbal Serial, see
Alexmos Gimbal

8
SToRM32 Gimbal Serial, see
SToRM32 Gimbal

9
Rangefinder, see
Rangefinders

10
FrSky SPort Passthrough (OpenTX), see
FrSky Passthrough Telemetry

11
Lidar360, see
360 Lidars here

13
Beacon, see
Non-GPS Navigation

14
Volz Servo, see
Volz Servos

15
SBus Servo, see
SBus Servos

16
ESC Telemetry, see
blheli32-esc-telemetry

17
Devo Telemetry

18
OpticalFlow, see
Optical Flow Sensors

19
RobotisServo, see
Robotis Servos

20
NMEA Output, NEMA Output stream from GPS
21
WindVane, see
Wind Vane

22
SLCAN

23
RC Input, see
Typical Autopilot Wiring Connections

24
MegaSquirt EFI, see
MegaSquirt EFI

25
LTM Telemetry, see
LTM Telemetry

26
Runcam see
RunCam Camera Support

27
HOTT Telem see
HOTT Telemetry

28
Scripting see
Lua Scripts

29
Crossfire Receiver
Crossfire and ELRS RC Systems

30
Generator see
RichenPower Generator

31
Winch

32
MSP Telemetry see
Multiwii Serial Protocol (MSP)

33
DJI FPV telemetry see
MSP OSD

34
Serial Airspeed sensor

35
Serial ADSB receiver

36
External AHRS, see
External AHRS Systems

37
Smart Audio, see
Video Transmitter Support

38
FETtecOneWire, see
FETtec OneWire ESCs

39
Torqeedo, see
Torqeedo Electric Motors

40
AIS, see
AIS (for boats)

41
CoDevESC

42
DisplayPort, see
DisplayPort OSD

43
MAVLink High Latency, see
MAVLink High Latency Mode

44
IRC Tramp, see
Video Transmitter Support

45
DDS XRCE

46
IMU Data

48
PPP

49
i-BUS Telemetry

--- chunk_id: chunk-0240
source_document: common-serial-options.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: a42ca488e5e84653
prev_chunk_id: chunk-0239
next_chunk_id: chunk-0241
section_heading: SERIALx_OPTIONS Parameter
document_type: technical_reference

## SERIALx_OPTIONS Parameter
### ¶
Every serial port has in addition, to its baud rate (
SERIALx_BAUD
) and protocol format (
SERIALx_PROTOCOL
), the ability to invert its RX input and/or TX data, operate in half-duplex mode, and/or swap its RX and TX inputs. For example, for direct connection to FRSky SPort telemetry, normally inverters and diode OR externally would be required. With SERIALx_OPTIONS bitmask set to 7, direct connection to the SPort can be accomplished from a serial port. ### Bitmask Options
### ¶
if bit 0 is set, then RX data received is inverted internally. if bit 1 is set, the TX data is inverted before outputting. if bit 2 is set, then HalfDuplex operation using the TX pin is implemented. if bit 3 is set, then the TX and RX pins are effectively swapped internally. if bit 4 is set, then the RX pin has a weak pull down resistor activated. if bit 5 is set, then the RX pin has a weak pull up resistor activated. if bit 6 is set, then the TX pin has a weak pull down resistor activated. if bit 7 is set, then the TX pin has a weak pull up resistor activated. if bit 8 is set, then the RX has no DMA activated (assuming DMA is available on this UART)

if bit 9 is set, then the TX has no DMA activated (assuming DMA is available on this UART)

if bit 10 is set, then MAVLink forwarding will not be active on this UART port. (moved to MAVx_OPTIONS in 4.7 and later)

if bit 11 is set, then the hardware FIFO in H7 autopilots is disabled

if bit 12 is set, the GCS are prevented from changing the MAVLink message stream rates set by the
SRx_... parameters.(moved to MAVx_OPTIONS in 4.7 and later)

Note

HalfDuplex is supported on all ChiBiOS based autopilots, but inversion and swap are only supported on boards with F7 or H7 microprocessors.

--- chunk_id: chunk-0241
source_document: common-serial-options.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: 94e6f50b3083bfb5
prev_chunk_id: chunk-0240
next_chunk_id: chunk-0242
section_heading: MAVLINK PROTOCOL OPTIONS
document_type: technical_reference

## MAVLINK PROTOCOL OPTIONS
### ¶
If MAVLINK protocol is being used in any serial port, there are several options that can be selected to modify default behavior using parameters:

### MAV_OPTIONS
### ¶
Setting bit 0 of this parameter, will make the autopilot only accept MAVLink from system IDs given by
MAV_GCS_SYSID
and
MAV_GCS_SYSID_HI
. ### Individual MAVLink Channel Options
### ¶
Each MAVLink channel can have its behavior modified by settings its channel option parameter bitmask. Channel 1 options are shown below:

MAV1_OPTIONS
:

Bit set

Description

0

Accept unsigned MAVLink2 messages

1

Don’t forward mavlink to/from this channel, from/to other channels

2

Ignore Streamrate set by GCS

3

forward mavlink packets that don’t pass CRC (bit 1 overrides this)






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0242
source_document: common-telemetry-landingpage.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: ce89aced7e5c21ec
prev_chunk_id: chunk-0241
next_chunk_id: chunk-0243
document_type: technical_reference

Telemetry (landing page) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
Drive Calculator Motor/Propeller Analyzer
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Tether
PPM Encoder
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Short Range (<10KM)
Bluetooth
CUAV PW-Link
DroneBridge for ESP32
ESP8266 wifi telemetry
FrSky telemetry
i-BUS telemetry
Yaapu Bi-Directional Telemetry GCS
HOTT telemetry
MSP (version 4.2)
SiK Radio v1
SiK Radio v2
SiK Radio configuration
SiK Radio advanced configuration
Teravolt AeroTel-24
XBee
Long Range
Andruav Android Cellular
Blicube RLINK P900
ClearSky Airlink 4G LTE Telemetry
CRSF/ELRS Telemetry
CUAV P8 Radio
CUAV P9 Radio
DragonLink
Herelink
Holybro SiK Telemetry Radio - Long Range
Holybro 900Mhz XBP9X Telemetry Radio
Holybro Microhard Radio Telemetry Radio (P900/P840/P400-C1S)
Holybro Microhard Radio Telemetry Radio V2 (P400/P900)
LTE Modems using Lua driver
LTM telemetry
mLRS
RFD900
Rockblock Satellite Modem
SPL Satellite Telemetry
UAVCast 3G/4G Cellular
XBStation 4G LTE Link
Applications and Info
FlightDeck FrSky Transmitter App
MAVLink2 Packet Signing (Security)
MAVLink High Latency Protocol
Repeater for Wireless Ground Station Connections
Telemetry Radio Regional Regulations
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Peripheral Hardware
- Telemetry (landing page)
Edit on GitHub

# Telemetry (landing page)
# ¶
Copter/Plane/Rover/Blimp support sharing information with a ground station (or
transmitter) using telemetry.

--- chunk_id: chunk-0243
source_document: common-telemetry-landingpage.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 525
content_hash: 930186a2085d99fd
prev_chunk_id: chunk-0242
next_chunk_id: chunk-0244
document_type: technical_reference

Telemetry (landing page) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
Drive Calculator Motor/Propeller Analyzer
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Tether
PPM Encoder
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Short Range (<10KM)
Bluetooth
CUAV PW-Link
DroneBridge for ESP32
ESP8266 wifi telemetry
FrSky telemetry
i-BUS telemetry
Yaapu Bi-Directional Telemetry GCS
HOTT telemetry
MSP (version 4.2)
SiK Radio v1
SiK Radio v2
SiK Radio configuration
SiK Radio advanced configuration
Teravolt AeroTel-24
XBee
Long Range
Andruav Android Cellular
Blicube RLINK P900
ClearSky Airlink 4G LTE Telemetry
CRSF/ELRS Telemetry
CUAV P8 Radio
CUAV P9 Radio
DragonLink
Herelink
Holybro SiK Telemetry Radio - Long Range
Holybro 900Mhz XBP9X Telemetry Radio
Holybro Microhard Radio Telemetry Radio (P900/P840/P400-C1S)
Holybro Microhard Radio Telemetry Radio V2 (P400/P900)
LTE Modems using Lua driver
LTM telemetry
mLRS
RFD900
Rockblock Satellite Modem
SPL Satellite Telemetry
UAVCast 3G/4G Cellular
XBStation 4G LTE Link
Applications and Info
FlightDeck FrSky Transmitter App
MAVLink2 Packet Signing (Security)
MAVLink High Latency Protocol
Repeater for Wireless Ground Station Connections
Telemetry Radio Regional Regulations
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Peripheral Hardware
- Telemetry (landing page)
Edit on GitHub

# Telemetry (landing page)
# ¶
Copter/Plane/Rover/Blimp support sharing information with a ground station (or
transmitter) using telemetry. Follow the links below for configuration
information based upon your set-up.

--- chunk_id: chunk-0244
source_document: common-telemetry-landingpage.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 565
content_hash: 066d3e360e6c77c7
prev_chunk_id: chunk-0243
next_chunk_id: chunk-0245
document_type: technical_reference

Telemetry (landing page) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
Drive Calculator Motor/Propeller Analyzer
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Tether
PPM Encoder
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Short Range (<10KM)
Bluetooth
CUAV PW-Link
DroneBridge for ESP32
ESP8266 wifi telemetry
FrSky telemetry
i-BUS telemetry
Yaapu Bi-Directional Telemetry GCS
HOTT telemetry
MSP (version 4.2)
SiK Radio v1
SiK Radio v2
SiK Radio configuration
SiK Radio advanced configuration
Teravolt AeroTel-24
XBee
Long Range
Andruav Android Cellular
Blicube RLINK P900
ClearSky Airlink 4G LTE Telemetry
CRSF/ELRS Telemetry
CUAV P8 Radio
CUAV P9 Radio
DragonLink
Herelink
Holybro SiK Telemetry Radio - Long Range
Holybro 900Mhz XBP9X Telemetry Radio
Holybro Microhard Radio Telemetry Radio (P900/P840/P400-C1S)
Holybro Microhard Radio Telemetry Radio V2 (P400/P900)
LTE Modems using Lua driver
LTM telemetry
mLRS
RFD900
Rockblock Satellite Modem
SPL Satellite Telemetry
UAVCast 3G/4G Cellular
XBStation 4G LTE Link
Applications and Info
FlightDeck FrSky Transmitter App
MAVLink2 Packet Signing (Security)
MAVLink High Latency Protocol
Repeater for Wireless Ground Station Connections
Telemetry Radio Regional Regulations
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Peripheral Hardware
- Telemetry (landing page)
Edit on GitHub

# Telemetry (landing page)
# ¶
Copter/Plane/Rover/Blimp support sharing information with a ground station (or
transmitter) using telemetry. Follow the links below for configuration
information based upon your set-up. Note

Some RC systems incorporate telemetry in addition to RC control


Note

most pure telemetry radios connect to the autopilot via a serial UART using MAVLink 1 or 2 protocol.

--- chunk_id: chunk-0245
source_document: common-telemetry-landingpage.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 84
content_hash: 8a40227c0cf2ff7a
prev_chunk_id: chunk-0244
next_chunk_id: chunk-0246
document_type: technical_reference

Follow the links below for configuration
information based upon your set-up. Note

Some RC systems incorporate telemetry in addition to RC control


Note

most pure telemetry radios connect to the autopilot via a serial UART using MAVLink 1 or 2 protocol. See
Telemetry / Serial Port Setup


Note

High value systems using RC control over a telemetry link should consider
Redundant Telemetry Links

--- chunk_id: chunk-0246
source_document: common-telemetry-landingpage.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 256
content_hash: 8d465a76f23211d5
prev_chunk_id: chunk-0245
next_chunk_id: chunk-0247
section_heading: Short Range (<10KM)
document_type: technical_reference

## Short Range (<10KM)
### ¶
Bluetooth
CUAV PW-Link
DroneBridge for ESP32
ESP8266 wifi telemetry
FrSky telemetry
i-BUS telemetry
Yaapu Bi-Directional Telemetry GCS
HOTT telemetry
MSP (version 4.2)
SiK Radio v1
SiK Radio v2
SiK Radio configuration
SiK Radio advanced configuration
Teravolt AeroTel-24
XBee

### Long Range
### ¶
Andruav Android Cellular
Blicube RLINK P900
ClearSky Airlink 4G LTE Telemetry
CRSF/ELRS Telemetry
CUAV P8 Radio
CUAV P9 Radio
DragonLink
Herelink
Holybro SiK Telemetry Radio - Long Range
Holybro 900Mhz XBP9X Telemetry Radio
Holybro Microhard Radio Telemetry Radio (P900/P840/P400-C1S)
Holybro Microhard Radio Telemetry Radio V2 (P400/P900)
LTE Modems using Lua driver
LTM telemetry
mLRS
RFD900
Rockblock Satellite Modem
SPL Satellite Telemetry
UAVCast 3G/4G Cellular
XBStation 4G LTE Link

### Applications and Info
### ¶
FlightDeck FrSky Transmitter App
MAVLink2 Packet Signing (Security)
MAVLink High Latency Protocol
Repeater for Wireless Ground Station Connections
Telemetry Radio Regional Regulations

Yaapu Telemetry Scripts for OpenTX





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0247
source_document: common-tuning.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 8fdf70431142f70e
prev_chunk_id: chunk-0246
next_chunk_id: chunk-0248
document_type: technical_reference

Tuning — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Center of Gravity
Starting up and calibrating Plane
Pre-Arm Safety Checks
Arming Plane
Takeoff
Tuning Quickstart
Automatic Tuning
Tuning in Detail
Tuning QuickStart
Automatic Tuning with AUTOTUNE
Manual Roll, Pitch and Yaw Controller Tuning(firmware 4.1 and after)
Manual Roll, Pitch and Yaw Controller Tuning(firmware before 4.1)
Navigation Tuning
Cruise Speed Tuning
TECS (Total Energy Control System) for Speed & Height – Tuning Guide
Calibrating an Airspeed Sensor
Tuning Ground Steering for a Plane
Tuning Configuration Values for Common Airframes
Measuring Vibration
Transmitter based tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
First Flight
- Tuning
Edit on GitHub

# Tuning
# ¶
With the default PID settings, ArduPilot will fly most RC vehicles
safely right out of the box. To fly well, with tight navigation and
reliable performance in the wind, you’ll want to tune your autopilot
parameters. The following topics show you how. Tuning QuickStart
Automatic Tuning with AUTOTUNE
Manual Roll, Pitch and Yaw Controller Tuning(firmware 4.1 and after)
Manual Roll, Pitch and Yaw Controller Tuning(firmware before 4.1)
Navigation Tuning
Cruise Speed Tuning
TECS (Total Energy Control System) for Speed & Height – Tuning Guide
Calibrating an Airspeed Sensor
Tuning Ground Steering for a Plane




Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0248
source_document: common-uavcan-escs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 385
content_hash: 728f41eecc16ffe3
prev_chunk_id: chunk-0247
next_chunk_id: chunk-0249
document_type: technical_reference

DroneCAN ESCs — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
ADS-B Receiver
Airspeed Sensor
AIS (Automatic Identification System)
Barometer (external)
BlackBox Logger using an AutoPilot
Button Inputs
Buzzer
Cameras & Gimbals
Companion Computers
Crop Sprayer
Display (Onboard)
Drive Calculator Motor/Propeller Analyzer
DroneCAN Adapter Node
DroneCAN Peripherals
ESCs and Motors
Motors
ESC for Brushless Motors
Protocols
ESCs using BLHeli32, AM32, or BLHeli-S Configuration Firmware
Telemetry
Electronic Fuel Injectors (EFI)
ESC wiring and Large QuadPlane ESC Issues
Ethernet Adapters and Switches
External AHRS Systems
First Person View Video
Fuel Flow and Level Sensors
Generators
GPS/Compass
Grippers
Joystick or Gamepad
Landing Gear/ Retractable Camera Mount
LEDs (external)
On-Screen Display (OSD)
Optical Flow Sensor
Parachute
Power Modules
Power Tether
PPM Encoder
Radio Control Systems
Rangefinders (Sonar, Lidar, Depth Cameras)
Relay Switch
Remote Id (aka Drone Id)
RPM Sensor
Safety Switch
Servos and Actuators
Smart Batteries
Telemetry Radio
Temperature Sensors
Video (High Definition)
Winch
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Peripheral Hardware
DroneCAN Peripherals
- DroneCAN ESCs
Edit on GitHub

# DroneCAN ESCs
# ¶
Copter, Plane and Rover support
DroneCAN
Electronic Speed Controllers
(ESCs) that allow two-way communication with the autopilot
enabling potentially easier setup and in-flight monitoring of ESC and
motor health.

--- chunk_id: chunk-0249
source_document: common-uavcan-escs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 190
content_hash: e7238f78ceaa1bda
prev_chunk_id: chunk-0248
next_chunk_id: chunk-0250
section_heading: List of DroneCAN ESCs
document_type: technical_reference

## List of DroneCAN ESCs
### ¶
AM32 DroneCAN ESCs

Currawong Velocity ESCs

Hargrave Technologies DroneCAN ESCs

Hobbywing CAN ESCs

Holybro Kotleta20

KDE UVC ESCs

Zubax Mitochondrik

Zubax Myxa

Zubax Orel 20

### Connecting to the Flight Controller
### ¶
One ESC (it does not matter which) should be connected to the autopilot’s
CAN port using a 4-pin DF13 to 4-pin DroneCAN adapter cable. Each
subsequent ESC should be connected to the previous using a 4-pin
DroneCAN cable. The final ESC should have a CAN bus terminator plugged
into one of its 4-pin DroneCAN ports. An FTDI Cable connection to the ESC’s debug port is only required for set-up if the ESC does not present its parameters via DroneCAN. In that case, contact the manufacturer for detailed instructions. Preferably, the ESC can be configured via CAN bus using the
DroneCAN GUI Tool
.

--- chunk_id: chunk-0250
source_document: common-uavcan-escs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 290
content_hash: 88af3d99cf2799ca
prev_chunk_id: chunk-0249
next_chunk_id: chunk-0251
section_heading: Autopilot Setup
document_type: technical_reference

## Autopilot Setup
### ¶
There are several parameters that determine which autopilot servo/motor channels are sent to the DroneCAN ESCs:
For the examples below, the values are shown for DroneCAN driver #1 using CAN Port #1

CAN_P1_DRIVER
= 1, which assigns driver1 to port1

CAN_D1_PROTOCOL
= 1 (DroneCAN protocol)

CAN_D1_UC_NODE
- which is the node ID of the autopilot sending the commands to the ESCs so that there can be differentiation between multiple sources on the CAN bus. This is normally automatically set during discovery, but can be altered for advanced configurations (multiple sources on the bus). CAN_D1_UC_ESC_BM
- bitmask that determines which autopilot servo/motor output signals are sent to the DroneCAN ESCSs

CAN_D1_UC_ESC_RV
- bitmask that designates which autopilot servo/motor outputs have reversible DroneCAN ESCs, allowing both positive and negative control values to be sent. ### Logging and Reporting
### ¶
DroneCAN ESCs provide information back to the autopilot which is recorded in the autopilot’s onboard log’s CESC messages and can be viewed in any
ArduPilot compatible log viewer
. This information includes:

Error Count

Voltage

Current

Temperature

RPM

Power (as a percentage)

The RCOU messages are also written to the onboard logs which hold the requested output level sent to the ESCs expressed as a number from 1000 (meaning stopped) to 2000 (meaning full output).

--- chunk_id: chunk-0251
source_document: common-uavcan-escs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 80
content_hash: e2d20e016bcca824
prev_chunk_id: chunk-0250
next_chunk_id: chunk-0252
section_heading: Additional information
document_type: technical_reference

## Additional information
### ¶
Zubax Sapog wiki page
,
Sapog reference manual
,
and
ESC firmware
. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0252
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 532
content_hash: 4537a3f119a642c9
prev_chunk_id: chunk-0251
next_chunk_id: chunk-0253
document_type: technical_reference

DroneCAN Setup — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
Overview
DroneCAN Peripheral Types Supported
DroneCAN Setup Parameters
DroneCAN Adapter Node
DroneCAN ESC and Servo Configuration settings
GPS configuration settings
DroneCAN LED configuration
DroneCAN Rangefinder configuration
DroneCAN Options
DroneCAN Node ID Conflicts
CAN FD (Flexible Data rate)
Mixed Protocols on a DroneCAN CAN bus
SLCAN
SLCAN Access on F4 Based Autopilots
SLCAN Access on F7/H7 Based Autopilots
DroneCAN GUI
EKF (Extended Kalman Filter)
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- DroneCAN Setup
Edit on GitHub

# DroneCAN Setup
# ¶
DroneCAN was created to continue the development of the widely used UAVCAN v0 protocol.

--- chunk_id: chunk-0253
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 568
content_hash: 7ac172fa6e322824
prev_chunk_id: chunk-0252
next_chunk_id: chunk-0254
document_type: technical_reference

DroneCAN Setup — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
Overview
DroneCAN Peripheral Types Supported
DroneCAN Setup Parameters
DroneCAN Adapter Node
DroneCAN ESC and Servo Configuration settings
GPS configuration settings
DroneCAN LED configuration
DroneCAN Rangefinder configuration
DroneCAN Options
DroneCAN Node ID Conflicts
CAN FD (Flexible Data rate)
Mixed Protocols on a DroneCAN CAN bus
SLCAN
SLCAN Access on F4 Based Autopilots
SLCAN Access on F7/H7 Based Autopilots
DroneCAN GUI
EKF (Extended Kalman Filter)
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- DroneCAN Setup
Edit on GitHub

# DroneCAN Setup
# ¶
DroneCAN was created to continue the development of the widely used UAVCAN v0 protocol. This protocol has proven itself as robust and feature rich and has been widely deployed in the commercial drone industry and enjoys broad support among industry partners.

--- chunk_id: chunk-0254
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 602
content_hash: d463fd5d614edb9d
prev_chunk_id: chunk-0253
next_chunk_id: chunk-0255
document_type: technical_reference

DroneCAN Setup — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Analog Pins
Advanced Failsafe
Autopilot Output Mapping
Auxiliary Functions
Battery Voltage Compensation
Bootloader Update
BLHeli ESCs
CAN Bus Setup
Compass Setup (Advanced)
Compass-less Operation
Crash Detection
Damaged Motor/Prop RPM Checks
DisplayPort
DroneCAN Setup
Overview
DroneCAN Peripheral Types Supported
DroneCAN Setup Parameters
DroneCAN Adapter Node
DroneCAN ESC and Servo Configuration settings
GPS configuration settings
DroneCAN LED configuration
DroneCAN Rangefinder configuration
DroneCAN Options
DroneCAN Node ID Conflicts
CAN FD (Flexible Data rate)
Mixed Protocols on a DroneCAN CAN bus
SLCAN
SLCAN Access on F4 Based Autopilots
SLCAN Access on F7/H7 Based Autopilots
DroneCAN GUI
EKF (Extended Kalman Filter)
EKF Affinity & Lane Switching
EKF Sources and Selection
Ethernet/Network Setup
Network Capture
Flight Time Recorder
Flight Options
Fly-By-Wire Low Altitude Limit
FPort Setup
GeoFencing Failsafe
GPIOs
GPS for Yaw (aka Moving Baseline)
GPS for Altitude
GPS/Non-GPS Transitions
Ground Control Station Only Operation
IMU Temperature Calibration
Independent Watchdog
In-Flight FTT and filter control
Limiting Maximum Power Draw
Limit Cycle Prevention
LUA Scripting
Magnetic Interference
Magnetometer GeoPhys Array
MAVLink
MAVLink2 Packet Signing (Security)
Moving Vehicle Initialization
Multiple Radio Control Receivers
Non-GPS Navigation
Notification Devices (LEDs,Buzzer,etc.)
Notch Filter Configuration
Object Avoidance
Optical Flow Sensor
On Screen Displays (OSD)
OSD Parameter Editor
Parameter List (Full)
Parameter Lockdown
Parameter Reset
RC Input Channel Mapping (RCMAP)
RC Options
Received Signal Strength Indication (RSSI)
Redundant Telemetry
Reverse Thrust Setup
RunCam Camera Configuration and Control
Safety Switch
Sensor Position Offset Compensation
Sensor Testing
Serial Forwarding to DroneCAN
Serial Port to Port Passthrough
Serial Port Configuration
Ship(Moving Vehicle) Takeoff/Landing
Telemetry Port Setup
Terrain Following
Transmitter Based Tuning
Video Stabilization (Gyroflow)
Video Transmitter Control
UBlox GPS Configuration
Vibration Damping
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Advanced Configuration
- DroneCAN Setup
Edit on GitHub

# DroneCAN Setup
# ¶
DroneCAN was created to continue the development of the widely used UAVCAN v0 protocol. This protocol has proven itself as robust and feature rich and has been widely deployed in the commercial drone industry and enjoys broad support among industry partners. The proposed introduction of the UAVCAN v1 protocol involved changes to UAVCAN that increased complexity and did not offer a smooth migration path for existing deployments.

--- chunk_id: chunk-0255
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 148
content_hash: 6b4cfa2d8bab84b8
prev_chunk_id: chunk-0254
next_chunk_id: chunk-0256
document_type: technical_reference

This protocol has proven itself as robust and feature rich and has been widely deployed in the commercial drone industry and enjoys broad support among industry partners. The proposed introduction of the UAVCAN v1 protocol involved changes to UAVCAN that increased complexity and did not offer a smooth migration path for existing deployments. After extended discussions within the UAVCAN consortium it was decided that the best solution was to continue development of UAVCAN v0 under the name DroneCAN. This article provides guidance to setup DroneCAN protocol on ArduPilot. Tip

The physical CAN port, and its driver selected as DroneCAN protocol, should be enabled first. Please refer to the
CAN Bus Setup

--- chunk_id: chunk-0256
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: 55c048ddf64c0c0a
prev_chunk_id: chunk-0255
next_chunk_id: chunk-0257
section_heading: Overview
document_type: technical_reference

## Overview
### ¶
DroneCAN is a lightweight protocol designed for reliable communication
in aerospace and robotic applications via CAN bus. The DroneCAN network is a decentralized peer network, where each peer
(node) has a unique numeric identifier - node ID and that is only one
parameter needs to be set for basic setup. Detailed description of protocol can be found at
https://dronecan.github.io/

### DroneCAN Peripheral Types Supported
### ¶
ArduPilot currently supports the following types of DroneCAN peripherals:

GPS

Compass

Barometer

Rangefinder

ADSB Receiver

Power Module

LED

Buzzer

Airspeed

Safety Switch/LED

DroneCAN Adapter Node

DroneCAN device type is selected by:

GPS,Compass, Barometer, ADSB Receiver, LED, Buzzer, Safety Switch/LED, and Airspeed devices are automatically identified in the DroneCAN protocol

Rangefinder:
RNGFNDx_TYPE
= 24

Power Module:
BATT_MONITOR
or
BATTx_MONITOR
= 8

--- chunk_id: chunk-0257
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 490
content_hash: 2e6f98dbba6465f4
prev_chunk_id: chunk-0256
next_chunk_id: chunk-0258
section_heading: DroneCAN Setup Parameters
document_type: technical_reference

## DroneCAN Setup Parameters
### ¶
shown for the first DroneCAN driver, second driver has identical parameters

CAN_D1_PROTOCOL
if set for DroneCAN(1) has the following associated parameters:

CAN_D1_UC_POOL
: a memory pool for the driver of this size will be allocated if possible. The default size can usually be reduced, saving RAM for other functions and features, if the CAN traffic is light, as with GPSes or Compass, as opposed to ESCs. ### DroneCAN Adapter Node
### ¶
These devices are general purpose DroneCAN nodes with I/O ports that allow the attachment of non-DroneCAN ArduPilot peripherals to the DroneCAN bus via UART ports, I2C, SPI, and/or GPIOs. See
DroneCAN Adapter Nodes
. ### DroneCAN ESC and Servo Configuration settings
### ¶
See
DroneCAN ESCs
for information on DroneCAN ESCs. Each DroneCAN ESC or Servo will have an programmed ID or channel address corresponding to the autopilot’s servo/motor output channel. These are set by switches on the ESC or via a setup/configuration program, depending on the ESC. There are three parameters that determine which autopilot servo/motor channels are sent to the CAN ESC and/or Servos:
For the examples below, the values are shown for CAN driver #1. CAN_D1_UC_NODE
- which is the node ID of the autopilot sending the commands to the ESCs so that there can be differentiation between multiple sources on the CAN bus

CAN_D1_UC_ESC_BM
- bitmask that determines which autopilot servo/motor output signals are sent to the DroneCAN ESCs. CAN_D1_UC_SRV_BM
- bitmask that determines which autopilot servo/motor output signals are sent to the Servos on DroneCAN Servos

In the bitmap masks, each bit position represents an ESC or servo ID number
that the corresponding autopilot servo/motor channel command will be directed to. For example, 00001111 (15 decimal) would send commands to ESC or SERVO IDs 0 through 3. Note

When using DroneCAN ESCs/Servos, you can set the
SERVOx_FUNCTION
for those, but still use those outputs on the autopilot for GPIOs using the
SERVO_GPIO_MASK
parameter. The autopilot outputs will become GPIOS and the corresponding
SERVOx_FUNCTION
will be sent out DroneCAN. To reduce bandwidth, the
CAN_D1_UC_ESC_BM
and
CAN_D1_UC_SRV_BM
params should be set
to enable only the motor and servo channels you need CAN signals to be sent to.

--- chunk_id: chunk-0258
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 166
content_hash: 4accdc863ce77051
prev_chunk_id: chunk-0257
next_chunk_id: chunk-0259
section_heading: DroneCAN Setup Parameters
document_type: technical_reference

The autopilot outputs will become GPIOS and the corresponding
SERVOx_FUNCTION
will be sent out DroneCAN. To reduce bandwidth, the
CAN_D1_UC_ESC_BM
and
CAN_D1_UC_SRV_BM
params should be set
to enable only the motor and servo channels you need CAN signals to be sent to. In addition, the
CAN_D1_UC_ESC_OF
parameter lets you further maximize bandwidth by offsetting the ESC position to the first time slots on the bus, eliminating empty time slots. For example, if the ESCs are on outputs 5 to 8, an offset of 4 will transport them in the first 4 timeslots which would otherwise be empty and consume bandwidth. Example: For a configuration of CAN servos on channels 1,2,4 and ESC motor on channel 3, set:

Example:
CAN_D1_UC_SRV_BM
= 0x0B

Example:
CAN_D1_UC_ESC_BM
= 0x04

--- chunk_id: chunk-0259
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 325
content_hash: 5f2a53f955ffd1d8
prev_chunk_id: chunk-0258
next_chunk_id: chunk-0260
section_heading: GPS configuration settings
document_type: technical_reference

## GPS configuration settings
### ¶
If there is a DroneCAN GPS device, it has to be enabled in
GPS
subgroup of parameters. The
TYPE
parameter should be set to 9 for corresponding GPS receiver in autopilot. ### DroneCAN LED configuration
### ¶
DroneCAN LEDs are enabled by setting bit 5 in the
NTF_LED_TYPES
bitmask. The
CAN_D1_UC_NTF_RT
sets the rate that notification messages are transmitted in DroneCAN. ### DroneCAN Rangefinder configuration
### ¶
Set
RNGFNDx_TYPE
= 24 to enable DroneCAN rangefinder type. Rangefinder data received over DroneCAN will only be used if the received sensor_id matches the parameter
RNGFNDx_ADDR
. For AP_Periph firmware based adaptor nodes, this value is 0, so
RNGFNDx_ADDR
must be set to 0. Other DroneCAN rangefinders may differ. See also
DroneCAN Adaptor Node
instructions. ### DroneCAN Options
### ¶
Several options for each DroneCAN driver can be selected via the
CAN_D1_UC_OPTION
and
CAN_D2_UC_OPTION
bitmask parameters. Default is not set:

CAN_Dx_UC_OPTION bit

Function when set

0

ClearDNADatabase,
see below

1

IgnoreDNANodeConflicts,
see below

2

EnableCanfd,
CANFD below

3

IgnoreDNANodeUnhealthy, ignore disconnected node ids

4

SendServoAsPWM, instead of sending servo positions as -1 to -1, send as PWM values in us

5

SendGNSS, send GPS fix and status info over DroneCAN, used by some gimbals

6

UseHimarkServo, enable Himark Servo command set

7

HobbyWingESC, enable command set for this esc

8

EnableStats, enable peripheral to send bus stats

9

EnableFlexDebug, enable flexible debugging via LUA, see
this example

10

SecondaryAllowExtendedFrames, see
https://github.com/ArduPilot/ardupilot/blob/master/libraries/AP_Scripting/applets/CAN_playback.lua

--- chunk_id: chunk-0260
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 184
content_hash: 0d203fef06669e41
prev_chunk_id: chunk-0259
next_chunk_id: chunk-0261
section_heading: DroneCAN Node ID Conflicts
document_type: technical_reference

## DroneCAN Node ID Conflicts
### ¶
When a device is attached and recognized, it’s node ID and hardware ID are entered into a database which is stored between power cycles. If multiple devices with the same node ID and different hardware IDs are used (swapping smart batteries, for example, with the same node ID), a conflict will arise in the database. This will require the use of the
CAN_D1_UC_OPTION
parameter to allow the database to be reset on the next boot, or conflicts in the database to be ignored. ### CAN FD (Flexible Data rate)
### ¶
If the DroneCAN port is attached to CAN FD peripherals, setting
CAN_D1_UC_OPTION
bit 2 (+ value 4) will enable this mode. Note

CAN FD requires a larger memory pool allocation than normal. Default is 24KB instead of the normal 12KB.

--- chunk_id: chunk-0261
source_document: common-uavcan-setup-advanced.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 245
content_hash: 5bef56d6334c9c77
prev_chunk_id: chunk-0260
next_chunk_id: chunk-0262
section_heading: Mixed Protocols on a DroneCAN CAN bus
document_type: technical_reference

## Mixed Protocols on a DroneCAN CAN bus
### ¶
If the
CAN_Dx_PROTOCOL
is DroneCAN, then the following other devices with differing protocols can also reside on that bus by setting the
CAN_Dx_PROTOCOL2
parameter:

ID

Device Protocol

7

USD1

10

Scripting

11

Benewake

12

Scripting2

13

TOFSenseP

14

NanoRadar_NRA24

### SLCAN
### ¶
Note

SLCAN access via COM port is disabled when armed to lower cpu load. Use SLCAN via MAVLink instead. This method is generally preferred, in any case. ArduPilot and DroneCAN provide a means to directly communicate with DroneCAN devices on the CAN BUS attached to the autopilot: SLCAN. Enabling SLCAN and communicating with the DroneCAN devices is dependent on the autopilot’s processor. F7/H7 processors use one method and F4, a different method. Mission Planner SLCAN

SLCAN Access on F4 Based Autopilots
SLCAN Access on F7/H7 Based Autopilots
DroneCAN GUI





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0262
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: 725c18a4317d8b42
prev_chunk_id: chunk-0261
next_chunk_id: chunk-0263
document_type: technical_reference

Vibration Damping — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Mounting the Autopilot
Autopilot Wiring
NAVIO2 (Linux based) Wiring QuickStart
Attaching NAVIO2 to a Raspberry Pi
Powering NAVIO2
Connect remote control inputs
GNSS Antenna
Connect Motors
Connect other peripherals
Related information
Installing GPS + Compass Module
Detailed Vehicle Builds
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Autopilot System Assembly Instructions for Plane
NAVIO2 Assembly and Wiring Quick Start
- Vibration Damping
Edit on GitHub

# Vibration Damping
# ¶
Autopilots have accelerometers that are sensitive to vibrations. These accelerometer values are combined with barometer and
GPS data to estimate the vehicle’s position. With excessive
vibrations, the estimate can be thrown off and lead to very bad
performance in modes that rely on accurate positioning (e.g. on Copter:
AltHold, Loiter, RTL, Guided, Position and Auto flight modes). Please refer to the
Measuring Vibration
page for details of
how to measure your vehicle’s vibration levels and confirm they are within the acceptable range

The goal of vibration damping is to reduce high and medium frequency
vibrations while still allowing low frequency actual board movement to
take place in concert with the airframe. Double sided foam tape or Velcro has traditionally been used to attach
the autopilot to the frame. In many cases foam tape or Velcro
does not provide adequate vibration isolation because the mass of the
autopilot is so small. Note

The examples and images in this article refer to Copter, but the
information is also largely applicable to Plane and Rover.

--- chunk_id: chunk-0263
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 170
content_hash: 1649c642a27ebd81
prev_chunk_id: chunk-0262
next_chunk_id: chunk-0264
section_heading: 3M, Du-Bro or HobbyKing Foam
document_type: technical_reference

## 3M, Du-Bro or HobbyKing Foam
### ¶
One of the following three types of foam should be cut into small 1cm ~ 2cm squares and attached to each of the four corners of the autopilot as described on the
Mounting the Autopilot wiki page
:

3M Foam is sticky on both sides and comes pre-cut so that individual squares can be easily attached to the autopilot
sold by mRobotics

sold by Holybro

Du-Bro 1/4” R/C foam

HobbyKing orange foam
(discontinued)

For the last two options “carpet fixing tape” will be required to attach the foam to the autopilot and vehicle frame. For vehicles with
internal combustion engines
, the autopilot should be mounted on an intermediate plate with
self adhesive lead weights
added to increase its mass.

--- chunk_id: chunk-0264
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 228
content_hash: a746f88cad30a74b
prev_chunk_id: chunk-0263
next_chunk_id: chunk-0265
section_heading: Gel pads
document_type: technical_reference

## Gel pads
### ¶
Cut one of the recommended gels into 1cm ~ 2cm squares and attach to each corner of the autopilot. Possible gels include:

Kyosho Zeal Gel Tape
performs best and is available from Amazon, E-Bay and A-Main Hobbies

United States Silicone Gel Tape and Pads (V10Z62MGT5 tape recommended)

United Kingdom Silicone Gel Tape, Pads
and
grommets

Moon Gel Pads
(also available in music stores). Caution: Moon Gel has been shown
to fail in heat above 100 degrees Fahrenheit so it should be used
cautiously. Secure the autopilot to the frame with 1cm) wide velcro retaining
strap or a rubber band. Be careful the strap does not hold down the
controller so securely that it interferes with the damping of the
pads. Consider putting a layer of soft foam between the strap and the
autopilot. FlameWheel F330 with PX4FMU Mounted on Intermediate platform
¶

The blog
Testing simple anti-vibration solutions for GoPro on an ArduCopter
has a video demonstrating vibration isolation using Moon Gel on a Go-Pro camera.

--- chunk_id: chunk-0265
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: 3312e3bd6e8e51ea
prev_chunk_id: chunk-0264
next_chunk_id: chunk-0266
section_heading: 3D Printed Anti-Vibration Platform
document_type: technical_reference

## 3D Printed Anti-Vibration Platform
### ¶
GuyMcCaldin’s 3D Printed vibration mount on
Thingiverse
using
dampers like these
. The mount can be installed using double sided tape, or M3 screws. ### 3D Printed Anti-Vibration Platform for NAVIO2
### ¶
Anti-vibration for NAVIO2 can be easily 3D printed. It significantly simplifies mounting and eliminates vibrations. You can find STL files
here
. Anti-vibration with Navio2 mounted on frame:

### O-ring Suspension Mount
### ¶
Create a platform upon which to mount your autopilot with
holes or screws on the four corners. Mount your autopilot on
this board with double sided foam tape. Mount 4 standoffs on the top of your frame spaced 1/10” to 1/8”
further apart than the width of the platform upon which the control
board has been mounted. Insert 1/16” nylon O-rings through each corner of the autopilot and the standoffs so that the autopilot has no hard
connections to the frame. Link
(Here!)

The overall O-ring diameter should be chosen to firmly retain the
board while providing for light to moderate initial but rapidly
snubbed movement of the board (generally 1/2” to 3/4” OD) and
Silicone O-rings should generally damp better than Buna-N O-rings
(Sizes 15 - 21) if you can acquire them. FlameWheel F450 O-Ring Suspension Platform Mount
¶

Vibrations are short coupled, so all that leaving excess corner
clearance does is to require higher initial O-ring tension which reduces
vibration damping responsiveness and allows the board to physically tilt
more (which is undesirable as it throws the sensor to airframe
relationship off). The disadvantage to O-ring suspension versus Gel pads is that it is
mechanically more complex and it requires tuning of both of O-ring
diameter and cross section. You can combine O-ring and gel pad design by using an intermediate plate
and benefit from dual rate damping.

--- chunk_id: chunk-0266
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: cf8a266147caed55
prev_chunk_id: chunk-0265
next_chunk_id: chunk-0267
section_heading: Ear Plug Mount
document_type: technical_reference

## Ear Plug Mount
### ¶
Purchase slow response silicon or urethane foam or PVC foam earplugs
such as
these from 3M
. Create a platform upon which to mount your autopilot with
holes at the four corners. The holes should be large enough to allow
the ear plugs to be inserted into them but not so loose that the
board comes loose during hard landings. Ensure the holes are smooth
so they do not cut into the ear plugs. Also keep the holes near the
corners of your electronic module plate as possible to minimize
unnecessary module movement. Mount your autopilot on this board with double sided foam
tape. Extra mass added to the board may improve vibration damping. Squeeze the earplugs through existing holes in the frame (or cut new
holes) and the holes in the board upon which the autopilot is
mounted. “Tuning” is possible by varying the amount of earplug left
exposed in the middle. Ear Plug Vibration Mount
¶

--- chunk_id: chunk-0267
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 266
content_hash: eff7645e33e5e74e
prev_chunk_id: chunk-0266
next_chunk_id: chunk-0268
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

## Bulb Damper + Ear Plug Vibration Mount
### ¶
Mounting plate with a 100g soft rubber bulb type
“gimbal” damper at each corner and a half a urethane foam earplug
placed inside each one. Gimbal bulb type dampers themselves can work in tension or
compression. The earplugs provide an additional damping medium with a different
frequency damping range than the bulb dampers by themselves. The ear plugs also stiffen the bulb mounts up a bit preventing
excessive free motion being caused by normal flight maneuvers. This was successful at damping a Flamewheel clone with flexible arms
and over size 12” propellers into the .05 G range. The autopilot is also mounted on anti-vibration grommets available from
McMaster Carr
(package of 25 each part #9311K64 recommended). The 100G bulb type gimbal vibration dampers can be ordered direct
from a variety of vendors:
copter-rc.com

### Advice for reducing vibrations
### ¶
For copters the largest source of vibration is normally the blades passing over the arms but other sources of vibration also exist and may be reduced by following this advice:

Frame flex especially arm flex is a big cause of asynchronous
vibration, Frame arms should be as rigid as possible.

--- chunk_id: chunk-0268
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 486
content_hash: 2279e2410e49131b
prev_chunk_id: chunk-0267
next_chunk_id: chunk-0269
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

The autopilot is also mounted on anti-vibration grommets available from
McMaster Carr
(package of 25 each part #9311K64 recommended). The 100G bulb type gimbal vibration dampers can be ordered direct
from a variety of vendors:
copter-rc.com

### Advice for reducing vibrations
### ¶
For copters the largest source of vibration is normally the blades passing over the arms but other sources of vibration also exist and may be reduced by following this advice:

Frame flex especially arm flex is a big cause of asynchronous
vibration, Frame arms should be as rigid as possible. Original DJI Flamewheel copters have sufficiently rigid injection molded arms, the many clones do not

Aluminum or carbon fibre arms twist and bend less which reduces vibrations

Copters with injection molded exoskeletons or arms like the Iris are sufficiently rigid

Cheap, light frames tend to flex more than high quality stronger ones and the heavier you load the copter the more flex it gets (not good)

Motor to frame arm and frame arm to central hub mounts need to be secure and flex free (sometimes a problem for carbon tube arms)

Motors need to run smoothly (bearings not worn-out or “screeching”)

Prop adapters connecting the propellers to the motors need to be concentric and very straight

Propellers should be fully balanced using a good manual prop balancer

Motor balancing (or really well factory balanced motors like T-Motor) can have a major effect

Propellers that are not well matched to the frame and weight or do  not have the same flex for CCW and CW are very problematic

Good propellers vibrate less

Carbon fiber props are rigid and vibrate less which reduces vibration but are very sharp which is a major safety hazard


### Summary of the vibrations that should be damped
### ¶
The vibration frequency and amplitude we primarily need to reduce is
a characteristic of the motor / prop units turning at flight speed. That is, it is a fairly high frequency with fairly low amplitude. This requires that we provide a short coupled damping and isolation range. The board itself does not need to have nor benefit from a range of
motion that exceeds the amplitude of the vibration.

--- chunk_id: chunk-0269
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: ca11d8a2e435f042
prev_chunk_id: chunk-0268
next_chunk_id: chunk-0270
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

This requires that we provide a short coupled damping and isolation range. The board itself does not need to have nor benefit from a range of
motion that exceeds the amplitude of the vibration. Because the board does not apply any force to the airframe, the only
thing we need to be concerned with Damping / Isolating is the weight
(mass) of the board itself plus the forces applied to it by
airframe’s normal flight maneuvering. Since excellent broad frequency range, high damping materials are
available our biggest concern will be to use the proper amount of
them to optimally damp our autopilot (too much is just as
bad as too little). Combining the autopilot and receiver onto a separate
vibration damped electronics module “plate” or enclosure can increase
the mass of the module making it easier to damp effectively as well
as reducing the interconnecting wiring and making the whole system
more modular. ### Additional Vibration Reduction Considerations
### ¶
Hard Disk Drive Anti-Vibration Grommets
. can provide sufficient or supplemental vibration reduction

Significant gains in vibration isolation can also be realized by
using a high flex wire and strain relief approach to all wires
connected to the autopilot (and using the minimum number
of wires necessary as well). Some frames have lower than normal vibration characteristics due to
frame stiffness / flex and isolated centralized mass can greatly
influence motor/prop vibration transfer to the central fight
controller. Isolation and damping can be improved somewhat by sandwiching the
autopilot / enclosure between damping pads on both sides
in about twenty percent compression. 30 durometer Sorbothane is
actually specified at 15 to 20 percent compression for optimal
damping. Although 30 durometer Sorbothane seems an excellent candidate,
experience indicates that it becomes permanently compressed
and is not as effective at vibration reduction as the Gel solutions. A link to a Blog about the first APM anti-vibration mounting system
to achieve 0.05 G damping (2/20/2013 improved to 0.02 G), a dual zone
isolation system, combining O-ring suspension and silicone pad is
(Here!)

Motor balancing can also reduce vibration and especially so for
cheaper or larger motors. Balancing involves:

Tightly fasten a small tie wrap around a motor (WITH NO PROP),
trim off the extended tab and spin it up.

--- chunk_id: chunk-0270
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: b5960c662639a5d0
prev_chunk_id: chunk-0269
next_chunk_id: chunk-0271
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

A link to a Blog about the first APM anti-vibration mounting system
to achieve 0.05 G damping (2/20/2013 improved to 0.02 G), a dual zone
isolation system, combining O-ring suspension and silicone pad is
(Here!)

Motor balancing can also reduce vibration and especially so for
cheaper or larger motors. Balancing involves:

Tightly fasten a small tie wrap around a motor (WITH NO PROP),
trim off the extended tab and spin it up. Try multiple times, each time turning the tie wrap on the motor
housing a bit until the vibration reduces or goes away. A small piece of Scotch tape can be re-positioned instead of the
tie wrap if desired or for smaller motors. When you locate the spot where there is the least vibration (and
you should be able to hear it), mark the spot directly under the
clasp of the tie-wrap with a felt pen. Add a small dot of hot glue gun glue where the Tie-Wrap clasp was
and increase the glue a bit at a time till the vibration is
minimized. If you put too much glue on it can be removed with an X-acto knife. Camera Mounts also need to be effectively isolated and damped from
vibration, but they already have a number of “soft” mounting
solutions. The camera servos need to be vibration isolated as well, either in
the isolated camera mount itself or with their own vibration
reduction solution. You should use high quality ball joints on your camera servo arms and
adequate bearings or bushings in the mount itself with zero free play
to prevent inertial slop. Quality servos without free play are also a must for precision camera
work. At this point in time it seems that the more rigid the frame the
better because frame flex introduces undesirable mechanical delay
(hysteresis) in translating motor induced actions to the centrally
located autopilot. (Do NOT shock mount the motor Arms). The amount and type of damping medium needs to be carefully matched
to the weight (mass) of the item we are trying to isolate as well as
the frequency and amplitude of the vibrations we are seeking to
damp. We are trying to isolate an autopilot that weighs
less than 2 ounces and this is a very small mass.

--- chunk_id: chunk-0271
source_document: common-vibration-damping.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: 0e5c86f30392b5a1
prev_chunk_id: chunk-0270
next_chunk_id: chunk-0272
section_heading: Bulb Damper + Ear Plug Vibration Mount
document_type: technical_reference

The amount and type of damping medium needs to be carefully matched
to the weight (mass) of the item we are trying to isolate as well as
the frequency and amplitude of the vibrations we are seeking to
damp. We are trying to isolate an autopilot that weighs
less than 2 ounces and this is a very small mass. Virtually all off the shelf solutions (either pad or stud type) are
designed for an isolated mass that would weigh at least 5 to 10 times
what an average autopilot weighs for optimal effectiveness. This
includes all pre-made Sorbothane, Alpha gel, EAR, memory foam or
other silicone or urethane gel or foam mounts as well as Lord Micro
mounts. A threaded stud or sleeve type mount gel mount properly designed for
the mass of our autopilot or electronics module undergoing
the stress’s of normal flight would be a much better long term
solution. ### Terminology
### ¶
The methods used will typically incorporate both damping and isolation:

Isolation
is simple undamped (spring or rubber band support) which
allows the movement of the isolated object largely separate from the
containing object (Automobile spring for instance). Damping
is the conversion of vibration into heat energy by a shock
absorbing medium (automobile shock absorber for instance). ### Links to related discussions
### ¶
RC Groups page on Vibration Effects relating to a camera mounts

DIYDrones discussion related to Vibration Control

Gary McCray’s DIYDrones BLOG re Vibration Control






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0272
source_document: cruise-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: 9906dcdbeda1bb79
prev_chunk_id: chunk-0271
next_chunk_id: chunk-0273
document_type: technical_reference

CRUISE Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- CRUISE Mode
Edit on GitHub

# CRUISE Mode
# ¶
Cruise mode is a bit like
FLY BY WIRE_B (FBWB)
, but it
has “heading lock”. It is the ideal mode for longer distance FPV flight,
as you can point the plane at a distant object and it will accurately
track to that object, automatically controlling altitude, airspeed and
heading. Warning

CRUISE mode is not suitable for flight close to the ground. The
time constants for height control in CRUISE mode are the ones from
TECS, which are quite slow. When you are close to the ground CRUISE
mode does not give you the agility needed in pitch control to avoid
hitting the ground. The way it works is this:

if you have any aileron or rudder input then it flies just like
FBWB
.

--- chunk_id: chunk-0273
source_document: cruise-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 4362467594e4a53c
prev_chunk_id: chunk-0272
next_chunk_id: chunk-0274
document_type: technical_reference

When you are close to the ground CRUISE
mode does not give you the agility needed in pitch control to avoid
hitting the ground. The way it works is this:

if you have any aileron or rudder input then it flies just like
FBWB
. So it holds altitude until you use the elevator
to change the target altitude (at the
FBWB_CLIMB_RATE
rate) and
it adjusts airspeed based on throttle

when you let go of the aileron and rudder sticks for more than 0.5
seconds it sets an internal waypoint at your current location, and
projects a target waypoint one kilometre ahead (note that heading
lock will only activate if you have GPS lock, and have a ground speed
of at least 3 m/s)

as it flies along it heads for the target waypoint, and constantly
updates that target to always be one kilometre ahead, leaving the
previous waypoint as the position that you centred the aileron and
rudder sticks

as long as you don’t touch the aileron or rudder, it will run the
same navigation system it uses for waypoints, including crabbing,
cross-track etc, so it will very accurately hold that ground course
even in the face of changing wind conditions

One of the nicer aspects of CRUISE mode is how it handles rudder. If you
give it some rudder then the roll controller will keep the wings level,
but the plane will yaw with the rudder. So you get a “wings level” turn,
allowing you to rotate your flight to point at whatever geographic
feature you want to head towards. Then when you let go of the rudder it
will head straight for that point. Note that you can configure CRUISE mode to do terrain following on
autopilots with microSD storage available. See the
terrain following documentation
. Warning

Make sure you only fly FPV if it is allowed by your country’s
flight and airspace control rules. Many countries do not allow
non-line-of-sight flight without a special operating license.

--- chunk_id: chunk-0274
source_document: cruise-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 72
content_hash: 1fde16d66e6f0088
prev_chunk_id: chunk-0273
next_chunk_id: chunk-0275
section_heading: Advanced Configuration
document_type: technical_reference

## Advanced Configuration
### ¶
Fly-By-Wire Low Altitude Limit

Min/Max Altitude Fences





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0275
source_document: fbwa-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: 0cbbe5c234769661
prev_chunk_id: chunk-0274
next_chunk_id: chunk-0276
document_type: technical_reference

FBWA Mode (FLY BY WIRE_A) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- FBWA Mode (FLY BY WIRE_A)
Edit on GitHub

# FBWA Mode (FLY BY WIRE_A)
# ¶
This is the most popular mode for assisted flying in Plane, and is the
best mode for inexperienced flyers. In this mode Plane will hold the
roll and pitch specified by the control sticks. So if you hold the
aileron stick hard right then the plane will hold its pitch level and
will bank right by the angle specified in the
ROLL_LIMIT_DEG
parameter (in
degrees). It is not possible to roll the plane past the roll limit
specified in
ROLL_LIMIT_DEG
(see also bit 16 in
Flight Options
), and it is not possible to pitch the plane
beyond the
PTCH_LIM_MIN_DEG
or
PTCH_LIM_MAX_DEG
settings. Note that holding level pitch does not mean the plane will hold
altitude. How much altitude a plane gains or loses at a particular pitch
depends on its airspeed, which is primarily controlled by throttle. So
to gain altitude you should raise the throttle, and to lose altitude you
should lower the throttle. If you want Plane to take care of holding
altitude then you should look at the FlyByWireB mode.

--- chunk_id: chunk-0276
source_document: fbwa-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 174
content_hash: 44e759c90cc25e16
prev_chunk_id: chunk-0275
next_chunk_id: chunk-0277
document_type: technical_reference

So
to gain altitude you should raise the throttle, and to lose altitude you
should lower the throttle. If you want Plane to take care of holding
altitude then you should look at the FlyByWireB mode. In FBWA mode throttle is manually controlled, but is constrained by the
THR_MIN
and
THR_MAX
settings. In FBWA mode the rudder is under both manual control, plus whatever
rudder mixing for roll you have configured. Thus you can use the rudder
for ground steering, and still have it used for automatically
coordinating turns. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0277
source_document: fbwb-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 486
content_hash: 657e544773b03166
prev_chunk_id: chunk-0276
next_chunk_id: chunk-0278
document_type: technical_reference

FBWB Mode (FLY BY WIRE B) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- FBWB Mode (FLY BY WIRE B)
Edit on GitHub

# FBWB Mode (FLY BY WIRE B)
# ¶
The FBWB mode is similar to
FLY BY WIRE A (FBWA)
, but
Plane will try to hold altitude as well. Roll control is the same as
FBWA, and altitude is controlled using the elevator. The target airspeed
is controlled using the throttle. To control your altitude in FBWB mode you use the elevator stick to ask for a
change in altitude. If you leave the elevator centered then Plane will
try to hold the current altitude. As you move the elevator stick, Plane will
try to gain or lose altitude at a rate in proportion to how far you move the
elevator. How much altitude it tries to gain for full elevator
deflection depends on the
FBWB_CLIMB_RATE
parameter, which defaults
to 2 meters/second. Note that 2 m/s is quite a slow change, so many
users will want to raise
FBWB_CLIMB_RATE
to a higher value to make
the altitude change more responsive.

--- chunk_id: chunk-0278
source_document: fbwb-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: bb752d5dd6e79a3e
prev_chunk_id: chunk-0277
next_chunk_id: chunk-0279
document_type: technical_reference

How much altitude it tries to gain for full elevator
deflection depends on the
FBWB_CLIMB_RATE
parameter, which defaults
to 2 meters/second. Note that 2 m/s is quite a slow change, so many
users will want to raise
FBWB_CLIMB_RATE
to a higher value to make
the altitude change more responsive. Whether you need to pull back on the elevator stick or push forward to
climb depends on the setting of the
FBWB_ELEV_REV
parameter. The
default is for pulling back on the elevator to cause the plane to climb. This corresponds to the normal response direction for a RC model. If you
are more comfortable with the reverse you can set
FBWB_ELEV_REV
to 1
and the elevator will be reversed in FBWB mode. Note that the elevator stick does not directly control pitch, it controls target
climb or descent rate. The amount of pitch that will be used to achieve this
rate depends on your TECS tuning settings, but in
general the autopilot primarily climb or descend by raising or lowering the pitch AND throttle. This can be disconcerting for people used to flying in FBWA mode, where
you have much more direct control over pitch. If you have an airspeed sensor then the throttle will control the target
airspeed in the range
AIRSPEED_MIN
to
AIRSPEED_MAX
. If
throttle is minimum then the plane will try to fly at
AIRSPEED_MIN
. If it is maximum it will try to fly at
AIRSPEED_MAX
. If you don’t have an airspeed sensor then the throttle input will set the
target throttle of the plane, which is
TRIM_THROTTLE
, at throttle midstick and lower positions, and Plane will adjust the throttle around
that value to achieve the desired altitude hold while trying to maintain the pitch generally at its calibrated LEVEL setting, although the autopilot will primarily use pitch for climbing and descending, and manage throttle to maintain airspeed. Increasing the throttle stick above mid-stick
can be used to push the target throttle up beyond what it calculates is
needed, to fly faster. As with FBWA, the rudder is under a combination of manual control and
auto control for turn coordination. You should also have a look at CRUISE mode, as it is generally better
than FBWB, especially if there is significant wind.

--- chunk_id: chunk-0279
source_document: fbwb-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 89
content_hash: f6d20a92a255920c
prev_chunk_id: chunk-0278
next_chunk_id: chunk-0280
document_type: technical_reference

As with FBWA, the rudder is under a combination of manual control and
auto control for turn coordination. You should also have a look at CRUISE mode, as it is generally better
than FBWB, especially if there is significant wind. In CRUISE mode the
aircraft will hold a ground track as opposed to just leveling the wings
when you don’t input any roll with the aileron stick.

--- chunk_id: chunk-0280
source_document: fbwb-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 72
content_hash: 1fde16d66e6f0088
prev_chunk_id: chunk-0279
next_chunk_id: chunk-0281
section_heading: Advanced Configuration
document_type: technical_reference

## Advanced Configuration
### ¶
Fly-By-Wire Low Altitude Limit

Min/Max Altitude Fences





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0281
source_document: first-flight-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 336
content_hash: 91610aed004f880f
prev_chunk_id: chunk-0280
next_chunk_id: chunk-0282
document_type: technical_reference

First Flight — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Center of Gravity
Starting up and calibrating Plane
Pre-Arm Safety Checks
Arming Plane
Takeoff
Tuning Quickstart
Automatic Tuning
Tuning in Detail
Tuning Configuration Values for Common Airframes
Measuring Vibration
Transmitter based tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
- First Flight
Edit on GitHub

# First Flight
# ¶
The following topics explain how to set up and configure your Plane for
its first flight, and includes an explanation of the main
Flight Modes
that you will use. Center of Gravity
Starting up and calibrating Plane
Pre-Arm Safety Checks
Arming Plane
Takeoff
Tuning Quickstart
Automatic Tuning
Tuning in Detail
Tuning Configuration Values for Common Airframes
Measuring Vibration
Transmitter based tuning




Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0282
source_document: flight-modes.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 276
content_hash: cb6994e7e7f869c2
prev_chunk_id: chunk-0281
next_chunk_id: chunk-0283
document_type: technical_reference

Flight Modes — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
- Flight Modes
Edit on GitHub

# Flight Modes
# ¶
This article provides links to Plane’s flight modes.

--- chunk_id: chunk-0283
source_document: flight-modes.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 456
content_hash: 63fa64773a67d01a
prev_chunk_id: chunk-0282
next_chunk_id: chunk-0284
section_heading: Overview
document_type: technical_reference

## Overview
### ¶
Plane has a wide range of built in flight modes. Plane can act as a
simple flight stabilization system, a sophisticated autopilot, a
training system or a flight safety system depending on what flight mode
and options you choose. Flight modes are controlled through a
radio transmitter switch
, via mission
commands, or using commands from a ground station (GCS) or companion
computer. ### Major Flight Modes
### ¶
All of the flight modes below have optional additional controls that may
be used to change the behaviour to suit particular flying needs. After
you have read the introductory material below it is highly recommended
that you look through the complete set of
Plane parameters
so you can explore the full range
of functionality available. Mode
Roll
Pitch
Throttle
GPS
Need TX
Summary
MANUAL
-
-
-
Y
Manual control surface movement, passthrough
FBWA
s
s
-
Y
Roll and pitch follow stick input, up to set limits
FBWB
s
A
SPD
Y
Y
like FBWA, but with automatic height and speed control
CRUISE
A
A
SPD
Y
Y
like FBWB, but with ground course tracking
STABILIZE
+
+
-
Y
Wing-leveling on stick release
AUTOTUNE
s
s
-
Y
like FBWA, but learns attitude tuning while flying
TRAINING
+
+
-
Y
Manual control up to roll and pitch limits
ACRO
+
+
-
Y
rate controlled mode with no attitude limits
Q(Copter Modes)
s
s
A
Y
Y
Varies depending on mode. See quadplane documentation
AUTO
A
A
A
Y
Follows Mission
LOITER
A
A
A
Y
Circles point where mode switched
CIRCLE
A
A
A
Gently turns aircraft
GUIDED
A
A
A
Y
Circles user defined point from GCS
Return To Launch (RTL)
A
A
A
Y
Returns to and circles home or rally point
TAKEOFF
A
A
A
Y
Automatic takeoff to specific altitude, and loiter at distance from takeoff until mode is changed
THERMAL
A
A
A
Y
Mode entered to search for thermal lift by SOARING feature or manually if lift is encountered.

--- chunk_id: chunk-0284
source_document: flight-modes.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: 33c7e75044e9acf0
prev_chunk_id: chunk-0283
next_chunk_id: chunk-0285
section_heading: Overview
document_type: technical_reference

Mode
Roll
Pitch
Throttle
GPS
Need TX
Summary
MANUAL
-
-
-
Y
Manual control surface movement, passthrough
FBWA
s
s
-
Y
Roll and pitch follow stick input, up to set limits
FBWB
s
A
SPD
Y
Y
like FBWA, but with automatic height and speed control
CRUISE
A
A
SPD
Y
Y
like FBWB, but with ground course tracking
STABILIZE
+
+
-
Y
Wing-leveling on stick release
AUTOTUNE
s
s
-
Y
like FBWA, but learns attitude tuning while flying
TRAINING
+
+
-
Y
Manual control up to roll and pitch limits
ACRO
+
+
-
Y
rate controlled mode with no attitude limits
Q(Copter Modes)
s
s
A
Y
Y
Varies depending on mode. See quadplane documentation
AUTO
A
A
A
Y
Follows Mission
LOITER
A
A
A
Y
Circles point where mode switched
CIRCLE
A
A
A
Gently turns aircraft
GUIDED
A
A
A
Y
Circles user defined point from GCS
Return To Launch (RTL)
A
A
A
Y
Returns to and circles home or rally point
TAKEOFF
A
A
A
Y
Automatic takeoff to specific altitude, and loiter at distance from takeoff until mode is changed
THERMAL
A
A
A
Y
Mode entered to search for thermal lift by SOARING feature or manually if lift is encountered. See :ref:`THERMAL Mode
`
AUTOLAND
A
A
A
Y
Fixed wing Autoland See :ref:`AUTOLAND Mode
`
Symbol
Definition
-
Full manual control of flight surfaces
+
Manual control with stabilized limits or assistance
s
Stabilized control with limits
A
Automatic control
SPD
Controls speed
Note

Automatic throttle controlled modes can optionally have pilot-based speed adjustments using the throttle stick via the
THROTTLE_NUDGE
parameter. Otherwise, the autopilot will attempt to maintain
AIRSPEED_CRUISE
airspeed if an airspeed sensor is being used, or
TRIM_THROTTLE
as a target throttle, as in FBWA and CRUISE modes. Note

Most altitude controlled modes can optionally maintain altitude with respect to Terrain instead of relative to HOME. See
Terrain Following
for more information. Warning

Any stabilized control mode requires tuning for optimal performance. The default PID and TECS values are very conservative to avoid uncontrollable
oscillations. Perform an
AUTOTUNE
before using stabilized or automatic roll and pitch modes
extensively. Tune TECS
before using automatic throttle modes
extensively. Note

AUTO mode also provides for
Automatic Takeoff
and
Automatic Landing
.

--- chunk_id: chunk-0285
source_document: flight-modes.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 117
content_hash: 56592faa0910afa4
prev_chunk_id: chunk-0284
next_chunk_id: chunk-0286
section_heading: Flight Mode List
document_type: technical_reference

## Flight Mode List
### ¶
ACRO Mode
AUTO Mode
AUTOLAND
AUTOTUNE Mode
CRUISE Mode
CIRCLE Mode
FBWA Mode (FLY BY WIRE_A)
FBWB Mode (FLY BY WIRE_B)
GUIDED Mode
LOITER Mode
MANUAL Mode
RTL Mode (Return To Launch)
STABILIZE Mode
TAKEOFF Mode
TRAINING Mode
THERMAL Mode





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0286
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 156
content_hash: ca20bbdcf2805906
prev_chunk_id: chunk-0285
next_chunk_id: chunk-0287
document_type: technical_reference

Geo-Fencing in Plane — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
Upcoming Features
Ready to Fly/Use Vehicles
Antenna Tracking
Simulation
OEM Customization
Use Cases and Applications
Web Tools

--- chunk_id: chunk-0287
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 246
content_hash: 261328f85b7bb4d7
prev_chunk_id: chunk-0286
next_chunk_id: chunk-0288
document_type: technical_reference

Appendix
Abbreviations
Acknowledgments
Commercial Support
Contact Us
Developer tools (downloads)
Donating to ArduPilot
Firmware (downloads)
Glossary
History of ArduPilot
Partners
Partners Program
Ready-To-Use vehicles
Records
Stores
Top Contributors
Training Centers
Wiki Editing Guide
Common Airframe Builds
Release Notes
Archived Topics
Loading ChibiOS firmware onto Pixhawk
NAVIO+ Overview
APM 2.x
PX4FMU
PX4IO
Qualcomm Snapdragon Flight Kit
Open Camera Control Board
VR Gimbal Controller (3-Axis Open Source)
External GPS AP2.x
GPS Module (External)
External Compass (Magnetometer)
Recording and Playing Back Missions
AttoPilot Current/Voltage Sensor
Erle-Brain2 Wiring Quick Start
PXFmini Wiring Quick Start
Web Apps
Camera Triggering using CHDK
Camera Triggering using CHDK Tutorial
Edge Quick Start
Skysight Mono Camera Trigger
PPM Encoders
PPM Encoder
Toshiba CAN ESCs
Tarot Gimbal
DROTAG x Geotagger
Robsense SwarmLink
ARCHIVED TOPIC
Multiwii Serial Protocol (MSP)
ArduSimple GPS
Migration from release 3.7 to 3.8
Mandatory Hardware Configuration
Normal/Elevon/VTail Mode & Reversing Servos
Channel Output Functions
ADNS3080 Mouse Sensor (no longer supported)
LAND mode
Geofencing prior to 4.1
Manual Roll, Pitch and Yaw Controller Tuning(firmware before 4.1)
Advanced user tools (downloads)
User Alerts
Individual
Partners
SWAG Shop



Plane
Additional Information and Topics of Interest

--- chunk_id: chunk-0288
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 276
content_hash: bcaa036506d044dc
prev_chunk_id: chunk-0287
next_chunk_id: chunk-0289
document_type: technical_reference

Appendix
Archived Topics
- Geo-Fencing in Plane
Edit on GitHub

ARCHIVED: See
GeoFencing
for info for firmware versions 4.1 and later

# Geo-Fencing in Plane
# ¶
The Geo-Fencing support in Plane firmware versions prior to 4.1, allows you to set a virtual ‘fence’ around the area you want to fly in, specified as an enclosed polygon of
GPS positions plus a minimum and maximum altitude. For firmware versions 4.1 and later, Plane uses the either a home centered Cylindrical Fence, see
Cylindrical Fence
and/or Inclusion/Exclusion Fences, see
Inclusion and Exclusion Fences
. Note

In Plane you MUST have the fence polygon drawn for the geofence
parameters to work. In Copter you can specify a maximum fence altitude
without the fence polygon and Copter will adhere to it but Plane
requires you to draw the polygon for any of the fence parameters
including the max/min ALT to work. When fencing is enabled, if your plane goes outside the fenced area then
it will switch to GUIDED mode, and will fly back to a pre-defined return
point, and loiter there ready for you to take over again. You then use a
switch on your transmitter or use commands in your Ground Control
Station (GCS) to take back control.

--- chunk_id: chunk-0289
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 222
content_hash: 14dd166ae31477cf
prev_chunk_id: chunk-0288
next_chunk_id: chunk-0290
section_heading: Use for R/C training
document_type: technical_reference

## Use for R/C training
### ¶
One of the main uses of geo-fencing is to teach yourself (or someone
else) to fly radio controlled planes. When you have a properly
configured geo-fence it is very hard to crash, and you can try
manoeuvres that would normally be too likely to end in a crash, trusting
the APM to ‘bounce’ the plane off the geo-fence before the flight ends
in disaster. Geo-fencing can be combined with any flight mode. So for a raw
beginner, you would combine it with one of the stabilised flight modes
(such as STABILIZE or FBWA). Once the pilot has gained some confidence
you could combine it with MANUAL mode, which gives direct control of the
plane and allows for the most interesting aerobatic manoeuvres. When
used in this way the autopilot stays out of your way completely, just passing
the controls to the servos directly, and only takes control if you go
outside the fenced area or outside the defined altitude range.

--- chunk_id: chunk-0290
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 177
content_hash: eae78df7ffa79c13
prev_chunk_id: chunk-0289
next_chunk_id: chunk-0291
section_heading: Use for containment
document_type: technical_reference

## Use for containment
### ¶
During fully autonomous operation the fence can be used as a failsafe
measure to ensure the aircraft stays within the intended flight area. During fully autonomous operation use the
FENCE_AUTOENABLE
parameter
and the plane will automatically engage the fence after takeoff is
complete and automatically disable the fence when it arrives at a
landing waypoint. Set the
FENCE_AUTOENABLE
parameter to 1 to use this
feature. For details on setting up landing and takeoff waypoints see
the
Planning a Mission with Waypoints and Events
page. Of course, the fence can be used for containment in semi-autonomous
missions as well (missions where, e.g., takeoff and/or landing are
manual) – the fence would still be enabled/disabled via the R/C
transmitter or the GCS in that case –
FENCE_AUTOENABLE
is optional.

--- chunk_id: chunk-0291
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 486
content_hash: b09651c3231dc96e
prev_chunk_id: chunk-0290
next_chunk_id: chunk-0292
section_heading: Setting up geo-fencing
document_type: technical_reference

## Setting up geo-fencing
### ¶
To setup geo-fencing in Plane you need to configure several things:

the boundary of the fence, as a set of GPS points

the action to take on fence breach

the location of the return point; note that optionally you may use
the
FENCE_RET_RALLY
parameter to have the plane return to the
closest
Rally Point
instead of the fence return point. the minimum and maximum altitude of the fenced area

what RC channel on your transmitter you will use to enable
geo-fencing (if any)

an optional setting (
FENCE_AUTOENABLE
) when you want to configure
the fence to automatically enable after an autonomous takeoff and
automatically disable after an autonomous landing

how you want to take back control after a fence breach

These can all be setup using Mission Planner. There are a few rules that you must follow when setting up your fence
boundary:

the return point must be inside the fence boundary

the fence boundary must be fully enclosed. This means it must have at
least 4 points, and the last point must be the same as the first
point

the boundary can have at most 18 points

If you setup your fence with the APM planner it should ensure you follow
these rules. Please remember when making your fence boundary that your plane will
have some momentum when it hits the fence, and will take time to turn
back to the return point. For a plane like the SkyWalker we recommend an
additional safety margin of around 30 meters inside the true boundary of
where you want to fly. The same goes for the minimum altitude - you need
to make it high enough that the APM has time to recover from a fast
dive. How much margin you need depends on the flight characteristics of
your plane. Apart from the fence boundary, the following MAVLink parameters control
geo-fencing behaviour:

FENCE_ACTION
- the action to take on fence breach. This defaults to
zero which disables geo-fencing. Set it to 1 to enable geo-fencing
and fly to the return point on fence breach. Set to 2 to report a
breach to the GCS but take no other action.

--- chunk_id: chunk-0292
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: fe9605f610302982
prev_chunk_id: chunk-0291
next_chunk_id: chunk-0293
section_heading: Setting up geo-fencing
document_type: technical_reference

Set it to 1 to enable geo-fencing
and fly to the return point on fence breach. Set to 2 to report a
breach to the GCS but take no other action. Set to 3 to have the
plane head to the return point on breach, but the pilot will maintain
manual throttle control in this case. FENCE_ALT_MIN
- the minimum altitude in meters. If this is zero then
you will not have a minimum altitude. FENCE_ALT_MAX
- the maximum altitude in meters. If this is zero then
you will not have a maximum altitude. FENCE_CHANNEL<FENCE_CHANNEL>
(revs previous to 4.1),
RCx_OPTION
= 11 - the RC input channel to watch for enabling the
geo-fence. This defaults to zero, which disables geo-fencing. You
should set it to a spare RC input channel that is connected to a two
position switch on your transmitter. Fencing will be enabled when
this channel goes above a PWM value of 1750. If your transmitter
supports it it is also a good idea to enable audible feedback when
this channel is enabled (a beep every few seconds), so you can tell
if the fencing is enabled without looking down. FENCE_TOTAL
- the number of points in your fence (the return point
plus the enclosed boundary). This should be set for you by the
planner when you create the fence. FENCE_RETALT
- the altitude the aircraft will fly at when flying to
the return point and when loitering at the return point (in meters). Note that when
FENCE_RET_RALLY
is set to 1 this parameter is
ignored and the loiter altitude of the closest
Rally Point
is
used instead. If this parameter is zero and
FENCE_RET_RALLY
is
also zero, the midpoint of the
FENCE_ALT_MAX
and
FENCE_ALT_MIN
parameters is used as the return altitude. FENCE_AUTOENABLE
- if set to 1, the aircraft will boot with the
fence disabled. After an autonomous takeoff completes the fences
will automatically enable. When the autonomous mission arrives at a
landing waypoint the fence automatically disables. FENCE_RET_RALLY
- if set to 1 the aircraft will head to the nearest
Rally Point
rather than the fence return point when the fence is breached. Note
that the loiter altitude of the Rally Point is used as the return
altitude. Note

A Rally Point can be outside of the geofence but this is NOT
recommended.

--- chunk_id: chunk-0293
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: 1841782d41cec2bf
prev_chunk_id: chunk-0292
next_chunk_id: chunk-0294
section_heading: Setting up geo-fencing
document_type: technical_reference

Note
that the loiter altitude of the Rally Point is used as the return
altitude. Note

A Rally Point can be outside of the geofence but this is NOT
recommended. If you have a rally point outside the geofence you
will need to disable the geofence using
FENCE_CHANNEL
before you
can control the plane again otherwise the plane will stay in GUIDED
mode FOREVER circling the rally point. Once the geofence is disabled
you should fly the plane back inside the geofence and then re-enable
it. One additional parameter may be useful to get the most out of
geo-fencing. When you breach the fence, the plane will switch to GUIDED
mode and fly back to the return point (or the nearest Rally Point, if
FENCE_RET_RALLY
has been set to 1). Once you are back inside the fence
boundary you are able to take control again, and you need to tell the
APM that you want to take control. You can do that in one of 3 ways:

changing modes using the mode switch on your transmitter, or
changing modes via the Mission Planner GCS (e.g., change from GUIDED
mode to AUTO mode). disabling and re-enabling geo-fencing using the rc
channel setup for fence control above. set the
RST_SWITCH_CH
MAVLink parameter to another two-position
channel that is attached to a spring loaded switch. The
RST_SWITCH
parameter defaults to zero which disables it. If you
set it to a channel then you can use this channel switch to take back
control after a fence breach. If not flying completely autonomously, I find that using
RST_SWITCH_CH
is the best option for geo-fencing as it means that the APM has fencing
enabled throughout the flight, and you don’t get any behaviour change by
switching modes. It does take up another channel though, so some people
may not have enough channels to use it.

--- chunk_id: chunk-0294
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 353
content_hash: 9eedb0346dd80bbf
prev_chunk_id: chunk-0293
next_chunk_id: chunk-0295
section_heading: Setting up the fence boundary
document_type: technical_reference

## Setting up the fence boundary
### ¶
### APMPlanner
### ¶
To setup a fence boundary you should use the ‘Flight Planner’ screen in
the APM Planner. Start by right-clicking the location you want for the return point and
choosing ‘Set return location’. The return point should be somewhere in
the middle of your flight area, and in easy visual range of where you
will be standing when you fly. After you’ve set the return point you should right click on the first
point on the boundary of the fence you want. Choose ‘Draw Polygon ->

Add polygon point’. You are then in polygon mode, and you should
left-click to add each point in the boundary of your fence. The planner
will automatically complete the polygon by connecting the last point to
the first one. You can then right-click and choose geo-fencing upload to send your
fence boundary to the APM. The planner will ask you for the minimum and
maximum altitude (in meters) of your fence before uploading. You can
also save your fence to a file for later loading. ### Mission Planner
### ¶
Mission Planner follows a very similar process. Start by right-clicking
where you want to begin the geo-fence boundary. Add Polygon Point
¶

Continue to click on the map where you want the geo-fence boundary and
the polygon will appear. You can drag any points you want to adjust. Then right click on the map where you want the plane to return to when a
geo-fence breach occurs. Geo-Fence Set ReturnLocation
¶

Finally upload the geo-fence. Geo-Fence Upload
¶

--- chunk_id: chunk-0295
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 300
content_hash: e22a53639a61ea11
prev_chunk_id: chunk-0294
next_chunk_id: chunk-0296
section_heading: Altitude of the return point
document_type: technical_reference

## Altitude of the return point
### ¶
If you set the
FENCE_RET_RALLY
parameter to 1, then the return
altitude will be
the same as the loiter altitude of the nearest Rally
Point
. If the
FENCE_RET_RALLY
is set to 0, then you may set the
return altitude in meters above the Home Point with the
FENCE_RETALT
parameter. Otherwise
:

If you set
FENCE_MINALT
and
FENCE_MAXALT
to other than zero (and have
FENCE_MAXALT
greater than FENCE_MINALT) then the return point altitude
will be half way between
FENCE_MINALT
and
FENCE_MAXALT
. If you don’t setup
FENCE_MINALT
and
FENCE_MAXALT
(ie. leave them at
zero) then the return point altitude will be given by the
RTL_ALTITUDE
parameter, which is also used for RTL mode. Note that
RTL_ALTITUDE
is
in centimetres, whereas
FENCE_MINALT
and
FENCE_MAXALT
are in meters. If your flying club and local flying rules don’t set a maximum altitude
then we recommend you use a maximum altitude of at most 122 meters
(which is around 400 feet). Beyond that altitude it becomes quite
difficult to keep good eye contact with your model. With
FENCE_MINALT
set at 30 meters (to allow for some dive momentum)
and
FENCE_MAXALT
set to 122 meters, the return point will be 76 meters,
which is quite a good altitude to leave the plane loitering while you
are getting ready to have another go.

--- chunk_id: chunk-0296
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 184
content_hash: 8e5a37a9ddfe6f11
prev_chunk_id: chunk-0295
next_chunk_id: chunk-0297
section_heading: Stick-mixing on fence breach
document_type: technical_reference

## Stick-mixing on fence breach
### ¶
ArduPilot enables ‘stick mixing’ by default when in auto modes. This means
that you can change the path of a loiter, for example, by using your
transmitter sticks. When you are using geo-fencing, stick mixing will be disabled on fence
breach until your plane is back inside the fenced region. This is to
ensure that the bad control inputs that caused you to breach the fence
don’t prevent it from recovering to the return point. As soon as you are back inside the fence stick mixing will be
re-enabled, allowing you to control the GUIDED mode that the plane will
be in. If by using stick mixing you manage to take the plane outside the
fence again then stick mixing will again be disabled until you are back
inside the fence.

--- chunk_id: chunk-0297
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 404
content_hash: 7366c331457fd776
prev_chunk_id: chunk-0296
next_chunk_id: chunk-0298
section_heading: Tips for flying with geo-fencing
document_type: technical_reference

## Tips for flying with geo-fencing
### ¶
You should have geo-fencing disabled when on the ground and for takeoff. Be careful not to enable it on the ground, as it may declare a fence
breach and try to fly to the return point. If flying fully autonomously
you may use the
FENCE_AUTOENABLE
parameter to assist with this
complication. Also remember to disable it for landing, as the altitude breach when you
are coming in will make it very hard to land! If you are using an APM1 and want to combine geo-fencing with MANUAL
mode, then remember that on the APM1 the APM software is bypassed when
using channel 8 for mode switching and a switch PWM channel value above
1750 (this is called ‘hardware manual’ on the APM1). So you either need
to set a different switch position as MANUAL, or use a different mode
switch control channel (and set
FLTMODE_CH
to the channel you are
using). Before you takeoff and fly with geo-fencing make sure all the parameters
are setup as described above, and also make sure you have a good GPS
lock. If you lose GPS lock then geo-fencing will disable itself until
GPS lock is regained, so don’t use it if your GPS signal is marginal. I’d also recommend you test it gently at first. Try slowly approaching a
fence boundary and ensure it correctly ‘bounces’ off the virtual wall
and returns to the return point OK. Then after taking control again, try
slowly approaching the minimum altitude and ensure it bounces off the
FENCE_MINALT
you have set. While developing geo-fencing I found that combining it with MANUAL mode
is the most fun. It gives you all of the excitement of manual flight
with sharp turns and fancy stunts while saving your plane when you make
a mistake.

--- chunk_id: chunk-0298
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 252
content_hash: 5a4ce45cdc3b8996
prev_chunk_id: chunk-0297
next_chunk_id: chunk-0299
section_heading: Example flight
document_type: technical_reference

## Example flight
### ¶
This is the track from a flight with geo-fencing enabled at my local
flying club while flying my !SkyWalker. The white lines show the
geo-fence boundary, plus you can see the return point in the middle. You
can also see the points where the plane breached the geo-fence to the
north, west and south. There were also numerous altitude breaches, as I
was using this flight to try to improve my inverted flight skills in
MANUAL mode. The plane would not have survived without the geo-fence! Notice that the geo-fence in this example runs along the middle of the
runway. This is to conform to my local club rules. The takeoff and
landing were done with the fence disabled. I had
FENCE_CHANNEL
set to
7, and
RST_SWITCH_CH
set to 6. That allowed me to enable the fence
after takeoff using one switch, then to take back control after a breach
using the spring loaded trainer switch. Note

in firmware versions 4.1 and later,
FENCE_CHANNEL
is replaced by setting a channel’s
RCx_OPTION
to 208, and
RST_SWITCH_CH
is replaced by setting a channel’s
RCx_OPTION
to 96.

--- chunk_id: chunk-0299
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 314
content_hash: f8a885fc387f4a00
prev_chunk_id: chunk-0298
next_chunk_id: chunk-0300
section_heading: MAVLink support
document_type: technical_reference

## MAVLink support
### ¶
ArduPilot will report the fence status via the MAVLink GCS protocol. The
key status packet is called FENCE_STATUS, and is defined in
“ardupilotmega.xml”. A typical FENCE_STATUSpacket looks like this:

2011
-
12
-
20
16
:
36
:
35.60
:
FENCE_STATUS
breach_status
:
1
,
breach_count
:
15
,
breach_type
:
1
,
breach_time
:
1706506


The breach_status field is 0 if inside the fence, and 1 if outside. The
breach_count is how many fence breaches you have had on this flight. The breach_type is the type of the last breach (see the FENCE_BREACH
enum in ardupilotmega.xml). The breach_time is the time in milliseconds
of the breach since APM was booted. The MAV_SYS_STATUS_GEOFENCE bit of the MAV_SYS_STATUS_SENSOR
portion of the SYS_STATUS message indicates whether or not the
geo-fence is breached. As of this writing only the MAVProxy GCS
recognizes this status bit and reports the status of the geo-fence. In
the future the Mission Planner, APM Planner, and other GCS applications
should get support for announcing geo-fence status during the flight. The MAV_CMD_DO_FENCE_ENABLE MAVLink command message allows a GCS to
enable or disable a fence interactively. As of this writing only
MAVProxy supports this message using the “fence enable” or “fence
disable” commands. In the future Mission Planner, APM Planner, and
other GCS applications should get support for interactively enabling and
disabling the geo-fence without needing to use a manual transmitter.

--- chunk_id: chunk-0300
source_document: geofencing.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 192
content_hash: f3e93e5189600019
prev_chunk_id: chunk-0299
next_chunk_id: chunk-0301
section_heading: Advanced Features
document_type: technical_reference

## Advanced Features
### ¶
Geo-fencing in Plane can also be used as part of a failsafe system, for
competitions like the Outback Challenge. For those type of events you
should define your fence boundary as usual, but additionally build APM
with the FENCE_TRIGGERED_PIN option set in
APM_Config.h
. This
option allows you to set a digital pin on your APM to go high when the
fence is breached. You can connect this pin to your planes failsafe
device to trigger the planes failsafe mode (which for the OBC
competition involves setting extreme servo values to dive the plane into
the ground). Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0301
source_document: guided-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 8aa122f7ecb3c41c
prev_chunk_id: chunk-0300
next_chunk_id: chunk-0302
document_type: technical_reference

GUIDED Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- GUIDED Mode
Edit on GitHub

# GUIDED Mode
# ¶
The GUIDED mode is used when you want the aircraft to fly to a specific
point on the map without setting up a mission. Most ground control
stations support a “click to fly to” feature where you can click a point
on the map and the aircraft will fly to that location then loiter. The other major use for GUIDED mode is in
geo-fencing
. When the geo-fence is breached the aircraft will enter GUIDED mode, and
head to the predefined geo-fence return point, where it will loiter
until the operator takes over. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0302
source_document: loiter-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: 3d665d8862167acf
prev_chunk_id: chunk-0301
next_chunk_id: chunk-0303
document_type: technical_reference

LOITER Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- LOITER Mode
Edit on GitHub

# LOITER Mode
# ¶
In LOITER mode the plane will circle around the point where you started
the loiter, holding altitude at the altitude that you entered loiter in. The radius of the circle is controlled by the
WP_LOITER_RAD
parameter,
but is also limited by your
NAV_ROLL_CD
limit, and your
NAVL1_PERIOD
navigation tuning. As with
Return To Launch (RTL)
and
AUTO
mode you can “nudge” the plane while in LOITER
using stick mixing, if enabled. If
FLIGHT_OPTIONS
bit 12 is set (+4096 to value) and
STICK_MIXING
is set to 1, then altitude of the loiter can be changed using the pitch stick, as in FBWB mode. Warning

“Home” position is always supposed to be your Plane’s actual
GPS takeoff location:

It is very important to acquire GPS lock before arming in order for
RTL, Loiter, Auto or any GPS dependent mode to work properly. For Plane the home position is initially established at the time the
plane acquires its GPS lock. It is then continuously updated as long as
the autopilot is disarmed.

--- chunk_id: chunk-0303
source_document: loiter-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 154
content_hash: ae4ef0730c8fb54b
prev_chunk_id: chunk-0302
next_chunk_id: chunk-0304
document_type: technical_reference

For Plane the home position is initially established at the time the
plane acquires its GPS lock. It is then continuously updated as long as
the autopilot is disarmed. This means if you execute an RTL in Plane, it will return to the location where it was when it was armed - assuming it had acquired GPS lock. Consider the use of
Rally Points
to avoid returning directly to your arming point on RTL. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0304
source_document: manual-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 378
content_hash: a0d0b80b22d7b0bf
prev_chunk_id: chunk-0303
next_chunk_id: chunk-0305
document_type: maintenance_procedure

MANUAL Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- MANUAL Mode
Edit on GitHub

# MANUAL Mode
# ¶
Regular RC control, no stabilization. All RC inputs are passed through
to the servo outputs set by their SERVOx_FUNCTION. Note

the
MAN_EXPO_ROLL
,
MAN_EXPO_PITCH
, and
MAN_EXPO_RUDDER
parameters will apply exponential to the stick inputs, if non-zero, in this mode. This is for users with transmitters which do not provide this function and desire to “soften” stick feel around neutral. Note

This assumes that the RC channel is being used as a servo output function instead of one selected by its RCx_OPTION parameter.

--- chunk_id: chunk-0305
source_document: manual-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 156
content_hash: 9e45edb31f8282ce
prev_chunk_id: chunk-0304
next_chunk_id: chunk-0306
document_type: maintenance_procedure

This is for users with transmitters which do not provide this function and desire to “soften” stick feel around neutral. Note

This assumes that the RC channel is being used as a servo output function instead of one selected by its RCx_OPTION parameter. The only ways in which the input to a servo output function may be different from inputs in this mode is if a configured failsafe or geofence triggers, and Plane takes control. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0306
source_document: mission-planner-telemetry-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 250
content_hash: 1c824f3586cab649
prev_chunk_id: chunk-0305
next_chunk_id: chunk-0307
document_type: technical_reference

Telemetry Logs — Mission Planner  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
Stores
About
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Mission Planner


Mission Planner Overview
Installing Mission Planner
Loading Firmware onto boards with existing ArduPilot firmware
Loading Firmware onto boards without existing ArduPilot firmware (first time only)
Connect Mission Planner to AutoPilot
Mission Planning
Mission Planner Features/Screens
Flight DATA Screen Overview
Flight PLAN Screen
SETUP Screen
CONFIGuration and Tuning Screens
SIMULATION Screen
Logs
Advanced Mission Planner Features
Telemetry Logs
When and where tlogs are created
Setting the datarate
Playing back missions
Creating 3d images of the flight path
Extracting parameters and Waypoints
Graphing data from a flight
Video overview of tlogs
Images with Mission Planner
MAVLink2 Signing (security)
Using Python Scripts in Mission Planner
Swarming
Advanced Tools
Language Translations
Compass Calibration
Accelerometer Calibration
Radio Control Calibration
RC Transmitter Flight Mode Configuration
Live Video
OpenDroneID Panel
Mission Planner Building

--- chunk_id: chunk-0307
source_document: mission-planner-telemetry-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 98
content_hash: 97f35010869410ce
prev_chunk_id: chunk-0306
next_chunk_id: chunk-0308
document_type: technical_reference

Appendix
Individual
Partners
SWAG Shop



Mission Planner
Mission Planner Features/Screens
Other Mission Planner Features
- Telemetry Logs
Edit on GitHub

# Telemetry Logs
# ¶
Telemetry logs (also known as “tlogs”) are recorded by the ground station when you connect ArduPilot to your
computer via a
telemetry link
. This topic explains how to configure and access tlogs. Note

Dataflash logs
collect similar information to tlogs (see
Diagnosing problems using Logs
for more information).

--- chunk_id: chunk-0308
source_document: mission-planner-telemetry-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 253
content_hash: 64636a4aedf61703
prev_chunk_id: chunk-0307
next_chunk_id: chunk-0309
section_heading: When and where tlogs are created
document_type: technical_reference

## When and where tlogs are created
### ¶
Tlogs are recordings of the MAVLink telemetry messages sent between the
autopilot and the ground station and are automatically created the moment
you press the connect button on the ground station. If using the Mission Planner, files of the
format YYYY-MM-DD hh-mm-ss.tlog appear in the “logs” subfolder in your
Mission Planner installation folder or to the location you select in the
Planner options [Config/Tuning] [Planner]. Besides the “.tlog” files, “.rlog” files are also created. These
contain all the .tlog data plus additional debug output from the mission
planner. but cannot be parsed or played back so they should be ignored. ### Setting the datarate
### ¶
The desired rate at which data is sent from the autopilot to the ground station can be controlled through the mission planner’s Config/Tuning > Planner screen’s Telemetry drop-downs. Because all data sent over the telemetry link is also recorded in the tlog, this also controls the rate of data saved to the tlogs. Note that due to bandwidth limitations, the actual rate of the data sent and saved may be lower than the rate requested.

--- chunk_id: chunk-0309
source_document: mission-planner-telemetry-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 212
content_hash: 0d895aad810be1c8
prev_chunk_id: chunk-0308
next_chunk_id: chunk-0310
section_heading: Playing back missions
document_type: technical_reference

## Playing back missions
### ¶
It is possible to play back a tlog by doing the following:

Open the mission planner’s Flight Data screen

click on the Telemetry Logs tab

Press “Load Log” and find the flight’s tlog file

Press “Play”

You can also jump to the point of interest in the log using the slider
and control the speed of the playback with the predefined Speed buttons. While the log is replaying, the HUD will move and the vehicles location
on the map will update as it did during the flight. Individual data
values can be seen through the Status tab and you can even display them
in a graph by clicking on the “Tuning” checkbox under the map and then
double clicking on the data legend to bring up a box from which you can
choose exactly which data fields are graphed as shown below. This will
show the recorded data changing as the flight progresses.

--- chunk_id: chunk-0310
source_document: mission-planner-telemetry-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 281
content_hash: 9f8b0c0bbeb87abf
prev_chunk_id: chunk-0309
next_chunk_id: chunk-0311
section_heading: Creating 3d images of the flight path
document_type: technical_reference

## Creating 3d images of the flight path
### ¶
You can create KMZ files by doing this:

Open the mission planner’s Flight Data screen

Click on the Telemetry Logs tab

Press the “Tlog > Kml or Graph” button

Press the “Create KML + GPX” button

select the flight tlog

A .kmz and .kml file will be created along side the original .tlog and
this can be opened in google earth to interactively view the 3d flight
path. You can open the kmz file in Google Earth to view the flight or
path. Just double click the file or drag it and drop into Google Earth. The different flight modes used during the flight will appear as
different colored tracks. You can change some details about how the
flight paths are displayed including their color and whether the paths
extend to the ground by doing this:

Find the log file’s name in the “Places” pane on the left. It should
appear in a “Temporary Places” folder. Right click on an individual path and select “Properties” to open the
Edit Path window. The color can be changed on the “Style, Color” tab

The area below the path can be removed (added) on the “Altitude” tab
by un-checking (checking) “Extend path to ground”

--- chunk_id: chunk-0311
source_document: mission-planner-telemetry-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 182
content_hash: 6847a0e400418379
prev_chunk_id: chunk-0310
next_chunk_id: chunk-0312
section_heading: Extracting parameters and Waypoints
document_type: technical_reference

## Extracting parameters and Waypoints
### ¶
You can extract the parameters and waypoints from the tlog by following
the same steps as for creating the KML file except that at the last step
select “Extract Params” or “Extract WPs”. Extract Params will cause a .param file to be created along side the
tlog. This file is tab separated and contains a full list of parameters
(in the same order as they appear in the eeprom) along with their values
during the flight. This can be opened in excel or a text editor. Extract WPs will create one or more .txt files containing any missions
uploaded to the autopilot. These files can be opened in the Mission
Planner by switching to the Flight Plan screen, right-mouse-button
clicking on the map and selecting “File Load/Save”, “Load WP File”.

--- chunk_id: chunk-0312
source_document: mission-planner-telemetry-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: 7b0921345372b665
prev_chunk_id: chunk-0311
next_chunk_id: chunk-0313
section_heading: Graphing data from a flight
document_type: technical_reference

## Graphing data from a flight
### ¶
Data from the flight can be graphed by doing the following:

Open the mission planner’s Flight Data screen

Click on the Telemetry Logs tab

Press the “Tlog > Kml or Graph” button

Press the “Graph Log” button

select the flight tlog

When the “Graph This” screen appears, use the left or right mouse
button to click on the checkboxes beside the items you wish to
graph. Note that the items are grouped into categories like
“RC_CHANNELS” and “RAW_IMU” although it’s still often difficult to
find exactly the item you wish to graph

If you use the left mouse button the scale for the item will appear
on the left of the graph. If you use the right mouse button it will
appear on the right

Click the checkbox multiple times to cycle through all the possible
colours

Change the zoom of the graph with your mouse’s middle wheel, by
select an area of the graph with the left mouse button held down or
by right-mouse-button clicking on the graph and selecting “Set Scale
To Default”

--- chunk_id: chunk-0313
source_document: mission-planner-telemetry-logs.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 65
content_hash: 24422fad0afd51d0
prev_chunk_id: chunk-0312
next_chunk_id: chunk-0314
section_heading: Video overview of tlogs
document_type: technical_reference

## Video overview of tlogs
### ¶
Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0314
source_document: mode_autoland.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: e473c6d0132343d0
prev_chunk_id: chunk-0313
next_chunk_id: chunk-0315
document_type: technical_reference

AUTOLAND Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- AUTOLAND Mode
Edit on GitHub

# AUTOLAND Mode
# ¶
AUTOLAND mode provides a fully automatic fixed wing landing which can also be used as an RC failsafe action. In TAKEOFF, FBWA, MANUAL, TRAINING, ACRO,  STABILIZE modes, and during a NAV_TAKEOFF in AUTO, the takeoff direction will be captured from the GPS ground course once a GPS ground speed of 5m/s is obtained. This usually occurs early in the takeoff run of a rolling takeoff or almost immediately during a hand or bungee launch. It will setup a parameterized LOITER-TO-ALT base waypoint and final approach waypoint/altitude, based on the takeoff direction, and proceed to it, loiter down in altitude if required, and then switch to an automatic landing at home. It can also be selected as a
FS_LONG_ACTN
for RC failsafes. This is useful when programming a mission with a
DO_LAND_START
landing sequence is not convenient since it requires a GCS on a laptop or phone, such as traveling with impromptu stops to fly FPV or photograph. Simply takeoff in one of the previously mentioned modes and the AUTOLAND will be setup.

--- chunk_id: chunk-0315
source_document: mode_autoland.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 245
content_hash: b566db53650fb692
prev_chunk_id: chunk-0314
next_chunk_id: chunk-0316
document_type: technical_reference

This is useful when programming a mission with a
DO_LAND_START
landing sequence is not convenient since it requires a GCS on a laptop or phone, such as traveling with impromptu stops to fly FPV or photograph. Simply takeoff in one of the previously mentioned modes and the AUTOLAND will be setup. It is also useful for fields which have varying wind directions, which would prevent using a single home-loaded autolanding mission or require using the MissionSelector LUA script to select from several missions with different approaches. Upon entry, an optional minimum climb to an above ground alt before turning can be programmed, which can be useful if it is used for RC failsafe when this occurs during takeoff to climb to an altitude to clear obstacles or to get a minimum altitude above current terrain before turning toward the landing approach. If
TERRAIN_FOLLOW
is set to 1 or “AUTOLAND”, then the vehicle will terrain follow as it flies to the LOITER-TO-ALT base waypoint. AUTOLAND mode may be entered either as a
normal flight mode switch
or as an
RC Auxiliary switch
set to “183”.

--- chunk_id: chunk-0316
source_document: mode_autoland.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 173
content_hash: b8433a7b91485204
prev_chunk_id: chunk-0315
next_chunk_id: chunk-0317
section_heading: Operation
document_type: technical_reference

## Operation
### ¶
To use simply make a takeoff and at any point later switch into AUTOLAND. A final approach waypoint will be created behind the HOME landing target at
AUTOLAND_WP_DIST
(400m by default) at
AUTOLAND_WP_ALT
(55m by default)using the takeoff direction plus
AUTOLAND_DIR_OFF
(“0” default) and land using all the parametrics of a normal autolanding. A loiter to alt waypoint tangential to the final approach waypoint is also created at the same altitude and at 1/3
AUTOLAND_WP_DIST
or
WP_LOITER_RAD
, whichever is smaller, from the final approach waypoint as shown below:

LAND
parameter defaults are usually acceptable for most planes in the 1-2m wingspan, <2kg class) and should yield a safe, if not optimally tuned, autolanding. LAND
parameters can be optimized with test flights (See
Automatic Landing
).

--- chunk_id: chunk-0317
source_document: mode_autoland.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 181
content_hash: 69bacd6014e7db1f
prev_chunk_id: chunk-0316
next_chunk_id: chunk-0318
section_heading: Options
document_type: technical_reference

## Options
### ¶
The
AUTOLAND_OPTIONS
bitmask provides optional behavior. Currently, if bit 0 is set, then instead of capturing takeoff direction( and therefore autolanding direction), the landing direction will be captured immediately at arming if a compass is being used. This allows the direction to be set “manually” by orienting the plane at homw in the desired landing direction and arming. The
AUTOLAND_DIR_OFF
parameter is ignored in this case. A minimum climb  of
AUTOLAND_CLIMB
can be set, during which navigation (roll) is limited to
LEVEL_ROLL_LIMIT
. If AUTOLAND is being used as a
FS_LONG_ACTN
, then setting this to allow clearing takeoff obstacles to the sides is recommended. The climb altitude will be above terrain, if enabled, or using rangefinder, if enabled and in range, or just relative to current altitude if neither is available.

--- chunk_id: chunk-0318
source_document: mode_autoland.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 200
content_hash: 4a8a674601b6f5f4
prev_chunk_id: chunk-0317
next_chunk_id: chunk-0319
section_heading: Notes:
document_type: technical_reference

## Notes:
### ¶
Switching out of AUTOLAND to another mode aborts the landing and returns control to that new mode. Throttle aborts of the final landing sequence are not supported. (
LAND_ABORT_THR
)

If the plane has taken off not using the aforementioned modes, the mode cannot be entered since the takeoff direction has not been captured. In these cases, if it is selected as a long failsafe action (“5”),
FS_LONG_ACTN
, it will switch to normal RTL instead of AUTOLAND on failsafe. The mode co-exists with any mission autolanding sequence, which can be used in AUTO mode, or with
RTL_AUTOLAND
. QuadPlanes cannot use this mode. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0319
source_document: navigation-tuning.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 300
content_hash: de66c72108c1d050
prev_chunk_id: chunk-0318
next_chunk_id: chunk-0320
document_type: technical_reference

Navigation Tuning — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Center of Gravity
Starting up and calibrating Plane
Pre-Arm Safety Checks
Arming Plane
Takeoff
Tuning Quickstart
Automatic Tuning
Tuning in Detail
Tuning QuickStart
Automatic Tuning with AUTOTUNE
Manual Roll, Pitch and Yaw Controller Tuning(firmware 4.1 and after)
Manual Roll, Pitch and Yaw Controller Tuning(firmware before 4.1)
Navigation Tuning
Navigation Tuning with the L1 Controller
Steps to tuning the L1 controller
Tuning waypoint transition behaviour
L1 Controller Background & Description
Cruise Speed Tuning
TECS (Total Energy Control System) for Speed & Height – Tuning Guide
Calibrating an Airspeed Sensor
Tuning Ground Steering for a Plane
Tuning Configuration Values for Common Airframes
Measuring Vibration
Transmitter based tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
First Flight
Tuning
- Navigation Tuning
Edit on GitHub

# Navigation Tuning
# ¶

--- chunk_id: chunk-0320
source_document: navigation-tuning.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 484
content_hash: 40f92ed616b48405
prev_chunk_id: chunk-0319
next_chunk_id: chunk-0321
section_heading: Navigation Tuning with the L1 Controller
document_type: technical_reference

## Navigation Tuning with the L1 Controller
### ¶
Starting with Plane 2.72 a new navigation controller called the “L1
controller” was introduced. This controller produces much more accurate
flight paths both for waypoints and loiter than the previous crosstrack
and PID controller. Tuning the navigation controller usually involves adjusting one key
parameter, called
NAVL1_PERIOD
. The default is 20, which results in
reasonable turns for most R/C airframes. A smaller value for
NAVL1_PERIOD
will lead to more aggressive navigation (sharper corners). A larger value will lead to gentler navigation. You can additionally
adjust the
NAVL1_DAMPING
and
WP_RADIUS
for further tuning. ### Steps to tuning the L1 controller
### ¶
Make sure you have already tuned the roll and pitch controller,
correctly trimmed your plane, and have ensured the plane does not
gain or lose altitude in turns

Make sure you have setup
ROLL_LIMIT_DEG
to an appropriate value for
the bank angle you are comfortable with your plane flying without
stalling. For slow flying electric gliders a value of around 5000 (50
degrees) is a good start. For fast flying aerobatic planes you may
wish to use a larger value, such as 6500 (65 degrees). Setup a rectangular mission for your plane to fly, with a loop so it
repeats the mission continuously. Ensure that the size of the mission
is small enough that you will have a good view of the aircraft at all
times

Set
NAVL1_PERIOD
to the default value of 17, and
NAVL1_DAMPING
to
the default value of 0.75. Set
WP_RADIUS
to the distance your plane
would fly in 2 seconds at cruise speed. Takeoff and put the plane in AUTO using your transmitter switch

Observe the behaviour of the plane in the turns. If it turns too
slowly then reduce
NAVL1_PERIOD
by 5. If it is “weaving” after a
turn then increase
NAVL1_PERIOD
by 1 or 2

If you are tuning for maximum performance, once you have completed
the tuning of
NAVL1_PERIOD
you can increment
NAVL1_PERIOD
by 1 and
then modify
NAVL1_DAMPING
in steps of 0.05 to get the
response you want. Do not decrease
NAVL1_DAMPING
too much - it is
unlikely you will need a value below 0.6.

--- chunk_id: chunk-0321
source_document: navigation-tuning.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: 63b3dde7bef32425
prev_chunk_id: chunk-0320
next_chunk_id: chunk-0322
section_heading: Tuning waypoint transition behaviour
document_type: technical_reference

## Tuning waypoint transition behaviour
### ¶
To control whether Plane flies through a waypoint, then turns afterwards
or turns before the waypoint so that it neatly lines up for the next leg
of the mission you should adjust the waypoint radius via the
WP_RADIUS
parameter. If you want Plane to fly through the waypoint then set the
WP_RADIUS
to a small number, perhaps 10 meters. If you want Plane to
turn before the waypoint so that it lines up with the next leg of the
mission then set
WP_RADIUS
to a larger number. A good starting value is
to set it equal to the turn radius your aircraft can easily achieve. This will normally be the same as your loiter radius
WP_LOITER_RAD
. ### L1 Controller Background & Description
### ¶
The L1 controller concept is based on the following technical paper:

S
. Park
,
J
. Deyst
,
and
J
. P
. How
,
"A New Nonlinear Guidance Logic for
Trajectory
Tracking
,
" Proceedings of the AIAA Guidance, Navigation and
Control
Conference
,
Aug
2004. AIAA
-
2004
-
4900. This was the basis for Brandon Jones’ original pull request:
https://github.com/ArduPilot/ardupilot/pull/101

These algorithms were subsequently modified by Paul Riseborough with the
following changes:

The L1 length was calculated dynamically to enable a constant period
for the tracking loop to be specified by the user and to enable the
navigation loop gain to automatically adjust for changes in aircraft
ground speed. Achieving a constant period for the guidance loop gives
a consistent response across a range of airspeeds and enables the
tuning parameter to be related to the time required to roll the
aircraft and measure its response. The guidance gain was changed from a fixed value of 2 to be
calculated based on the
NAVL1_DAMPING
value set by the user. This
enabled additional damping to be specified to compensate for delays
in the velocity measurement and aircraft roll response. A complementary filter fusing GPS velocities, airspeed and aircraft
heading was used to estimate the ground speed vector. This enabled
the accuracy of the GPs velocity to be taken advantage of, without
the limitations imposed by its inherent latency. The track capture algorithm was modified to enable explicit control
over the track capture angle.

--- chunk_id: chunk-0322
source_document: navigation-tuning.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 248
content_hash: 316de48e84210c0f
prev_chunk_id: chunk-0321
next_chunk_id: chunk-0323
section_heading: Tuning waypoint transition behaviour
document_type: technical_reference

This enabled
the accuracy of the GPs velocity to be taken advantage of, without
the limitations imposed by its inherent latency. The track capture algorithm was modified to enable explicit control
over the track capture angle. The waypoint circle tracking algorithm used during RTL, GUIDED and
LOITER modes was modified to use a modified PD control law rather
than the L1 control law. This was necessary to enable small loiter
radius’ to be flown in combination with larger values of
NAVL1_PERIOD
. The distance from the next waypoint to start the turn onto the next
track segment was modified to use the L1 length dynamically
calculated by the algorithm, but constrained to be no greater than
WP_RADIUS
. This enabled the user to select whether they would rather
fly through the waypoint and then turn, or turn early and smoothly
intercept the next track. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0323
source_document: plane-configuration-landing-page.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 465
content_hash: 67ccd84fc07c60bb
prev_chunk_id: chunk-0322
next_chunk_id: chunk-0324
document_type: technical_reference

Plane Configuration — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
- Plane Configuration
Edit on GitHub

# Plane Configuration
# ¶
This section contains topics related to configuring and testing Plane
components, including those required for the operation of the autopilot. Note

In addition to the configuration discussed in this section, you
may also choose to
Configure Optional Hardware
including battery monitor, sonar,
airspeed sensor, optical flow, OSD, camera gimbal, antenna tracker
etc. Note

ARSPD_TYPE
defaults to MS4525. If you don’t have an Airspeed sensor or don’t have an MS4525 then you should change it and other airspeed related parameters, appropriately. Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane




Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0324
source_document: rtl-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 476
content_hash: 437e6727ceaa7399
prev_chunk_id: chunk-0323
next_chunk_id: chunk-0325
document_type: technical_reference

RTL Mode (Return To Launch) — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- RTL Mode (Return To Launch)
Edit on GitHub

# RTL Mode (Return To Launch)
# ¶
In RTL mode the plane will return to its home location (the point where the
plane armed - assuming it had GPS lock) and loiter there until given
alternate instructions (or it runs out of fuel!). As with
AUTO
mode
you can also “nudge” the aircraft manually in this mode using stick
mixing (assuming the RTL was not a result of RC failsafe). The target altitude for RTL mode is set using the
RTL_ALTITUDE
parameter in meters. When initiated below
RTL_ALTITUDE
, Plane will immediately climb at maximum allowable rate to reach that altitude, if above, it will descend in a linear manner versus distance to home, reaching that altitude at the home loiter point. The loiter radius at home is determined by
RTL_RADIUS
, if it’s non-zero, otherwise
WP_LOITER_RAD
is used. Clock-wise or Counter-Clock-wise circling can be set by positive or negative values for the radius.

--- chunk_id: chunk-0325
source_document: rtl-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 162
content_hash: 264dffdc623cdfbb
prev_chunk_id: chunk-0324
next_chunk_id: chunk-0326
document_type: technical_reference

The loiter radius at home is determined by
RTL_RADIUS
, if it’s non-zero, otherwise
WP_LOITER_RAD
is used. Clock-wise or Counter-Clock-wise circling can be set by positive or negative values for the radius. Additionally, in firmware versions 4.0.6 and later, by setting
RTL_CLIMB_MIN
to a non-zero value, the plane will climb that many meters, limited in bank angle by
LEVEL_ROLL_LIMIT
degrees until the additional altitude is reached, then begin the above return to home action from that altitude. To prevent the vehicle from turning until the return atlitude is reached, if below that value(
RTL_ALTITUDE
+
RTL_CLIMB_MIN
), set bit 4 of the
FLIGHT_OPTIONS
bitmask. Alternatively, you may
configure the plane to return to a Rally Point
, rather than the home location.

--- chunk_id: chunk-0326
source_document: rtl-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 254
content_hash: 1f9350151d44d912
prev_chunk_id: chunk-0325
next_chunk_id: chunk-0327
section_heading: RTL_AUTOLAND
document_type: technical_reference

## RTL_AUTOLAND
### ¶
It is possible to setup an
Automatic Landing
to be executed when entering RTL. See
Using DO_LAND_START
for details. You must have setup your vehicle to properly do a automatic landing, of course. Warning

“Home” position is always supposed to be your Plane’s actual
GPS takeoff location:

It is very important to acquire GPS lock before arming in order for
RTL, Loiter, Auto or any GPS dependent mode to work properly. For Plane the home position is initially established at the time the
plane acquires its GPS lock. It is then continuously updated as long as
the autopilot is disarmed. This means if you execute an RTL in Plane, it will return to the location where it was when it was armed - assuming it had acquired GPS lock. Consider the use of
Rally Points
to avoid returning directly to your arming point on RTL






Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0327
source_document: stabilize-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 498
content_hash: dc726431328bcca3
prev_chunk_id: chunk-0326
next_chunk_id: chunk-0328
document_type: technical_reference

STABILIZE Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- STABILIZE Mode
Edit on GitHub

# STABILIZE Mode
# ¶
RC control with simple stabilization. If you let go of the sticks then
Plane will level the plane. This is a bit like flying a plane with a lot
of dihedral. You will find that while it is possible to do maneuvers
like rolls and loops in stabilize mode, the tendency of the plane to
right itself will make these maneuvers difficult. For people wanting the
plane to mostly fly itself, with the pilot just telling it where to fly,
you are better off using the
FLY BY WIRE_A (FBWA)
mode. In stabilize mode the throttle is limited by the
THR_MIN
and
THR_MAX
settings. Note

STABILIZE mode is not a good mode to use for tuning the control
loops. You are far better off using
FLY BY WIRE_A (FBWA)
for that. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0328
source_document: takeoff-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 316
content_hash: f5a46d24a3eed1ad
prev_chunk_id: chunk-0327
next_chunk_id: chunk-0329
document_type: technical_reference

TAKEOFF Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- TAKEOFF Mode
Edit on GitHub

# TAKEOFF Mode
# ¶
Automatic takeoff can be accomplished either as a mission control command in AUTO mode (NAV_TAKEOFF) or by directly changing into the TAKEOFF mode. See also the
Automatic Takeoff
topic for general setup information for automatic takeoffs.

--- chunk_id: chunk-0329
source_document: takeoff-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 352
content_hash: 86579dff41539e87
prev_chunk_id: chunk-0328
next_chunk_id: chunk-0330
section_heading: NAV_TAKEOFF Mission Command
document_type: technical_reference

## NAV_TAKEOFF Mission Command
### ¶
The takeoff mission command specifies a takeoff pitch and a target altitude. The takeoff mission item is considered complete when the plane has
reached the target altitude specified in the mission. The mission will then execute its normal end of mission behavior if it runs out of commands in the mission list. For Plane, this is RTL. ### TAKEOFF Flight Mode
### ¶
Automatic Takeoff is also a mode itself. When entered, the plane will use maximum throttle as set by the
TKOFF_THR_MAX
parameter, climbing with
TKOFF_LVL_PITCH
maximum and takeoff roll limits (
LEVEL_ROLL_LIMIT
) up to the
TKOFF_ALT
altitude. Then, it will loiter at
TKOFF_ALT
altitude until the mode is changed. If the plane travels for
TKOFF_DIST
from the point where the mode is entered, before reaching
TKOFF_ALT
altitude, then it will loiter at that spot, still trying to climb to
TKOFF_ALT
. Once
TKOFF_LVL_ALT
is reached, or the loiter point distance is reached, maximum throttle and takeoff roll limits (
LEVEL_ROLL_LIMIT
) are stopped and normal navigation begins towards the loiter point and altitude. Normally,
TKOFF_LVL_ALT
is 10 meters and is intended to limit navigation (roll) in order to prevent wing tip ground strikes. If the mode is entered while already flying, it will immediately begin loitering as in LOITER mode if at or above
TKOFF_ALT
altitude above ground, otherwise it will climb to that altitude and then begin loitering . TAKEOFF mode can also be entered via a switch using an RCx_OPTION = 77, as well as via normal selection by the flight mode channel.

--- chunk_id: chunk-0330
source_document: takeoff-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: 0c6fd383507e0e10
prev_chunk_id: chunk-0329
next_chunk_id: chunk-0331
section_heading: TAKEOFF Heading
document_type: technical_reference

## TAKEOFF Heading
### ¶
Before takeoff it is important that the plane be pointing into the wind,
and be aligned with the runway (if a wheeled takeoff is used). The plane
will try to hold its heading during takeoff, with the initial heading
set by the direction the plane is facing when the takeoff starts. It is
highly recommended that a compass be enabled and properly configured for
auto takeoff, as takeoff with a GPS heading can lead to poor initial heading
control such that heading can different from the initial heading by tens of degrees during the climb. While this may not be an issue for hand launches, runway takeoffs require a compass for adequate heading control during the takeoff rollout. If you are using a wheeled aircraft then you should look at the
WHEELSTEER_*
PID settings for controlling ground steering. If you
are hand launching or using a catapult you should look at the
TKOFF_THR_MINACC
and
TKOFF_THR_MINSPD
parameters.

--- chunk_id: chunk-0331
source_document: takeoff-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 258
content_hash: 50a2d05f4b61e9e2
prev_chunk_id: chunk-0330
next_chunk_id: chunk-0332
section_heading: TAKEOFF Throttle
document_type: technical_reference

## TAKEOFF Throttle
### ¶
By default, Plane will set the throttle to
TKOFF_THR_MAX
(or if that is 0, to
THR_MAX
) up until it reaches
TKOFF_ALT
. This behaviour is reflected in the
TKOFF_OPTIONS
bit 0 setting, which by default is 0 (unset). In case more fine-grained throttle control is required, an airspeed sensor must be installed and enabled via the
ARPSD_USE
parameter and
TKOFF_OPTIONS
bit 0 must be set to 1. IF no airspeed sensor is enabled or
TECS_SYNAIRSPEED
is enabled (not recommended), then this bit has no effect. In this configuration, right after takeoff the throttle is set to
TKOFF_THR_MAX
for
TKOFF_THR_MAX_T
or until
TKOFF_LVL_ALT
(whichever lasts longer). Finally, the throttle will be managed by the TECS controller to achieve a speed controlled, maximum (
TECS_CLMB_MAX
) climb, ranging between
TKOFF_THR_MIN
and
TKOFF_THR_MAX
. The difference between these two throttle control options can be seen in the following diagrams:





Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0332
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: ee56b2f87561b676
prev_chunk_id: chunk-0331
next_chunk_id: chunk-0333
document_type: technical_reference

TECS (Total Energy Control System) for Speed and Height Tuning Guide — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
First Flight and Tuning
Center of Gravity
Starting up and calibrating Plane
Pre-Arm Safety Checks
Arming Plane
Takeoff
Tuning Quickstart
Automatic Tuning
Tuning in Detail
Tuning QuickStart
Automatic Tuning with AUTOTUNE
Manual Roll, Pitch and Yaw Controller Tuning(firmware 4.1 and after)
Manual Roll, Pitch and Yaw Controller Tuning(firmware before 4.1)
Navigation Tuning
Cruise Speed Tuning
TECS (Total Energy Control System) for Speed & Height – Tuning Guide
Calibrate the airspeed sensor
Tune the Pitch to Servo Loop
Set initial parameters — throttle, pitch, airspeed and vertical speed limits
Set initial parameters - when no airspeed sensor is used
Flight Testing
Fine Tuning
Advanced Parameters
Complete Parameter List
Algorithm Overview
Calibrating an Airspeed Sensor
Tuning Ground Steering for a Plane
Tuning Configuration Values for Common Airframes
Measuring Vibration
Transmitter based tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
First Flight
Tuning
- TECS (Total Energy Control System) for Speed and Height Tuning Guide
Edit on GitHub

# TECS (Total Energy Control System) for Speed and Height Tuning Guide
# ¶
This article explains how to tune the TECs system for speed and height
control.

--- chunk_id: chunk-0333
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 234
content_hash: 68163f10fa86c1af
prev_chunk_id: chunk-0332
next_chunk_id: chunk-0334
section_heading: Calibrate the airspeed sensor
document_type: technical_reference

## Calibrate the airspeed sensor
### ¶
This only applies if you are using an airspeed sensor. A properly installed and calibrated airspeed sensor enables your model
to fly with much better control over its airspeed, which in turn enables
lower speeds to be used safely, extending endurance. For this reason if
you are interested in maximising the climb performance and endurance of
your aircraft, using an airspeed sensor and setting it up properly is
worth the effort. Instructions on how to calibrate an airspeed sensor
can be found here
. Note

Glider Pilots:
Set
TECS_SPDWEIGHT
to 2.0,
and you can also use an airspeed sensor and take advantage of TECS
ability to control your airspeed. ### Tune the Pitch to Servo Loop
### ¶
The performance of the TECS speed and height controller is dependent on
having the pitch to servo control loop tuned correctly. Before tuning
TECS you need to have tuned the pitch loop following the instructions either in
Automatic Tuning with AUTOTUNE
or manually using
Roll, Pitch and Yaw Controller Tuning
.

--- chunk_id: chunk-0334
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 89
content_hash: c77491342c0454b5
prev_chunk_id: chunk-0333
next_chunk_id: chunk-0335
section_heading: Set initial parameters — throttle, pitch, airspeed and vertical speed limits
document_type: technical_reference

## Set initial parameters — throttle, pitch, airspeed and vertical speed limits
### ¶
If you have a properly calibrated airspeed sensor and a well tuned pitch
to servo loop, then the throttle, pitch angle, airspeed and vertical
speed limits limits are the final keys to getting the TECS algorithm to
perform well. Note

if you are not using an airspeed sensor, then skip down to the

--- chunk_id: chunk-0335
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: e0d7a533ccf25980
prev_chunk_id: chunk-0334
next_chunk_id: chunk-0336
section_heading: Section below for setting initial parameters without an airspeed sensor
document_type: technical_reference

Section below for setting initial parameters without an airspeed sensor
. The following instructions are based around taking a series of
measurements, whilst the plane is being flown at the speed set by
AIRSPEED_CRUISE
which represents the speed that you are most likely going to be flying
at. Flying these tests at
AIRSPEED_CRUISE
is impractical unless you
have an assistant calling out airspeed, so where these instructions ask
for the plane to be flown at
AIRSPEED_CRUISE
, fly at a speed in the middle zone between your
AIRSPEED_MIN
and
AIRSPEED_MAX
and that will be good enough for
most applications. Those users wanting to extract maximum performance
can dial the numbers in over a number of flights, using the log data. Set the maximum throttle percentage
THR_MAX
. The
maximum throttle should be set to a value that enables the aircraft
to climb at its maximum pitch angle (default value of 20 degrees) at
AIRSPEED_CRUISE
. The default value of 75% should be OK for
moderately powered aircraft. Low powered aircraft will need to
increase it to 100%, high powered models (capable of vertical climbs)
will need to reduce it. Set the throttle percentage required to fly level at
AIRSPEED_CRUISE
by adjusting the
TRIM_THROTTLE
parameter. This can be determined
initially by testing different throttle settings in FBWA mode. Set the maximum and minimum airspeed limits (in metres/second) using
the
AIRSPEED_MAX
and
AIRSPEED_MIN
parameters. AIRSPEED_MAX
should be set to just slightly less than the maximum speed your aircraft is
capable of in level flight with the throttle set to
THR_MAX
. AIRSPEED_MIN
should be set to the slowest speed your aircraft
can safely fly without stalling in level flight. Set the maximum pitch angle
PTCH_LIM_MAX_DEG
(in
degrees) your aircraft can fly with the throttle set to
THR_MAX
. This can be determined by performing maximum pitch angle
climbs in FBWA with the throttle set to the maximum and checking the
airspeed during climb. If the airspeed rises above
AIRSPEED_CRUISE
during
the climb, then either increase
PTCH_LIM_MAX_DEG
or
reduce
THR_MAX
. If it falls below
AIRSPEED_MIN
during
climb then either reduce
PTCH_LIM_MAX_DEG
or
increase
THR_MAX
. Make sure you allow some margin for reduction
in power due to reduced battery voltage or other effects.

--- chunk_id: chunk-0336
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 365
content_hash: b814e4ddaa822266
prev_chunk_id: chunk-0335
next_chunk_id: chunk-0337
section_heading: Section below for setting initial parameters without an airspeed sensor
document_type: technical_reference

If it falls below
AIRSPEED_MIN
during
climb then either reduce
PTCH_LIM_MAX_DEG
or
increase
THR_MAX
. Make sure you allow some margin for reduction
in power due to reduced battery voltage or other effects. Remember
that the amount of power from an electric power system at the end of
flight will only be 80% of what you have at the start. Note

Glider Pilots:
If a pure glider (no motor), set
PTCH_LIM_MAX_DEG
to a value low enough to assure that the glider will not stall if the autopilot demands that pitch angle. Set the minimum pitch angle
PTCH_LIM_MIN_DEG
(in degrees) your aircraft can fly with the throttle set to
THR_MIN
that can be flown without over-speeding the
aircraft. Set the maximum climb rate
TECS_CLMB_MAX
(in
metres/second). This is the best climb rate that the aircraft can
achieve with the throttle set to
THR_MAX
and flying at
AIRSPEED_CRUISE
. For electric aircraft make sure this number can be
achieved towards the end of flight when the battery voltage has
reduced. This can be measured in FBWA mode by performing climbs to
height with the throttle set to
THR_MAX
. Set the minimum sink rate
TECS_SINK_MIN
(in
metres/second). This is the sink rate of the aircraft with the
throttle set to
THR_MIN
and flown at
AIRSPEED_CRUISE
. This can
be measured by closing the throttle in FBWA and gliding the aircraft
down from height. Set the maximum sink rate
TECS_SINK_MAX
(in
metres/second). If this value is too large, the aircraft can
over-speed on descent. This should be set to a value that can be
achieved without exceeding the lower pitch angle limit and without
exceeding
AIRSPEED_MAX
.

--- chunk_id: chunk-0337
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 394
content_hash: 884652e757484529
prev_chunk_id: chunk-0336
next_chunk_id: chunk-0338
section_heading: Set initial parameters - when no airspeed sensor is used
document_type: technical_reference

## Set initial parameters - when no airspeed sensor is used
### ¶
Using a GCS and assistant, or flight logs:

Setup the desired cruising speed and throttle in FBWA. This can be adjusted using the
PTCH_TRIM_DEG
parameter to get level flight at the desired throttle level. If cruising speed is too great, lower throttle and increase
PTCH_TRIM_DEG
until altitude is constant, or vice-a-versa. Set the
TRIM_THROTTLE
to that throttle value. In FBWA, do a full throttle full back stick climb (you can also lower this throttle value with
THR_MAX
if full throttle seems excessive). Set
PTCH_LIM_MAX_DEG
such that you maintain close to the cruising speed, or at least not less than a safe flying speed. Note the steady state climb rate, and set
TECS_CLMB_MAX
to 80% of that value for margin at low battery. You can set lower pilot demanded climb rates with
FBWB_CLIMB_RATE
, but you want TECS to have the maximum capability of you aircraft for sudden altitude demand changes, like switching to RTL, to maximize its climbing ability in order to get out of bad situations. Set
TECS_PITCH_MAX
to
PTCH_LIM_MAX_DEG
. Now idle the throttle while sticks are centered and establish the  descent rate. Set
TECS_SINK_MIN
to that rate. Using idle throttle, push full down elevator and establish this new sink rate. If the aircraft overspeeds, set the
PTCH_LIM_MIN_DEG
to a higher value. Set
TECS_SINK_MAX
to that maximum sink rate. Note

AIRSPEED_MIN
,
AIRSPEED_CRUISE
, and
AIRSPEED_MAX
are not used when no airspeed sensor is present (unless
TECS_SYNAIRSPEED
is enabled, which is usually not recommended since the synthetic airspeed estimate can be very wrong on occasion. However,
AIRSPEED_MIN
and
AIRSPEED_MAX
should be set to the normal minimum and maximum flying speeds in order for
AUTOTUNE
and
STALL PREVENTION
features to work properly.

--- chunk_id: chunk-0338
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 485
content_hash: d7f40528e33204b0
prev_chunk_id: chunk-0337
next_chunk_id: chunk-0339
section_heading: Flight Testing
document_type: technical_reference

## Flight Testing
### ¶
Place the aircraft into a loiter about a waypoint either using auto,
RTL or guided mode. Check that the aircraft maintains height without
noticeable pitching or height changes greater than 10m. If the
aircraft appears to be oscillating in height then try
increasing
TECS_TIME_CONST
in increments
of 1 (do not increase to more than 10). If you need to increase to
more than 10 to reduce the oscillation in height, then this normally
indicates a problem with the pitch to servo loop tuning or the
settings of the pitch angle and climb rate limits. Verify that
THR_MAX
,
PTCH_LIM_MAX_DEG
and
TECS_CLMB_MAX
are set correctly. The setting of these parameters can be checked by
commanding a positive altitude change of no less than 50m in loiter,
RTL or guided mode. The objective is to set these parameters such
that the throttle required to climb is about 80% of
THR_MAX
,
the aircraft is maintaining airspeed, and the demanded pitch angle is
about 5 degrees below
PTCH_LIM_MAX_DEG
. If speed drops below the desired value, and the throttle increases
to and stays on
THR_MAX
, then either
TECS_CLMB_MAX
should
be reduced or
THR_MAX
increased. If the demanded pitch angle is constantly at the limit set
by
PTCH_LIM_MAX_DEG
, then either the pitch angle
limit
PTCH_LIM_MAX_DEG
needs to be increased or the maximum
climb rate
TECS_CLMB_MAX
needs to be reduced. Verify
PTCH_LIM_MIN_DEG
and
TECS_SINK_MAX
are set correctly. The
setting of these parameters can be checked by commanding a negative
altitude change of no less than 50m in loiter, RTL or guided mode. The
objective is to set these parameters such that the throttle is on
THR_MIN
, the airspeed is below
AIRSPEED_MAX
(or visually
confirm that model is not gaining too much speed if an airspeed sensor
is not being used), and the demanded pitch angle is about 5 degrees
above
PTCH_LIM_MIN_DEG
. If the speed is too high, then
TECS_SINK_MAX
should be reduced. If the demanded pitch angle is constantly at the limit set
by
PTCH_LIM_MIN_DEG
, then either the pitch angle
limit
PTCH_LIM_MIN_DEG
needs to be reduced (become more negative)
or the maximum sink rate
TECS_SINK_MAX
needs to be reduced.

--- chunk_id: chunk-0339
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 289
content_hash: 7fea16c2a0e7fe54
prev_chunk_id: chunk-0338
next_chunk_id: chunk-0340
section_heading: Flight Testing
document_type: technical_reference

If the speed is too high, then
TECS_SINK_MAX
should be reduced. If the demanded pitch angle is constantly at the limit set
by
PTCH_LIM_MIN_DEG
, then either the pitch angle
limit
PTCH_LIM_MIN_DEG
needs to be reduced (become more negative)
or the maximum sink rate
TECS_SINK_MAX
needs to be reduced. If the height response oscillates you can try increasing the value of
TECS_PTCH_DAMP
in increments of 0.1 (don’t go
above 0.5 unless you know how to check for excessive noise in the
nav_pitch signal using the mission planner tuning window) and then try
increasing the value of
TECS_TIME_CONST
in increments of 1.0. Note

If you are not using an airspeed sensor and you have problems with
pitch and height oscillation using the default parameters, then it
usually indicates that your pitch to servo loop has not been tuned
properly or your model could have a significant thrust line misalignment
where throttle changes cause noticeable pitch angle changes. You
should make sure your pitch loop tuning is adequate, before adjusting
TECS_PTCH_DAMP
and
TECS_TIME_CONST
as described above. If using airspeed sensing, adjust the value of
TRIM_THROTTLE
so
that it matches the average amount of throttle required by the
controller during constant height loiter. If not using airspeed sensing,
adjust
TRIM_THROTTLE
to achieve a level flight speed you are happy
with.

--- chunk_id: chunk-0340
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 341f3ec50754d3e3
prev_chunk_id: chunk-0339
next_chunk_id: chunk-0341
section_heading: Fine Tuning
document_type: technical_reference

## Fine Tuning
### ¶
The following parameters can be adjusted to fine-tune the controller
response:

THR_SLEWRATE
: This
is the maximum % change in throttle over one second . A setting of 100
means to not change the throttle by more than 100% of the full throttle
range in one second. Reducing this value will reduce the amount of
throttle ‘surging’ in windy conditions but will reduce controller
accuracy and will produce oscillation in throttle, speed and height if
reduced too much. TECS_THR_DAMP
:
This is the damping gain for the throttle demand loop. Increase to add
damping to correct for oscillations in speed and height. This gain has
no effect if an airspeed sensor is not being used. TECS_INTEG_GAIN
: This
is the integrator gain on the control loop. Increasing this gain
increases the speed at which speed and height offsets are trimmed out,
but reduces damping and increases overshoot. TECS_RLL2THR
:
Increasing this gain turn increases the amount of throttle that will be
used to compensate for the additional drag created by turning. Ideally
this should be set to approximately 10 x the extra sink rate in m/s
created by a 45 degree bank turn. Increase this gain if the aircraft
initially loses energy in turns and reduce if the aircraft initially
gains energy in turns. Efficient high aspect-ratio aircraft (eg powered
sailplanes) can use a lower value, whereas inefficient low aspect-ratio
models (eg delta wings) can use a higher value. This gain has no
effect if an airspeed sensor is not being used. TECS_SPDWEIGHT
:
This parameter adjusts the amount of weighting that the pitch control
applies to speed vs height errors. Setting it to 0.0 will cause the
pitch control to control height and ignore speed errors. This will
normally improve height accuracy but give larger airspeed
errors. Setting it to 2.0 will cause the pitch control loop to control
speed and ignore height errors. This will normally reduce airspeed
errors, but give larger height errors. The default value of 1.0 allows
the pitch control to simultaneously control height and speed. Note

This parameter is has no effect if the TECS has no airspeed estimate, in which
case a value of 0.0 will be used. To provide an airspeed estimate an airspeed
sensor must be installed, or
TECS_SYNAIRSPEED
must be
set to 1.

--- chunk_id: chunk-0341
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: c7efaa0f75813d73
prev_chunk_id: chunk-0340
next_chunk_id: chunk-0342
section_heading: Fine Tuning
document_type: technical_reference

Note

This parameter is has no effect if the TECS has no airspeed estimate, in which
case a value of 0.0 will be used. To provide an airspeed estimate an airspeed
sensor must be installed, or
TECS_SYNAIRSPEED
must be
set to 1. Note

Glider Pilots
: Set this parameter to 2.0 (The glider will
adjust its pitch angle to maintain airspeed, ignoring changes in
height). Note

When the
soaring
feature is in use and is requesting the TECS shut off
throttle to glide, a value of 2.0 will automatically be used providing an airspeed
estimate is available. TECS_PTCH_FF_K
:
This parameter can be used together with
TECS_PTCH_FF_V0
to provide a
feedforward gain between demanded airspeed and pitch attitude. This is best
used with
TECS_SPDWEIGHT
set to 2.0. As noted above, this is appropriate for
gliders, and setting
TECS_PTCH_FF_K
can improve the responsiveness to changes
in speed demand. Note

The units of this parameter are radians of pitch per metre per second between
current demanded airspeed and TECS_PTCH_FF_V0. Appropriate values are negative
(pitch down with increasing speed demand). Sensible starting values are -0.04
for gliders and -0.08 for draggy airframes. To tune this parameter, either use FBWB to manually input speed demand changes,
or set up a mission involving DO_CHANGE_SPEED items. Set TECS_PTCH_FF_V0 to the
normal flight speed of your aircraft. This should also be the speed it glides at
with no pitch input in FBWA mode (i.e. when flying at a pitch attitude specified
by the
STAB_PITCH_DOWN
parameter). When reviewing the log from such a flight, look
at the TECS pitch integrator item (TECS.iph) in the onboard logs. Usually this
reduces (becomes more negative) to trim the aircraft nose-down for a higher airspeed,
and vice versa. The goal is to use the feed-forward gain to reduce the required
changes in this integrator value to trim the aircraft to a new airspeed. If the
TECS.iph value becomes more negative when the demanded airspeed increases, make the
TECS_PTCH_FF_K
more negative. If the TECS.iph value becomes
more positive when the demanded aispeed increases, make the
TECS_PTCH_FF_K
value more positive. When this process in complete and the feed-forward gain is providing
most of the pitch attitude change needed, the TECS.iph value doesn’t need to change much. This gives better tracking of changes in demanded airspeed.

--- chunk_id: chunk-0342
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 210
content_hash: 1fe090dc8888f027
prev_chunk_id: chunk-0341
next_chunk_id: chunk-0343
section_heading: Advanced Parameters
document_type: technical_reference

## Advanced Parameters
### ¶
TECS_VERT_ACC
:
This is the maximum vertical acceleration either up or down that the
controller will use to correct speed or height errors. The default value
of 7 m/s/s (equivalent to +- 0.7 g) allows for reasonably aggressive
pitch changes if required to recover from under-speed conditions. TECS_HGT_OMEGA
:
This is the cross-over frequency (in radians/second) of the
complementary filter used to fuse vertical acceleration and barometric
height to obtain an estimate of height rate and height. Increasing this
frequency weights the solution more towards use of the barometer, whilst
reducing it weights the solution more towards use of the accelerometer data. TECS_SPD_OMEGA
:
This is the cross-over frequency (in radians/second)of the
complementary filter used to fuse longitudinal acceleration and airspeed
to obtain an improved airspeed estimate. Increasing this frequency
weights the solution more towards use of the airspeed sensor, whilst
reducing it weights the solution more towards use of the accelerometer
data.

--- chunk_id: chunk-0343
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: c66fd1314ef07845
prev_chunk_id: chunk-0342
next_chunk_id: chunk-0344
section_heading: Complete Parameter List
document_type: technical_reference

## Complete Parameter List
### ¶
THR_MAX
:
This is the maximum throttle % that can be used by the controller. For
overpowered aircraft, this should be reduced to a value that provides
sufficient thrust to climb at the maximum pitch angle
PTCH_LIM_MAX_DEG
. THR_MIN
: This
is the minimum throttle % that can be used by the controller. For
electric aircraft this will normally be set to zero, but can be set to a
small non-zero value if a folding prop is fitted to prevent the prop
from folding and unfolding repeatedly in-flight or to provide some
aerodynamic drag from a turning prop to improve the descent rate. THR_SLEWRATE
(definition above)

TRIM_THROTTLE
:
This is the throttle % required for level flight at the normal cruise
speed. AIRSPEED_MAX
:
This is the maximum airspeed (in metres/second) that the autopilot will
use in auto-throttle modes. It should be set to the highest speed that
the aircraft can achieve in level flight with the throttle set to
THR_MAX
. It must be sufficiently above the
AIRSPEED_MIN
value
to allow the autopilot to accurately control altitude using airspeed (at
least 50% above
AIRSPEED_MIN
is recommended). For electric
aircraft, make sure this number is achievable at the end of flight when
the battery voltage has reduced. AIRSPEED_MIN
: This
is the minimum indicated airspeed (in metres/second) that the speed
controller will attempt to control to. This should be set to a speed
that allows the aircraft to turn at the maximum bank angle without
stalling. TECS_CLMB_MAX
:
This is the best climb rate (in metres/second) that the aircraft can achieve
with the throttle set to
THR_MAX
and the airspeed set to the default
value. For electric aircraft make sure this number can be achieved
towards the end of flight when the battery voltage has reduced. The
setting of this parameter can be checked by commanding a positive
altitude change of 100m in loiter, RTL or guided mode. If the throttle
required to climb is close to
THR_MAX
and the aircraft is
maintaining airspeed, then this parameter is set correctly. If
the airspeed starts to reduce, then the parameter is set to high, and if
the throttle demand required to climb and maintain speed is noticeably
less than
THR_MAX
, then either
TECS_CLMB_MAX
should be increased or
THR_MAX
reduced.

--- chunk_id: chunk-0344
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: b8c218f6c33286be
prev_chunk_id: chunk-0343
next_chunk_id: chunk-0345
section_heading: Complete Parameter List
document_type: technical_reference

If the throttle
required to climb is close to
THR_MAX
and the aircraft is
maintaining airspeed, then this parameter is set correctly. If
the airspeed starts to reduce, then the parameter is set to high, and if
the throttle demand required to climb and maintain speed is noticeably
less than
THR_MAX
, then either
TECS_CLMB_MAX
should be increased or
THR_MAX
reduced. TECS_SINK_MIN
:
This is the sink rate of the aircraft (in metres/second) with the throttle
set to
THR_MIN
and flown at the same airspeed as used to measure
TECS_CLMB_MAX: Maximum Climb Rate (metres/sec)
. TECS_TIME_CONST
:
This is the time constant of the TECS control algorithm (in seconds). Smaller
values make it faster to respond, larger values make it slower to respond. TECS_THR_DAMP
(definition above)

TECS_INTEG_GAIN
(definition above)

TECS_VERT_ACC
(definition above)

TECS_HGT_OMEGA
(definition above)

TECS_SPD_OMEGA
(definition above)

PTCH_LIM_MAX_DEG
:
This is the maximum pitch angle (in degrees) that the controller
will demand. It should be set to a value that the aircraft can achieve
whilst maintaining airspeed with the throttle set to
THR_MAX: Maximum Throttle
. PTCH_LIM_MIN_DEG
:
This is the minimum pitch angle (in degrees) that the controller
will demand. It should be set to a value that the aircraft can achieve
without over-speeding with the throttle set to
THR_MIN
. TECS_RLL2THR
(definition above)

TECS_SPDWEIGHT
(definition above)

TECS_PTCH_DAMP
:
This is the damping gain for the pitch demand loop. Increase to add
damping to correct for oscillations in height. The default value of 0.0
will work well provided the pitch to servo controller has been tuned
properly. TECS_SINK_MAX
:
This sets the maximum descent rate (in metres/second) that the
controller will use. If this value is too large, the aircraft can
over-speed on descent. This should be set to a value that can be
achieved without exceeding the lower pitch angle limit and without
over-speeding the aircraft.

--- chunk_id: chunk-0345
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: 1ff2b38a73310ee0
prev_chunk_id: chunk-0344
next_chunk_id: chunk-0346
section_heading: Algorithm Overview
document_type: technical_reference

## Algorithm Overview
### ¶
TECS stands for Total Energy Control System and for Plane refers to a
new control algorithm that coordinates throttle and pitch angle demands
to control the aircraft’s height and airspeed. The underlying physics
behind the operation of TECS is simple, but to understand how it works
you need to understand the two types of mechanical energy that TECS
controls. These are:

Gravitational
Potential
Energy
=
mass
x
gravity
x
height


and,

Kinetic Energy = ½ x mass x speed²


Gravitational Potential Energy is the energy stored in an object due to
its height and is proportional to the height of the object. We all know
intuitively that to raise the height of an object requires energy and
that when an object falls energy is released. Similarly, to increase the
height of our aircraft requires more energy, which means more throttle
is required. Kinetic energy is the energy stored in an object due to its velocity and
is proportional to velocity squared. An example is a rifle bullet, which
although it doesn’t weigh very much, has a lot of energy due to its high
speed. Our aircraft don’t travel at the speeds of rifle bullet, but they
do require energy to be supplied to increase their speed. The total energy of the aircraft is the sum of the gravitational
potential energy and the kinetic energy. The drag acting on an aircraft
in flight is continually reducing its total energy, so the only way to
maintain height and speed is to supply thrust using a motor or utilise
energy from some other external source such as a rising air current. TECS calculates the total energy required based on the demanded speed
and height and adjusts the throttle to maintain total energy at the
demanded value. The other job of the TECS algorithm is to ensure that the balance
between gravitational potential and kinetic energy is correct. For
example if the aircraft is flying too slow and too high simultaneously,
its total energy might be correct, but there is too much potential
energy and not enough kinetic energy. TECS tries to maintain the correct
balance between potential and kinetic energy by adjusting the demanded
pitch angle. By lowering the nose energy is transferred from
gravitational potential to kinetic energy or vice-versa.

--- chunk_id: chunk-0346
source_document: tecs-total-energy-control-system-for-speed-height-tuning-guide.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 246
content_hash: c18cf95755647884
prev_chunk_id: chunk-0345
next_chunk_id: chunk-0347
section_heading: Algorithm Overview
document_type: technical_reference

TECS tries to maintain the correct
balance between potential and kinetic energy by adjusting the demanded
pitch angle. By lowering the nose energy is transferred from
gravitational potential to kinetic energy or vice-versa. How much weighting is placed on kinetic energy or speed errors vs
potential energy or height errors is controlled by the
TECS_SPDWEIGHT
parameter. At the default setting of 1.0, even weight
is placed on speed and height errors. If
TECS_SPDWEIGHT
is set to
0.0 then the pitch angle demand will respond 100% to height errors and
ignore speed and if set to 2.0 will respond 100% to speed errors and
ignore height. If the airspeed measurement is not used (as selected by
setting
ARSPD_USE
and
ARSPD2_USE
= 0), then the pitch angle will be used 100% to
control height and the throttle will be calculated from the demanded
pitch angle. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0347
source_document: thermal-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 453
content_hash: 085ec3bfd9e5cc22
prev_chunk_id: chunk-0346
next_chunk_id: chunk-0348
document_type: technical_reference

THERMAL Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- THERMAL Mode
Edit on GitHub

# THERMAL Mode
# ¶
If SOARING is enabled (
SOAR_ENABLE
= 1 and it has not been disabled by an RC switch (
RCx_OPTION
=88
), this mode will idle the throttle, and begin circling searching for vertical lift. This is the mode that is used for autonomous soaring (See
soaring-4_1
) and is automatically entered if a thermal is detected during the gliding portion of SOARING flight, and will begin circling searching for the lift center. THERMAL mode is exited under the following conditions:

SOAR_ALT_MAX
is reached. SOAR_ALT_MIN
is reached. Flight mode is changed by the pilot. The estimate of achievable climb rate falls below
SOAR_VSPEED
, and
thermalling has lasted at least
SOAR_MIN_THML_S
seconds. The aircraft drifts more than
SOAR_MAX_DRIFT
- see
Limit maximum distance from home


The flight mode will be returned to whatever it was before THERMAL was triggered.

--- chunk_id: chunk-0348
source_document: thermal-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 208
content_hash: 3ffed77eea4783f4
prev_chunk_id: chunk-0347
next_chunk_id: chunk-0349
document_type: technical_reference

The estimate of achievable climb rate falls below
SOAR_VSPEED
, and
thermalling has lasted at least
SOAR_MIN_THML_S
seconds. The aircraft drifts more than
SOAR_MAX_DRIFT
- see
Limit maximum distance from home


The flight mode will be returned to whatever it was before THERMAL was triggered. This mode can be triggered by the pilot from any mode (like FBWA) using the GCS or RC transmitter, in which case THERMAL mode will begin searching for lift until THERMAL mode exit conditions are met or the pilot commands a mode change

While in THERMAL mode, the airspeed target is set to
SOAR_THML_ARSPD
(meters/sec) if its non-zero, otherwise, if “0” (default) it will be set to
AIRSPEED_CRUISE
. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });

--- chunk_id: chunk-0349
source_document: training-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 28eaf492c229b4fe
prev_chunk_id: chunk-0348
next_chunk_id: chunk-0350
document_type: technical_reference

TRAINING Mode — Plane  documentation
Home
Copter
Plane
Rover
Blimp
Sub
AntennaTracker
Mission Planner
APM Planner 2
MAVProxy
Companion Computers
Developer
Downloads
Mission Planner
APM Planner 2
Advanced User Tools
Developer Tools
Firmware
Community
Support Forums
Facebook
Developer Chat (Discord)
Developer Voice (Discord)
Contact us
Getting involved
Commercial Support
Development Team
UAS Training Centers
Stores
About
News
History
License
Trademark
Acknowledgments
Wiki Editing Guide
Partners Program

Plane


Introduction to Plane
Choosing an Autopilot
Ground Control Stations
First Time Setup
Install Ground Station Software
Autopilot System Assembly
Loading Firmware to boards with existing ArduPilot firmware
Loading Firmware to boards without existing ArduPilot firmware
Connect Mission Planner to AutoPilot
Configuration
Basic System Overview
Choosing Servo Output Functions
RC Input Throw and Trim
Radio Control Calibration
Accelerometer Calibration
Compass Calibration
Flight Modes
Overview
Major Flight Modes
Flight Mode List
RC Transmitter Mode Setup
ESC Calibration
Automatic Trim
Failsafe Function
Airspeed Parameters Setup
Basic FPV Plane
Airframe Specific Setup Guides
First Flight and Tuning
QuadPlane Setup and Operation
Mission Planning
If A Problem Arises
Advanced Configuration
Peripheral Hardware
Additional Information
User Alerts
Individual
Partners
SWAG Shop



Plane
Setup for Plane
Plane Configuration
Flight Modes
- TRAINING Mode
Edit on GitHub

# TRAINING Mode
# ¶
TRAINING mode is ideal for teaching students manual R/C control. It
gives users complete control over the rudder and throttle, but clips the
maximum roll and maximum/minimum pitch to certain limits which cannot be
exceeded. TRAINING mode also restricts plane
roll to the
Stall Prevention
roll limits. More specifically:

If the roll is less the
ROLL_LIMIT_DEG
parameter than the pilot has manual roll control. If the plane tries
to roll past that limit then the roll will be held at that limit. The
plane will not automatically roll back to level flight, but it will
prevent the pilot from rolling past the limit. The same applies to
pitch - the pilot has manual pitch control until the
PTCH_LIM_MIN_DEG
or
PTCH_LIM_MAX_DEG
limits are reached, at which point the plane won’t allow the pitch to
go past those limits. When turning, the autopilot will monitor the demanded bank angle and
airspeed and work out if there is a sufficient margin above the stall
speed to turn at the demanded bank angle. If not the bank angle is
limited to the safe value.

--- chunk_id: chunk-0350
source_document: training-mode.html
page: 1
quality: 0.95
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 217
content_hash: 8dda2689756b284f
prev_chunk_id: chunk-0349
next_chunk_id: null
document_type: technical_reference

When turning, the autopilot will monitor the demanded bank angle and
airspeed and work out if there is a sufficient margin above the stall
speed to turn at the demanded bank angle. If not the bank angle is
limited to the safe value. The stall prevention system will always
allow a bank of at least 25 degrees (to ensure you can still
manoeuvre if your airspeed estimate is badly off). The rudder and throttle are both completely under manual control. Note

the
MAN_EXPO_ROLL
,
MAN_EXPO_PITCH
, and
MAN_EXPO_RUDDER
parameters will apply exponential to the stick inputs, if non-zero, in this mode. This is for users with transmitters which do not provide this function and desire to “soften” stick feel around neutral. Previous
Next

Questions, issues, and suggestions about this page can be raised on the
forums
. Issues and suggestions may be posted on the forums or the
Github Issue Tracker
. © Copyright 2024, ArduPilot Dev Team. jQuery(function () {
          SphinxRtdTheme.Navigation.enable(true);
      });
